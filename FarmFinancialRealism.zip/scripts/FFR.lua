FarmFinancialRealism = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FarmFinancialRealism:new()

    local self = {}

    setmetatable(
        self,
        {__index = FarmFinancialRealism}
    )

    self.registry = nil

    self.commodityManager = nil
    self.marketEngine = nil
    self.inputMarket = nil
    self.newsSystem = nil

    self.financialManager = nil
    self.creditManager = nil

    self.assetManager = nil

    self.gameIntegrationManager = nil
    self.saveManager = nil

    self.loadedExistingEconomy = false

    self.isInitialized = false
    self.hasPrintedFinalReports = false
    self.isDeleted = false

    --------------------------------------------------
    -- Calendar Monitoring
    --------------------------------------------------

    self.calendarTimer = 0

    self.calendarCheckInterval = 1000

    self.currentCalendarPeriod = 0

    self.currentCalendarYear = 0

    return self

end

--------------------------------------------------
-- Validate Required Classes
--------------------------------------------------

function FarmFinancialRealism:validateClasses()

    local requiredClasses = {

        {
            name = "FFR_Registry",
            class = FFR_Registry
        },

        {
            name = "FFR_CommodityManager",
            class = FFR_CommodityManager
        },

        {
            name = "FFR_MarketEngine",
            class = FFR_MarketEngine
        },

        {
            name = "FFR_InputMarket",
            class = FFR_InputMarket
        },

        {
            name = "FFR_NewsSystem",
            class = FFR_NewsSystem
        },

        {
            name = "FFR_FinancialManager",
            class = FFR_FinancialManager
        },

        {
            name = "FFR_CreditManager",
            class = FFR_CreditManager
        },

        {
            name = "FFR_AssetManager",
            class = FFR_AssetManager
        },

        {
            name = "FFR_GameIntegrationManager",
            class = FFR_GameIntegrationManager
        },

        {
            name = "FFR_SaveManager",
            class = FFR_SaveManager
        }

    }

    local allValid = true

    for _, requiredClass in ipairs(
        requiredClasses
    ) do

        if requiredClass.class == nil then

            Logging.error(
                "FFR: Required class %s was not loaded",
                requiredClass.name
            )

            allValid = false

        elseif requiredClass.class.new == nil then

            Logging.error(
                "FFR: Required class %s has no constructor",
                requiredClass.name
            )

            allValid = false

        end

    end

    return allValid

end

--------------------------------------------------
-- Read FS25 Calendar
--------------------------------------------------

function FarmFinancialRealism:getGameCalendar()

    if g_currentMission == nil then
        return nil, nil
    end

    local environment =
        g_currentMission.environment

    if environment == nil then
        return nil, nil
    end

    local period =

        tonumber(
            environment.currentPeriod
        )

    local year =

        tonumber(
            environment.currentYear
        )

    if period == nil
        or period < 1
        or period > 12
    then

        return nil, nil
    end

    if year == nil
        or year < 1
    then

        return nil, nil
    end

    return period, year

end

--------------------------------------------------
-- Initialize Registry
--------------------------------------------------

function FarmFinancialRealism:initializeRegistry()

    self.registry =
        FFR_Registry:new()

    self.registry:scanFillTypes()

    self.registry:scanFarmland()

    self.registry:scanVehicles()

    self.registry:printSummary()

end

--------------------------------------------------
-- Initialize Economy
--------------------------------------------------

function FarmFinancialRealism:initializeEconomy()

    self.commodityManager =
        FFR_CommodityManager:new()

    self.commodityManager:buildFromRegistry(
        self.registry
    )

    self.marketEngine =
        FFR_MarketEngine:new()

    self.inputMarket =
        FFR_InputMarket:new()

    self.newsSystem =
        FFR_NewsSystem:new()

end

--------------------------------------------------
-- Initialize Financial Systems
--------------------------------------------------

function FarmFinancialRealism:initializeFinancialSystems()

    --------------------------------------------------
    -- One financial profile per farm (FFR_FarmState).
    -- The aliases (self.financialManager, ...) follow
    -- the local player's farm for the dashboard.
    --------------------------------------------------

    self.farms = {}

    self.localFarmId = nil

    for _, farmId in ipairs(FFR_FarmState.getGameFarmIds()) do
        self:getFarmState(farmId)
    end

    self:updateLocalFarm()

    if FFR_AdvisorManager ~= nil then

        self.advisorManager =
            FFR_AdvisorManager:new()

    end

    --------------------------------------------------
    -- Created before the save loads so saved
    -- contracts have somewhere to go.
    --------------------------------------------------

    if FFR_ContractManager ~= nil then

        self.contractManager =
            FFR_ContractManager:new()

    end

end

--------------------------------------------------
-- Farm States
--------------------------------------------------

-- The financial profile of one farm, created on first use.
function FarmFinancialRealism:getFarmState(
    farmId
)

    farmId = tonumber(farmId)

    if farmId == nil
        or farmId <= 0
    then

        return nil

    end

    if self.farms[farmId] == nil then

        self.farms[farmId] =
            FFR_FarmState.new(farmId)

        Logging.info(
            "FFR: Financial profile created for farm %d",
            farmId
        )

    end

    return self.farms[farmId]

end

-- Every real farm (see FFR_FarmState.getGameFarmIds) plus the local farm, sorted.
-- Profiles for anything else (e.g. a helper farm saved by v0.9.9) stay in memory
-- but are not charged, synced or saved.
function FarmFinancialRealism:getFarmStates()

    local ids = FFR_FarmState.getGameFarmIds()

    local localFarmId = self.localFarmId

    local hasLocal = false

    for _, farmId in ipairs(ids) do

        if farmId == localFarmId then
            hasLocal = true
        end

    end

    if localFarmId ~= nil and not hasLocal then

        table.insert(ids, localFarmId)

        table.sort(ids)

    end

    local listText = table.concat(ids, ", ")

    if listText ~= self.trackedFarmsText then

        self.trackedFarmsText = listText

        Logging.info(
            "FFR: Tracking farm finances for farm(s) %s",
            listText
        )

    end

    local states = {}

    for _, farmId in ipairs(ids) do

        local state = self:getFarmState(farmId)

        if state ~= nil then
            table.insert(states, state)
        end

    end

    return states

end

-- The local player's farm, or the default farm when there is none
-- (dedicated server, or before the player is placed).
function FarmFinancialRealism:getLocalFarmId()

    local farmId = nil

    if self.gameIntegrationManager ~= nil then

        farmId =
            self.gameIntegrationManager:getActiveFarmId()

    elseif g_currentMission ~= nil
        and g_currentMission.getFarmId ~= nil
    then

        farmId =
            tonumber(g_currentMission:getFarmId())

    end

    if farmId == nil
        or farmId <= 0
    then

        farmId =
            self.localFarmId
            or FFR_FarmState.getDefaultFarmId()

    end

    return farmId

end

-- Points the dashboard aliases at the local player's farm.
function FarmFinancialRealism:updateLocalFarm()

    local farmId =
        self:getLocalFarmId()

    if farmId == self.localFarmId
        and self.financialManager ~= nil
    then

        return

    end

    local state =
        self:getFarmState(farmId)

    if state == nil then
        return
    end

    for _, name in ipairs(FFR_FarmState.ALIASES) do
        self[name] = state[name]
    end

    if self.localFarmId ~= nil then

        Logging.info(
            "FFR: Dashboard now shows farm %d",
            farmId
        )

    end

    self.localFarmId = farmId

end

--------------------------------------------------
-- Initialize Save System
--------------------------------------------------

function FarmFinancialRealism:initializeSaveSystem()

    self.saveManager =
        FFR_SaveManager:new()

    self.loadedExistingEconomy =

        self.saveManager:load(
            self
        )

    if self.loadedExistingEconomy then

        Logging.info(
            "FFR: Existing economy state restored"
        )

    else

        Logging.info(
            "FFR: No existing economy state found"
        )

        Logging.info(
            "FFR: Creating a new economy"
        )

    end

end

--------------------------------------------------
-- Initialize Calendar State
--------------------------------------------------

function FarmFinancialRealism:initializeCalendar()

    local period,
        year =

        self:getGameCalendar()

    if period == nil
        or year == nil
    then

        Logging.warning(
            "FFR Calendar: FS25 calendar is not ready"
        )

        return false

    end

    self.currentCalendarPeriod =
        period

    self.currentCalendarYear =
        year

    if self.loadedExistingEconomy then

        self.inputMarket:ensureCalendarExpiry(
            period,
            year
        )

    else

        self.inputMarket:createRandomEvent(
            period,
            year
        )

    end

    Logging.info(
        "FFR Calendar: Current period %d, year %d",
        period,
        year
    )

    Logging.info(
        "FFR Calendar: %s",
        self.inputMarket:getExpiryText()
    )

    return true

end

--------------------------------------------------
-- Generate New Commodity Economy
--------------------------------------------------

function FarmFinancialRealism:generateNewCommodityEconomy()

    if self.marketEngine.activeEvent == nil then

        --------------------------------------------------
        -- Use the real calendar so event start, expiry
        -- and cooldown serials line up with game time.
        --------------------------------------------------

        local period,
            year =

            self:getGameCalendar()

        self.marketEngine:createRandomEvent(
            period,
            year
        )

        self.marketEngine:applyToCommodityManager(
            self.commodityManager
        )

        if self.newsSystem ~= nil then

            self.newsSystem:createMarketStory(
                self.marketEngine.activeEvent
            )

        end

    end

end

--------------------------------------------------
-- Validate Loaded Commodity Economy
--------------------------------------------------

function FarmFinancialRealism:validateLoadedCommodityEconomy()

    if self.marketEngine.activeEvent == nil then

        Logging.warning(
            "FFR: Saved market event unavailable; generating replacement"
        )

        local period,
            year =

            self:getGameCalendar()

        self.marketEngine:createRandomEvent(
            period,
            year
        )

        self.marketEngine:applyToCommodityManager(
            self.commodityManager
        )

    end

end

--------------------------------------------------
-- Generate News
--------------------------------------------------

function FarmFinancialRealism:generateNews()

    if self.newsSystem == nil
        or self.inputMarket == nil
    then

        return
    end

    if self.inputMarket.activeEvent == nil then
        return
    end

    self.newsSystem:createInputMarketStory(
        self.inputMarket.activeEvent
    )

end

--------------------------------------------------
-- Print Economy Reports
--------------------------------------------------

function FarmFinancialRealism:printEconomyReports()

    self.commodityManager:printSummary()

    self.inputMarket:printMarket()

    self.newsSystem:printNews()

    self.saveManager:printReport()

end

--------------------------------------------------
-- Initialize Game Integration
--------------------------------------------------

function FarmFinancialRealism:initializeGameIntegration()

    self.gameIntegrationManager =
        FFR_GameIntegrationManager:new()

    self.gameIntegrationManager:beginDeferredSync()

end

--------------------------------------------------
-- Main Load
--------------------------------------------------

function FarmFinancialRealism:load()

    if self.isInitialized then
        return
    end

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR STARTING"
    )

    Logging.info(
        "Farm Financial Realism v0.9.62"
    )

    Logging.info(
        "========================================"
    )

    if not self:validateClasses() then

        Logging.error(
            "FFR: Initialization stopped because required classes are missing"
        )

        return

    end

    --------------------------------------------------
    -- Stations from a previously loaded savegame must
    -- not be reused.
    --------------------------------------------------

    if g_FFRStationPriceManager ~= nil
        and g_FFRStationPriceManager.clearCache ~= nil
    then

        g_FFRStationPriceManager:clearCache()

    end

    self:initializeRegistry()

    self:initializeEconomy()

    self:initializeFinancialSystems()

    self:initializeSaveSystem()

    if self.loadedExistingEconomy then

        self:validateLoadedCommodityEconomy()

    else

        self:generateNewCommodityEconomy()

    end

    self:initializeCalendar()

    self:generateNews()

    self:printEconomyReports()

    self:initializeGameIntegration()

    self.isInitialized = true

    addModEventListener(
        self
    )

    Logging.info(
        "FFR: Internal systems initialized"
    )

    Logging.info(
        "FFR: Waiting for FS25 farm data"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR INITIALIZATION COMPLETE"
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Process Calendar Changes
--------------------------------------------------

function FarmFinancialRealism:updateCalendar(
    dt
)

    --------------------------------------------------
    -- Supplier programs change on the server only;
    -- clients receive them in the network sync.
    --------------------------------------------------

    if FFR_Network ~= nil
        and FFR_Network.isClientOnly()
    then

        return

    end

    self.calendarTimer =

        self.calendarTimer + dt

    if self.calendarTimer <
        self.calendarCheckInterval
    then

        return

    end

    self.calendarTimer = 0

    local period,
        year =

        self:getGameCalendar()

    if period == nil
        or year == nil
    then

        return

    end

    if self.currentCalendarPeriod == 0
        or self.currentCalendarYear == 0
    then

        self.currentCalendarPeriod =
            period

        self.currentCalendarYear =
            year

        self.inputMarket:ensureCalendarExpiry(
            period,
            year
        )

        return

    end

    if period ==
        self.currentCalendarPeriod
        and year ==
        self.currentCalendarYear
    then

        return

    end

    Logging.info(
        "FFR Calendar Advanced: period %d year %d",
        period,
        year
    )

    self.currentCalendarPeriod =
        period

    self.currentCalendarYear =
        year

    local eventChanged =

        self.inputMarket:updateCalendar(
            period,
            year
        )

    if eventChanged then

        self:generateNews()

        self.inputMarket:printActiveEvent()

        self.inputMarket:printMarket()

        --------------------------------------------------
        -- Written with the next native save so the FFR
        -- file never runs ahead of the savegame.
        --------------------------------------------------

        if self.saveManager ~= nil then

            self.saveManager:requestSave(
                self
            )

        end

    end

end

--------------------------------------------------
-- Runtime Update
--------------------------------------------------

function FarmFinancialRealism:update(
    dt
)

    if not self.isInitialized
        or self.isDeleted
    then

        return
    end

    self:updateCalendar(
        dt
    )

    --------------------------------------------------
    -- The player can join another farm mid-game.
    --------------------------------------------------

    self:updateLocalFarm()

    if self.gameIntegrationManager == nil then
        return
    end

    if self.gameIntegrationManager:isFullySynced() then

        if not self.hasPrintedFinalReports then

            self:finishGameDataInitialization()

        end

        return

    end

    self.gameIntegrationManager:updateDeferredSync(
        dt,
        self.assetManager,
        nil,
        self.financialManager
    )

    if self.gameIntegrationManager:isSyncFinished()
        and not self.hasPrintedFinalReports
    then

        self:finishGameDataInitialization()

    end

end

--------------------------------------------------
-- Finish Game Data Initialization
--------------------------------------------------

function FarmFinancialRealism:finishGameDataInitialization()

    if self.hasPrintedFinalReports then
        return
    end

    self.assetManager:updateTotals()

    self.assetManager:updateFinancialManager(
        self.financialManager
    )

    self.financialManager:update()

    self.creditManager:update(
        self.financialManager
    )

    self.assetManager:printAssetReport()

    self.financialManager:printFinancialStatement()

    self.creditManager:printCreditReport()

    self.gameIntegrationManager:printReport()

    self.saveManager:printReport()

    self.hasPrintedFinalReports = true

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR GAME DATA INITIALIZATION COMPLETE"
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Save Economy
--------------------------------------------------

function FarmFinancialRealism:saveEconomy(
    savegameDirectory
)

    if not self.isInitialized
        or self.saveManager == nil
    then

        return false

    end

    if savegameDirectory ~= nil
        and savegameDirectory ~= ""
    then

        self.saveManager.savegameDirectory =
            savegameDirectory

        self.saveManager.filePath = nil

    end

    for _, state in ipairs(self:getFarmStates()) do

        state.assetManager:updateTotals()

        state.assetManager:updateFinancialManager(
            state.financialManager
        )

        state.financialManager:update()

    end

    return self.saveManager:save(
        self
    )

end

--------------------------------------------------
-- Required Listener Methods
--------------------------------------------------

function FarmFinancialRealism:loadMap(
    mapName
)

end

function FarmFinancialRealism:deleteMap()

    self.isDeleted = true

    self.isInitialized = false

    self.hasPrintedFinalReports = false

    if g_FFR == self then

        g_FFR = nil

    end

end

function FarmFinancialRealism:draw()

end

function FarmFinancialRealism:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)

end

function FarmFinancialRealism:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)

end

--------------------------------------------------
-- Mission Callback
--------------------------------------------------

local function FFR_LoadMission()

    if g_currentMission == nil
        or g_FFR ~= nil
    then

        return

    end

    Logging.info(
        "FFR: Mission Loaded"
    )

    g_FFR =
        FarmFinancialRealism:new()

    g_FFR:load()

end

--------------------------------------------------
-- Save Callback
--------------------------------------------------

local function FFR_SaveToXMLFile(
    careerMissionInfo
)

    if g_FFR == nil
        or g_FFR.saveManager == nil
    then

        return

    end

    local savegameDirectory = nil

    if careerMissionInfo ~= nil then

        savegameDirectory =
            careerMissionInfo.savegameDirectory

    end

    Logging.info(
        "FFR: Native save detected"
    )

    g_FFR:saveEconomy(
        savegameDirectory
    )

    -- Households and land titles are inside FFR_economy.xml (format 3);
    -- there are no side files any more.

end

--------------------------------------------------
-- Register Hooks
--------------------------------------------------

Mission00.loadMission00Finished =

    Utils.appendedFunction(
        Mission00.loadMission00Finished,
        FFR_LoadMission
    )

FSCareerMissionInfo.saveToXMLFile =

    Utils.appendedFunction(
        FSCareerMissionInfo.saveToXMLFile,
        FFR_SaveToXMLFile
    )