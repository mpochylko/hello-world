FFR_AdvisorManager = {}

--------------------------------------------------
-- Financial advisor
--
-- review(state) looks at one farm's profile and
-- returns everything the Advisor page shows:
--
-- * health: a 0-100 score from five factors of
--   20 points each (cash cover, debt load, profit
--   trend, credit, bank standing) and a grade A-F;
-- * runway: cash, the average monthly result of the
--   last closed months, how long the cash lasts if
--   that continues, and the next big bills;
-- * advice: ranked lines with real numbers (loan
--   savings, overdraft, selling opportunities from
--   the price history, household share, events).
--
-- It only reads state, so it runs the same on the
-- server and on clients (which read synced state).
--------------------------------------------------

FFR_AdvisorManager.RUNWAY_MONTHS = 3
FFR_AdvisorManager.SELL_SIGNAL = 0.08
FFR_AdvisorManager.MIN_HISTORY_MONTHS = 3
FFR_AdvisorManager.MAX_ADVICE = 8

FFR_AdvisorManager.GRADES = {
    -- Verdicts: ffr_advisor_grade_<letter>.
    {85, "A"}, {70, "B"}, {55, "C"}, {40, "D"}, {0, "F"}
}

function FFR_AdvisorManager:new()
    local self = {}
    setmetatable(self, {__index = FFR_AdvisorManager})
    self.lastReview = nil
    return self
end

local function number(value)
    return tonumber(value) or 0
end

function FFR_AdvisorManager:formatMoney(value)
    if g_FFRDashboardDataManager ~= nil and g_FFRDashboardDataManager.formatMoney ~= nil then
        return g_FFRDashboardDataManager:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

function FFR_AdvisorManager:formatName(name)
    return FFR_L10n.fillTypeTitle(name)
end

--------------------------------------------------
-- Monthly result
--------------------------------------------------

-- Average net of the last (up to) n closed monthly statements, and how many there were.
function FFR_AdvisorManager:getAverageNet(state, n)
    local statements = state.statements or {}
    local count, sum = 0, 0
    for i = #statements, math.max(1, #statements - n + 1), -1 do
        sum = sum + number(statements[i].net)
        count = count + 1
    end
    if count == 0 then return nil, 0 end
    return sum / count, count
end

-- Months until the March tax bill (period 1). The bill for a year is charged on
-- the first month of the next, so in March itself the next one is 12 months away.
function FFR_AdvisorManager:getMonthsToTax()
    local period = g_currentMission ~= nil and g_currentMission.environment ~= nil
        and tonumber(g_currentMission.environment.currentPeriod) or nil
    if period == nil then return nil end
    return 13 - period
end

function FFR_AdvisorManager:getRunway(state)
    local f = state.financialManager
    local cash = number(f.cashOnHand)
    local average, months = self:getAverageNet(state, FFR_AdvisorManager.RUNWAY_MONTHS)
    local runway = {cash = cash, average = average, months = months}
    if average == nil then
        -- No closed month yet: FFR's own monthly charges are the only known cost.
        local overhead = number(state.lastMonthlyTotal)
        runway.average = overhead > 0 and -overhead or nil
        runway.estimated = true
    end
    if cash < 0 then
        runway.monthsLeft = 0
    elseif runway.average ~= nil and runway.average < 0 then
        runway.monthsLeft = cash / -runway.average
    end
    -- Next big bills.
    local t = state.taxManager
    t:calculateIncomeTax(math.max(0, number(f.annualProfit)))
    t:updatePropertyTax(f)
    runway.taxEstimate = number(t.incomeTaxDue) + number(t.propertyTaxDue)
    runway.monthsToTax = self:getMonthsToTax()
    runway.principal = number(f.monthlyLandPayment)
    runway.interest = state.bankingManager:calculateMonthlyInterest(f, state.creditManager) or 0
    runway.household = number(state.familyManager.totalMonthlyCost)
    return runway
end

--------------------------------------------------
-- Health score
--------------------------------------------------

function FFR_AdvisorManager:scoreCash(runway)
    if runway.cash < 0 then return 0, FFR_L10n.t("ffr_advisor_f_overdrawn") end
    if runway.monthsLeft == nil then return 20, FFR_L10n.t("ffr_advisor_cash_growing") end
    local m = runway.monthsLeft
    local points = m >= 12 and 20 or m >= 6 and 15 or m >= 3 and 10 or m >= 1 and 5 or 0
    return points, FFR_L10n.t("ffr_advisor_f_cash_months", m)
end

function FFR_AdvisorManager:scoreDebt(f)
    local ratio = number(f.debtRatio)
    local points = ratio <= 0.20 and 20 or ratio <= 0.40 and 16 or ratio <= 0.60 and 10 or ratio <= 0.80 and 5 or 0
    return points, FFR_L10n.t("ffr_advisor_f_assets", math.floor(ratio * 100 + 0.5))
end

-- Total net of the closed statements from the newest back: skip the newest
-- `skip`, then up to n months. Returns total and how many months it covers.
function FFR_AdvisorManager:getNetTotal(state, n, skip)
    local statements = state.statements or {}
    local last = #statements - (skip or 0)
    local count, sum = 0, 0
    for i = last, math.max(1, last - n + 1), -1 do
        sum = sum + number(statements[i].net)
        count = count + 1
    end
    return sum, count
end

-- Farms earn in a few months (harvest, grain sales) and spend all year, so the
-- trend is the result over the last 12 closed months, compared with the 12 before.
function FFR_AdvisorManager:scoreProfit(state)
    local year, count = self:getNetTotal(state, 12, 0)
    if count == 0 then
        local profit = number(state.financialManager.annualProfit)
        return profit > 0 and 14 or 10, FFR_L10n.t(profit > 0 and "ffr_advisor_f_profitable" or "ffr_advisor_f_no_month")
    end
    local before, beforeCount = self:getNetTotal(state, 12, 12)
    local improving = beforeCount == 0 or year >= before
    local detail = FFR_L10n.t("ffr_advisor_f_year_result", self:formatMoney(year), count)
    if year > 0 then return improving and 20 or 16, detail end
    return improving and beforeCount > 0 and 10 or 4, detail
end

function FFR_AdvisorManager:scoreCredit(credit)
    local score = number(credit.creditScore)
    local points = math.max(0, math.min(20, math.floor((score - 500) / 300 * 20 + 0.5)))
    return points, string.format("%d %s", score, FFR_CreditManager.getRatingName(credit.creditRating))
end

function FFR_AdvisorManager:scoreStanding(credit)
    local stage = number(credit.insolvencyStage)
    local points = ({[0] = 20, [1] = 12, [2] = 6, [3] = 2, [4] = 0})[stage] or 0
    local name = FFR_InsolvencyManager ~= nil and FFR_InsolvencyManager.getStageName(credit) or FFR_L10n.t("ffr_insolvency_stage_0")
    return points, name
end

function FFR_AdvisorManager:getHealth(state, runway)
    local f, credit = state.financialManager, state.creditManager
    local factors = {}
    local function add(label, points, detail)
        table.insert(factors, {label = label, points = points, detail = detail})
    end
    add(FFR_L10n.t("ffr_advisor_factor_cash"), self:scoreCash(runway))
    add(FFR_L10n.t("ffr_advisor_factor_debt"), self:scoreDebt(f))
    add(FFR_L10n.t("ffr_advisor_factor_profit"), self:scoreProfit(state))
    add(FFR_L10n.t("ffr_advisor_factor_credit"), self:scoreCredit(credit))
    add(FFR_L10n.t("ffr_advisor_factor_standing"), self:scoreStanding(credit))
    local score = 0
    for _, factor in ipairs(factors) do score = score + factor.points end
    local grade, verdict = "F", ""
    for _, g in ipairs(FFR_AdvisorManager.GRADES) do
        if score >= g[1] then grade, verdict = g[2], FFR_L10n.t("ffr_advisor_grade_" .. string.lower(g[2])); break end
    end
    return {score = score, grade = grade, verdict = verdict, factors = factors}
end

--------------------------------------------------
-- Stored crops and selling advice
--------------------------------------------------

-- Stored commodities: {fillTypeIndex, name, liters}. Server: the inventory sync;
-- client: the list from the snapshot.
function FFR_AdvisorManager:getStoredCrops(state)
    if state.assetManager.isRemote then return state.storedCrops or {} end
    local list = {}
    for _, item in pairs(state.assetManager.inventoryAssets or {}) do
        if number(item.liters) > 0 and number(item.marketValue) > 0 then
            table.insert(list, {fillTypeIndex = item.fillTypeIndex, name = item.name, liters = number(item.liters)})
        end
    end
    table.sort(list, function(a, b) return a.liters > b.liters end)
    return list
end

function FFR_AdvisorManager:findCommodity(fillTypeIndex)
    if g_FFR == nil or g_FFR.commodityManager == nil then return nil end
    for _, commodity in pairs(g_FFR.commodityManager.commodities or {}) do
        if commodity.index == fillTypeIndex then return commodity end
    end
    return nil
end

-- Compares each stored crop's best live price with its closed-month average.
function FFR_AdvisorManager:getSellingAdvice(state, advice)
    if g_FFRPriceHistory == nil or g_FFRStationPriceManager == nil then return end
    for _, crop in ipairs(self:getStoredCrops(state)) do
        local commodity = self:findCommodity(crop.fillTypeIndex)
        local best = commodity ~= nil and g_FFRStationPriceManager:getBestPrice(commodity.index) or nil
        if best ~= nil and crop.liters >= 1000 then
            local sum, closed = 0, 0
            for _, p in ipairs(g_FFRPriceHistory:getSeries(commodity)) do
                if not p.partial then sum, closed = sum + p.avg, closed + 1 end
            end
            if closed >= FFR_AdvisorManager.MIN_HISTORY_MONTHS and sum > 0 then
                local average = sum / closed
                local change = best.ffrPrice / average - 1
                local name = self:formatName(commodity.name)
                local value = crop.liters / 1000 * best.ffrPrice
                if change >= FFR_AdvisorManager.SELL_SIGNAL then
                    table.insert(advice, {priority = 60 + change * 100, text = FFR_L10n.t(
                        "ffr_advisor_sell",
                        name, math.floor(change * 100 + 0.5), closed, tostring(best.name),
                        FFR_UnitManager.formatPrice(best.ffrPrice, commodity.name),
                        FFR_UnitManager.formatAmount(crop.liters, commodity.name), self:formatMoney(value))})
                elseif change <= -FFR_AdvisorManager.SELL_SIGNAL then
                    table.insert(advice, {priority = 40 - change * 50, text = FFR_L10n.t(
                        "ffr_advisor_hold",
                        name, math.floor(-change * 100 + 0.5), closed, FFR_UnitManager.formatAmount(crop.liters, commodity.name))})
                end
            end
        end
    end
end

function FFR_AdvisorManager:formatNumber(value)
    return FFR_L10n.formatNumber(value)
end

--------------------------------------------------
-- Actions with numbers
--------------------------------------------------

function FFR_AdvisorManager:getActions(state, runway, advice)
    local f, credit, bank = state.financialManager, state.creditManager, state.bankingManager
    local cash = runway.cash
    local burn = (runway.average ~= nil and runway.average < 0) and -runway.average or 0
    local frozen = FFR_InsolvencyManager ~= nil and FFR_InsolvencyManager.isFrozen(credit)

    if cash < 0 then
        local outlook = FFR_InsolvencyManager ~= nil and FFR_InsolvencyManager.getOutlook(credit) or ""
        table.insert(advice, {priority = 100, text = FFR_L10n.t(
            "ffr_advisor_urgent",
            self:formatMoney(-cash), outlook)})
    end

    -- Spare cash beyond 3 months of costs could pay down the operating line.
    local loan = number(f.operatingLoan)
    local spare = cash - burn * FFR_AdvisorManager.RUNWAY_MONTHS
    if loan > 0 and spare >= 10000 then
        local repay = math.min(loan, math.floor(spare / 10000) * 10000)
        local saving = repay * bank:getOperatingRate(credit) / 12
        table.insert(advice, {priority = 55, text = FFR_L10n.t(
            "ffr_advisor_repay",
            self:formatMoney(repay), self:formatMoney(saving))})
    end

    -- Short runway: a bridge on the operating line, if the bank still lends.
    if cash >= 0 and runway.monthsLeft ~= nil and runway.monthsLeft < FFR_AdvisorManager.RUNWAY_MONTHS then
        if frozen then
            table.insert(advice, {priority = 80, text = FFR_L10n.t(
                "ffr_advisor_frozen", runway.monthsLeft)})
        else
            local available = bank:getOperatingAvailable(f, credit)
            local need = math.min(available, math.ceil((burn * FFR_AdvisorManager.RUNWAY_MONTHS - cash) / 10000) * 10000)
            if need > 0 then
                table.insert(advice, {priority = 75, text = FFR_L10n.t(
                    "ffr_advisor_bridge",
                    runway.monthsLeft, self:formatMoney(need), self:formatMoney(need * bank:getOperatingRate(credit) / 12))})
            end
        end
    end

    -- Tax bill coming with little cash to cover it.
    if runway.taxEstimate > 0 and runway.monthsToTax ~= nil and runway.monthsToTax <= 3 and cash < runway.taxEstimate then
        table.insert(advice, {priority = 70, text = FFR_L10n.t(
            "ffr_advisor_tax",
            self:formatMoney(runway.taxEstimate), FFR_L10n.months(runway.monthsToTax), self:formatMoney(cash))})
    end

    -- Household share of revenue.
    local revenue = 0
    local statements = state.statements or {}
    for i = #statements, math.max(1, #statements - 2), -1 do revenue = revenue + number(statements[i].revenue) end
    local months = math.min(3, #statements)
    if months > 0 and runway.household > 0 then
        local share = runway.household / math.max(1, revenue / months)
        if share > 10 then
            table.insert(advice, {priority = 35, text = FFR_L10n.t(
                "ffr_advisor_household_over", self:formatMoney(runway.household))})
        elseif share >= 0.30 then
            table.insert(advice, {priority = 35, text = FFR_L10n.t(
                "ffr_advisor_household",
                self:formatMoney(runway.household), math.floor(share * 100 + 0.5))})
        end
    end

    -- Credit worth protecting.
    if number(credit.latePayments) > 0 and not frozen and cash >= 0 then
        -- How marks leave the file: FFR_CreditManager (Marks).
        table.insert(advice, {priority = 20, text = FFR_L10n.t(
            credit.latePayments == 1 and "ffr_advisor_late_one" or "ffr_advisor_late_many",
            credit.latePayments, credit.latePayments * 15, FFR_CreditManager.MARK_MONTHS,
            FFR_CreditManager.CLEAN_MONTHS, math.floor(number(credit.cleanMonths)), FFR_CreditManager.CLEAN_MONTHS)})
    end
end

-- Weather damage and crop insurance: claims to file, uninsured losses, sign-up.
function FFR_AdvisorManager:getInsuranceAdvice(state, advice)
    local ins = FFR_CropInsuranceManager
    if ins == nil then return end
    local policy = ins.getPolicy(state)
    local claims = ins.getClaimByParcel(state)
    local uninsuredLoss = 0
    for _, row in ipairs(ins.getDamageRows(state)) do
        local total = number(row.total)
        local loss = number(row.expectedValue) * total
        -- Coverage of this planting (its bill, or its crop year's policy; v0.9.50).
        local coverage = ins.getRecordCoverage(state, row)
        if coverage ~= nil and total > 1 - coverage and not row.claimed and claims[row.farmlandId] == nil then
            table.insert(advice, {priority = 85, text = FFR_L10n.t(
                "ffr_advisor_claim",
                row.farmlandId, self:formatName(row.fruitName), math.floor(total * 100 + 0.5),
                self:formatMoney(number(row.expectedValue) * (total - (1 - coverage))))})
        elseif coverage == nil and total > 0 then
            uninsuredLoss = uninsuredLoss + loss
        end
    end
    if uninsuredLoss >= 1000 then
        table.insert(advice, {priority = 45, text = FFR_L10n.t(
            "ffr_advisor_uninsured", self:formatMoney(uninsuredLoss))})
    end
    -- Livestock: an uninsured herd at raised disease risk.
    local li = FFR_LivestockInsuranceManager
    if li ~= nil and FFR_HerdRiskManager ~= nil and li.getPolicy(state) == nil then
        local rows = (FFR_Network ~= nil and FFR_Network.isClientOnly()) and (state.herdRows or {}) or FFR_HerdRiskManager.getBarnRows(state.farmId)
        local value, risky = 0, nil
        for _, row in ipairs(rows) do
            value = value + number(row.value)
            if number(row.risk) > 0.035 and (risky == nil or number(row.risk) > number(risky.risk)) then risky = row end
        end
        if value > 0 then
            local scale = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("insurance")) or 1) or 1
            local text = FFR_L10n.t("ffr_advisor_herd",
                self:formatMoney(value), self:formatMoney(value * li.PREMIUM_RATE * scale))
            if risky ~= nil then
                text = text .. " " .. FFR_L10n.t("ffr_advisor_herd_risk", tostring(risky.name), number(risky.risk) * 100)
            end
            table.insert(advice, {priority = risky ~= nil and 48 or 30, text = text})
        end
    end
    -- Sign-up open and nothing on that crop year's policy yet: what insuring all crop land would cost.
    if ins.isSignupOpen() and (policy == nil or #(policy.crops or {}) == 0) and not (policy ~= nil and policy.allCrops) then
        local acres = ins.getInsurableAcres(state.farmId)
        if acres > 0 then
            table.insert(advice, {priority = 50, text = FFR_L10n.t(
                "ffr_advisor_signup",
                FFR_L10n.formatArea(acres / FFR_L10n.ACRES_PER_HA, 0), self:formatMoney(acres * ins.getRate(0.75)))})
        end
    end
end

-- Context from the market and supplier events.
function FFR_AdvisorManager:getMarketNotes(advice)
    local engine = g_FFR ~= nil and g_FFR.marketEngine or nil
    local event = engine ~= nil and engine.activeEvent or nil
    if event ~= nil and event.id ~= "STABLE_MARKETS" and event.name ~= nil then
        table.insert(advice, {priority = 15, text = FFR_L10n.t(
            (number(event.direction) > 0) and "ffr_advisor_market_up" or "ffr_advisor_market_down",
            FFR_L10n.eventName(event.name), FFR_L10n.named("ffr_event_severity_", event.severity),
            FFR_L10n.named("ffr_event_phase_", event.phase))})
    end
    local input = g_FFR ~= nil and g_FFR.inputMarket or nil
    local event = input ~= nil and input.activeEvent or nil
    if event ~= nil and event.name ~= nil and not input:isRegular(event) then
        local title = input:getEventTitle(event)
        -- A shortage raises prices above normal; a deal lowers them.
        local shortage = false
        for _, data in pairs(input.inputs or {}) do
            if number(data.modifier) > 1.0001 then shortage = true end
        end
        if shortage then
            table.insert(advice, {priority = 30, text = FFR_L10n.t(
                "ffr_advisor_supplier_shortage", title)})
        else
            table.insert(advice, {priority = 25, text = FFR_L10n.t(
                "ffr_advisor_supplier_deal", title)})
        end
    end
end

--------------------------------------------------
-- Full review
--------------------------------------------------

function FFR_AdvisorManager:review(state)
    if state == nil then return nil end
    state.financialManager:update()
    local runway = self:getRunway(state)
    local health = self:getHealth(state, runway)
    local advice = {}
    self:getActions(state, runway, advice)
    self:getSellingAdvice(state, advice)
    pcall(self.getInsuranceAdvice, self, state, advice)
    self:getMarketNotes(advice)
    table.sort(advice, function(a, b) return a.priority > b.priority end)
    local lines = {}
    for i = 1, math.min(#advice, FFR_AdvisorManager.MAX_ADVICE) do lines[i] = advice[i].text end
    self.lastReview = {health = health, runway = runway, advice = lines}
    return self.lastReview
end
