FFR_AnimalPriceManager = {}

--------------------------------------------------
-- Animal prices (FFR owns them, like inputs)
--
-- Each FS25 animal subtype (Angus, Holstein, ...)
-- has buy and sell price curves by age. FFR reads
-- them once per session as the baseline and writes
-- baseline x the market event modifier for the
-- animal's category back into the curves, so the
-- animal dealer buys and sells at FFR prices:
--
--   COW, WATERBUFFALO -> cattle, PIG -> pig,
--   SHEEP, GOAT -> sheep, CHICKEN -> poultry
--   (horses keep FS25 prices).
--
-- Prices are rewritten when the market changes, on
-- the server and every client, and put back when
-- the map unloads. The first time, the structure FS25
-- uses is written to log.txt (diagnostic), so a
-- version where it differs can be fixed.
--------------------------------------------------

FFR_AnimalPriceManager.TYPE_CATEGORIES = {
    COW = "cattle", WATERBUFFALO = "cattle", BUFFALO = "cattle",
    PIG = "pig",
    SHEEP = "sheep", GOAT = "sheep",
    CHICKEN = "poultry"
}


-- subTypeIndex -> {buyPrice = {{v1, ...}, ...}, sellPrice = {...}} baseline keyframe values
FFR_AnimalPriceManager.baselines = {}
FFR_AnimalPriceManager.appliedSignature = nil
FFR_AnimalPriceManager.updateTimer = 0
FFR_AnimalPriceManager.hasLoggedDiagnostics = false
FFR_AnimalPriceManager.loggedPrices = {}

--------------------------------------------------
-- Subtypes
--------------------------------------------------

function FFR_AnimalPriceManager.getAnimalSystem()
    return g_currentMission ~= nil and g_currentMission.animalSystem or nil
end

function FFR_AnimalPriceManager.getSubTypes()
    local system = FFR_AnimalPriceManager.getAnimalSystem()
    local list = {}
    if system == nil then return list end
    if system.getSubTypeByIndex ~= nil then
        for index = 1, 250 do
            local ok, subType = pcall(system.getSubTypeByIndex, system, index)
            if not ok or subType == nil then break end
            table.insert(list, {index = index, subType = subType})
        end
    end
    if #list == 0 and type(system.subTypes) == "table" then
        for index, subType in ipairs(system.subTypes) do table.insert(list, {index = index, subType = subType}) end
    end
    return list
end

function FFR_AnimalPriceManager.getTypeName(subType)
    local system = FFR_AnimalPriceManager.getAnimalSystem()
    if system ~= nil and system.getTypeByIndex ~= nil and subType.typeIndex ~= nil then
        local ok, animalType = pcall(system.getTypeByIndex, system, subType.typeIndex)
        if ok and animalType ~= nil and animalType.name ~= nil then return string.upper(animalType.name) end
    end
    local name = string.upper(tostring(subType.name or ""))
    return name:match("^([^_]+)") or name
end

function FFR_AnimalPriceManager.getCategory(subType)
    return FFR_AnimalPriceManager.TYPE_CATEGORIES[FFR_AnimalPriceManager.getTypeName(subType)]
end

-- Breed name players see, e.g. "Angus".
function FFR_AnimalPriceManager.getTitle(subType)
    if g_fillTypeManager ~= nil and subType.fillTypeIndex ~= nil then
        local fillType = g_fillTypeManager:getFillTypeByIndex(subType.fillTypeIndex)
        if fillType ~= nil and type(fillType.title) == "string" and fillType.title ~= "" then return fillType.title end
    end
    if type(subType.title) == "string" and subType.title ~= "" then return subType.title end
    return FFR_L10n.fillTypeTitle(subType.name or "animal")
end

-- The keyframes of a price curve, or nil if FS25 stores it differently.
function FFR_AnimalPriceManager.getKeyframes(curve)
    if type(curve) ~= "table" then return nil end
    if type(curve.keyframes) == "table" then return curve.keyframes end
    return nil
end

--------------------------------------------------
-- Writing prices
--------------------------------------------------

function FFR_AnimalPriceManager.applyCurve(index, field, curve, modifier)
    local keyframes = FFR_AnimalPriceManager.getKeyframes(curve)
    if keyframes == nil then return false end
    local store = FFR_AnimalPriceManager.baselines[index] or {}
    FFR_AnimalPriceManager.baselines[index] = store
    if store[field] == nil then
        store[field] = {}
        for i, keyframe in ipairs(keyframes) do
            local values = {}
            for j, value in ipairs(keyframe) do
                if type(value) == "number" then values[j] = value end
            end
            store[field][i] = values
        end
    end
    for i, keyframe in ipairs(keyframes) do
        for j, base in pairs(store[field][i] or {}) do keyframe[j] = base * modifier end
    end
    return true
end

function FFR_AnimalPriceManager.applyPrices()
    local engine = g_FFR ~= nil and g_FFR.marketEngine or nil
    if engine == nil then return end
    for _, entry in ipairs(FFR_AnimalPriceManager.getSubTypes()) do
        local category = FFR_AnimalPriceManager.getCategory(entry.subType)
        if category ~= nil then
            local modifier = tonumber(engine:getModifier(category)) or 1
            local applied = FFR_AnimalPriceManager.applyCurve(entry.index, "sellPrice", entry.subType.sellPrice, modifier)
            FFR_AnimalPriceManager.applyCurve(entry.index, "buyPrice", entry.subType.buyPrice, modifier)
            if applied then FFR_AnimalPriceManager.logPrice(entry, category, modifier) end
        end
    end
end

function FFR_AnimalPriceManager.restoreAll()
    for _, entry in ipairs(FFR_AnimalPriceManager.getSubTypes()) do
        local store = FFR_AnimalPriceManager.baselines[entry.index]
        if store ~= nil then
            for _, field in ipairs({"sellPrice", "buyPrice"}) do
                local keyframes = FFR_AnimalPriceManager.getKeyframes(entry.subType[field])
                for i, keyframe in ipairs(keyframes or {}) do
                    for j, base in pairs((store[field] or {})[i] or {}) do keyframe[j] = base end
                end
            end
        end
    end
    FFR_AnimalPriceManager.baselines = {}
end

function FFR_AnimalPriceManager.logPrice(entry, category, modifier)
    local key = tostring(entry.index) .. "|" .. string.format("%.4f", modifier)
    if FFR_AnimalPriceManager.loggedPrices[key] or math.abs(modifier - 1) < 0.0001 then return end
    FFR_AnimalPriceManager.loggedPrices[key] = true
    Logging.info("FFR Animal Prices: %s now %s / head at best (normal %s, %+d%%)",
        FFR_AnimalPriceManager.getTitle(entry.subType),
        FFR_AnimalPriceManager.formatMoney(FFR_AnimalPriceManager.getHeadPrice(entry.index)),
        FFR_AnimalPriceManager.formatMoney(FFR_AnimalPriceManager.getNormalHeadPrice(entry.index)),
        math.floor((modifier - 1) * 100 + (modifier >= 1 and 0.5 or -0.5)))
end

function FFR_AnimalPriceManager.formatMoney(value)
    if g_FFRDashboardDataManager ~= nil and g_FFRDashboardDataManager.formatMoney ~= nil then
        return g_FFRDashboardDataManager:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

--------------------------------------------------
-- Prices for the Markets page
--------------------------------------------------

-- Highest sell value on the curve (prime age), current FFR price.
function FFR_AnimalPriceManager.getHeadPrice(index)
    local system = FFR_AnimalPriceManager.getAnimalSystem()
    local ok, subType = false, nil
    if system ~= nil and system.getSubTypeByIndex ~= nil then ok, subType = pcall(system.getSubTypeByIndex, system, index) end
    local best = 0
    for _, keyframe in ipairs(ok and subType ~= nil and FFR_AnimalPriceManager.getKeyframes(subType.sellPrice) or {}) do
        if type(keyframe[1]) == "number" then best = math.max(best, keyframe[1]) end
    end
    return best
end

-- The same at the map's normal price.
function FFR_AnimalPriceManager.getNormalHeadPrice(index)
    local store = FFR_AnimalPriceManager.baselines[index]
    if store == nil or store.sellPrice == nil then return FFR_AnimalPriceManager.getHeadPrice(index) end
    local best = 0
    for _, values in ipairs(store.sellPrice) do
        if type(values[1]) == "number" then best = math.max(best, values[1]) end
    end
    return best
end

-- Animal entries for the Markets list and price history (same shape as commodities).
function FFR_AnimalPriceManager.getMarketEntries()
    local list = {}
    local engine = g_FFR ~= nil and g_FFR.marketEngine or nil
    for _, entry in ipairs(FFR_AnimalPriceManager.getSubTypes()) do
        local category = FFR_AnimalPriceManager.getCategory(entry.subType)
        if category ~= nil and FFR_AnimalPriceManager.getKeyframes(entry.subType.sellPrice) ~= nil then
            table.insert(list, {
                name = "ANIMAL_" .. string.upper(tostring(entry.subType.name or entry.index)),
                displayName = string.format("%s (%s)", FFR_AnimalPriceManager.getTitle(entry.subType), FFR_L10n.t("ffr_market_animal_" .. tostring(category))),
                isAnimal = true, subTypeIndex = entry.index, category = category,
                priceModifier = engine ~= nil and engine:getModifier(category) or 1
            })
        end
    end
    return list
end

--------------------------------------------------
-- Diagnostic: what FS25's animal data looks like
--------------------------------------------------

function FFR_AnimalPriceManager.describe(value)
    if type(value) ~= "table" then return type(value) .. "=" .. tostring(value) end
    local keys = {}
    for k, v in pairs(value) do
        table.insert(keys, tostring(k) .. ":" .. type(v))
        if #keys >= 14 then break end
    end
    return "{" .. table.concat(keys, ", ") .. "}"
end

function FFR_AnimalPriceManager.logDiagnostics()
    if FFR_AnimalPriceManager.hasLoggedDiagnostics then return end
    FFR_AnimalPriceManager.hasLoggedDiagnostics = true
    local subTypes = FFR_AnimalPriceManager.getSubTypes()
    Logging.info("FFR Animal Prices: %d animal subtype(s) found", #subTypes)
    local first = subTypes[1]
    if first ~= nil then
        local s = first.subType
        Logging.info("FFR Animal Prices: diagnostic subtype %s (type %s): sellPrice %s", tostring(s.name),
            FFR_AnimalPriceManager.getTypeName(s), FFR_AnimalPriceManager.describe(s.sellPrice))
        local keyframes = FFR_AnimalPriceManager.getKeyframes(s.sellPrice)
        Logging.info("FFR Animal Prices: diagnostic first keyframe %s; buyPrice %s",
            keyframes ~= nil and FFR_AnimalPriceManager.describe(keyframes[1]) or "none",
            FFR_AnimalPriceManager.describe(s.buyPrice))
    end
    if AnimalCluster ~= nil then
        local names = {}
        for k, v in pairs(AnimalCluster) do
            if type(v) == "function" and (string.find(k, "Price") or string.find(k, "Health") or string.find(k, "NumAnimals")) then
                table.insert(names, k)
            end
        end
        table.sort(names)
        Logging.info("FFR Animal Prices: diagnostic AnimalCluster functions: %s", table.concat(names, ", "))
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_AnimalPriceManager:update(dt)
    FFR_AnimalPriceManager.updateTimer = FFR_AnimalPriceManager.updateTimer + dt
    if FFR_AnimalPriceManager.updateTimer < 1000 then return end
    FFR_AnimalPriceManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted or g_FFR.marketEngine == nil then return end
    pcall(FFR_AnimalPriceManager.logDiagnostics)
    local parts = {}
    for _, category in ipairs({"cattle", "pig", "sheep", "poultry"}) do
        table.insert(parts, string.format("%.4f", tonumber(g_FFR.marketEngine:getModifier(category)) or 1))
    end
    local signature = table.concat(parts, ";")
    if signature == FFR_AnimalPriceManager.appliedSignature then return end
    local ok, err = pcall(FFR_AnimalPriceManager.applyPrices)
    if ok then
        FFR_AnimalPriceManager.appliedSignature = signature
    else
        Logging.warning("FFR Animal Prices: Could not set animal prices (%s)", tostring(err))
        FFR_AnimalPriceManager.appliedSignature = signature
    end
end

function FFR_AnimalPriceManager:loadMap(mapName)
    FFR_AnimalPriceManager.baselines = {}
    FFR_AnimalPriceManager.appliedSignature = nil
    FFR_AnimalPriceManager.loggedPrices = {}
    FFR_AnimalPriceManager.hasLoggedDiagnostics = false
end

function FFR_AnimalPriceManager:deleteMap()
    pcall(FFR_AnimalPriceManager.restoreAll)
    FFR_AnimalPriceManager.appliedSignature = nil
end

function FFR_AnimalPriceManager:draw() end
function FFR_AnimalPriceManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_AnimalPriceManager:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_AnimalPriceManager)
Logging.info("FFR Animal Prices: FFR sets animal prices (map prices are the baseline)")
