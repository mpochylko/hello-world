FFR_AssetManager = {}

function FFR_AssetManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_AssetManager}
    )

    --------------------------------------------------
    -- Asset Collections
    --------------------------------------------------

    self.landAssets = {}

    self.equipmentAssets = {}

    self.buildingAssets = {}

    self.inventoryAssets = {}

    --------------------------------------------------
    -- Totals
    --------------------------------------------------

    self.totalLandValue = 0

    self.totalEquipmentValue = 0

    self.totalBuildingValue = 0

    self.totalInventoryValue = 0

    self.totalAssetValue = 0

    --------------------------------------------------
    -- Statistics
    --------------------------------------------------

    self.totalDepreciation = 0

    self.totalAppreciation = 0

    return self

end

--------------------------------------------------
-- Add Land
--------------------------------------------------

function FFR_AssetManager:addLandAsset(

    id,
    acres,
    value

)

    self.landAssets[id] = {

        id = id,

        acres = acres,

        marketValue = value,

        originalValue = value

    }

    self:updateTotals()

end

--------------------------------------------------
-- Add Equipment
--------------------------------------------------

function FFR_AssetManager:addEquipmentAsset(

    id,

    name,

    purchasePrice

)

    self.equipmentAssets[id] = {

        id = id,

        name = name,

        purchasePrice =
            purchasePrice,

        marketValue =
            purchasePrice,

        ageYears = 0

    }

    self:updateTotals()

end

--------------------------------------------------
-- Add Building
--------------------------------------------------

function FFR_AssetManager:addBuildingAsset(

    id,

    name,

    value

)

    self.buildingAssets[id] = {

        id = id,

        name = name,

        marketValue = value

    }

    self:updateTotals()

end

--------------------------------------------------
-- Add Inventory
--------------------------------------------------

function FFR_AssetManager:addInventoryAsset(

    id,

    name,

    value

)

    self.inventoryAssets[id] = {

        id = id,

        name = name,

        marketValue = value

    }

    self:updateTotals()

end

--------------------------------------------------
-- Equipment Depreciation
--------------------------------------------------

function FFR_AssetManager:applyYearlyDepreciation()

    for _, asset
        in pairs(
            self.equipmentAssets
        )
    do

        local oldValue =
            asset.marketValue

        asset.marketValue =

            asset.marketValue
            * 0.90

        asset.ageYears =
            asset.ageYears + 1

        self.totalDepreciation =

            self.totalDepreciation

            +
            (
                oldValue
                -
                asset.marketValue
            )

    end

    self:updateTotals()

end

--------------------------------------------------
-- Land Appreciation
--------------------------------------------------

function FFR_AssetManager:applyLandAppreciation()

    for _, land
        in pairs(
            self.landAssets
        )
    do

        local oldValue =
            land.marketValue

        land.marketValue =

            land.marketValue
            * 1.03

        self.totalAppreciation =

            self.totalAppreciation

            +
            (
                land.marketValue
                -
                oldValue
            )

    end

    self:updateTotals()

end

--------------------------------------------------
-- Recalculate Totals
--------------------------------------------------

function FFR_AssetManager:updateTotals()

    --------------------------------------------------
    -- On a multiplayer client the totals come from the
    -- server (FFR_Network); the asset lists are empty.
    --------------------------------------------------

    if self.isRemote then
        return
    end

    self.totalLandValue = 0
    self.totalEquipmentValue = 0
    self.totalBuildingValue = 0
    self.totalInventoryValue = 0

    --------------------------------------------------
    -- Land
    --------------------------------------------------

    for _, asset
        in pairs(
            self.landAssets
        )
    do

        self.totalLandValue =

            self.totalLandValue
            + asset.marketValue

    end

    --------------------------------------------------
    -- Equipment
    --------------------------------------------------

    for _, asset
        in pairs(
            self.equipmentAssets
        )
    do

        self.totalEquipmentValue =

            self.totalEquipmentValue
            + asset.marketValue

    end

    --------------------------------------------------
    -- Buildings
    --------------------------------------------------

    for _, asset
        in pairs(
            self.buildingAssets
        )
    do

        self.totalBuildingValue =

            self.totalBuildingValue
            + asset.marketValue

    end

    --------------------------------------------------
    -- Inventory
    --------------------------------------------------

    for _, asset
        in pairs(
            self.inventoryAssets
        )
    do

        self.totalInventoryValue =

            self.totalInventoryValue
            + asset.marketValue

    end

    --------------------------------------------------
    -- Grand Total
    --------------------------------------------------

    self.totalAssetValue =

        self.totalLandValue

        + self.totalEquipmentValue

        + self.totalBuildingValue

        + self.totalInventoryValue

end

--------------------------------------------------
-- Push Values To Financial Manager
--------------------------------------------------

function FFR_AssetManager:updateFinancialManager(

    financialManager

)

    if financialManager == nil then
        return
    end

    financialManager.landValue =
        self.totalLandValue

    financialManager.equipmentValue =
        self.totalEquipmentValue

    financialManager.buildingValue =
        self.totalBuildingValue

    financialManager.inventoryValue =
        self.totalInventoryValue

end

--------------------------------------------------
-- Asset Report
--------------------------------------------------

function FFR_AssetManager:printAssetReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR ASSET REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Land Value: $"
        .. tostring(
            math.floor(
                self.totalLandValue
            )
        )
    )

    Logging.info(
        "Equipment Value: $"
        .. tostring(
            math.floor(
                self.totalEquipmentValue
            )
        )
    )

    Logging.info(
        "Building Value: $"
        .. tostring(
            math.floor(
                self.totalBuildingValue
            )
        )
    )

    Logging.info(
        "Inventory Value: $"
        .. tostring(
            math.floor(
                self.totalInventoryValue
            )
        )
    )

    Logging.info(
        "Total Asset Value: $"
        .. tostring(
            math.floor(
                self.totalAssetValue
            )
        )
    )

    Logging.info(
        "Depreciation: $"
        .. tostring(
            math.floor(
                self.totalDepreciation
            )
        )
    )

    Logging.info(
        "Appreciation: $"
        .. tostring(
            math.floor(
                self.totalAppreciation
            )
        )
    )

    Logging.info(
        "========================================"
    )

end