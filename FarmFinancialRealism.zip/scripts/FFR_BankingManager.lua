FFR_BankingManager = {}

function FFR_BankingManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_BankingManager}
    )

    --------------------------------------------------
    -- Rates
    --------------------------------------------------

    self.baseOperatingRate = 0.080

    self.baseEquipmentRate = 0.065

    self.baseLandRate = 0.055

    --------------------------------------------------
    -- Approvals
    --------------------------------------------------

    self.lastLoanDecision = ""

    --------------------------------------------------
    -- Statistics
    --------------------------------------------------

    self.totalBorrowed = 0

    self.totalInterestPaid = 0

    return self

end

--------------------------------------------------
-- Interest Rate Calculation
--
-- Rate = base x credit-rating modifier x difficulty
-- preset, plus the insolvency penalty rate while
-- the farm is in credit freeze or worse.
--------------------------------------------------

function FFR_BankingManager:adjustRate(
    rate,
    creditManager
)

    if FFR_Settings ~= nil then
        rate = rate * (tonumber(FFR_Settings.getValue("interest")) or 1)
    end

    if FFR_InsolvencyManager ~= nil then
        rate = rate + FFR_InsolvencyManager.getPenaltyRate(creditManager)
    end

    return rate

end

function FFR_BankingManager:getOperatingRate(
    creditManager
)

    if creditManager == nil then
        return self:adjustRate(self.baseOperatingRate, nil)
    end

    return self:adjustRate(
        self.baseOperatingRate * creditManager.interestRateModifier,
        creditManager
    )

end

--------------------------------------------------
-- Equipment Rate
--------------------------------------------------

function FFR_BankingManager:getEquipmentRate(
    creditManager
)

    if creditManager == nil then
        return self:adjustRate(self.baseEquipmentRate, nil)
    end

    return self:adjustRate(
        self.baseEquipmentRate * creditManager.interestRateModifier,
        creditManager
    )

end

--------------------------------------------------
-- Land Rate
--------------------------------------------------

function FFR_BankingManager:getLandRate(
    creditManager
)

    if creditManager == nil then
        return self:adjustRate(self.baseLandRate, nil)
    end

    return self:adjustRate(
        self.baseLandRate * creditManager.interestRateModifier,
        creditManager
    )

end

--------------------------------------------------
-- Loan Settings
--
-- Operating line: revolving, interest only.
-- Expansion loan: secured by titled land, paid off
-- in equal monthly principal over the term. It is
-- stored as financialManager.landDebt (the "land"
-- names in the code all refer to this loan).
--------------------------------------------------

FFR_BankingManager.OPERATING_STEP = 100000

FFR_BankingManager.LAND_STEP = 250000

FFR_BankingManager.LAND_TERM_MONTHS = 120

-- Collateral share used for land with no title record.
FFR_BankingManager.DEFAULT_LAND_COLLATERAL = 0.85

--------------------------------------------------
-- Formatting
--------------------------------------------------

function FFR_BankingManager:formatMoney(
    value
)

    if g_FFRDashboardDataManager ~= nil then

        return g_FFRDashboardDataManager:formatMoney(
            value
        )

    end

    return FFR_L10n.formatMoney(value)

end

--------------------------------------------------
-- Land Collateral
--
-- Uses the land-title collateral values when a
-- parcel is registered, otherwise a default share
-- of its market value.
--------------------------------------------------

-- The farm this bank account belongs to (set by FFR_FarmState).
function FFR_BankingManager:getFarmState()

    if g_FFR == nil
        or g_FFR.getFarmState == nil
    then

        return nil

    end

    return g_FFR:getFarmState(self.farmId or g_FFR.localFarmId)

end

function FFR_BankingManager:getLandCollateral()

    local state = self:getFarmState()

    if state == nil then
        return 0
    end

    -- Multiplayer client: the server sends the collateral total.
    if state.assetManager.isRemote then
        return tonumber(state.assetManager.remote ~= nil and state.assetManager.remote.landCollateral) or 0
    end

    local total = 0

    for _, asset in pairs(
        state.assetManager.landAssets or {}
    ) do

        local collateral =
            tonumber(asset.collateralValue)

        if collateral == nil then

            collateral =
                (tonumber(asset.marketValue) or 0)
                * FFR_BankingManager.DEFAULT_LAND_COLLATERAL

        end

        total = total + collateral

    end

    return total

end

--------------------------------------------------
-- Available Borrowing
--------------------------------------------------

function FFR_BankingManager:getOperatingAvailable(
    financialManager,
    creditManager
)

    if financialManager == nil
        or creditManager == nil
    then

        return 0

    end

    return math.max(
        0,
        (tonumber(creditManager.maxOperatingLoan) or 0)
            - (tonumber(financialManager.operatingLoan) or 0)
    )

end

function FFR_BankingManager:getLandLimit(
    creditManager
)

    if creditManager == nil then
        return 0
    end

    return math.min(
        tonumber(creditManager.maxExpansionLoan) or 0,
        self:getLandCollateral()
    )

end

function FFR_BankingManager:getLandAvailable(
    financialManager,
    creditManager
)

    if financialManager == nil then
        return 0
    end

    return math.max(
        0,
        self:getLandLimit(creditManager)
            - (tonumber(financialManager.landDebt) or 0)
    )

end

--------------------------------------------------
-- Move Real Farm Money
--------------------------------------------------

function FFR_BankingManager:moveFarmMoney(
    amount
)

    if g_FFRMonthlyFinancialProcessor == nil then
        return false
    end

    local moneyType = nil

    if MoneyType ~= nil then
        moneyType = MoneyType.LOAN or MoneyType.OTHER
    end

    return g_FFRMonthlyFinancialProcessor:applyFarmBalance(
        amount,
        moneyType,
        self.farmId
    )

end

--------------------------------------------------
-- Refresh Credit After A Loan Change
--------------------------------------------------

function FFR_BankingManager:afterLoanChange(
    financialManager,
    creditManager
)

    financialManager:update()

    if creditManager ~= nil then
        creditManager:update(financialManager)
    end

    if g_FFR ~= nil
        and g_FFR.saveManager ~= nil
    then

        g_FFR.saveManager:requestSave(g_FFR)

    end

end

--------------------------------------------------
-- Current Cash
--------------------------------------------------

function FFR_BankingManager:getCash(
    financialManager
)

    if g_FFRMonthlyFinancialProcessor ~= nil then
        g_FFRMonthlyFinancialProcessor:refreshCash(self.farmId or financialManager.farmId)
    end

    return tonumber(financialManager.cashOnHand) or 0

end

--------------------------------------------------
-- Operating Loan
--
-- All loan actions return success plus a message
-- for the dashboard.
--------------------------------------------------

function FFR_BankingManager:requestOperatingLoan(

    amount,

    financialManager,

    creditManager

)

    amount = tonumber(amount) or 0

    if amount <= 0
        or financialManager == nil
        or creditManager == nil
    then

        return false, FFR_L10n.t("ffr_bank_unavailable")

    end

    if not self:isApproved(creditManager) then

        self.lastLoanDecision =
            "DENIED_CREDIT"

        return false, FFR_L10n.t("ffr_bank_denied_credit")

    end

    if FFR_InsolvencyManager ~= nil
        and FFR_InsolvencyManager.isFrozen(creditManager)
    then

        self.lastLoanDecision =
            "DENIED_FROZEN"

        return false, FFR_L10n.t(FFR_InsolvencyManager.FROZEN_MESSAGE)

    end

    local available =

        self:getOperatingAvailable(
            financialManager,
            creditManager
        )

    if amount > available then

        self.lastLoanDecision =
            "DENIED_LIMIT"

        return false, FFR_L10n.t("ffr_bank_denied_operating", self:formatMoney(available))

    end

    if not self:moveFarmMoney(amount) then

        return false, FFR_L10n.t("ffr_bank_payout_failed")

    end

    financialManager.operatingLoan =
        (tonumber(financialManager.operatingLoan) or 0)
        + amount

    self.totalBorrowed =
        self.totalBorrowed
        + amount

    self.lastLoanDecision =
        "APPROVED"

    self:afterLoanChange(
        financialManager,
        creditManager
    )

    Logging.info(
        "FFR Operating Loan Approved: $%d (balance $%d)",
        math.floor(amount),
        math.floor(financialManager.operatingLoan)
    )

    return true, FFR_L10n.t("ffr_bank_borrowed_operating", self:formatMoney(amount))

end

function FFR_BankingManager:repayOperatingLoan(

    amount,

    financialManager,

    creditManager

)

    if financialManager == nil then
        return false, FFR_L10n.t("ffr_bank_repay_unavailable")
    end

    local balance =
        tonumber(financialManager.operatingLoan) or 0

    if balance <= 0 then
        return false, FFR_L10n.t("ffr_bank_no_operating")
    end

    local payment =
        math.min(tonumber(amount) or 0, balance)

    if self:getCash(financialManager) < payment then
        return false, FFR_L10n.t("ffr_bank_not_enough_cash", self:formatMoney(payment))
    end

    if not self:moveFarmMoney(-payment) then
        return false, FFR_L10n.t("ffr_bank_repay_failed")
    end

    financialManager.operatingLoan =
        math.max(0, balance - payment)

    self:afterLoanChange(
        financialManager,
        creditManager
    )

    Logging.info(
        "FFR Operating Loan Repaid: $%d (balance $%d)",
        math.floor(payment),
        math.floor(financialManager.operatingLoan)
    )

    return true, FFR_L10n.t("ffr_bank_repaid_operating", self:formatMoney(payment))

end

--------------------------------------------------
-- Land Loan
--------------------------------------------------

function FFR_BankingManager:requestLandLoan(

    amount,

    financialManager,

    creditManager

)

    amount = tonumber(amount) or 0

    if amount <= 0
        or financialManager == nil
        or creditManager == nil
    then

        return false, FFR_L10n.t("ffr_bank_unavailable")

    end

    if not self:isApproved(creditManager) then

        self.lastLoanDecision =
            "DENIED_CREDIT"

        return false, FFR_L10n.t("ffr_bank_denied_credit")

    end

    if FFR_InsolvencyManager ~= nil
        and FFR_InsolvencyManager.isFrozen(creditManager)
    then

        self.lastLoanDecision =
            "DENIED_FROZEN"

        return false, FFR_L10n.t(FFR_InsolvencyManager.FROZEN_MESSAGE)

    end

    local available =

        self:getLandAvailable(
            financialManager,
            creditManager
        )

    if amount > available then

        self.lastLoanDecision =
            "DENIED_LIMIT"

        if self:getLandCollateral() <= 0 then
            return false, FFR_L10n.t("ffr_bank_denied_no_land")
        end

        return false, FFR_L10n.t("ffr_bank_denied_collateral", self:formatMoney(available))

    end

    if not self:moveFarmMoney(amount) then

        return false, FFR_L10n.t("ffr_bank_payout_failed")

    end

    financialManager.landDebt =
        (tonumber(financialManager.landDebt) or 0)
        + amount

    --------------------------------------------------
    -- Each draw adds its own equal principal payment.
    --------------------------------------------------

    financialManager.monthlyLandPayment =
        (tonumber(financialManager.monthlyLandPayment) or 0)
        + amount / FFR_BankingManager.LAND_TERM_MONTHS

    self.totalBorrowed =
        self.totalBorrowed
        + amount

    self.lastLoanDecision =
        "APPROVED"

    self:afterLoanChange(
        financialManager,
        creditManager
    )

    Logging.info(
        "FFR Expansion Loan Approved: $%d (balance $%d, principal $%d/month)",
        math.floor(amount),
        math.floor(financialManager.landDebt),
        math.floor(financialManager.monthlyLandPayment)
    )

    return true, FFR_L10n.t("ffr_bank_borrowed_land", self:formatMoney(amount))

end

function FFR_BankingManager:repayLandLoan(

    amount,

    financialManager,

    creditManager

)

    if financialManager == nil then
        return false, FFR_L10n.t("ffr_bank_repay_unavailable")
    end

    local balance =
        tonumber(financialManager.landDebt) or 0

    if balance <= 0 then
        return false, FFR_L10n.t("ffr_bank_no_land")
    end

    local payment =
        math.min(tonumber(amount) or 0, balance)

    if self:getCash(financialManager) < payment then
        return false, FFR_L10n.t("ffr_bank_not_enough_cash", self:formatMoney(payment))
    end

    if not self:moveFarmMoney(-payment) then
        return false, FFR_L10n.t("ffr_bank_repay_failed")
    end

    self:reduceLandDebt(
        financialManager,
        payment
    )

    self:afterLoanChange(
        financialManager,
        creditManager
    )

    Logging.info(
        "FFR Expansion Loan Repaid: $%d (balance $%d)",
        math.floor(payment),
        math.floor(financialManager.landDebt)
    )

    return true, FFR_L10n.t("ffr_bank_repaid_land", self:formatMoney(payment))

end

--------------------------------------------------
-- Pay Off In Full
--------------------------------------------------

function FFR_BankingManager:payOffOperatingLoan(
    amount,
    financialManager,
    creditManager
)

    if financialManager == nil then
        return false, FFR_L10n.t("ffr_bank_repay_unavailable")
    end

    return self:repayOperatingLoan(
        tonumber(financialManager.operatingLoan) or 0,
        financialManager,
        creditManager
    )

end

function FFR_BankingManager:payOffLandLoan(
    amount,
    financialManager,
    creditManager
)

    if financialManager == nil then
        return false, FFR_L10n.t("ffr_bank_repay_unavailable")
    end

    return self:repayLandLoan(
        tonumber(financialManager.landDebt) or 0,
        financialManager,
        creditManager
    )

end

--------------------------------------------------
-- Reduce Land Debt
--
-- Extra repayments shorten nothing; they scale the
-- monthly principal down with the balance so the
-- loan still ends on its original schedule.
--------------------------------------------------

function FFR_BankingManager:reduceLandDebt(
    financialManager,
    payment
)

    local balance =
        tonumber(financialManager.landDebt) or 0

    local newBalance =
        math.max(0, balance - (tonumber(payment) or 0))

    if newBalance < 0.01 then

        financialManager.landDebt = 0

        financialManager.monthlyLandPayment = 0

        return

    end

    if balance > 0 then

        financialManager.monthlyLandPayment =
            (tonumber(financialManager.monthlyLandPayment) or 0)
            * newBalance / balance

    end

    financialManager.landDebt = newBalance

end

--------------------------------------------------
-- Equipment Financing
--------------------------------------------------

function FFR_BankingManager:financeEquipment(

    price,

    downPaymentPercent,

    financialManager,

    creditManager

)

    local downPayment =

        price

        * downPaymentPercent

    local financedAmount =

        price
        - downPayment

    if financedAmount <= 0 then
        return false
    end

    financialManager:removeCash(
        downPayment
    )

    financialManager.equipmentDebt =

        financialManager.equipmentDebt

        + financedAmount

    self.totalBorrowed =
        self.totalBorrowed
        + financedAmount

    self.lastLoanDecision =
        "APPROVED"

    Logging.info(
        "FFR Equipment Financing Approved: $"
        .. tostring(
            financedAmount
        )
    )

    return true

end

--------------------------------------------------
-- Monthly Interest
--------------------------------------------------

function FFR_BankingManager:calculateMonthlyInterest(

    financialManager,

    creditManager

)

    local operatingInterest =

        financialManager.operatingLoan

        * self:getOperatingRate(
            creditManager
        )

        / 12

    local equipmentInterest =

        financialManager.equipmentDebt

        * self:getEquipmentRate(
            creditManager
        )

        / 12

    local landInterest =

        financialManager.landDebt

        * self:getLandRate(
            creditManager
        )

        / 12

    return

        operatingInterest

        + equipmentInterest

        + landInterest

end

--------------------------------------------------
-- Process Monthly Interest
--------------------------------------------------

function FFR_BankingManager:processMonth(

    financialManager,

    creditManager

)

    local interest =

        self:calculateMonthlyInterest(

            financialManager,

            creditManager

        )

    financialManager:removeCash(
        interest
    )

    financialManager.monthlyInterestCost =
        interest

    self.totalInterestPaid =

        self.totalInterestPaid
        + interest

    Logging.info(
        "FFR Monthly Interest: $"
        .. tostring(
            math.floor(
                interest
            )
        )
    )

end

--------------------------------------------------
-- Credit Check
--------------------------------------------------

function FFR_BankingManager:isApproved(

    creditManager

)

    if creditManager.creditRating ==
        "HIGH_RISK"
    then

        return false

    end

    return true

end

--------------------------------------------------
-- Banking Report
--------------------------------------------------

function FFR_BankingManager:printReport(

    financialManager,

    creditManager

)

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR BANKING REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Credit Rating: "
        .. creditManager.creditRating
    )

    Logging.info(
        "Operating Rate: "
        .. string.format(
            "%.2f%%",
            self:getOperatingRate(
                creditManager
            ) * 100
        )
    )

    Logging.info(
        "Equipment Rate: "
        .. string.format(
            "%.2f%%",
            self:getEquipmentRate(
                creditManager
            ) * 100
        )
    )

    Logging.info(
        "Land Rate: "
        .. string.format(
            "%.2f%%",
            self:getLandRate(
                creditManager
            ) * 100
        )
    )

    Logging.info(
        "Operating Debt: $"
        .. math.floor(
            financialManager.operatingLoan
        )
    )

    Logging.info(
        "Equipment Debt: $"
        .. math.floor(
            financialManager.equipmentDebt
        )
    )

    Logging.info(
        "Land Debt: $"
        .. math.floor(
            financialManager.landDebt
        )
    )

    Logging.info(
        "========================================"
    )

end