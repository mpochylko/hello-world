FFR_BuildingSyncManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_BuildingSyncManager:new()

    local self = {}

    setmetatable(
        self,
        {
            __index = FFR_BuildingSyncManager
        }
    )

    --------------------------------------------------
    -- Timing
    --------------------------------------------------

    self.updateTimer = 0

    self.updateInterval = 10000

    --------------------------------------------------
    -- Previous State
    --------------------------------------------------

    self.lastBuildingCount = -1

    self.lastBuildingValue = -1

    self.lastFarmId = nil

    --------------------------------------------------
    -- Statistics
    --------------------------------------------------

    self.syncCount = 0

    self.changeCount = 0

    self.skippedCount = 0

    self.isActive = true

    return self

end

--------------------------------------------------
-- Get Active Farm ID
--------------------------------------------------

function FFR_BuildingSyncManager:getActiveFarmId()

    if g_FFR ~= nil
        and g_FFR.gameIntegrationManager ~= nil
        and g_FFR.gameIntegrationManager.getActiveFarmId ~= nil
    then

        local farmId =

            g_FFR.gameIntegrationManager:
                getActiveFarmId()

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    if g_currentMission == nil then
        return nil
    end

    if g_currentMission.getFarmId ~= nil then

        local farmId =
            g_currentMission:getFarmId()

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    if g_currentMission.player ~= nil then

        local farmId =
            g_currentMission.player.farmId

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    return nil

end

--------------------------------------------------
-- Get Mission Placeables
--------------------------------------------------

function FFR_BuildingSyncManager:getMissionPlaceables()

    if g_currentMission == nil then
        return nil
    end

    if g_currentMission.placeableSystem == nil then
        return nil
    end

    return

        g_currentMission
            .placeableSystem
            .placeables

end

--------------------------------------------------
-- Get Placeable Owner
--------------------------------------------------

function FFR_BuildingSyncManager:getOwnerFarmId(
    placeable
)

    if placeable == nil then
        return nil
    end

    if placeable.getOwnerFarmId ~= nil then

        local success,
            result =

            pcall(
                placeable.getOwnerFarmId,
                placeable
            )

        if success
            and result ~= nil
        then

            return tonumber(result)

        end

    end

    if placeable.ownerFarmId ~= nil then

        return

            tonumber(
                placeable.ownerFarmId
            )

    end

    return nil

end

--------------------------------------------------
-- Ownership Check
--------------------------------------------------

function FFR_BuildingSyncManager:isOwnedByFarm(
    placeable,
    farmId
)

    if placeable == nil
        or farmId == nil
    then

        return false

    end

    if placeable.isDeleted == true then
        return false
    end

    local ownerFarmId =

        self:getOwnerFarmId(
            placeable
        )

    return ownerFarmId == farmId

end

--------------------------------------------------
-- Sellable Check
--------------------------------------------------

function FFR_BuildingSyncManager:canPlaceableBeSold(
    placeable
)

    if placeable == nil then
        return false
    end

    if placeable.canBeSold ~= nil then

        local success,
            result =

            pcall(
                placeable.canBeSold,
                placeable
            )

        if success
            and result ~= nil
        then

            return result == true

        end

    end

    --------------------------------------------------
    -- If the method is unavailable, retain the owned
    -- placeable if it has a valid financial value.
    --------------------------------------------------

    return true

end

--------------------------------------------------
-- Get Placeable ID
--------------------------------------------------

function FFR_BuildingSyncManager:getPlaceableId(
    placeable,
    fallbackIndex
)

    if placeable == nil then

        return tostring(
            fallbackIndex or "UNKNOWN"
        )

    end

    if placeable.getUniqueId ~= nil then

        local success,
            result =

            pcall(
                placeable.getUniqueId,
                placeable
            )

        if success
            and result ~= nil
            and result ~= ""
        then

            return tostring(result)

        end

    end

    if placeable.uniqueId ~= nil then

        return tostring(
            placeable.uniqueId
        )

    end

    if placeable.id ~= nil then

        return tostring(
            placeable.id
        )

    end

    return tostring(
        fallbackIndex or "UNKNOWN"
    )

end

--------------------------------------------------
-- Get Placeable Name
--------------------------------------------------

function FFR_BuildingSyncManager:getPlaceableName(
    placeable
)

    if placeable == nil then
        return "UNKNOWN BUILDING"
    end

    if placeable.getName ~= nil then

        local success,
            result =

            pcall(
                placeable.getName,
                placeable
            )

        if success
            and result ~= nil
            and result ~= ""
        then

            return tostring(result)

        end

    end

    if placeable.name ~= nil
        and placeable.name ~= ""
    then

        return tostring(
            placeable.name
        )

    end

    if placeable.configFileName ~= nil then

        return tostring(
            placeable.configFileName
        )

    end

    return "UNKNOWN BUILDING"

end

--------------------------------------------------
-- Get Original Purchase Price
--------------------------------------------------

function FFR_BuildingSyncManager:getPurchasePrice(
    placeable
)

    if placeable == nil then
        return 0
    end

    if placeable.getPrice ~= nil then

        local success,
            result =

            pcall(
                placeable.getPrice,
                placeable
            )

        if success
            and result ~= nil
        then

            local value =
                tonumber(result)

            if value ~= nil
                and value >= 0
            then

                return value

            end

        end

    end

    if placeable.price ~= nil then

        local value =

            tonumber(
                placeable.price
            )

        if value ~= nil
            and value >= 0
        then

            return value

        end

    end

    return 0

end

--------------------------------------------------
-- Get Current Placeable Value
--------------------------------------------------

function FFR_BuildingSyncManager:getPlaceableValue(
    placeable
)

    if placeable == nil then
        return 0
    end

    --------------------------------------------------
    -- Preferred value:
    -- actual current recoverable sell value.
    --------------------------------------------------

    if placeable.getSellPrice ~= nil then

        local success,
            result =

            pcall(
                placeable.getSellPrice,
                placeable
            )

        if success
            and result ~= nil
        then

            local sellPrice =
                tonumber(result)

            if sellPrice ~= nil
                and sellPrice >= 0
            then

                return sellPrice

            end

        end

    end

    --------------------------------------------------
    -- Fallback to original/configured price.
    --------------------------------------------------

    return

        self:getPurchasePrice(
            placeable
        )

end

--------------------------------------------------
-- Determine Building Type
--------------------------------------------------

function FFR_BuildingSyncManager:getBuildingType(
    placeable
)

    if placeable == nil then
        return "building"
    end

    if placeable.spec_productionPoint ~= nil then

        return "production"

    end

    if placeable.spec_husbandry ~= nil then

        return "husbandry"

    end

    if placeable.spec_silo ~= nil
        or placeable.spec_siloExtension ~= nil
    then

        return "storage"

    end

    if placeable.spec_farmhouse ~= nil then

        return "farmhouse"

    end

    if placeable.spec_sellingStation ~= nil then

        return "sellingStation"

    end

    return "building"

end

--------------------------------------------------
-- Which land a building stands on
--
-- Only buildings on land the farm still owns count:
-- a parcel sold away (also by a forced sale) takes
-- its buildings out of the farm's assets. Land titled
-- "Access only" is land the farm only crosses;
-- buildings that came with it do not count either.
--------------------------------------------------

-- Farmland id under the building, or nil when unknown.
function FFR_BuildingSyncManager:getFarmlandId(
    placeable
)

    if g_farmlandManager == nil
        or g_farmlandManager.getFarmlandIdAtWorldPosition == nil
        or placeable.rootNode == nil
        or getWorldTranslation == nil
    then

        return nil

    end

    local success, x, _, z =
        pcall(
            getWorldTranslation,
            placeable.rootNode
        )

    if not success or x == nil or z == nil then
        return nil
    end

    local found, farmlandId =
        pcall(
            g_farmlandManager.getFarmlandIdAtWorldPosition,
            g_farmlandManager,
            x,
            z
        )

    return found and tonumber(farmlandId) or nil

end

function FFR_BuildingSyncManager:isOnFarmLand(
    placeable,
    farmId,
    farmlandId
)

    if farmlandId == nil or farmlandId <= 0 then
        return true
    end

    local ok, owner =
        pcall(
            g_farmlandManager.getFarmlandOwner,
            g_farmlandManager,
            farmlandId
        )

    if ok and tonumber(owner) ~= nil and tonumber(owner) ~= farmId then
        return false
    end

    if g_FFRLandRegistryManager ~= nil then

        local record =
            g_FFRLandRegistryManager.registrations[
                g_FFRLandRegistryManager:getKey(farmlandId)
            ]

        if record ~= nil and record.use == "ACCESS" then
            return false
        end

    end

    return true

end

--------------------------------------------------
-- Synchronize Buildings
--------------------------------------------------

-- One farm's owned, sellable placeables into its own financial profile.
function FFR_BuildingSyncManager:syncFarmBuildings(farmId, state)

    if g_FFR == nil
        or not g_FFR.isInitialized
        or state.assetManager == nil
    then

        return false

    end


    local placeables =
        self:getMissionPlaceables()

    if placeables == nil then
        return false
    end

    local buildingAssets = {}

    local buildingCount = 0
    local totalValue = 0
    local skippedCount = 0

    -- Counted buildings per farmland, for the log ("?" = position unknown).
    local perFarmland = {}

    for placeableIndex, placeable in pairs(
        placeables
    ) do

        local farmlandId =
            self:isOwnedByFarm(placeable, farmId)
            and self:getFarmlandId(placeable)
            or nil

        if self:isOwnedByFarm(
            placeable,
            farmId
        ) then

            if self:canPlaceableBeSold(
                placeable
            ) and self:isOnFarmLand(
                placeable,
                farmId,
                farmlandId
            ) then

                local label = tostring(farmlandId or "?")

                perFarmland[label] =
                    (perFarmland[label] or 0) + 1

                local assetId =

                    self:getPlaceableId(
                        placeable,
                        placeableIndex
                    )

                local name =

                    self:getPlaceableName(
                        placeable
                    )

                local marketValue =

                    self:getPlaceableValue(
                        placeable
                    )

                local purchasePrice =

                    self:getPurchasePrice(
                        placeable
                    )

                local buildingType =

                    self:getBuildingType(
                        placeable
                    )

                buildingAssets[
                    assetId
                ] = {

                    id = assetId,

                    name = name,

                    category =
                        buildingType,

                    purchasePrice =
                        purchasePrice,

                    marketValue =
                        marketValue

                }

                buildingCount =
                    buildingCount + 1

                totalValue =
                    totalValue + marketValue

            else

                skippedCount =
                    skippedCount + 1

            end

        end

    end

    state.assetManager.buildingAssets =
        buildingAssets

    state.assetManager:updateTotals()

    state.assetManager:updateFinancialManager(
        state.financialManager
    )

    if state.financialManager ~= nil then

        state.financialManager:update()

    end

    local changed =

        buildingCount ~=
            state.sync.lastBuildingCount

        or math.abs(
            totalValue
            - state.sync.lastBuildingValue
        ) >= 1

    if changed then

        local parts = {}

        for label, count in pairs(perFarmland) do
            table.insert(parts, string.format("farmland %s: %d", label, count))
        end

        table.sort(parts)

        Logging.info(
            "FFR Building Sync: %d owned buildings, $%d (%s)",
            buildingCount,
            math.floor(totalValue),
            table.concat(parts, ", ")
        )

        self.changeCount =
            self.changeCount + 1

    end

    state.sync.lastBuildingCount =
        buildingCount

    state.sync.lastBuildingValue =
        totalValue

    self.lastFarmId =
        farmId

    self.skippedCount =
        skippedCount


    return true

end

-- Every farm's buildings.
function FFR_BuildingSyncManager:syncBuildings()

    if g_FFR == nil
        or not g_FFR.isInitialized
        or g_FFR.getFarmStates == nil
    then

        return false

    end

    for _, state in ipairs(g_FFR:getFarmStates()) do

        state.sync.lastBuildingCount = state.sync.lastBuildingCount or -1
        state.sync.lastBuildingValue = state.sync.lastBuildingValue or -1

        self:syncFarmBuildings(state.farmId, state)

    end

    self.syncCount =
        self.syncCount + 1

    return true

end

--------------------------------------------------
-- Runtime Update
--------------------------------------------------

function FFR_BuildingSyncManager:update(
    dt
)

    if not self.isActive then
        return
    end

    --------------------------------------------------
    -- Buildings are valued on the server; clients get
    -- the totals in the network sync.
    --------------------------------------------------

    if FFR_Network ~= nil
        and FFR_Network.isClientOnly()
    then

        return

    end

    self.updateTimer =

        self.updateTimer + dt

    if self.updateTimer <
        self.updateInterval
    then

        return

    end

    self.updateTimer = 0

    self:syncBuildings()

end

--------------------------------------------------
-- Required Listener Methods
--------------------------------------------------

function FFR_BuildingSyncManager:loadMap(
    mapName
)

    self.updateTimer = 0

    self.lastBuildingCount = -1

    self.lastBuildingValue = -1

    self.lastFarmId = nil

end

function FFR_BuildingSyncManager:deleteMap()

    self.updateTimer = 0

    self.lastBuildingCount = -1

    self.lastBuildingValue = -1

    self.lastFarmId = nil

end

function FFR_BuildingSyncManager:draw()

end

function FFR_BuildingSyncManager:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)

end

function FFR_BuildingSyncManager:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)

end

--------------------------------------------------
-- Report
--------------------------------------------------

function FFR_BuildingSyncManager:printReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR BUILDING SYNC REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Sync Runs: %d",
        self.syncCount
    )

    Logging.info(
        "Detected Changes: %d",
        self.changeCount
    )

    Logging.info(
        "Owned Buildings: %d",
        math.max(
            self.lastBuildingCount,
            0
        )
    )

    Logging.info(
        "Building Value: $%d",
        math.floor(
            math.max(
                self.lastBuildingValue,
                0
            )
        )
    )

    Logging.info(
        "Unsellable Owned Placeables Skipped: %d",
        self.skippedCount
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Property maintenance
--
-- FS25 books its buildings' daily upkeep at
-- midnight (MoneyType.PROPERTY_MAINTENANCE). FFR
-- holds those bookings back per farm
-- (state.propertyMaintenanceDue) and charges the
-- month's total on the month-end bill instead
-- (FFR_MonthlyFinancialProcessor), so the cost stays
-- but FFR's statement is the one place it shows.
--------------------------------------------------

function FFR_BuildingSyncManager.onAddMoney(
    mission,
    superFunc,
    amount,
    farmId,
    moneyType,
    ...
)

    local state =
        (MoneyType ~= nil
            and MoneyType.PROPERTY_MAINTENANCE ~= nil
            and moneyType == MoneyType.PROPERTY_MAINTENANCE
            and (tonumber(amount) or 0) < 0
            and g_FFR ~= nil
            and g_FFR.isInitialized
            and not g_FFR.isDeleted)
        and g_FFR:getFarmState(farmId)
        or nil

    if state == nil then
        return superFunc(mission, amount, farmId, moneyType, ...)
    end

    state.propertyMaintenanceDue =
        (tonumber(state.propertyMaintenanceDue) or 0)
        - amount

    Logging.info(
        "FFR Property Maintenance: Farm %d upkeep $%d moved to the month-end bill ($%d due)",
        state.farmId,
        math.floor(-amount + 0.5),
        math.floor(state.propertyMaintenanceDue + 0.5)
    )

end

function FFR_BuildingSyncManager.installMaintenanceHook()

    if FSBaseMission == nil
        or FSBaseMission.addMoney == nil
        or MoneyType == nil
        or MoneyType.PROPERTY_MAINTENANCE == nil
    then

        Logging.warning(
            "FFR Property Maintenance: PROPERTY_MAINTENANCE money type not found; FS25 keeps charging upkeep daily"
        )

        return

    end

    FSBaseMission.addMoney =
        Utils.overwrittenFunction(
            FSBaseMission.addMoney,
            FFR_BuildingSyncManager.onAddMoney
        )

end

--------------------------------------------------
-- Create Global Listener
--------------------------------------------------

FFR_BuildingSyncManager.installMaintenanceHook()

g_FFRBuildingSyncManager =

    FFR_BuildingSyncManager:new()

addModEventListener(
    g_FFRBuildingSyncManager
)

Logging.info(
    "FFR Building Sync: Listener installed"
)
