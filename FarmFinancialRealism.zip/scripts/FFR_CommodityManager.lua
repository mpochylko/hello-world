FFR_CommodityManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_CommodityManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_CommodityManager}
    )

    self.commodities = {}

    self.registeredCount = 0

    self.nativePriceCount = 0

    self.fallbackPriceCount = 0

    return self

end

--------------------------------------------------
-- Safe Number
--------------------------------------------------

function FFR_CommodityManager:getNumber(
    value,
    defaultValue
)

    local result =
        tonumber(value)

    if result == nil then
        return defaultValue or 0
    end

    return result

end

--------------------------------------------------
-- Commodity Categories
--------------------------------------------------

function FFR_CommodityManager:getCategory(
    fillTypeName
)

    local name =
        string.upper(
            tostring(
                fillTypeName or ""
            )
        )

    local categories = {

        --------------------------------------------------
        -- Grain
        --------------------------------------------------

        WHEAT = "grain",
        BARLEY = "grain",
        OAT = "grain",
        MAIZE = "grain",
        CORN = "grain",
        SORGHUM = "grain",
        RYE = "grain",
        TRITICALE = "grain",
        SPELT = "grain",
        BUCKWHEAT = "grain",
        RICE = "grain",
        RICELONGGRAIN = "grain",

        --------------------------------------------------
        -- Oilseed
        --------------------------------------------------

        CANOLA = "oilseed",
        SUNFLOWER = "oilseed",
        SOYBEAN = "oilseed",
        MUSTARD = "oilseed",
        FLAX = "oilseed",
        LINSEED = "oilseed",
        SAFFLOWER = "oilseed",
        PEANUT = "oilseed",

        --------------------------------------------------
        -- Pulses
        --------------------------------------------------

        PEA = "pulse",
        DRYPEAS = "pulse",
        LENTILS = "pulse",
        CHICKPEAS = "pulse",
        NAVYBEAN = "pulse",
        PINTOBEAN = "pulse",
        KIDNEYBEAN = "pulse",

        --------------------------------------------------
        -- Vegetables and Root Crops
        --------------------------------------------------

        POTATO = "vegetable",
        SUGARBEET = "vegetable",
        BEETROOT = "vegetable",
        CARROT = "vegetable",
        PARSNIP = "vegetable",
        GREENBEAN = "vegetable",
        SPINACH = "vegetable",
        GARLIC = "vegetable",
        ONION = "vegetable",
        TARO = "vegetable",

        --------------------------------------------------
        -- Forage
        --------------------------------------------------

        GRASS = "forage",
        DRYGRASS = "forage",
        HAY = "forage",
        STRAW = "forage",
        SILAGE = "forage",
        ALFALFA = "forage",
        CLOVER = "forage",
        MEADOW = "forage",

        --------------------------------------------------
        -- Industrial
        --------------------------------------------------

        COTTON = "industrial",
        SUGARCANE = "industrial",
        POPLAR = "industrial",

        --------------------------------------------------
        -- Animal Products
        --
        -- Lets the dairy, poultry and animal-product
        -- market events reach a selling price. Live
        -- animals are not sold through selling stations;
        -- cattle, pig, sheep and poultry events reach
        -- the animal dealer via FFR_AnimalPriceManager.
        --------------------------------------------------

        MILK = "dairy",
        GOATMILK = "dairy",
        BUFFALOMILK = "dairy",
        EGG = "poultry",
        WOOL = "animalProducts"

    }

    return categories[name]

end

--------------------------------------------------
-- Supported Commodity Check
--------------------------------------------------

function FFR_CommodityManager:isSupportedCommodity(
    fillTypeName
)

    return

        self:getCategory(
            fillTypeName
        )

        ~= nil

end

--------------------------------------------------
-- Get Fill Type Description
--------------------------------------------------

function FFR_CommodityManager:getFillTypeDescription(
    fillTypeName,
    fillTypeIndex
)

    if g_fillTypeManager == nil then
        return nil
    end

    local description = nil

    if fillTypeIndex ~= nil
        and g_fillTypeManager.getFillTypeByIndex ~= nil
    then

        description =

            g_fillTypeManager:getFillTypeByIndex(
                fillTypeIndex
            )

    end

    if description == nil
        and fillTypeName ~= nil
        and g_fillTypeManager.getFillTypeByName ~= nil
    then

        description =

            g_fillTypeManager:getFillTypeByName(
                tostring(fillTypeName)
            )

    end

    return description

end

--------------------------------------------------
-- Read Native Economy Price
--------------------------------------------------

function FFR_CommodityManager:getNativePricePerLiter(
    fillTypeDescription
)

    if fillTypeDescription == nil then
        return nil
    end

    --------------------------------------------------
    -- First choice:
    -- Ask the live FS25 economy manager.
    --------------------------------------------------

    if g_currentMission ~= nil
        and g_currentMission.economyManager ~= nil
        and g_currentMission.economyManager.getPricePerLiter ~= nil
        and fillTypeDescription.index ~= nil
    then

        local success,
            pricePerLiter =

            pcall(
                g_currentMission
                    .economyManager
                    .getPricePerLiter,

                g_currentMission
                    .economyManager,

                fillTypeDescription.index,

                0
            )

        pricePerLiter =
            tonumber(pricePerLiter)

        if success
            and pricePerLiter ~= nil
            and pricePerLiter > 0
        then

            return pricePerLiter

        end

    end

    --------------------------------------------------
    -- Fallback:
    -- Read the map's fill-type economy definition.
    --------------------------------------------------

    local pricePerLiter =

        tonumber(
            fillTypeDescription.pricePerLiter
        )

    if pricePerLiter ~= nil
        and pricePerLiter > 0
    then

        return pricePerLiter

    end

    return nil

end

--------------------------------------------------
-- Convert Native Price to Dashboard Units
--------------------------------------------------

function FFR_CommodityManager:getNativeBasePrice(
    fillTypeDescription
)

    local pricePerLiter =

        self:getNativePricePerLiter(
            fillTypeDescription
        )

    if pricePerLiter == nil
        or pricePerLiter <= 0
    then

        return nil

    end

    --------------------------------------------------
    -- FS25 economy values are stored per litre.
    -- FFR reports commodity prices per 1,000 litres.
    --------------------------------------------------

    return pricePerLiter * 1000

end

--------------------------------------------------
-- Register Commodity
--------------------------------------------------

function FFR_CommodityManager:registerCommodity(
    fillTypeName,
    fillTypeIndex
)

    if fillTypeName == nil then
        return false
    end

    local name =

        string.upper(
            tostring(fillTypeName)
        )

    if not self:isSupportedCommodity(
        name
    ) then

        return false

    end

    if self.commodities[name] ~= nil then
        return false
    end

    local fillTypeDescription =

        self:getFillTypeDescription(
            name,
            fillTypeIndex
        )

    if fillTypeDescription == nil then

        Logging.warning(
            "FFR Commodity: Fill type %s could not be resolved",
            name
        )

        return false

    end

    local nativeBasePrice =

        self:getNativeBasePrice(
            fillTypeDescription
        )

    local priceSource =
        "native"

    if nativeBasePrice == nil
        or nativeBasePrice <= 0
    then

        --------------------------------------------------
        -- Safe fallback only.
        -- We do not invent a random price.
        --------------------------------------------------

        nativeBasePrice = 0

        priceSource =
            "unavailable"

        self.fallbackPriceCount =
            self.fallbackPriceCount + 1

        Logging.warning(
            "FFR Commodity: Native price unavailable for %s",
            name
        )

    else

        self.nativePriceCount =
            self.nativePriceCount + 1

    end

    local category =

        self:getCategory(
            name
        )

    self.commodities[name] = {

        name = name,

        index =
            fillTypeDescription.index
            or fillTypeIndex
            or 0,

        category =
            category,

        fillType =
            fillTypeDescription,

        nativePricePerLiter =

            nativeBasePrice / 1000,

        nativeBasePrice =
            nativeBasePrice,

        basePrice =
            nativeBasePrice,

        currentPrice =
            nativeBasePrice,

        priceModifier =
            1.00,

        volatility =
            1.00,

        priceSource =
            priceSource

    }

    self.registeredCount =
        self.registeredCount + 1

    Logging.info(
        "FFR Commodity Registered: %s [%s] Native $%.2f/1000L",
        name,
        category,
        nativeBasePrice
    )

    return true

end

--------------------------------------------------
-- Build From Registry
--------------------------------------------------

function FFR_CommodityManager:buildFromRegistry(
    registry
)

    self.commodities = {}

    self.registeredCount = 0

    self.nativePriceCount = 0

    self.fallbackPriceCount = 0

    if registry == nil
        or registry.crops == nil
    then

        Logging.warning(
            "FFR Commodity Manager: Registry crops are unavailable"
        )

        return false

    end

    for cropName, cropData in pairs(
        registry.crops
    ) do

        local fillTypeIndex = nil

        if cropData ~= nil then

            fillTypeIndex =
                cropData.index

        end

        self:registerCommodity(
            cropName,
            fillTypeIndex
        )

    end

    Logging.info(
        "FFR Commodity Native Price Scan: %d native, %d unavailable",
        self.nativePriceCount,
        self.fallbackPriceCount
    )

    return true

end

--------------------------------------------------
-- Reset Commodity to Native Price
--------------------------------------------------

function FFR_CommodityManager:resetCommodityPrice(
    commodityName
)

    if commodityName == nil then
        return false
    end

    local name =

        string.upper(
            tostring(commodityName)
        )

    local commodity =
        self.commodities[name]

    if commodity == nil then
        return false
    end

    local nativeBasePrice =

        self:getNativeBasePrice(
            commodity.fillType
        )

    if nativeBasePrice == nil
        or nativeBasePrice <= 0
    then

        return false

    end

    commodity.nativeBasePrice =
        nativeBasePrice

    commodity.nativePricePerLiter =
        nativeBasePrice / 1000

    commodity.basePrice =
        nativeBasePrice

    commodity.currentPrice =
        nativeBasePrice

    commodity.priceModifier =
        1.00

    commodity.priceSource =
        "native"

    return true

end

--------------------------------------------------
-- Refresh All Native Prices
--------------------------------------------------

function FFR_CommodityManager:refreshNativePrices()

    local refreshedCount = 0

    for _, commodity in pairs(
        self.commodities
    ) do

        if self:resetCommodityPrice(
            commodity.name
        ) then

            refreshedCount =
                refreshedCount + 1

        end

    end

    Logging.info(
        "FFR Commodity Native Prices Refreshed: %d",
        refreshedCount
    )

    return refreshedCount

end

--------------------------------------------------
-- Apply Category Modifier
--------------------------------------------------

function FFR_CommodityManager:applyCategoryModifier(
    category,
    modifier
)

    local safeModifier =

        tonumber(modifier)

        or 1.00

    for _, commodity in pairs(
        self.commodities
    ) do

        if commodity.category ==
            category
        then

            commodity.priceModifier =
                safeModifier

            commodity.currentPrice =

                self:getNumber(
                    commodity.basePrice,
                    0
                )

                * safeModifier

        end

    end

end

--------------------------------------------------
-- Get Commodity
--------------------------------------------------

function FFR_CommodityManager:getCommodity(
    commodityName
)

    if commodityName == nil then
        return nil
    end

    return

        self.commodities[

            string.upper(
                tostring(
                    commodityName
                )
            )

        ]

end

--------------------------------------------------
-- Get Current Price
--------------------------------------------------

function FFR_CommodityManager:getCurrentPrice(
    commodityName
)

    local commodity =

        self:getCommodity(
            commodityName
        )

    if commodity == nil then
        return nil
    end

    return

        tonumber(
            commodity.currentPrice
        )

        or 0

end

--------------------------------------------------
-- Print Summary
--------------------------------------------------

function FFR_CommodityManager:printSummary()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR COMMODITY MARKET"
    )

    Logging.info(
        "========================================"
    )

    for commodityName, commodity in pairs(
        self.commodities
    ) do

        Logging.info(
            "%s Native $%.2f | FFR $%.2f | Modifier %.3f",
            tostring(commodityName),
            self:getNumber(
                commodity.nativeBasePrice,
                0
            ),
            self:getNumber(
                commodity.currentPrice,
                0
            ),
            self:getNumber(
                commodity.priceModifier,
                1.00
            )
        )

    end

    Logging.info(
        "FFR Commodity Count: %d",
        self.registeredCount
    )

    Logging.info(
        "Native Prices Found: %d",
        self.nativePriceCount
    )

    Logging.info(
        "Native Prices Unavailable: %d",
        self.fallbackPriceCount
    )

    Logging.info(
        "========================================"
    )

end