FFR_ContinuousAssetSyncManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:new()

    local self = {}

    setmetatable(
        self,
        {
            __index = FFR_ContinuousAssetSyncManager
        }
    )

    --------------------------------------------------
    -- Timing
    --------------------------------------------------

    self.updateTimer = 0

    self.updateInterval = 10000

    --------------------------------------------------
    -- Previous State
    --------------------------------------------------

    self.lastFarmId = nil

    self.lastVehicleCount = -1
    self.lastVehicleValue = -1

    self.lastLandCount = -1
    self.lastLandValue = -1

    self.lastCash = nil

    --------------------------------------------------
    -- Statistics
    --------------------------------------------------

    self.syncCount = 0

    self.vehicleChangeCount = 0

    self.landChangeCount = 0

    self.cashChangeCount = 0

    self.isActive = true

    return self

end

--------------------------------------------------
-- Get Active Farm ID
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:getActiveFarmId()

    if g_FFR ~= nil
        and g_FFR.gameIntegrationManager ~= nil
        and g_FFR.gameIntegrationManager.getActiveFarmId ~= nil
    then

        local farmId =

            g_FFR.gameIntegrationManager:
                getActiveFarmId()

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    if g_currentMission == nil then
        return nil
    end

    if g_currentMission.getFarmId ~= nil then

        local farmId =
            g_currentMission:getFarmId()

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    if g_currentMission.player ~= nil then

        local farmId =
            g_currentMission.player.farmId

        if farmId ~= nil
            and farmId > 0
        then

            return farmId

        end

    end

    return nil

end

--------------------------------------------------
-- Get Mission Vehicles
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:getMissionVehicles()

    if g_currentMission == nil then
        return nil
    end

    if g_currentMission.vehicleSystem ~= nil
        and g_currentMission.vehicleSystem.vehicles ~= nil
    then

        return

            g_currentMission
                .vehicleSystem
                .vehicles

    end

    if g_currentMission.vehicles ~= nil then

        return g_currentMission.vehicles

    end

    return nil

end

--------------------------------------------------
-- Vehicle Ownership
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:isVehicleOwnedByFarm(
    vehicle,
    farmId
)

    if vehicle == nil
        or farmId == nil
    then

        return false

    end

    if vehicle.isDeleted == true then
        return false
    end

    local ownerFarmId = nil

    if vehicle.getOwnerFarmId ~= nil then

        local success,
            result =

            pcall(
                vehicle.getOwnerFarmId,
                vehicle
            )

        if success then

            ownerFarmId =
                tonumber(result)

        end

    elseif vehicle.ownerFarmId ~= nil then

        ownerFarmId =

            tonumber(
                vehicle.ownerFarmId
            )

    end

    if ownerFarmId ~= farmId then
        return false
    end

    --------------------------------------------------
    -- Skip pallets and big bags. They are inventory,
    -- not equipment assets.
    --------------------------------------------------

    local typeName =

        string.lower(
            tostring(
                vehicle.typeName or ""
            )
        )

    if typeName == "pallet"
        or typeName == "bigbag"
    then

        return false

    end

    --------------------------------------------------
    -- Include owned equipment.
    -- Exclude leased equipment from owned assets.
    --------------------------------------------------

    local propertyState = nil

    if vehicle.getPropertyState ~= nil then

        local success,
            result =

            pcall(
                vehicle.getPropertyState,
                vehicle
            )

        if success then

            propertyState =
                tonumber(result)

        end

    end

    if propertyState == nil then

        propertyState =

            tonumber(
                vehicle.propertyState
            )

    end

    if propertyState ~= nil then

        --------------------------------------------------
        -- Compare against the engine enum instead of
        -- hard-coded numbers. The old check treated 3 as
        -- leased, which is the mission-vehicle state, so
        -- leased vehicles were counted as owned assets.
        --------------------------------------------------

        if VehiclePropertyState ~= nil then

            if propertyState == VehiclePropertyState.LEASED
                or propertyState == VehiclePropertyState.MISSION
            then

                return false

            end

        elseif propertyState == 2
            or propertyState == 3
        then

            return false

        end

    end

    return true

end

--------------------------------------------------
-- Get Vehicle Name
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:getVehicleName(
    vehicle
)

    if vehicle == nil then
        return "UNKNOWN"
    end

    if vehicle.getName ~= nil then

        local success,
            result =

            pcall(
                vehicle.getName,
                vehicle
            )

        if success
            and result ~= nil
            and result ~= ""
        then

            return tostring(result)

        end

    end

    if vehicle.configFileName ~= nil then

        return tostring(
            vehicle.configFileName
        )

    end

    return "UNKNOWN"

end

--------------------------------------------------
-- Get Vehicle ID
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:getVehicleId(
    vehicle,
    fallbackIndex
)

    if vehicle == nil then

        return tostring(
            fallbackIndex or "UNKNOWN"
        )

    end

    if vehicle.getUniqueId ~= nil then

        local success,
            result =

            pcall(
                vehicle.getUniqueId,
                vehicle
            )

        if success
            and result ~= nil
            and result ~= ""
        then

            return tostring(result)

        end

    end

    if vehicle.id ~= nil then

        return tostring(
            vehicle.id
        )

    end

    return tostring(
        fallbackIndex or "UNKNOWN"
    )

end

--------------------------------------------------
-- Get Vehicle Value
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:getVehicleValue(
    vehicle
)

    if vehicle == nil then
        return 0
    end

    if vehicle.getSellPrice ~= nil then

        local success,
            result =

            pcall(
                vehicle.getSellPrice,
                vehicle
            )

        if success
            and result ~= nil
        then

            local sellPrice =
                tonumber(result)

            if sellPrice ~= nil
                and sellPrice >= 0
            then

                return sellPrice

            end

        end

    end

    if vehicle.getPrice ~= nil then

        local success,
            result =

            pcall(
                vehicle.getPrice,
                vehicle
            )

        if success
            and result ~= nil
        then

            return

                tonumber(result)

                or 0

        end

    end

    if vehicle.price ~= nil then

        return

            tonumber(
                vehicle.price
            )

            or 0

    end

    return 0

end

--------------------------------------------------
-- Synchronize Vehicles
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:syncVehicles(
    farmId,
    state
)

    if g_FFR == nil
        or state.assetManager == nil
    then

        return false

    end

    local vehicles =
        self:getMissionVehicles()

    if vehicles == nil then
        return false
    end

    local equipmentAssets = {}

    local vehicleCount = 0
    local totalValue = 0

    for vehicleIndex, vehicle in pairs(
        vehicles
    ) do

        if self:isVehicleOwnedByFarm(
            vehicle,
            farmId
        ) then

            local assetId =

                self:getVehicleId(
                    vehicle,
                    vehicleIndex
                )

            local name =

                self:getVehicleName(
                    vehicle
                )

            local value =

                self:getVehicleValue(
                    vehicle
                )

            equipmentAssets[
                assetId
            ] = {

                id = assetId,

                name = name,

                purchasePrice =
                    value,

                marketValue =
                    value,

                ageYears =

                    tonumber(
                        vehicle.age
                    )

                    or 0

            }

            vehicleCount =
                vehicleCount + 1

            totalValue =
                totalValue + value

        end

    end

    state.assetManager.equipmentAssets =
        equipmentAssets

    state.assetManager:updateTotals()

    local changed =

        vehicleCount ~=
            state.sync.lastVehicleCount

        or math.abs(
            totalValue
            - state.sync.lastVehicleValue
        ) >= 1

    if changed then

        Logging.info(
            "FFR Continuous Sync: Equipment changed to %d vehicles, $%d",
            vehicleCount,
            math.floor(totalValue)
        )

        self.vehicleChangeCount =
            self.vehicleChangeCount + 1

    end

    state.sync.lastVehicleCount =
        vehicleCount

    state.sync.lastVehicleValue =
        totalValue

    if g_FFR.gameIntegrationManager ~= nil and farmId == g_FFR.localFarmId then

        g_FFR.gameIntegrationManager
            .totalVehicleValue = totalValue

        g_FFR.gameIntegrationManager
            .vehiclesSynced = true

    end

    return true

end

--------------------------------------------------
-- Farmland Ownership
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:isFarmlandOwnedByFarm(
    farmland,
    farmId,
    farmlandId
)

    if farmland == nil
        or farmId == nil
    then

        return false

    end

    --------------------------------------------------
    -- FS25 tracks ownership in the farmland manager,
    -- not on the farmland object itself.
    --------------------------------------------------

    if g_farmlandManager ~= nil
        and g_farmlandManager.getFarmlandOwner ~= nil
    then

        local success,
            ownerFarmId =

            pcall(
                g_farmlandManager.getFarmlandOwner,
                g_farmlandManager,
                farmland.id or farmlandId
            )

        if success
            and ownerFarmId ~= nil
        then

            -- Rented-out land stays the owner's asset; rented-in land is nobody's
            -- (FFR_LandRentManager).
            local holder = tonumber(ownerFarmId)

            if FFR_LandRentManager ~= nil then
                holder = FFR_LandRentManager.getAssetOwner(tonumber(farmland.id or farmlandId), holder)
            end

            return holder == farmId

        end

    end

    if farmland.farmId ~= nil then

        return

            tonumber(
                farmland.farmId
            )

            == farmId

    end

    if farmland.ownerFarmId ~= nil then

        return

            tonumber(
                farmland.ownerFarmId
            )

            == farmId

    end

    return false

end

--------------------------------------------------
-- Synchronize Farmland
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:syncFarmland(
    farmId,
    state
)

    if g_FFR == nil
        or state.assetManager == nil
        or g_farmlandManager == nil
        or g_farmlandManager.farmlands == nil
    then

        return false

    end

    local landAssets = {}

    local landCount = 0
    local totalValue = 0

    for farmlandId, farmland in pairs(
        g_farmlandManager.farmlands
    ) do

        if self:isFarmlandOwnedByFarm(
            farmland,
            farmId,
            farmlandId
        ) then

            local value =

                tonumber(
                    farmland.price
                )

                or 0

            landAssets[
                farmlandId
            ] = {

                id = farmlandId,

                acres = 0,

                marketValue =
                    value,

                originalValue =
                    value

            }

            landCount =
                landCount + 1

            totalValue =
                totalValue + value

        end

    end

    state.assetManager.landAssets =
        landAssets

    --------------------------------------------------
    -- Re-apply registered land-title values right away
    -- so net worth does not drop back to book value
    -- until the registry's next update.
    --------------------------------------------------

    if g_FFRLandRegistryManager ~= nil
        and g_FFRLandRegistryManager.applyValuations ~= nil
    then

        g_FFRLandRegistryManager:applyValuations()

    end

    state.assetManager:updateTotals()

    local changed =

        landCount ~=
            state.sync.lastLandCount

        or math.abs(
            totalValue
            - state.sync.lastLandValue
        ) >= 1

    if changed then

        Logging.info(
            "FFR Continuous Sync: Land changed to %d parcels, $%d",
            landCount,
            math.floor(totalValue)
        )

        self.landChangeCount =
            self.landChangeCount + 1

    end

    state.sync.lastLandCount =
        landCount

    state.sync.lastLandValue =
        totalValue

    if g_FFR.gameIntegrationManager ~= nil and farmId == g_FFR.localFarmId then

        g_FFR.gameIntegrationManager
            .totalFarmlandValue = totalValue

        g_FFR.gameIntegrationManager
            .landSynced = true

    end

    return true

end

--------------------------------------------------
-- Synchronize Cash
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:syncCash(
    farmId,
    state
)

    if g_FFR == nil
        or state.financialManager == nil
        or g_farmManager == nil
        or g_farmManager.getFarmById == nil
    then

        return false

    end

    local farm =

        g_farmManager:getFarmById(
            farmId
        )

    if farm == nil
        or farm.money == nil
    then

        return false

    end

    local currentCash =

        tonumber(
            farm.money
        )

        or 0

    local changed =

        state.sync.lastCash == nil

        or math.abs(
            currentCash
            - state.sync.lastCash
        ) >= 1

    state.financialManager.cashOnHand =
        currentCash

    if changed then

        if state.sync.lastCash ~= nil then

            Logging.info(
                "FFR Continuous Sync: Cash changed from $%d to $%d",
                math.floor(state.sync.lastCash),
                math.floor(currentCash)
            )

        end

        self.cashChangeCount =
            self.cashChangeCount + 1

    end

    state.sync.lastCash =
        currentCash

    if g_FFR.gameIntegrationManager ~= nil and farmId == g_FFR.localFarmId then

        g_FFR.gameIntegrationManager
            .moneySynced = true

    end

    return true

end

--------------------------------------------------
-- Push Current Totals
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:updateFinancialTotals(state)

    if g_FFR == nil
        or state.assetManager == nil
        or state.financialManager == nil
    then

        return

    end

    state.assetManager:updateTotals()

    state.assetManager:updateFinancialManager(
        state.financialManager
    )

    state.financialManager:update()

end

--------------------------------------------------
-- Run Continuous Synchronization
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:runSync()

    if g_FFR == nil
        or not g_FFR.isInitialized
        or g_FFR.isDeleted
        or g_FFR.getFarmStates == nil
    then

        return false

    end

    --------------------------------------------------
    -- Every farm's assets and cash, each into its own
    -- financial profile.
    --------------------------------------------------

    for _, state in ipairs(g_FFR:getFarmStates()) do

        local farmId = state.farmId

        state.sync.lastVehicleCount = state.sync.lastVehicleCount or -1
        state.sync.lastVehicleValue = state.sync.lastVehicleValue or -1
        state.sync.lastLandCount = state.sync.lastLandCount or -1
        state.sync.lastLandValue = state.sync.lastLandValue or -1

        self:syncVehicles(farmId, state)

        self:syncFarmland(farmId, state)

        self:syncCash(farmId, state)

        self:updateFinancialTotals(state)

    end

    self.lastFarmId =
        g_FFR.localFarmId

    self.syncCount =
        self.syncCount + 1

    return true

end

--------------------------------------------------
-- Mod Event Listener Update
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:update(
    dt
)

    if not self.isActive then
        return
    end

    --------------------------------------------------
    -- Assets are valued on the server; clients get
    -- the totals in the network sync.
    --------------------------------------------------

    if FFR_Network ~= nil
        and FFR_Network.isClientOnly()
    then

        return

    end

    self.updateTimer =

        self.updateTimer + dt

    if self.updateTimer <
        self.updateInterval
    then

        return

    end

    self.updateTimer = 0

    self:runSync()

end

--------------------------------------------------
-- Required Listener Methods
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:loadMap(
    mapName
)

    self.updateTimer = 0

    self.lastVehicleCount = -1
    self.lastVehicleValue = -1

    self.lastLandCount = -1
    self.lastLandValue = -1

    self.lastCash = nil

end

function FFR_ContinuousAssetSyncManager:deleteMap()

    self.updateTimer = 0

    self.lastFarmId = nil

    self.lastVehicleCount = -1
    self.lastVehicleValue = -1

    self.lastLandCount = -1
    self.lastLandValue = -1

    self.lastCash = nil

end

function FFR_ContinuousAssetSyncManager:draw()

end

function FFR_ContinuousAssetSyncManager:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)

end

function FFR_ContinuousAssetSyncManager:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)

end

--------------------------------------------------
-- Report
--------------------------------------------------

function FFR_ContinuousAssetSyncManager:printReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR CONTINUOUS ASSET SYNC"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Sync Runs: %d",
        self.syncCount
    )

    Logging.info(
        "Vehicle Changes: %d",
        self.vehicleChangeCount
    )

    Logging.info(
        "Land Changes: %d",
        self.landChangeCount
    )

    Logging.info(
        "Cash Changes: %d",
        self.cashChangeCount
    )

    Logging.info(
        "Equipment: %d vehicles, $%d",
        math.max(
            self.lastVehicleCount,
            0
        ),
        math.floor(
            math.max(
                self.lastVehicleValue,
                0
            )
        )
    )

    Logging.info(
        "Land: %d parcels, $%d",
        math.max(
            self.lastLandCount,
            0
        ),
        math.floor(
            math.max(
                self.lastLandValue,
                0
            )
        )
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Create Global Listener
--------------------------------------------------

g_FFRContinuousAssetSyncManager =

    FFR_ContinuousAssetSyncManager:new()

addModEventListener(
    g_FFRContinuousAssetSyncManager
)

Logging.info(
    "FFR Continuous Asset Sync: Listener installed"
)
