FFR_ContractManager = {}

--------------------------------------------------
-- Forward Contracts (cash forward contracts with a buyer)
--
-- Modelled on real elevator contracts:
--
-- * Signed with one buyer (a selling station) for a
--   volume and a delivery month. Nothing is paid at
--   signing.
-- * Forward price = the buyer's native price (FFR
--   event effect removed) x the event's projected
--   effect at delivery x a small carry for storage.
--   It can be above or below today's spot price.
-- * Only sales to that buyer count. Each delivery is
--   paid the locked price; anything beyond the
--   contract gets the normal spot price.
-- * Short at the deadline: the farm pays a buyout =
--   any rise of the buyer's live price above the
--   locked price on the shortfall, plus a buyout fee.
--   It is recorded as a contract default and that
--   buyer refuses new contracts for a while.
-- * A contract can be rolled to a later month for a
--   fee, or bought out early with no default.
-- * Delivery calls (v0.9.61, user): the buyer does not
--   take the whole volume at once. At signing the
--   volume is split into 2-4 calls, 2-3 months apart,
--   starting in the month the player picked; earlier
--   calls are random shares, the last one is the rest,
--   so they always add up to the volume. A call is open
--   for its month and the next (CALL_WINDOW). Only the
--   open call's amount is taken at the locked price;
--   more is paid at spot. A call that closes short is
--   settled like a buyout (price rise + fee) on what is
--   missing and marked late on credit; the contract
--   goes on. Short at the last call = contract default.
--   Contracts from older saves have no calls and keep
--   the single deadline.
--
-- Balance values below.
--------------------------------------------------

FFR_ContractManager.CALL_MIN = 2
FFR_ContractManager.CALL_MAX = 4
FFR_ContractManager.CALL_GAP_MIN = 2
FFR_ContractManager.CALL_GAP_MAX = 3
FFR_ContractManager.CALL_WINDOW = 2
-- Each earlier call takes this share of the volume (random); the last gets the rest.
FFR_ContractManager.CALL_SHARE_MIN = 0.15
FFR_ContractManager.CALL_SHARE_MAX = 0.40
-- A call is never smaller than this (smaller contracts get fewer calls).
FFR_ContractManager.CALL_MIN_VOLUME = 10000

FFR_ContractManager.VOLUME_STEP = 10000
FFR_ContractManager.MIN_VOLUME = 10000
FFR_ContractManager.MAX_VOLUME = 2000000
FFR_ContractManager.DEFAULT_VOLUME = 100000

-- Carry: forward prices include storage/interest cost to the delivery month.
FFR_ContractManager.CARRY_PER_MONTH = 0.005
FFR_ContractManager.MAX_CARRY = 0.06

-- Forward contracts cover the current crop, next harvest or the one after
-- (24 months, decided by the user in v0.9.43; carry still stops at MAX_CARRY). Note: the FS25 year starts in March, so "January, Year 2" comes after
-- "October, Year 2"; the dashboard shows months ahead to avoid confusion.
FFR_ContractManager.MIN_MONTHS_AHEAD = 1
FFR_ContractManager.MAX_MONTHS_AHEAD = 24
FFR_ContractManager.DEFAULT_MONTHS_AHEAD = 6

-- Buyout fee, as a share of the shortfall's contract value.
FFR_ContractManager.BUYOUT_FEE = 0.05

-- Months a buyer refuses new contracts after a default.
FFR_ContractManager.DEFAULT_COOLDOWN_MONTHS = 3

-- Roll: fee as a share of the remaining contract value, per month rolled.
FFR_ContractManager.ROLL_FEE = 0.02
FFR_ContractManager.MAX_ROLLS = 2

FFR_ContractManager.MAX_ACTIVE = 6

-- Fulfilled, defaulted and bought-out contracts stay listed this many months.
FFR_ContractManager.KEEP_FINISHED_MONTHS = 3

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_ContractManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_ContractManager}
    )

    self.contracts = {}

    self.nextId = 1

    -- "farmId|buyerKey" -> calendar serial until which that buyer refuses new contracts
    self.blockedUntil = {}

    self.completedContracts = 0

    self.defaultedContracts = 0

    self.totalPenaltiesPaid = 0

    self.totalSettlement = 0

    -- farmId -> lifetime record for that farm (see getHistory).
    self.history = {}

    return self

end

--------------------------------------------------
-- Per-farm contract record
--
-- Kept after finished contracts drop off the list:
-- counts by outcome, litres delivered under
-- contract, what the contract prices earned over
-- the spot price at delivery, and fees paid (rolls
-- and buyouts).
--------------------------------------------------

function FFR_ContractManager:getHistory(farmId)

    local key = tonumber(farmId) or 0

    local history = self.history[key]

    if history == nil then

        history = {fulfilled = 0, boughtOut = 0, defaulted = 0, delivered = 0, premium = 0, fees = 0}

        self.history[key] = history

    end

    return history

end

-- One line for the Deals page, or nil before the farm's first contract ends.
function FFR_ContractManager:getHistoryText(farmId)

    local h = self:getHistory(farmId)

    if h.fulfilled + h.boughtOut + h.defaulted == 0 and h.delivered <= 0 then
        return nil
    end

    local premium = tonumber(h.premium) or 0

    return FFR_L10n.t(
        "ffr_contract_record",
        h.fulfilled, h.boughtOut, h.defaulted,
        premium >= 0 and "+" or "", self:formatMoney(premium),
        self:formatMoney(h.fees)
    )

end

--------------------------------------------------
-- Calendar
--------------------------------------------------

function FFR_ContractManager:getCalendar()

    if g_currentMission == nil
        or g_currentMission.environment == nil
    then

        return nil, nil

    end

    local period =
        tonumber(g_currentMission.environment.currentPeriod)

    local year =
        tonumber(g_currentMission.environment.currentYear)

    if period == nil or year == nil then
        return nil, nil
    end

    return period, year

end

function FFR_ContractManager:getSerial(period, year)

    return (tonumber(year) or 0) * 12 + (tonumber(period) or 0)

end

function FFR_ContractManager:getCurrentSerial()

    local period, year = self:getCalendar()

    if period == nil then
        return nil
    end

    return self:getSerial(period, year)

end

function FFR_ContractManager:addMonths(period, year, months)

    local serial =
        self:getSerial(period, year) + (tonumber(months) or 0)

    local resultYear =
        math.floor((serial - 1) / 12)

    return serial - resultYear * 12, resultYear

end

function FFR_ContractManager:getMonthName(period)

    return FFR_L10n.monthName(period)

end

function FFR_ContractManager:getDeadlineText(contract)

    return FFR_L10n.date(contract.deadlinePeriod, contract.deadlineYear)

end

--------------------------------------------------
-- Commodities and Buyers
--------------------------------------------------

function FFR_ContractManager:getCommodity(name)

    if g_FFR == nil
        or g_FFR.commodityManager == nil
    then

        return nil

    end

    return g_FFR.commodityManager:getCommodity(name)

end

-- Stations that accept the commodity, best price first (rows from the station price reader).
function FFR_ContractManager:getBuyers(commodity)

    if commodity == nil
        or g_FFRStationPriceManager == nil
    then

        return {}

    end

    local rows = g_FFRStationPriceManager:getPriceRows(commodity.index) or {}

    local buyers = {}

    for _, row in ipairs(rows) do

        if row.key ~= nil then
            table.insert(buyers, row)
        end

    end

    return buyers

end

-- Commodities that at least one buyer on this map accepts, by name.
function FFR_ContractManager:getContractableCommodities()

    local list = {}

    if g_FFR == nil
        or g_FFR.commodityManager == nil
    then

        return list

    end

    for _, commodity in pairs(g_FFR.commodityManager.commodities or {}) do

        if (tonumber(commodity.currentPrice) or 0) > 0
            and #self:getBuyers(commodity) > 0
        then

            table.insert(list, commodity)

        end

    end

    table.sort(
        list,
        function(a, b)
            return tostring(a.name) < tostring(b.name)
        end
    )

    return list

end

-- The buyer's live price per 1,000 L (FFR-adjusted, as it would pay today).
-- Falls back to the FFR commodity price if the buyer is gone.
function FFR_ContractManager:getBuyerPrice(contract)

    if g_FFRStationPriceManager ~= nil
        and contract.buyerKey ~= nil
    then

        local station = g_FFRStationPriceManager:findStationByKey(contract.buyerKey)

        if station ~= nil
            and station.getEffectiveFillTypePrice ~= nil
        then

            local ok, price = pcall(station.getEffectiveFillTypePrice, station, contract.fillTypeIndex)

            price = tonumber(price)

            if ok and price ~= nil and price > 0 then
                return price * 1000
            end

        end

    end

    local commodity = self:getCommodity(contract.commodity)

    return commodity ~= nil and (tonumber(commodity.currentPrice) or 0) or 0

end

function FFR_ContractManager:getCarry(monthsAhead)

    return math.min(
        FFR_ContractManager.MAX_CARRY,
        FFR_ContractManager.CARRY_PER_MONTH * (tonumber(monthsAhead) or 0)
    )

end

--------------------------------------------------
-- Quote
--
-- buyerIndex picks from getBuyers(); returns nil
-- when the commodity has no buyer.
--------------------------------------------------

function FFR_ContractManager:getQuote(
    commodityName,
    buyerIndex,
    volume,
    monthsAhead
)

    local period, year = self:getCalendar()

    if period == nil
        or commodityName == nil
    then

        return nil

    end

    local commodity = self:getCommodity(commodityName)

    if commodity == nil then
        return nil
    end

    local buyers = self:getBuyers(commodity)

    if #buyers == 0 then
        return nil
    end

    local index = math.max(1, math.min(#buyers, tonumber(buyerIndex) or 1))

    local buyer = buyers[index]

    local months =
        math.max(
            FFR_ContractManager.MIN_MONTHS_AHEAD,
            math.min(FFR_ContractManager.MAX_MONTHS_AHEAD, tonumber(monthsAhead) or 1)
        )

    local liters =
        math.max(
            FFR_ContractManager.MIN_VOLUME,
            math.min(FFR_ContractManager.MAX_VOLUME, tonumber(volume) or 0)
        )

    --------------------------------------------------
    -- Native price with the current FFR event effect
    -- removed, then the event's expected effect at the
    -- delivery month applied, plus carry.
    --------------------------------------------------

    local projected = 1.00

    if g_FFR ~= nil
        and g_FFR.marketEngine ~= nil
        and g_FFR.marketEngine.getProjectedModifier ~= nil
    then

        projected = g_FFR.marketEngine:getProjectedModifier(commodity.category, months)

    end

    local carry = self:getCarry(months)

    local spotPrice = tonumber(buyer.ffrPrice) or 0

    local lockedPrice = (tonumber(buyer.nativePrice) or 0) * projected * (1 + carry)

    local deadlinePeriod, deadlineYear =
        self:addMonths(period, year, months)

    return {
        commodity = commodity.name,
        fillTypeIndex = commodity.index,
        buyerKey = buyer.key,
        buyerName = buyer.name,
        buyerIndex = index,
        buyerCount = #buyers,
        volume = liters,
        monthsAhead = months,
        spotPrice = spotPrice,
        lockedPrice = lockedPrice,
        versusSpot = spotPrice > 0 and (lockedPrice / spotPrice - 1) or 0,
        projectedModifier = projected,
        currentModifier = tonumber(buyer.modifier) or 1.00,
        carry = carry,
        value = liters / 1000 * lockedPrice,
        deadlinePeriod = deadlinePeriod,
        deadlineYear = deadlineYear
    }

end

--------------------------------------------------
-- Contract Lists
--------------------------------------------------

function FFR_ContractManager:getActive(farmId)

    local list = {}

    for _, contract in ipairs(self.contracts) do

        if contract.status == "OPEN"
            and (farmId == nil or contract.farmId == farmId)
        then

            table.insert(list, contract)

        end

    end

    table.sort(
        list,
        function(a, b)

            local sa = self:getSerial(a.deadlinePeriod, a.deadlineYear)
            local sb = self:getSerial(b.deadlinePeriod, b.deadlineYear)

            if sa ~= sb then
                return sa < sb
            end

            return a.id < b.id

        end
    )

    return list

end

-- Open contracts by deadline, then recently finished ones, newest first.
function FFR_ContractManager:getListed(farmId)

    local list = self:getActive(farmId)

    local finished = {}

    for _, contract in ipairs(self.contracts) do

        if contract.status ~= "OPEN"
            and (farmId == nil or contract.farmId == farmId)
        then

            table.insert(finished, contract)

        end

    end

    table.sort(
        finished,
        function(a, b)
            return (tonumber(a.finishedSerial) or 0) > (tonumber(b.finishedSerial) or 0)
        end
    )

    for _, contract in ipairs(finished) do
        table.insert(list, contract)
    end

    return list

end

-- Still to deliver: the volume less deliveries and missed calls already settled.
function FFR_ContractManager:getRemaining(contract)

    return math.max(
        0,
        (tonumber(contract.volume) or 0) - (tonumber(contract.delivered) or 0) - (tonumber(contract.settled) or 0)
    )

end

--------------------------------------------------
-- Delivery calls
--------------------------------------------------

-- 2-4 calls from the first month: random shares, the last is the remainder.
function FFR_ContractManager:buildCalls(volume, firstPeriod, firstYear)

    local m = FFR_ContractManager
    local count = math.random(m.CALL_MIN, m.CALL_MAX)
    count = math.max(1, math.min(count, math.floor(volume / m.CALL_MIN_VOLUME)))

    local calls = {}
    local period, year = firstPeriod, firstYear
    local left = volume
    local step = m.VOLUME_STEP / 10

    for i = 1, count do

        local amount = left

        if i < count then
            local share = m.CALL_SHARE_MIN + math.random() * (m.CALL_SHARE_MAX - m.CALL_SHARE_MIN)
            amount = math.floor(volume * share / step + 0.5) * step
            -- Leave at least the minimum for every call still to come.
            amount = math.max(m.CALL_MIN_VOLUME, math.min(amount, left - (count - i) * m.CALL_MIN_VOLUME))
        end

        table.insert(calls, {serial = self:getSerial(period, year), volume = amount, delivered = 0, status = "OPEN"})
        left = left - amount

        period, year = self:addMonths(period, year, math.random(m.CALL_GAP_MIN, m.CALL_GAP_MAX))

    end

    return calls

end

-- Last month a call can be delivered (its month and the next).
function FFR_ContractManager:getCallEnd(call)

    return (tonumber(call.serial) or 0) + FFR_ContractManager.CALL_WINDOW - 1

end

function FFR_ContractManager:getCallRemaining(call)

    return math.max(0, (tonumber(call.volume) or 0) - (tonumber(call.delivered) or 0))

end

-- UPCOMING, ACTIVE, COMPLETED, MISSED (or SETTLED by a buyout).
function FFR_ContractManager:getCallStatus(call)

    if call.status == "COMPLETED" or call.status == "MISSED" or call.status == "SETTLED" then
        return call.status
    end

    local serial = self:getCurrentSerial() or 0

    if serial < (tonumber(call.serial) or 0) then
        return "UPCOMING"
    end

    return "ACTIVE"

end

-- The call open for deliveries now, or nil.
function FFR_ContractManager:getActiveCall(contract)

    for _, call in ipairs(contract.calls or {}) do
        if self:getCallStatus(call) == "ACTIVE" then return call end
    end

    return nil

end

-- How much of a delivery this contract takes now: the open call's rest
-- (contracts without calls: everything still owed).
function FFR_ContractManager:getDeliverable(contract)

    if contract.calls == nil or #contract.calls == 0 then
        return self:getRemaining(contract)
    end

    local call = self:getActiveCall(contract)

    return call ~= nil and math.min(self:getCallRemaining(call), self:getRemaining(contract)) or 0

end

-- The next call not yet closed (open or upcoming), or nil.
function FFR_ContractManager:getNextCall(contract)

    for _, call in ipairs(contract.calls or {}) do
        local status = self:getCallStatus(call)
        if status == "ACTIVE" or status == "UPCOMING" then return call end
    end

    return nil

end

-- One line per contract for the Deals page: "Nov Y2 85,000 bu Completed | ...".
function FFR_ContractManager:getCallsText(contract)

    local parts = {}

    for _, call in ipairs(contract.calls or {}) do

        local serial = tonumber(call.serial) or 0
        local year = math.floor((serial - 1) / 12)
        local status = self:getCallStatus(call)
        local amount = FFR_UnitManager.formatAmount(call.volume, contract.commodity)
        local state = FFR_L10n.t("ffr_contract_call_" .. string.lower(status))

        if status == "ACTIVE" then
            state = FFR_L10n.t("ffr_contract_call_active_left",
                FFR_UnitManager.formatAmount(self:getCallRemaining(call), contract.commodity))
        end

        table.insert(parts, FFR_L10n.t("ffr_contract_call_line", FFR_L10n.dateShort(serial - year * 12, year), amount, state))

    end

    return table.concat(parts, "  |  ")

end

-- A call whose window closed short (not the last): buyout on what is missing and a
-- late mark; the contract goes on. Returns the amount charged.
function FFR_ContractManager:settleMissedCall(contract, call)

    local shortfall = math.min(self:getCallRemaining(call), self:getRemaining(contract))
    local tons = shortfall / 1000
    local locked = tonumber(contract.lockedPrice) or 0
    local live = self:getBuyerPrice(contract)
    local fee = tonumber(contract.buyoutFee) or FFR_ContractManager.BUYOUT_FEE
    local cost = tons * math.max(0, live - locked) + tons * locked * fee

    -- Charged even if it overdraws the farm: the insolvency ladder handles that.
    if cost > 0 then self:chargeFarm(contract.farmId, cost) end

    call.status = "MISSED"
    call.settled = shortfall
    contract.settled = (tonumber(contract.settled) or 0) + shortfall
    contract.penaltyPaid = (tonumber(contract.penaltyPaid) or 0) + cost
    self.totalPenaltiesPaid = self.totalPenaltiesPaid + cost

    local history = self:getHistory(contract.farmId)
    history.fees = history.fees + cost

    local state = self:getFarmState(contract.farmId)
    if state ~= nil then state.creditManager:addLatePayment() end

    Logging.warning("FFR Contract %d: Delivery call missed, %d L short, settled $%d", contract.id, math.floor(shortfall), math.floor(cost))

    local text = FFR_L10n.t("ffr_contract_call_missed_news",
        FFR_UnitManager.formatAmount(shortfall, contract.commodity), self:formatName(contract.commodity),
        tostring(contract.buyerName or FFR_L10n.t("ffr_contract_the_buyer")), self:formatMoney(cost))
    self:addNews(text)
    if FFR_Network ~= nil then FFR_Network.sendNotice("CROP_DAMAGE", contract.farmId, {text = text}) end

    return cost

end

-- What settling the shortfall would cost right now: any rise of the buyer's
-- price above the locked price, plus the buyout fee.
function FFR_ContractManager:getBuyoutCost(contract)

    local shortfall = self:getRemaining(contract) / 1000

    local locked = tonumber(contract.lockedPrice) or 0

    local live = self:getBuyerPrice(contract)

    local fee = tonumber(contract.buyoutFee) or FFR_ContractManager.BUYOUT_FEE

    return shortfall * math.max(0, live - locked) + shortfall * locked * fee

end

function FFR_ContractManager:getExposure(contract)

    return self:getBuyoutCost(contract)

end

-- OPEN, DUE, FULFILLED, BOUGHT OUT or DEFAULTED (colours on the Deals page).
function FFR_ContractManager:getStatusCode(contract)

    if contract.status ~= "OPEN" then
        return contract.status
    end

    -- With delivery calls: due while a call is open.
    if contract.calls ~= nil and #contract.calls > 0 then
        return self:getActiveCall(contract) ~= nil and "DUE" or "OPEN"
    end

    local serial = self:getCurrentSerial()

    if serial ~= nil
        and serial == self:getSerial(contract.deadlinePeriod, contract.deadlineYear)
    then

        return "DUE"

    end

    return "OPEN"

end

FFR_ContractManager.STATUS_KEYS = {
    OPEN = "ffr_contract_status_open",
    DUE = "ffr_contract_status_due",
    FULFILLED = "ffr_contract_status_fulfilled",
    ["BOUGHT OUT"] = "ffr_contract_status_boughtout",
    DEFAULTED = "ffr_contract_status_defaulted"
}

function FFR_ContractManager:getStatusText(contract)

    local code = self:getStatusCode(contract)
    local key = FFR_ContractManager.STATUS_KEYS[code]

    return key ~= nil and FFR_L10n.t(key) or tostring(code)

end

-- Fixed text of the accepted terms, built once at signing.
function FFR_ContractManager:buildSummary(contract)

    return FFR_L10n.t(
        "ffr_contract_summary",
        self:formatName(contract.commodity),
        FFR_UnitManager.formatAmount(contract.volume, contract.commodity),
        FFR_UnitManager.formatPrice(contract.lockedPrice, contract.commodity),
        self:formatMoney(contract.value),
        tostring(contract.buyerName or FFR_L10n.t("ffr_contract_any_buyer")),
        self:getDeadlineText(contract)
    )

end

--------------------------------------------------
-- Money
--
-- Charges the farm for a contract cost and books
-- it as an expense (the revenue tracker skips FFR's
-- own charges, so it is booked here).
--------------------------------------------------

-- The financial profile of the farm a contract belongs to.
function FFR_ContractManager:getFarmState(farmId)

    if g_FFR == nil
        or g_FFR.getFarmState == nil
    then

        return nil

    end

    return g_FFR:getFarmState(farmId)

end

function FFR_ContractManager:chargeFarm(farmId, amount)

    if amount <= 0 then
        return true
    end

    if g_FFRMonthlyFinancialProcessor == nil
        or not g_FFRMonthlyFinancialProcessor:applyFarmBalance(-amount, nil, farmId)
    then

        return false

    end

    local state = self:getFarmState(farmId)

    local financial = state ~= nil and state.financialManager or nil

    if financial ~= nil then

        financial.monthlyExpenses = (tonumber(financial.monthlyExpenses) or 0) + amount
        financial.annualExpenses = (tonumber(financial.annualExpenses) or 0) + amount
        financial:updateAnnualProfit()

    end

    if g_FFR ~= nil and g_FFR.saveManager ~= nil then
        g_FFR.saveManager:requestSave(g_FFR)
    end

    return true

end

function FFR_ContractManager:addNews(text)

    if g_FFR ~= nil and g_FFR.newsSystem ~= nil then
        g_FFR.newsSystem:addNewsItem(text)
    end

end

--------------------------------------------------
-- Create
--------------------------------------------------

function FFR_ContractManager:getBlockKey(farmId, buyerKey)

    return tostring(farmId) .. "|" .. tostring(buyerKey)

end

function FFR_ContractManager:canCreate(farmId, buyerKey)

    if farmId == nil then
        return false, FFR_L10n.t("ffr_msg_no_farm")
    end

    local serial = self:getCurrentSerial()

    local blockedUntil = tonumber(self.blockedUntil[self:getBlockKey(farmId, buyerKey)]) or 0

    if serial ~= nil and serial < blockedUntil then

        return false, FFR_L10n.t(
            "ffr_contract_blocked",
            FFR_L10n.months(blockedUntil - serial)
        )

    end

    if #self:getActive(farmId) >= FFR_ContractManager.MAX_ACTIVE then

        return false, FFR_L10n.t(
            "ffr_contract_limit",
            FFR_ContractManager.MAX_ACTIVE
        )

    end

    return true

end

function FFR_ContractManager:createContract(
    farmId,
    quote
)

    if quote == nil
        or quote.lockedPrice == nil
        or quote.lockedPrice <= 0
    then

        return false, FFR_L10n.t("ffr_contract_no_offer")

    end

    local ok, message = self:canCreate(farmId, quote.buyerKey)

    if not ok then
        return false, message
    end

    --------------------------------------------------
    -- The quote is a snapshot. If the month rolled
    -- over while it was on screen, its deadline may
    -- already be due or past.
    --------------------------------------------------

    local serial = self:getCurrentSerial()

    if serial ~= nil
        and self:getSerial(quote.deadlinePeriod, quote.deadlineYear) <= serial
    then

        return false, FFR_L10n.t("ffr_contract_month_passed")

    end

    local contract = {
        id = self.nextId,
        farmId = farmId,
        commodity = quote.commodity,
        fillTypeIndex = quote.fillTypeIndex,
        buyerKey = quote.buyerKey,
        buyerName = quote.buyerName,
        volume = quote.volume,
        delivered = 0,
        lockedPrice = quote.lockedPrice,
        value = quote.volume / 1000 * quote.lockedPrice,
        buyoutFee = FFR_ContractManager.BUYOUT_FEE,
        deadlinePeriod = quote.deadlinePeriod,
        deadlineYear = quote.deadlineYear,
        rolls = 0,
        status = "OPEN",
        penaltyPaid = 0,
        settled = 0
    }

    -- The picked month is the first delivery call; the deadline is the last call's window end.
    contract.calls = self:buildCalls(contract.volume, quote.deadlinePeriod, quote.deadlineYear)
    local lastEnd = self:getCallEnd(contract.calls[#contract.calls])
    contract.deadlineYear = math.floor((lastEnd - 1) / 12)
    contract.deadlinePeriod = lastEnd - contract.deadlineYear * 12

    contract.summary = self:buildSummary(contract)

    self.nextId = self.nextId + 1

    table.insert(
        self.contracts,
        contract
    )

    Logging.info(
        "FFR Contract %d: %s %d L to %s at $%.2f / 1,000 L, due %s",
        contract.id,
        contract.commodity,
        contract.volume,
        tostring(contract.buyerName),
        contract.lockedPrice,
        self:getDeadlineText(contract)
    )

    return true, contract.summary

end

--------------------------------------------------
-- Deliveries
--
-- Counts a sale toward the farm's open contracts
-- with that buyer, oldest deadline first. Returns
-- the money adjustment that brings the counted
-- litres to the locked price. Contracts without a
-- buyer (signed before v0.9.5) accept any station.
--------------------------------------------------

-- Without changing anything: how many of these litres the farm's open contracts
-- with this buyer would take, and what they are worth at the locked prices.
function FFR_ContractManager:planDelivery(
    farmId,
    fillTypeIndex,
    liters,
    stationKey
)

    local left = tonumber(liters) or 0

    local applied = 0

    local lockedValue = 0

    for _, contract in ipairs(self:getActive(farmId)) do

        if left <= 0 then
            break
        end

        if contract.fillTypeIndex == fillTypeIndex
            and (contract.buyerKey == nil or contract.buyerKey == stationKey)
        then

            -- Only the open delivery call is taken at the locked price.
            local take = math.min(left, self:getDeliverable(contract))

            applied = applied + take

            lockedValue = lockedValue + take * (tonumber(contract.lockedPrice) or 0) / 1000

            left = left - take

        end

    end

    return applied, lockedValue

end

function FFR_ContractManager:recordDelivery(
    farmId,
    fillTypeIndex,
    liters,
    unitPricePerLiter,
    stationKey
)

    local left = tonumber(liters) or 0

    local adjustment = 0

    if left <= 0 then
        return 0
    end

    for _, contract in ipairs(self:getActive(farmId)) do

        if left <= 0 then
            break
        end

        if contract.fillTypeIndex == fillTypeIndex
            and (contract.buyerKey == nil or contract.buyerKey == stationKey)
        then

            local applied =
                math.min(left, self:getDeliverable(contract))

            if applied > 0 then

                contract.delivered =
                    (tonumber(contract.delivered) or 0) + applied

                local call = self:getActiveCall(contract)

                if call ~= nil then
                    call.delivered = (tonumber(call.delivered) or 0) + applied
                    if self:getCallRemaining(call) <= 0 then
                        call.status = "COMPLETED"
                        Logging.info("FFR Contract %d: Delivery call of %d L completed", contract.id, math.floor(call.volume))
                    end
                end

                local gain = applied * (contract.lockedPrice / 1000 - (tonumber(unitPricePerLiter) or 0))

                adjustment = adjustment + gain

                local history = self:getHistory(contract.farmId)

                history.delivered = history.delivered + applied

                history.premium = history.premium + gain

                left = left - applied

                if self:getRemaining(contract) <= 0 then

                    contract.status = "FULFILLED"

                    contract.finishedSerial = self:getCurrentSerial() or 0

                    self.completedContracts =
                        self.completedContracts + 1

                    history.fulfilled = history.fulfilled + 1

                    Logging.info(
                        "FFR Contract %d: Fulfilled",
                        contract.id
                    )

                    self:addNews(FFR_L10n.t(
                        "ffr_contract_news_fulfilled",
                        FFR_UnitManager.formatAmount(contract.volume, contract.commodity),
                        self:formatName(contract.commodity),
                        tostring(contract.buyerName or FFR_L10n.t("ffr_contract_the_buyer"))
                    ))

                end

            end

        end

    end

    self.totalSettlement =
        self.totalSettlement + adjustment

    return adjustment

end

--------------------------------------------------
-- Roll
--
-- Moves an open contract one month later for a fee.
--------------------------------------------------

function FFR_ContractManager:rollContract(contract)

    if contract == nil
        or contract.status ~= "OPEN"
    then

        return false, FFR_L10n.t("ffr_contract_select_roll")

    end

    if (tonumber(contract.rolls) or 0) >= FFR_ContractManager.MAX_ROLLS then

        return false, FFR_L10n.t(
            "ffr_contract_max_rolls",
            FFR_ContractManager.MAX_ROLLS
        )

    end

    local fee =
        self:getRemaining(contract) / 1000
        * (tonumber(contract.lockedPrice) or 0)
        * FFR_ContractManager.ROLL_FEE

    if not self:chargeFarm(contract.farmId, fee) then
        return false, FFR_L10n.t("ffr_contract_roll_failed")
    end

    contract.deadlinePeriod, contract.deadlineYear =
        self:addMonths(contract.deadlinePeriod, contract.deadlineYear, 1)

    -- The open and upcoming delivery calls move with it.
    for _, call in ipairs(contract.calls or {}) do
        local status = self:getCallStatus(call)
        if status == "ACTIVE" or status == "UPCOMING" then call.serial = (tonumber(call.serial) or 0) + 1 end
    end

    contract.rolls = (tonumber(contract.rolls) or 0) + 1

    contract.penaltyPaid = (tonumber(contract.penaltyPaid) or 0) + fee

    local history = self:getHistory(contract.farmId)

    history.fees = history.fees + fee

    Logging.info(
        "FFR Contract %d: Rolled to %s for $%d",
        contract.id,
        self:getDeadlineText(contract),
        math.floor(fee)
    )

    return true, FFR_L10n.t(
        "ffr_contract_rolled",
        self:getDeadlineText(contract),
        self:formatMoney(fee)
    )

end

--------------------------------------------------
-- Buyout
--
-- Settles the undelivered volume. Early buyouts are
-- an agreed cancellation; at the deadline it is a
-- default, recorded on credit and with the buyer.
--------------------------------------------------

function FFR_ContractManager:buyOut(contract, isDefault)

    if contract == nil
        or contract.status ~= "OPEN"
    then

        return false, FFR_L10n.t("ffr_contract_select_buyout")

    end

    local shortfall = self:getRemaining(contract)

    local cost = self:getBuyoutCost(contract)

    if not self:chargeFarm(contract.farmId, cost) then
        return false, FFR_L10n.t("ffr_contract_buyout_failed")
    end

    local serial = self:getCurrentSerial() or 0

    contract.status = isDefault and "DEFAULTED" or "BOUGHT OUT"

    contract.finishedSerial = serial

    -- Calls not delivered are closed by the buyout (the last one missed on a default).
    for _, call in ipairs(contract.calls or {}) do
        local status = self:getCallStatus(call)
        if status == "ACTIVE" or status == "UPCOMING" then call.status = isDefault and "MISSED" or "SETTLED" end
    end

    contract.penaltyPaid = (tonumber(contract.penaltyPaid) or 0) + cost

    self.totalPenaltiesPaid =
        self.totalPenaltiesPaid + cost

    local history = self:getHistory(contract.farmId)

    history.fees = history.fees + cost

    if isDefault then
        history.defaulted = history.defaulted + 1
    else
        history.boughtOut = history.boughtOut + 1
    end

    if isDefault then

        self.defaultedContracts =
            self.defaultedContracts + 1

        self.blockedUntil[self:getBlockKey(contract.farmId, contract.buyerKey)] =
            serial + FFR_ContractManager.DEFAULT_COOLDOWN_MONTHS

        local state = self:getFarmState(contract.farmId)

        if state ~= nil then
            state.creditManager:addContractDefault()
        end

        Logging.warning(
            "FFR Contract %d: Defaulted, %d L short, buyout $%d",
            contract.id,
            math.floor(shortfall),
            math.floor(cost)
        )

        self:addNews(FFR_L10n.t(
            "ffr_contract_news_default",
            FFR_UnitManager.formatAmount(shortfall, contract.commodity),
            self:formatName(contract.commodity),
            tostring(contract.buyerName or FFR_L10n.t("ffr_contract_the_buyer")),
            self:formatMoney(cost)
        ))

    else

        Logging.info(
            "FFR Contract %d: Bought out, %d L, $%d",
            contract.id,
            math.floor(shortfall),
            math.floor(cost)
        )

    end

    return true, FFR_L10n.t(
        isDefault and "ffr_contract_settled_default" or "ffr_contract_settled_buyout",
        FFR_UnitManager.formatAmount(shortfall, contract.commodity),
        self:formatMoney(cost)
    )

end

--------------------------------------------------
-- Monthly Settlement
--
-- Called by the monthly processor. Every open
-- contract whose deadline month has ended defaults.
-- Returns the total charged.
--------------------------------------------------

function FFR_ContractManager:settleDue(period, year)

    local serial = self:getSerial(period, year)

    local total = 0

    for _, contract in ipairs(self:getActive(nil)) do

        -- Delivery calls whose window has closed: the last one short is a default
        -- (below); an earlier one is settled on its own and the contract goes on.
        local calls = contract.calls or {}
        for index, call in ipairs(calls) do
            if index < #calls and self:getCallStatus(call) == "ACTIVE" and self:getCallEnd(call) < serial then
                if self:getCallRemaining(call) > 0 and self:getRemaining(contract) > 0 then
                    total = total + self:settleMissedCall(contract, call)
                else
                    call.status = "COMPLETED"
                end
            end
        end

        if self:getRemaining(contract) <= 0 and #calls > 0 then

            -- Everything delivered or settled through the earlier calls.
            contract.status = "FULFILLED"
            contract.finishedSerial = serial

        elseif self:getSerial(contract.deadlinePeriod, contract.deadlineYear) < serial then

            local before = tonumber(contract.penaltyPaid) or 0

            self:buyOut(contract, true)

            total = total + (tonumber(contract.penaltyPaid) or 0) - before

        end

    end

    self:removeFinished(serial)

    return total

end

-- Drops finished contracts once they have been listed long enough.
function FFR_ContractManager:removeFinished(serial)

    local kept = {}

    for _, contract in ipairs(self.contracts) do

        local age = (tonumber(serial) or 0) - (tonumber(contract.finishedSerial) or 0)

        if contract.status == "OPEN"
            or age < FFR_ContractManager.KEEP_FINISHED_MONTHS
        then

            table.insert(kept, contract)

        end

    end

    self.contracts = kept

end

--------------------------------------------------
-- Formatting
--------------------------------------------------

function FFR_ContractManager:formatNumber(value)

    return FFR_L10n.formatNumber(value)

end

function FFR_ContractManager:formatMoney(value)

    return FFR_L10n.formatMoney(value)

end

function FFR_ContractManager:formatName(name)

    return FFR_L10n.fillTypeTitle(name)

end

--------------------------------------------------
-- Save / Load
--------------------------------------------------

function FFR_ContractManager:saveToXML(
    xmlFile,
    key
)

    setXMLInt(xmlFile, key .. "#nextId", self.nextId)
    setXMLInt(xmlFile, key .. "#completed", self.completedContracts)
    setXMLInt(xmlFile, key .. "#defaulted", self.defaultedContracts)
    setXMLFloat(xmlFile, key .. "#totalPenalties", self.totalPenaltiesPaid)

    local index = 0

    for _, contract in ipairs(self.contracts) do

        local itemKey = string.format("%s.contract(%d)", key, index)

        setXMLInt(xmlFile, itemKey .. "#id", contract.id)
        setXMLInt(xmlFile, itemKey .. "#farmId", tonumber(contract.farmId) or 0)
        setXMLString(xmlFile, itemKey .. "#commodity", tostring(contract.commodity))
        if contract.buyerKey ~= nil then
            setXMLString(xmlFile, itemKey .. "#buyerKey", tostring(contract.buyerKey))
            setXMLString(xmlFile, itemKey .. "#buyerName", tostring(contract.buyerName or ""))
        end
        setXMLFloat(xmlFile, itemKey .. "#volume", tonumber(contract.volume) or 0)
        setXMLFloat(xmlFile, itemKey .. "#delivered", tonumber(contract.delivered) or 0)
        setXMLFloat(xmlFile, itemKey .. "#lockedPrice", tonumber(contract.lockedPrice) or 0)
        setXMLFloat(xmlFile, itemKey .. "#value", tonumber(contract.value) or 0)
        setXMLFloat(xmlFile, itemKey .. "#buyoutFee", tonumber(contract.buyoutFee) or FFR_ContractManager.BUYOUT_FEE)
        setXMLInt(xmlFile, itemKey .. "#deadlinePeriod", tonumber(contract.deadlinePeriod) or 0)
        setXMLInt(xmlFile, itemKey .. "#deadlineYear", tonumber(contract.deadlineYear) or 0)
        setXMLInt(xmlFile, itemKey .. "#rolls", tonumber(contract.rolls) or 0)
        setXMLString(xmlFile, itemKey .. "#status", tostring(contract.status or "OPEN"))
        setXMLInt(xmlFile, itemKey .. "#finishedSerial", tonumber(contract.finishedSerial) or 0)
        setXMLFloat(xmlFile, itemKey .. "#penaltyPaid", tonumber(contract.penaltyPaid) or 0)
        setXMLString(xmlFile, itemKey .. "#summary", tostring(contract.summary or ""))
        setXMLFloat(xmlFile, itemKey .. "#settled", tonumber(contract.settled) or 0)

        for c, call in ipairs(contract.calls or {}) do
            local callKey = string.format("%s.call(%d)", itemKey, c - 1)
            setXMLInt(xmlFile, callKey .. "#serial", tonumber(call.serial) or 0)
            setXMLFloat(xmlFile, callKey .. "#volume", tonumber(call.volume) or 0)
            setXMLFloat(xmlFile, callKey .. "#delivered", tonumber(call.delivered) or 0)
            setXMLFloat(xmlFile, callKey .. "#settled", tonumber(call.settled) or 0)
            setXMLString(xmlFile, callKey .. "#status", tostring(call.status or "OPEN"))
        end

        index = index + 1

    end

    index = 0

    for farmId, h in pairs(self.history) do

        local itemKey = string.format("%s.history(%d)", key, index)

        setXMLInt(xmlFile, itemKey .. "#farmId", tonumber(farmId) or 0)
        setXMLInt(xmlFile, itemKey .. "#fulfilled", tonumber(h.fulfilled) or 0)
        setXMLInt(xmlFile, itemKey .. "#boughtOut", tonumber(h.boughtOut) or 0)
        setXMLInt(xmlFile, itemKey .. "#defaulted", tonumber(h.defaulted) or 0)
        setXMLFloat(xmlFile, itemKey .. "#delivered", tonumber(h.delivered) or 0)
        setXMLFloat(xmlFile, itemKey .. "#premium", tonumber(h.premium) or 0)
        setXMLFloat(xmlFile, itemKey .. "#fees", tonumber(h.fees) or 0)

        index = index + 1

    end

    index = 0

    for blockKey, serial in pairs(self.blockedUntil) do

        local itemKey = string.format("%s.blocked(%d)", key, index)

        setXMLString(xmlFile, itemKey .. "#key", tostring(blockKey))
        setXMLInt(xmlFile, itemKey .. "#untilSerial", tonumber(serial) or 0)

        index = index + 1

    end

end

function FFR_ContractManager:loadFromXML(
    xmlFile,
    key
)

    self.contracts = {}
    self.blockedUntil = {}
    self.history = {}

    if not hasXMLProperty(xmlFile, key) then
        return
    end

    self.nextId = getXMLInt(xmlFile, key .. "#nextId") or 1
    self.completedContracts = getXMLInt(xmlFile, key .. "#completed") or 0
    self.defaultedContracts = getXMLInt(xmlFile, key .. "#defaulted") or 0
    self.totalPenaltiesPaid = getXMLFloat(xmlFile, key .. "#totalPenalties") or 0

    local index = 0

    while true do

        local itemKey = string.format("%s.contract(%d)", key, index)

        if not hasXMLProperty(xmlFile, itemKey) then
            break
        end

        local commodityName = getXMLString(xmlFile, itemKey .. "#commodity")

        local commodity = self:getCommodity(commodityName)

        if commodity ~= nil then

            local status = getXMLString(xmlFile, itemKey .. "#status") or "OPEN"

            -- v0.9.4 called fulfilled contracts COMPLETED.
            if status == "COMPLETED" then status = "FULFILLED" end

            local contract = {
                id = getXMLInt(xmlFile, itemKey .. "#id") or self.nextId,
                farmId = getXMLInt(xmlFile, itemKey .. "#farmId"),
                commodity = commodity.name,
                fillTypeIndex = commodity.index,
                buyerKey = getXMLString(xmlFile, itemKey .. "#buyerKey"),
                buyerName = getXMLString(xmlFile, itemKey .. "#buyerName"),
                volume = getXMLFloat(xmlFile, itemKey .. "#volume") or 0,
                delivered = getXMLFloat(xmlFile, itemKey .. "#delivered") or 0,
                lockedPrice = getXMLFloat(xmlFile, itemKey .. "#lockedPrice") or 0,
                buyoutFee = getXMLFloat(xmlFile, itemKey .. "#buyoutFee") or FFR_ContractManager.BUYOUT_FEE,
                deadlinePeriod = getXMLInt(xmlFile, itemKey .. "#deadlinePeriod") or 1,
                deadlineYear = getXMLInt(xmlFile, itemKey .. "#deadlineYear") or 1,
                rolls = getXMLInt(xmlFile, itemKey .. "#rolls") or 0,
                status = status,
                finishedSerial = getXMLInt(xmlFile, itemKey .. "#finishedSerial") or 0,
                penaltyPaid = getXMLFloat(xmlFile, itemKey .. "#penaltyPaid") or 0,
                settled = getXMLFloat(xmlFile, itemKey .. "#settled") or 0
            }

            -- Delivery calls (v0.9.61); older contracts have none and keep one deadline.
            local c = 0
            while hasXMLProperty(xmlFile, string.format("%s.call(%d)", itemKey, c)) do
                local callKey = string.format("%s.call(%d)", itemKey, c)
                contract.calls = contract.calls or {}
                table.insert(contract.calls, {
                    serial = getXMLInt(xmlFile, callKey .. "#serial") or 0,
                    volume = getXMLFloat(xmlFile, callKey .. "#volume") or 0,
                    delivered = getXMLFloat(xmlFile, callKey .. "#delivered") or 0,
                    settled = getXMLFloat(xmlFile, callKey .. "#settled") or 0,
                    status = getXMLString(xmlFile, callKey .. "#status") or "OPEN"
                })
                c = c + 1
            end

            -- Older saves have no stored value or summary; rebuild them from the locked terms.
            contract.value = getXMLFloat(xmlFile, itemKey .. "#value") or (contract.volume / 1000 * contract.lockedPrice)
            local summary = getXMLString(xmlFile, itemKey .. "#summary")
            contract.summary = (summary ~= nil and summary ~= "") and summary or self:buildSummary(contract)

            table.insert(self.contracts, contract)

        else

            Logging.warning(
                "FFR Contracts: Dropped saved contract for unknown commodity %s",
                tostring(commodityName)
            )

        end

        index = index + 1

    end

    index = 0

    while true do

        local itemKey = string.format("%s.blocked(%d)", key, index)

        if not hasXMLProperty(xmlFile, itemKey) then
            break
        end

        local blockKey = getXMLString(xmlFile, itemKey .. "#key")

        -- v0.9.4 blocked the whole farm (farmId only); that block is dropped.
        if blockKey ~= nil then
            self.blockedUntil[blockKey] = getXMLInt(xmlFile, itemKey .. "#untilSerial") or 0
        end

        index = index + 1

    end

    index = 0

    while true do

        local itemKey = string.format("%s.history(%d)", key, index)

        if not hasXMLProperty(xmlFile, itemKey) then
            break
        end

        local h = self:getHistory(getXMLInt(xmlFile, itemKey .. "#farmId"))

        h.fulfilled = getXMLInt(xmlFile, itemKey .. "#fulfilled") or 0
        h.boughtOut = getXMLInt(xmlFile, itemKey .. "#boughtOut") or 0
        h.defaulted = getXMLInt(xmlFile, itemKey .. "#defaulted") or 0
        h.delivered = getXMLFloat(xmlFile, itemKey .. "#delivered") or 0
        h.premium = getXMLFloat(xmlFile, itemKey .. "#premium") or 0
        h.fees = getXMLFloat(xmlFile, itemKey .. "#fees") or 0

        index = index + 1

    end

    -- Saves before v0.9.14 have no record: start it from the contracts still listed.
    if index == 0 then

        for _, contract in ipairs(self.contracts) do

            local h = self:getHistory(contract.farmId)

            h.delivered = h.delivered + (tonumber(contract.delivered) or 0)
            h.fees = h.fees + (tonumber(contract.penaltyPaid) or 0)

            if contract.status == "FULFILLED" then
                h.fulfilled = h.fulfilled + 1
            elseif contract.status == "BOUGHT OUT" then
                h.boughtOut = h.boughtOut + 1
            elseif contract.status == "DEFAULTED" then
                h.defaulted = h.defaulted + 1
            end

        end

    end

    Logging.info(
        "FFR Contracts: %d contracts restored",
        #self.contracts
    )

end

--------------------------------------------------
-- Selling Station Hook
--
-- Contracted litres are paid the contract rate in
-- the sale itself: just before the station prices
-- the load, the sell-price hook is given one blended
-- per-litre price for this sale (contract rate on
-- the contracted litres, normal price on the rest).
-- If the station never asked for the price, the
-- difference is paid as a separate top-up instead.
-- Server only.
--------------------------------------------------

function FFR_ContractManager.onSellFillType(
    station,
    superFunc,
    farmId,
    deltaFillLevel,
    fillTypeIndex,
    toolType,
    ...
)

    local ok, plan = pcall(
        FFR_ContractManager.prepareSale,
        station,
        farmId,
        deltaFillLevel,
        fillTypeIndex,
        toolType
    )

    if not ok then

        Logging.warning(
            "FFR Contracts: Could not prepare contract pricing (%s)",
            tostring(plan)
        )

        plan = nil

    end

    if plan ~= nil and FFR_SellPriceManager ~= nil then
        FFR_SellPriceManager.saleOverride = plan.override
    end

    local results = {
        pcall(
            superFunc,
            station,
            farmId,
            deltaFillLevel,
            fillTypeIndex,
            toolType,
            ...
        )
    }

    -- Always cleared, even if the sale itself failed.
    if FFR_SellPriceManager ~= nil then
        FFR_SellPriceManager.saleOverride = nil
    end

    if not results[1] then
        error(results[2], 0)
    end

    if plan ~= nil then

        local finished, err = pcall(
            FFR_ContractManager.finishSale,
            plan
        )

        if not finished then

            Logging.warning(
                "FFR Contracts: Delivery tracking failed (%s)",
                tostring(err)
            )

        end

    end

    return unpack(results, 2)

end

-- Returns nil when no open contract with this buyer takes any of the litres.
function FFR_ContractManager.prepareSale(
    station,
    farmId,
    deltaFillLevel,
    fillTypeIndex,
    toolType
)

    if g_FFR == nil
        or not g_FFR.isInitialized
        or g_FFR.contractManager == nil
    then

        return nil

    end

    if g_currentMission ~= nil
        and g_currentMission.getIsServer ~= nil
        and not g_currentMission:getIsServer()
    then

        return nil

    end

    local liters = tonumber(deltaFillLevel) or 0

    if liters <= 0 then
        return nil
    end

    local stationKey = nil

    if g_FFRStationPriceManager ~= nil then
        stationKey = g_FFRStationPriceManager:getStationKey(station)
    end

    local applied, lockedValue =

        g_FFR.contractManager:planDelivery(
            tonumber(farmId),
            fillTypeIndex,
            liters,
            stationKey
        )

    if applied <= 0 then
        return nil
    end

    -- Normal (FFR-adjusted) price per litre at this station right now.
    local spot = 0

    if station.getEffectiveFillTypePrice ~= nil then
        spot = tonumber(station:getEffectiveFillTypePrice(fillTypeIndex, toolType)) or 0
    end

    local blended = (lockedValue + (liters - applied) * spot) / liters

    return {
        farmId = tonumber(farmId),
        fillTypeIndex = fillTypeIndex,
        liters = liters,
        stationKey = stationKey,
        spot = spot,
        applied = applied,
        override = {
            station = station,
            fillTypeIndex = fillTypeIndex,
            pricePerLiter = blended,
            used = false
        }
    }

end

function FFR_ContractManager.finishSale(plan)

    local cm = g_FFR.contractManager

    local adjustment =

        cm:recordDelivery(
            plan.farmId,
            plan.fillTypeIndex,
            plan.liters,
            plan.spot,
            plan.stationKey
        )

    if g_FFR.saveManager ~= nil then
        g_FFR.saveManager:requestSave(g_FFR)
    end

    if plan.override.used then

        -- Paid in the sale; the revenue tracker already booked the full amount.
        -- FS25 sells a load in many small chunks, so this is logged once per session.
        if not FFR_ContractManager.hasLoggedContractRate then

            FFR_ContractManager.hasLoggedContractRate = true

            Logging.info(
                "FFR Contracts: Deliveries are paid at the contract rate in the sale"
            )

        end

        return

    end

    --------------------------------------------------
    -- Fallback: the station did not ask for its price
    -- during the sale, so pay the difference now.
    --------------------------------------------------

    if math.abs(adjustment) < 1
        or g_FFRMonthlyFinancialProcessor == nil
    then

        return

    end

    local moneyType = nil

    if MoneyType ~= nil then
        moneyType = MoneyType.SOLD_PRODUCTS or MoneyType.HARVEST_INCOME or MoneyType.OTHER
    end

    if g_FFRMonthlyFinancialProcessor:applyFarmBalance(adjustment, moneyType, plan.farmId) then

        -- The tracker skips FFR's own payments, so book this as revenue here.
        local state = cm:getFarmState(plan.farmId)
        local financial = state ~= nil and state.financialManager or nil

        if financial ~= nil then

            financial.monthlyRevenue = (tonumber(financial.monthlyRevenue) or 0) + adjustment
            financial.annualRevenue = (tonumber(financial.annualRevenue) or 0) + adjustment
            financial:updateAnnualProfit()

        end

        Logging.info(
            "FFR Contracts: %d L delivered; contract top-up of $%d paid separately",
            math.floor(plan.applied),
            math.floor(adjustment)
        )

    end

end

function FFR_ContractManager.install()

    if SellingStation == nil
        or SellingStation.sellFillType == nil
    then

        Logging.warning(
            "FFR Contracts: SellingStation.sellFillType unavailable; deliveries will not count toward contracts"
        )

        return false

    end

    SellingStation.sellFillType =

        Utils.overwrittenFunction(
            SellingStation.sellFillType,
            FFR_ContractManager.onSellFillType
        )

    Logging.info(
        "FFR Contracts: Delivery tracking installed"
    )

    return true

end

FFR_ContractManager.install()
