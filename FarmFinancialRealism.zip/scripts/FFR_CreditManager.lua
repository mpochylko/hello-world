FFR_CreditManager = {}

function FFR_CreditManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_CreditManager}
    )

    --------------------------------------------------
    -- Credit Rating
    --------------------------------------------------

    self.creditScore = 700

    self.creditRating = "GOOD"

    self.interestRateModifier = 1.00

    self.maxOperatingLoan = 250000

    self.maxExpansionLoan = 1000000

    --------------------------------------------------
    -- History
    --------------------------------------------------

    self.missedPayments = 0

    self.latePayments = 0

    self.successfulYears = 0

    self.contractDefaults = 0

    self.taxPenalties = 0

    --------------------------------------------------
    -- Credit recovery: each mark above, with the
    -- month it was recorded (see Marks below).
    --------------------------------------------------

    self.marks = {}

    self.cleanMonths = 0

    self.lastMarkSerial = 0

    --------------------------------------------------
    -- Insolvency (FFR_InsolvencyManager)
    --------------------------------------------------

    -- 0 good standing, 1 warning, 2 credit freeze,
    -- 3 loans called, 4 forced sale.
    self.insolvencyStage = 0

    self.monthsOverdrawn = 0

    -- Bank's latest message for this farm.
    self.insolvencyNotice = ""

    self.forcedSaleTotal = 0

    --------------------------------------------------
    -- Risk Metrics
    --------------------------------------------------

    self.soilRiskPenalty = 0

    self.insurancePenalty = 0

    self.debtPenalty = 0

    self.cashReserveBonus = 0

    return self

end

--------------------------------------------------
-- Update Credit
--------------------------------------------------

function FFR_CreditManager:update(financialManager)

    if financialManager == nil then
        return
    end

    local score = 700

    --------------------------------------------------
    -- Debt Evaluation
    --------------------------------------------------

    if financialManager.debtRatio > 0.80 then

        score = score - 125

    elseif financialManager.debtRatio > 0.60 then

        score = score - 75

    elseif financialManager.debtRatio > 0.40 then

        score = score - 25

    end

    --------------------------------------------------
    -- Liquidity Evaluation
    --------------------------------------------------

    --------------------------------------------------
    -- With no monthly obligations the ratio is 0 and
    -- hasUnlimitedLiquidity is set. That is the best
    -- case, not the "< 1" penalty.
    --------------------------------------------------

    if financialManager.hasUnlimitedLiquidity then

        score = score + 60

    elseif financialManager.liquidityRatio >= 12 then

        score = score + 60

    elseif financialManager.liquidityRatio >= 6 then

        score = score + 30

    elseif financialManager.liquidityRatio < 1 then

        score = score - 75

    end

    --------------------------------------------------
    -- Payment History
    --------------------------------------------------

    score = score
        - (self.missedPayments * 50)

    score = score
        - (self.latePayments * 15)

    --------------------------------------------------
    -- Tax Penalties
    --------------------------------------------------

    score = score
        - (self.taxPenalties * 25)

    --------------------------------------------------
    -- Contract Defaults
    --------------------------------------------------

    --------------------------------------------------
    -- Halved from 40: a contract default mainly hurts
    -- the relationship with that buyer (it refuses
    -- new contracts for a while), not general credit.
    --------------------------------------------------

    score = score
        - (self.contractDefaults * 20)

    --------------------------------------------------
    -- Profitable Years
    --------------------------------------------------

    score = score
        + (self.successfulYears * 5)

    --------------------------------------------------
    -- Equity: a farm that owns far more than it owes
    -- is a safer borrower (cash cover is counted in
    -- the liquidity part above).
    --------------------------------------------------

    score = score
        + self:getEquityBonus(financialManager)

    --------------------------------------------------
    -- Clamp
    --------------------------------------------------

    if score > 850 then
        score = 850
    end

    if score < 300 then
        score = 300
    end

    self.creditScore = score

    self:updateRating()

    self:updateLoanLimits(financialManager)

    self:updateInterestModifier()

end

--------------------------------------------------
-- Rating Bands
--------------------------------------------------

function FFR_CreditManager:updateRating()

    local score =
        self.creditScore

    if score >= 800 then

        self.creditRating =
            "EXCELLENT"

    elseif score >= 700 then

        self.creditRating =
            "GOOD"

    elseif score >= 600 then

        self.creditRating =
            "FAIR"

    elseif score >= 500 then

        self.creditRating =
            "CONCERNING"

    else

        self.creditRating =
            "HIGH_RISK"

    end

end

-- EXCELLENT / GOOD / FAIR / CONCERNING / HIGH_RISK as shown to the player.
function FFR_CreditManager.getRatingName(rating)
    if rating == nil or rating == "" then return FFR_L10n.t("ffr_common_unavailable") end
    return FFR_L10n.named("ffr_credit_", rating)
end

--------------------------------------------------
-- Interest Modifier
--------------------------------------------------

function FFR_CreditManager:updateInterestModifier()

    local rating =
        self.creditRating

    if rating == "EXCELLENT" then

        self.interestRateModifier =
            0.85

    elseif rating == "GOOD" then

        self.interestRateModifier =
            1.00

    elseif rating == "FAIR" then

        self.interestRateModifier =
            1.20

    elseif rating == "CONCERNING" then

        self.interestRateModifier =
            1.50

    else

        self.interestRateModifier =
            2.00

    end

end

--------------------------------------------------
-- Loan Limits
--
-- The rating sets the most the bank lends. The
-- operating line is also sized to the farm: at most
-- OPERATING_EQUITY_SHARE of net worth (never below
-- OPERATING_MIN), like a real operating line.
-- The expansion loan is limited by land collateral
-- (FFR_BankingManager:getLandLimit).
--------------------------------------------------

FFR_CreditManager.OPERATING_EQUITY_SHARE = 0.25
FFR_CreditManager.OPERATING_MIN = 50000

function FFR_CreditManager:updateLoanLimits(financialManager)

    self:updateRatingLimits()

    if financialManager == nil then
        return
    end

    local byEquity = math.floor(
        math.max(0, tonumber(financialManager.netWorth) or 0)
        * FFR_CreditManager.OPERATING_EQUITY_SHARE / 10000
    ) * 10000

    self.maxOperatingLoan = math.min(
        self.maxOperatingLoan,
        math.max(FFR_CreditManager.OPERATING_MIN, byEquity)
    )

end

function FFR_CreditManager:updateRatingLimits()

    local rating =
        self.creditRating

    if rating == "EXCELLENT" then

        self.maxOperatingLoan =
            1000000

        self.maxExpansionLoan =
            10000000

    elseif rating == "GOOD" then

        self.maxOperatingLoan =
            500000

        self.maxExpansionLoan =
            5000000

    elseif rating == "FAIR" then

        self.maxOperatingLoan =
            250000

        self.maxExpansionLoan =
            2500000

    elseif rating == "CONCERNING" then

        self.maxOperatingLoan =
            100000

        self.maxExpansionLoan =
            1000000

    else

        self.maxOperatingLoan =
            50000

        self.maxExpansionLoan =
            250000

    end

end

--------------------------------------------------
-- Equity Bonus
--------------------------------------------------

FFR_CreditManager.EQUITY_BONUS = {
    -- {net worth at least, debt ratio below, points}
    {1000000, 0.25, 40},
    {250000, 0.40, 20}
}

function FFR_CreditManager:getEquityBonus(financialManager)

    local netWorth = tonumber(financialManager.netWorth) or 0
    local ratio = tonumber(financialManager.debtRatio) or 1

    for _, step in ipairs(FFR_CreditManager.EQUITY_BONUS) do
        if netWorth >= step[1] and ratio < step[2] then
            return step[3]
        end
    end

    return 0

end

--------------------------------------------------
-- Marks
--
-- Late payments, missed payments, contract defaults
-- and tax penalties are marks on the credit file.
-- Like a real credit report they do not stay
-- forever:
--
-- * each mark drops off MARK_MONTHS after it was
--   recorded;
-- * CLEAN_MONTHS months in a row that end with the
--   account above $0 and no new mark remove the
--   oldest mark early.
--
-- The counters (latePayments, ...) stay the numbers
-- the score uses; self.marks remembers when each one
-- was recorded. Marks from saves before v0.9.44 have
-- no date and count from the first month processed.
--------------------------------------------------

FFR_CreditManager.MARK_MONTHS = 24
FFR_CreditManager.CLEAN_MONTHS = 6

FFR_CreditManager.MARK_COUNTERS = {
    LATE = "latePayments",
    MISSED = "missedPayments",
    DEFAULT = "contractDefaults",
    TAX = "taxPenalties"
}

function FFR_CreditManager.getSerial()

    local e = g_currentMission ~= nil and g_currentMission.environment or nil
    local period = e ~= nil and tonumber(e.currentPeriod) or 0
    local year = e ~= nil and tonumber(e.currentYear) or 0

    return year * 12 + period

end

function FFR_CreditManager:addMark(kind)

    local counter = FFR_CreditManager.MARK_COUNTERS[kind]

    self[counter] = (tonumber(self[counter]) or 0) + 1

    local serial = FFR_CreditManager.getSerial()

    self.marks = self.marks or {}

    table.insert(self.marks, {kind = kind, serial = serial})

    self.lastMarkSerial = serial
    self.cleanMonths = 0

end

function FFR_CreditManager:removeMark(index)

    local mark = table.remove(self.marks, index)

    if mark == nil then
        return
    end

    local counter = FFR_CreditManager.MARK_COUNTERS[mark.kind]

    if counter ~= nil then
        self[counter] = math.max(0, (tonumber(self[counter]) or 0) - 1)
    end

end

-- Counters without a dated mark (older saves) get one dated `serial`.
function FFR_CreditManager:dateUndatedMarks(serial)

    self.marks = self.marks or {}

    local dated = {}

    for _, mark in ipairs(self.marks) do
        dated[mark.kind] = (dated[mark.kind] or 0) + 1
    end

    for kind, counter in pairs(FFR_CreditManager.MARK_COUNTERS) do
        for _ = (dated[kind] or 0) + 1, tonumber(self[counter]) or 0 do
            table.insert(self.marks, 1, {kind = kind, serial = serial})
        end
    end

    table.sort(self.marks, function(a, b) return a.serial < b.serial end)

end

-- Month end (server, after the bills and the bank's checks): old marks expire,
-- and a clean month counts toward removing the oldest one early.
function FFR_CreditManager:processMonth(serial, cash)

    self:dateUndatedMarks(serial)

    local expired = 0

    for i = #self.marks, 1, -1 do
        if serial - (tonumber(self.marks[i].serial) or serial) >= FFR_CreditManager.MARK_MONTHS then
            self:removeMark(i)
            expired = expired + 1
        end
    end

    local cleared = 0

    if (tonumber(cash) or 0) >= 0 and (tonumber(self.lastMarkSerial) or 0) ~= serial then

        self.cleanMonths = (tonumber(self.cleanMonths) or 0) + 1

        if self.cleanMonths >= FFR_CreditManager.CLEAN_MONTHS and #self.marks > 0 then
            self:removeMark(1)
            self.cleanMonths = 0
            cleared = 1
        end

    else

        self.cleanMonths = 0

    end

    if expired + cleared > 0 then
        Logging.info(
            "FFR Credit: %d mark(s) aged out, %d cleared by clean months; %d left",
            expired, cleared, #self.marks
        )
    end

end

function FFR_CreditManager:saveMarks(xmlFile, key)

    setXMLInt(xmlFile, key .. "#cleanMonths", math.floor(tonumber(self.cleanMonths) or 0))
    setXMLInt(xmlFile, key .. "#lastMarkSerial", math.floor(tonumber(self.lastMarkSerial) or 0))

    for i, mark in ipairs(self.marks or {}) do
        local base = string.format("%s.mark(%d)", key, i - 1)
        setXMLString(xmlFile, base .. "#kind", tostring(mark.kind))
        setXMLInt(xmlFile, base .. "#serial", math.floor(tonumber(mark.serial) or 0))
    end

end

function FFR_CreditManager:loadMarks(xmlFile, key)

    self.marks = {}
    self.cleanMonths = getXMLInt(xmlFile, key .. "#cleanMonths") or 0
    self.lastMarkSerial = getXMLInt(xmlFile, key .. "#lastMarkSerial") or 0

    local i = 0

    while hasXMLProperty(xmlFile, string.format("%s.mark(%d)", key, i)) do
        local base = string.format("%s.mark(%d)", key, i)
        local kind = getXMLString(xmlFile, base .. "#kind")
        if FFR_CreditManager.MARK_COUNTERS[kind or ""] ~= nil then
            table.insert(self.marks, {kind = kind, serial = getXMLInt(xmlFile, base .. "#serial") or 0})
        end
        i = i + 1
    end

end

-- Months until the next mark drops off on its own (nil without marks).
function FFR_CreditManager:getMonthsToNextExpiry()

    local oldest = self.marks ~= nil and self.marks[1] or nil

    if oldest == nil then
        return nil
    end

    return math.max(1, FFR_CreditManager.MARK_MONTHS - (FFR_CreditManager.getSerial() - (tonumber(oldest.serial) or 0)))

end

--------------------------------------------------
-- Events
--------------------------------------------------

function FFR_CreditManager:addLatePayment()

    self:addMark("LATE")

end

function FFR_CreditManager:addMissedPayment()

    self:addMark("MISSED")

end

function FFR_CreditManager:addSuccessfulYear()

    self.successfulYears =
        self.successfulYears + 1

end

function FFR_CreditManager:addContractDefault()

    self:addMark("DEFAULT")

end

function FFR_CreditManager:addTaxPenalty()

    self:addMark("TAX")

end

--------------------------------------------------
-- Report
--------------------------------------------------

function FFR_CreditManager:printCreditReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR CREDIT REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Credit Score: "
        .. tostring(
            self.creditScore
        )
    )

    Logging.info(
        "Rating: "
        .. self.creditRating
    )

    Logging.info(
        "Interest Modifier: "
        .. tostring(
            self.interestRateModifier
        )
    )

    Logging.info(
        "Operating Limit: $"
        .. tostring(
            self.maxOperatingLoan
        )
    )

    Logging.info(
        "Expansion Limit: $"
        .. tostring(
            self.maxExpansionLoan
        )
    )

    Logging.info(
        "========================================"
    )

end