FFR_CropDamageManager = {}

--------------------------------------------------
-- Crop weather damage (server)
--
-- Once per in-game hour, every farmland parcel a
-- farm owns is checked with FS25's own weather and
-- field state (FieldState, as SoilFertilizer reads
-- it):
--
-- * hail: each hour of hail damages standing crops
--   under a storm cell by HAIL_MIN..HAIL_MAX x the
--   cell's local intensity x CELL_CORE_FACTOR (ripe
--   crops x1.3), up to HAIL_CAP; fields outside
--   the cells are spared;
-- * rained out: a crop ready to harvest but still
--   standing in rain loses RAIN_MIN..RAIN_MAX per
--   hour (lodging, sprouting), up to RAIN_CAP.
--
-- Both scale with the difficulty's event strength.
-- Damage is real: combines harvesting that parcel
-- thresh (1 - damage) of the normal yield (the
-- threshingScale method AdvancedDamageSystem uses).
-- A parcel's record clears when its crop is
-- harvested or replaced.
--
-- Records are keyed by farmland id and synced to
-- each owning farm (state.cropDamage).
--------------------------------------------------

FFR_CropDamageManager.HAIL_MIN = 0.02
FFR_CropDamageManager.HAIL_MAX = 0.06
FFR_CropDamageManager.HAIL_RIPE_FACTOR = 1.3
FFR_CropDamageManager.HAIL_CAP = 0.70
FFR_CropDamageManager.RAIN_MIN = 0.005
FFR_CropDamageManager.RAIN_MAX = 0.010
FFR_CropDamageManager.RAIN_CAP = 0.30
FFR_CropDamageManager.TOTAL_CAP = 0.80
FFR_CropDamageManager.ACRES_PER_HA = 2.47105
FFR_CropDamageManager.CUT_KEEP_HOURS = 48

-- Crops that are not insured or damaged (grass, trees).
FFR_CropDamageManager.SKIP_FRUITS = {"GRASS", "MEADOW", "POPLAR", "OILSEEDRADISH", "TREE"}

-- farmlandId -> record
FFR_CropDamageManager.records = {}
FFR_CropDamageManager.lastHour = nil
FFR_CropDamageManager.updateTimer = 0
FFR_CropDamageManager.storm = nil
FFR_CropDamageManager.loggedHarvest = {}

--------------------------------------------------
-- Weather
--------------------------------------------------

function FFR_CropDamageManager.getWeather()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return env ~= nil and env.weather or nil
end

function FFR_CropDamageManager.isHailing()
    local weather = FFR_CropDamageManager.getWeather()
    if weather == nil or weather.getCurrentWeatherType == nil or WeatherType == nil then return false end
    local ok, current = pcall(weather.getCurrentWeatherType, weather)
    if not ok then return false end
    return (WeatherType.HAIL ~= nil and current == WeatherType.HAIL) or (WeatherType.HALL ~= nil and current == WeatherType.HALL)
end

function FFR_CropDamageManager.isRaining()
    local weather = FFR_CropDamageManager.getWeather()
    if weather == nil or weather.getIsRaining == nil then return false end
    local ok, raining = pcall(weather.getIsRaining, weather)
    return ok and raining == true
end

function FFR_CropDamageManager.getWeatherText()
    if FFR_CropDamageManager.isHailing() then return FFR_L10n.t("ffr_weather_hail") end
    if FFR_CropDamageManager.isRaining() then return FFR_L10n.t("ffr_weather_rain") end
    return FFR_L10n.t("ffr_weather_dry")
end

--------------------------------------------------
-- Hail storm cells
--
-- FS25 weather is the same everywhere, but real
-- hail falls in swaths. When FS25 starts hailing,
-- FFR creates one cell (sometimes two) that enters
-- from a map edge and crosses the map over a few
-- hours. Fields in a cell's core take full damage,
-- its edge less, everything outside none.
--
-- getHailIntensityAt is the only question damage
-- asks of the weather. A weather mod with local
-- hail (e.g. a future North Dakota Modding and
-- Mapping overhaul) can answer it instead by
-- replacing FFR_CropDamageManager.hailSource.
--------------------------------------------------

FFR_CropDamageManager.CELL_RADIUS_MIN = 0.12
FFR_CropDamageManager.CELL_RADIUS_MAX = 0.25
FFR_CropDamageManager.CELL_CROSS_HOURS_MIN = 3
FFR_CropDamageManager.CELL_CROSS_HOURS_MAX = 6
FFR_CropDamageManager.SECOND_CELL_CHANCE = 0.30
-- Inside a cell fewer fields are hit, so each is hit harder than the old map-wide hail.
FFR_CropDamageManager.CELL_CORE_FACTOR = 1.6
-- Dry hours in a row before a storm counts as over (FS25 hail pauses mid-storm).
FFR_CropDamageManager.STORM_GAP_HOURS = 2

FFR_CropDamageManager.cells = nil
FFR_CropDamageManager.dryHours = FFR_CropDamageManager.STORM_GAP_HOURS

function FFR_CropDamageManager.getMapSize()
    return tonumber(g_currentMission ~= nil and g_currentMission.terrainSize) or 2048
end

-- A random point on a random map edge, and one on the opposite side.
function FFR_CropDamageManager.createCell()
    local size = FFR_CropDamageManager.getMapSize()
    local half = size / 2
    local function edgePoint(side)
        local t = (math.random() - 0.5) * size
        if side == 1 then return -half, t elseif side == 2 then return half, t
        elseif side == 3 then return t, -half else return t, half end
    end
    local side = math.random(1, 4)
    local opposite = ({2, 1, 4, 3})[side]
    local x1, z1 = edgePoint(side)
    local x2, z2 = edgePoint(opposite)
    local hours = FFR_CropDamageManager.random(FFR_CropDamageManager.CELL_CROSS_HOURS_MIN, FFR_CropDamageManager.CELL_CROSS_HOURS_MAX)
    return {
        x = x1, z = z1,
        dx = (x2 - x1) / hours, dz = (z2 - z1) / hours,
        radius = size * FFR_CropDamageManager.random(FFR_CropDamageManager.CELL_RADIUS_MIN, FFR_CropDamageManager.CELL_RADIUS_MAX)
    }
end

function FFR_CropDamageManager.startCells()
    FFR_CropDamageManager.cells = {FFR_CropDamageManager.createCell()}
    if math.random() < FFR_CropDamageManager.SECOND_CELL_CHANCE then
        table.insert(FFR_CropDamageManager.cells, FFR_CropDamageManager.createCell())
    end
    Logging.info("FFR Crop Damage: Hailstorm with %d cell(s) crossing the map", #FFR_CropDamageManager.cells)
end

function FFR_CropDamageManager.moveCells()
    for _, cell in ipairs(FFR_CropDamageManager.cells or {}) do
        cell.x, cell.z = cell.x + cell.dx, cell.z + cell.dz
    end
end

-- Default hail source: 1 in a cell's core, falling to 0 at its edge.
function FFR_CropDamageManager.cellHailIntensityAt(x, z)
    local best = 0
    for _, cell in ipairs(FFR_CropDamageManager.cells or {}) do
        local d = math.sqrt((x - cell.x) ^ 2 + (z - cell.z) ^ 2) / cell.radius
        local intensity = d <= 0.5 and 1 or math.max(0, 1 - (d - 0.5) / 0.5)
        best = math.max(best, intensity)
    end
    return best
end

FFR_CropDamageManager.hailSource = FFR_CropDamageManager.cellHailIntensityAt

-- How hard it is hailing at a spot right now, 0..1.
function FFR_CropDamageManager.getHailIntensityAt(x, z)
    local ok, value = pcall(FFR_CropDamageManager.hailSource, x, z)
    return ok and math.max(0, math.min(1, tonumber(value) or 0)) or 0
end

function FFR_CropDamageManager.getStrength()
    return FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("eventStrength")) or 1) or 1
end

--------------------------------------------------
-- Fields and crops
--------------------------------------------------

function FFR_CropDamageManager.getFruitDesc(index)
    if g_fruitTypeManager == nil or index == nil then return nil end
    local ok, desc = pcall(g_fruitTypeManager.getFruitTypeByIndex, g_fruitTypeManager, index)
    return ok and desc or nil
end

function FFR_CropDamageManager.isInsurableFruit(desc)
    if desc == nil or desc.name == nil then return false end
    local name = string.upper(desc.name)
    for _, skip in ipairs(FFR_CropDamageManager.SKIP_FRUITS) do
        if string.find(name, skip, 1, true) then return false end
    end
    return true
end

-- Crop and growth stage at a point, or nil.
function FFR_CropDamageManager.readCrop(x, z)
    if FieldState == nil or FieldState.new == nil then return nil end
    local result = nil
    pcall(function()
        local fs = FieldState.new()
        fs:update(x, z)
        if fs.isValid and fs.fruitTypeIndex ~= nil and fs.fruitTypeIndex > 0 and fs.growthState ~= nil and fs.growthState > 0 then
            result = {fruitTypeIndex = fs.fruitTypeIndex, growthState = fs.growthState}
        end
    end)
    return result
end

function FFR_CropDamageManager.getFields()
    if g_fieldManager == nil then return {} end
    if g_fieldManager.getFields ~= nil then
        local ok, fields = pcall(g_fieldManager.getFields, g_fieldManager)
        if ok and type(fields) == "table" then return fields end
    end
    return g_fieldManager.fields or {}
end

function FFR_CropDamageManager.getFieldFarmland(field)
    local farmland = field.farmland
    if farmland == nil and field.getFarmland ~= nil then
        local ok, result = pcall(field.getFarmland, field)
        if ok then farmland = result end
    end
    return farmland
end

function FFR_CropDamageManager.getOwner(farmlandId)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandOwner == nil then return nil end
    local ok, owner = pcall(g_farmlandManager.getFarmlandOwner, g_farmlandManager, farmlandId)
    owner = ok and tonumber(owner) or nil
    if owner == nil or owner <= 0 then return nil end
    return owner
end

-- Crop area on a parcel (ha), from the land registry's field areas.
function FFR_CropDamageManager.getAreaHa(farmland, farmlandId)
    if g_FFRLandRegistryManager ~= nil and g_FFRLandRegistryManager.getArableHa ~= nil then
        local ok, ha = pcall(g_FFRLandRegistryManager.getArableHa, g_FFRLandRegistryManager, farmland, farmlandId)
        if ok and tonumber(ha) ~= nil and ha > 0 then return ha end
    end
    return tonumber(farmland.areaInHa) or 0
end

--------------------------------------------------
-- Records
--------------------------------------------------

-- The current month as year x 12 + period (0 when the calendar is not ready).
function FFR_CropDamageManager.getSerial()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    local period, year = env ~= nil and tonumber(env.currentPeriod) or nil, env ~= nil and tonumber(env.currentYear) or nil
    if period == nil or year == nil then return 0 end
    return year * 12 + period
end

function FFR_CropDamageManager.getTotal(record)
    local total = 1 - (1 - (tonumber(record.hail) or 0)) * (1 - (tonumber(record.rain) or 0))
    return math.min(FFR_CropDamageManager.TOTAL_CAP, total)
end

-- Normal yield (L) and value ($) of a record's crop, before damage.
function FFR_CropDamageManager.getExpected(record)
    local desc = FFR_CropDamageManager.getFruitDesc(record.fruitTypeIndex)
    local liters = (tonumber(record.areaHa) or 0) * 10000 * (desc ~= nil and tonumber(desc.literPerSqm) or 0)
    local price = 0
    if g_fruitTypeManager ~= nil and g_fruitTypeManager.getFillTypeIndexByFruitTypeIndex ~= nil and g_FFRStationPriceManager ~= nil then
        local ok, fillTypeIndex = pcall(g_fruitTypeManager.getFillTypeIndexByFruitTypeIndex, g_fruitTypeManager, record.fruitTypeIndex)
        local best = ok and fillTypeIndex ~= nil and g_FFRStationPriceManager:getBestPrice(fillTypeIndex) or nil
        price = best ~= nil and tonumber(best.ffrPrice) or 0
    end
    return liters, liters / 1000 * price
end

function FFR_CropDamageManager.getRecordsForFarm(farmId)
    local list = {}
    for _, record in pairs(FFR_CropDamageManager.records) do
        if record.farmId == farmId then table.insert(list, record) end
    end
    table.sort(list, function(a, b) return a.farmlandId < b.farmlandId end)
    return list
end

-- One row per owned parcel with a standing crop, for the Insurance page and the
-- snapshot: damage plus normal yield and value.
function FFR_CropDamageManager.getFarmRows(farmId)
    local rows = {}
    for _, record in ipairs(FFR_CropDamageManager.getRecordsForFarm(farmId)) do
        local liters, value = FFR_CropDamageManager.getExpected(record)
        table.insert(rows, {
            farmlandId = record.farmlandId, fruitName = record.fruitName, stage = record.stage,
            ready = record.ready == true, harvesting = (tonumber(record.cutHours) or 0) > 0,
            hail = record.hail, rain = record.rain,
            total = FFR_CropDamageManager.getTotal(record), areaHa = record.areaHa, plantedSerial = record.plantedSerial,
            expectedLiters = liters, expectedValue = value, claimed = record.claimed == true
        })
    end
    return rows
end

-- Every field on a farm's land, for the crop-health map: position and size.
-- Any machine can read this (fields and land ownership exist on clients too).
function FFR_CropDamageManager.getFarmMapFields(farmId)
    local list = {}
    for _, field in pairs(FFR_CropDamageManager.getFields()) do
        local farmland = FFR_CropDamageManager.getFieldFarmland(field)
        local farmlandId = farmland ~= nil and tonumber(farmland.id) or nil
        if farmlandId ~= nil and field.posX ~= nil and field.posZ ~= nil
            and FFR_CropDamageManager.getOwner(farmlandId) == farmId then
            local ha = nil
            if field.getAreaHa ~= nil then
                local ok, result = pcall(field.getAreaHa, field)
                if ok then ha = tonumber(result) end
            end
            ha = ha or tonumber(field.fieldArea) or tonumber(field.areaHa) or 1
            table.insert(list, {farmlandId = farmlandId, x = field.posX, z = field.posZ, areaHa = ha})
        end
    end
    return list
end

--------------------------------------------------
-- Hourly check
--------------------------------------------------

function FFR_CropDamageManager.random(minimum, maximum)
    return minimum + math.random() * (maximum - minimum)
end

function FFR_CropDamageManager.checkHour()
    local hailing, raining = FFR_CropDamageManager.isHailing(), FFR_CropDamageManager.isRaining()
    local strength = FFR_CropDamageManager.getStrength()
    -- FS25 hail often pauses for an hour mid-storm. The storm (its cells and its
    -- summary) only ends after STORM_GAP_HOURS dry hours in a row.
    if hailing then
        FFR_CropDamageManager.dryHours = 0
        if FFR_CropDamageManager.cells == nil then FFR_CropDamageManager.startCells() end
    elseif FFR_CropDamageManager.cells ~= nil then
        FFR_CropDamageManager.dryHours = (FFR_CropDamageManager.dryHours or 0) + 1
    end
    local stormOver = not hailing and (FFR_CropDamageManager.dryHours or 0) >= FFR_CropDamageManager.STORM_GAP_HOURS
    if stormOver then FFR_CropDamageManager.cells = nil end
    local visited = {}
    local hits = {}
    for _, field in pairs(FFR_CropDamageManager.getFields()) do
        local farmland = FFR_CropDamageManager.getFieldFarmland(field)
        local farmlandId = farmland ~= nil and tonumber(farmland.id) or nil
        if farmlandId ~= nil and not visited[farmlandId] and field.posX ~= nil and field.posZ ~= nil then
            visited[farmlandId] = true
            local owner = FFR_CropDamageManager.getOwner(farmlandId)
            local crop = owner ~= nil and FFR_CropDamageManager.readCrop(field.posX, field.posZ) or nil
            local desc = crop ~= nil and FFR_CropDamageManager.getFruitDesc(crop.fruitTypeIndex) or nil
            local record = FFR_CropDamageManager.records[farmlandId]
            if crop == nil or not FFR_CropDamageManager.isInsurableFruit(desc) then
                -- Harvested, cultivated or sold: the old crop's damage is gone.
                if record ~= nil then FFR_CropDamageManager.records[farmlandId] = nil end
            else
                local maxState = tonumber(desc.maxHarvestingGrowthState) or 99
                local minState = tonumber(desc.minHarvestingGrowthState) or maxState
                local isNew = record == nil or record.fruitTypeIndex ~= crop.fruitTypeIndex or record.farmId ~= owner
                    or crop.growthState < (tonumber(record.stage) or 0)
                if isNew then
                    -- A new crop starts clean; one first seen already cut is not tracked.
                    record = nil
                    FFR_CropDamageManager.records[farmlandId] = nil
                    if crop.growthState <= maxState then
                        record = {
                            farmlandId = farmlandId, farmId = owner, fruitTypeIndex = crop.fruitTypeIndex,
                            fruitName = tostring(desc.name), hail = 0, rain = 0,
                            areaHa = FFR_CropDamageManager.getAreaHa(farmland, farmlandId),
                            -- Month first seen (year x 12 + period): crop insurance ties the crop to its harvest year.
                            plantedSerial = FFR_CropDamageManager.getSerial()
                        }
                        FFR_CropDamageManager.records[farmlandId] = record
                    end
                end
                local hail = hailing and FFR_CropDamageManager.getHailIntensityAt(field.posX, field.posZ) or 0
                FFR_CropDamageManager.updateRecord(record, crop, minState, maxState, hail, raining, strength, hits)
            end
        end
    end
    if FFR_CropDamageManager.cells ~= nil then FFR_CropDamageManager.moveCells() end
    FFR_CropDamageManager.trackStorm(not stormOver, hits)
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

-- One parcel's hour: growth stage, then hail (hail = local intensity 0..1) or rain damage.
function FFR_CropDamageManager.updateRecord(record, crop, minState, maxState, hail, raining, strength, hits)
    if record == nil then return end
    record.stage = crop.growthState
    record.ready = crop.growthState >= minState and crop.growthState <= maxState
    local standing = crop.growthState <= maxState
    if not standing then
        -- Cut (or withered). The sample point may be cut before the rest of
        -- the parcel, so the damage stays for CUT_KEEP_HOURS of harvesting.
        record.cutHours = (tonumber(record.cutHours) or 0) + 1
        if record.cutHours >= FFR_CropDamageManager.CUT_KEEP_HOURS then
            FFR_CropDamageManager.records[record.farmlandId] = nil
        end
    elseif hail > 0 then
        local hit = FFR_CropDamageManager.random(FFR_CropDamageManager.HAIL_MIN, FFR_CropDamageManager.HAIL_MAX)
            * strength * (record.ready and FFR_CropDamageManager.HAIL_RIPE_FACTOR or 1)
            * hail * FFR_CropDamageManager.CELL_CORE_FACTOR
        record.hail = math.min(FFR_CropDamageManager.HAIL_CAP, (tonumber(record.hail) or 0) + hit)
        table.insert(hits, record)
    elseif raining and record.ready then
        local hit = FFR_CropDamageManager.random(FFR_CropDamageManager.RAIN_MIN, FFR_CropDamageManager.RAIN_MAX) * strength
        local before = tonumber(record.rain) or 0
        record.rain = math.min(FFR_CropDamageManager.RAIN_CAP, before + hit)
        -- Tell the farm at 5 % and every further 10 %.
        local step = function(v) return v < 0.05 and 0 or math.floor((v - 0.05) / 0.10) + 1 end
        if step(record.rain) > step(before) then
            FFR_CropDamageManager.notify(record.farmId, FFR_L10n.t(
                "ffr_damage_rain",
                FFR_CropDamageManager.formatName(record.fruitName), record.farmlandId,
                math.floor(record.rain * 100 + 0.5)))
        end
    end
end

-- Hail: one summary per farm when the storm ends.
function FFR_CropDamageManager.trackStorm(hailing, hits)
    if hailing then
        FFR_CropDamageManager.storm = FFR_CropDamageManager.storm or {}
        for _, record in ipairs(hits) do FFR_CropDamageManager.storm[record.farmlandId] = record end
        return
    end
    local storm = FFR_CropDamageManager.storm
    FFR_CropDamageManager.storm = nil
    if storm == nil then return end
    local byFarm = {}
    for _, record in pairs(storm) do
        byFarm[record.farmId] = byFarm[record.farmId] or {}
        table.insert(byFarm[record.farmId], record)
    end
    for farmId, list in pairs(byFarm) do
        table.sort(list, function(a, b) return a.hail > b.hail end)
        local parts = {}
        for i = 1, math.min(3, #list) do
            parts[i] = FFR_L10n.t("ffr_damage_hail_part", list[i].farmlandId,
                FFR_CropDamageManager.formatName(list[i].fruitName), math.floor(list[i].hail * 100 + 0.5))
        end
        local text = FFR_L10n.t("ffr_damage_hail",
            #list == 1 and FFR_L10n.t("ffr_insure_field_one") or FFR_L10n.t("ffr_insure_field_many", #list),
            table.concat(parts, ", ") .. (#list > 3 and ", ..." or ""))
        Logging.info("FFR Crop Damage: Farm %d - %s", farmId, text)
        FFR_CropDamageManager.notify(farmId, text)
    end
end

function FFR_CropDamageManager.formatName(name)
    return FFR_L10n.fillTypeTitle(name)
end

function FFR_CropDamageManager.notify(farmId, text)
    if FFR_Network ~= nil then
        FFR_Network.sendNotice("CROP_DAMAGE", farmId, {text = text})
    end
end

-- Shown on the machines of that farm's players.
function FFR_CropDamageManager.showNotice(text)
    if g_currentMission == nil or g_currentMission.addIngameNotification == nil then
        Logging.info("FFR Crop Damage: %s", tostring(text))
        return
    end
    local kind = FSBaseMission ~= nil and (FSBaseMission.INGAME_NOTIFICATION_CRITICAL or FSBaseMission.INGAME_NOTIFICATION_INFO) or nil
    pcall(g_currentMission.addIngameNotification, g_currentMission, kind, tostring(text))
end

--------------------------------------------------
-- Harvest: combines thresh less on damaged parcels
--------------------------------------------------

function FFR_CropDamageManager.getHarvestFactor(vehicle)
    local node = vehicle.rootNode or (vehicle.components ~= nil and vehicle.components[1] ~= nil and vehicle.components[1].node) or nil
    if node == nil or g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return 1, nil end
    local x, _, z = getWorldTranslation(node)
    local ok, farmlandId = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
    local record = ok and farmlandId ~= nil and FFR_CropDamageManager.records[farmlandId] or nil
    if record == nil then return 1, nil end
    return 1 - FFR_CropDamageManager.getTotal(record), record
end

function FFR_CropDamageManager.wrapCombine(vehicle)
    local original = vehicle.addCutterArea
    if type(original) ~= "function" then return end
    vehicle.ffrCropDamageWrapped = true
    vehicle.addCutterArea = function(self, area, realArea, ...)
        local spec = self.spec_combine
        local factor, record = 1, nil
        if spec ~= nil and tonumber(spec.threshingScale) ~= nil then
            local ok, f, r = pcall(FFR_CropDamageManager.getHarvestFactor, self)
            if ok then factor, record = f, r end
        end
        if factor >= 0.999 then return original(self, area, realArea, ...) end
        local scale = spec.threshingScale
        spec.threshingScale = scale * factor
        local results = {pcall(original, self, area, realArea, ...)}
        spec.threshingScale = scale
        if not results[1] then error(results[2], 0) end
        if record ~= nil and not FFR_CropDamageManager.loggedHarvest[record.farmlandId] then
            FFR_CropDamageManager.loggedHarvest[record.farmlandId] = true
            Logging.info("FFR Crop Damage: Harvesting Farmland %d (%s) at %d%% of normal yield",
                record.farmlandId, tostring(record.fruitName), math.floor(factor * 100 + 0.5))
        end
        return unpack(results, 2)
    end
end

function FFR_CropDamageManager.wrapCombines()
    local vehicles = g_currentMission.vehicleSystem ~= nil and g_currentMission.vehicleSystem.vehicles or g_currentMission.vehicles
    for _, vehicle in pairs(vehicles or {}) do
        if type(vehicle) == "table" and vehicle.spec_combine ~= nil and not vehicle.ffrCropDamageWrapped then
            FFR_CropDamageManager.wrapCombine(vehicle)
        end
    end
end

--------------------------------------------------
-- Save / load (server)
--------------------------------------------------

FFR_CropDamageManager.FIELDS = {"farmlandId", "farmId", "fruitTypeIndex", "hail", "rain", "areaHa", "stage", "plantedSerial"}

function FFR_CropDamageManager.saveToXML(xmlFile, key)
    local i = 0
    for _, record in pairs(FFR_CropDamageManager.records) do
        local base = string.format("%s.field(%d)", key, i)
        for _, f in ipairs(FFR_CropDamageManager.FIELDS) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(record[f]) or 0) end
        setXMLString(xmlFile, base .. "#fruitName", tostring(record.fruitName or ""))
        setXMLBool(xmlFile, base .. "#claimed", record.claimed == true)
        i = i + 1
    end
end

function FFR_CropDamageManager.loadFromXML(xmlFile, key)
    FFR_CropDamageManager.records = {}
    local i = 0
    while true do
        local base = string.format("%s.field(%d)", key, i)
        if not hasXMLProperty(xmlFile, base) then break end
        local record = {}
        for _, f in ipairs(FFR_CropDamageManager.FIELDS) do record[f] = getXMLFloat(xmlFile, base .. "#" .. f) end
        record.farmlandId = math.floor(record.farmlandId or 0)
        record.farmId = math.floor(record.farmId or 0)
        record.fruitTypeIndex = math.floor(record.fruitTypeIndex or 0)
        record.fruitName = getXMLString(xmlFile, base .. "#fruitName") or ""
        record.claimed = getXMLBool(xmlFile, base .. "#claimed") == true
        FFR_CropDamageManager.records[record.farmlandId] = record
        i = i + 1
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_CropDamageManager:update(dt)
    FFR_CropDamageManager.updateTimer = FFR_CropDamageManager.updateTimer + dt
    if FFR_CropDamageManager.updateTimer < 2000 then return end
    FFR_CropDamageManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    pcall(FFR_CropDamageManager.wrapCombines)
    local env = g_currentMission.environment
    local hour = env ~= nil and tonumber(env.currentHour) or nil
    if hour == nil and env ~= nil and env.dayTime ~= nil then
        hour = math.floor((tonumber(env.dayTime) or 0) / 3600000) % 24
    end
    if hour == nil or hour == FFR_CropDamageManager.lastHour then return end
    local first = FFR_CropDamageManager.lastHour == nil
    FFR_CropDamageManager.lastHour = hour
    local ok, err = pcall(FFR_CropDamageManager.checkHour)
    if not ok then
        Logging.warning("FFR Crop Damage: Hourly check failed (%s)", tostring(err))
    elseif first then
        local count = 0
        for _ in pairs(FFR_CropDamageManager.records) do count = count + 1 end
        Logging.info("FFR Crop Damage: Watching %d crop parcel(s); weather now %s", count, FFR_CropDamageManager.getWeatherText())
    end
end

function FFR_CropDamageManager:loadMap(mapName)
    FFR_CropDamageManager.records = {}
    FFR_CropDamageManager.lastHour = nil
    FFR_CropDamageManager.storm = nil
    FFR_CropDamageManager.cells = nil
    FFR_CropDamageManager.dryHours = FFR_CropDamageManager.STORM_GAP_HOURS
    FFR_CropDamageManager.loggedHarvest = {}
end

function FFR_CropDamageManager:deleteMap() FFR_CropDamageManager.records = {} end
function FFR_CropDamageManager:draw() end
function FFR_CropDamageManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_CropDamageManager:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_CropDamageManager)
Logging.info("FFR Crop Damage: Weather damage tracker installed")
