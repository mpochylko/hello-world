FFR_CropInsuranceManager = {}

--------------------------------------------------
-- Crop insurance (yield protection)
--
-- Per crop and per crop year (v0.9.50; before, one
-- policy covered every crop). As in real crop
-- insurance, the crop year is the HARVEST year:
--
-- * Spring sign-up (March-May) adds spring-sown
--   crops to this year's policy: crops first seen
--   from March to July.
-- * Fall sign-up (August-September) adds fall-sown
--   crops (winter wheat, winter canola...) to NEXT
--   year's policy: crops first seen from August to
--   February, harvested the following summer.
--
-- Each crop on a policy has its own coverage. The
-- premium is billed per acre actually planted to an
-- insured crop: on the month-end bill once the crop
-- is in the ground (or at a claim filed earlier).
-- Every planting is billed once (parcel, crop and
-- planting month), so a double crop on one parcel
-- is billed and covered separately. Once billed, a
-- planting stays covered at its coverage until it
-- is harvested, across the March year change. A
-- crop with billed acres keeps its coverage for
-- that sign-up. Only insured crops can claim.
-- Policies from older saves have no crop list and
-- cover every crop of their year (allCrops).
--
-- When weather damages a crop (FFR_CropDamageManager)
-- beyond the deductible (1 - coverage), the farm
-- files a claim for that parcel; the damage at that
-- moment is recorded, so the field can be harvested
-- straight away. An adjuster visits ADJUSTER_MIN..
-- ADJUSTER_MAX in-game hours later (hours, not days,
-- so short months do not delay payment by months),
-- confirms the damage (within a few percent) and pays:
--
--   expected crop value x (damage - deductible)
--
-- One claim per planting. A claim must be filed
-- before the parcel's damage record clears after
-- harvest.
--
-- Per farm: state.cropPolicies (one per crop year)
-- and state.cropClaims.
--------------------------------------------------

FFR_CropInsuranceManager.COVERAGE_LEVELS = {0.50, 0.60, 0.70, 0.75, 0.80, 0.85}

-- Premium per insured acre per crop at each coverage level (before difficulty).
FFR_CropInsuranceManager.PREMIUM_PER_ACRE = {
    [0.50] = 6, [0.60] = 10, [0.70] = 15, [0.75] = 20, [0.80] = 27, [0.85] = 36
}

-- Sign-up windows by FS25 period (1 = March): spring for this year's crops,
-- fall for crops sown now and harvested next year.
FFR_CropInsuranceManager.SPRING_SIGNUP = {1, 3}
FFR_CropInsuranceManager.FALL_SIGNUP = {6, 7}
-- Crops first seen from this period (August) to February are fall-sown.
FFR_CropInsuranceManager.FALL_FIRST_PERIOD = 6

-- In-game hours from filing to the adjuster's visit.
FFR_CropInsuranceManager.ADJUSTER_MIN = 6
FFR_CropInsuranceManager.ADJUSTER_MAX = 24
FFR_CropInsuranceManager.ASSESS_MIN = 0.92
FFR_CropInsuranceManager.ASSESS_MAX = 1.05

FFR_CropInsuranceManager.updateTimer = 0

--------------------------------------------------
-- Calendar
--------------------------------------------------

function FFR_CropInsuranceManager.getCalendar()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil then return nil, nil, 0 end
    local day = tonumber(env.currentMonotonicDay) or tonumber(env.currentDay) or 0
    return tonumber(env.currentPeriod), tonumber(env.currentYear), day
end

-- Hours since the start of the save (day x 24 + hour), for adjuster visits.
function FFR_CropInsuranceManager.getAbsoluteHour()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil then return 0 end
    local _, _, day = FFR_CropInsuranceManager.getCalendar()
    local hour = tonumber(env.currentHour)
    if hour == nil and env.dayTime ~= nil then hour = math.floor((tonumber(env.dayTime) or 0) / 3600000) % 24 end
    return day * 24 + (hour or 0)
end

-- When a claim's adjuster is due (claims saved before v0.9.28 stored a day).
function FFR_CropInsuranceManager.getVisitHour(claim)
    local hour = tonumber(claim.visitHour)
    if hour ~= nil and hour > 0 then return hour end
    return (tonumber(claim.visitDay) or 0) * 24
end

-- The open sign-up: "SPRING" / "FALL" and the crop year it adds crops to, or nil.
function FFR_CropInsuranceManager.getSignup()
    local period, year = FFR_CropInsuranceManager.getCalendar()
    if period == nil or year == nil then return nil, nil end
    local s, f = FFR_CropInsuranceManager.SPRING_SIGNUP, FFR_CropInsuranceManager.FALL_SIGNUP
    if period >= s[1] and period <= s[2] then return "SPRING", year end
    if period >= f[1] and period <= f[2] then return "FALL", year + 1 end
    return nil, nil
end

function FFR_CropInsuranceManager.isSignupOpen()
    return FFR_CropInsuranceManager.getSignup() ~= nil
end

-- A planting's season and crop year from the month it was first seen.
-- Records from before v0.9.50 have no month: this year's spring crop.
function FFR_CropInsuranceManager.getPlanting(record)
    local serial = tonumber(record ~= nil and record.plantedSerial or nil) or 0
    if serial <= 0 then
        local _, year = FFR_CropInsuranceManager.getCalendar()
        return "SPRING", year or 0, 0
    end
    local year = math.floor((serial - 1) / 12)
    local period = serial - year * 12
    if period >= FFR_CropInsuranceManager.FALL_FIRST_PERIOD then return "FALL", year + 1, serial end
    return "SPRING", year, serial
end

-- The farm's policy for a crop year (default: the year sign-up is open for, else this year).
function FFR_CropInsuranceManager.getPolicy(state, year)
    if year == nil then
        local _, signupYear = FFR_CropInsuranceManager.getSignup()
        local _, currentYear = FFR_CropInsuranceManager.getCalendar()
        year = signupYear or currentYear
    end
    for _, policy in ipairs(state ~= nil and state.cropPolicies or {}) do
        if tonumber(policy.year) == year then return policy end
    end
    return nil
end

function FFR_CropInsuranceManager.formatMoney(value)
    if g_FFRDashboardDataManager ~= nil and g_FFRDashboardDataManager.formatMoney ~= nil then
        return g_FFRDashboardDataManager:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

--------------------------------------------------
-- Rates
--------------------------------------------------

function FFR_CropInsuranceManager.getPremiumScale()
    return FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("insurance")) or 1) or 1
end

function FFR_CropInsuranceManager.getRate(coverage)
    local level = FFR_CropInsuranceManager.stepCoverage(coverage, 0)
    return (FFR_CropInsuranceManager.PREMIUM_PER_ACRE[level] or 20) * FFR_CropInsuranceManager.getPremiumScale()
end

-- Crop land a farm owns (acres), for the Advisor's sign-up estimate. Cached a few
-- seconds: the pages ask every second and the field scan is not free.
FFR_CropInsuranceManager.acreCache = {}

function FFR_CropInsuranceManager.getInsurableAcres(farmId)
    local now = tonumber(g_time) or 0
    local cached = FFR_CropInsuranceManager.acreCache[farmId]
    if cached ~= nil and now >= cached.time and now - cached.time < 5000 then return cached.acres end
    local acres = 0
    if g_FFRLandRegistryManager ~= nil then
        for _, row in ipairs(g_FFRLandRegistryManager:getTitles(farmId)) do
            local ha = tonumber(row.arableHa) or -1
            if ha < 0 then ha = tonumber(row.areaInHa) or 0 end
            acres = acres + ha * FFR_CropDamageManager.ACRES_PER_HA
        end
    end
    FFR_CropInsuranceManager.acreCache[farmId] = {time = now, acres = acres}
    return acres
end

function FFR_CropInsuranceManager.stepCoverage(coverage, direction)
    local levels = FFR_CropInsuranceManager.COVERAGE_LEVELS
    local index = 4
    for i, level in ipairs(levels) do
        if math.abs(level - (tonumber(coverage) or 0.75)) < 0.001 then index = i end
    end
    index = math.max(1, math.min(#levels, index + (tonumber(direction) or 0)))
    return levels[index]
end

--------------------------------------------------
-- Crops on a policy
--------------------------------------------------

-- Every crop on the map that can be insured (FS25 fruit name), A-Z by shown name.
function FFR_CropInsuranceManager.getInsurableCrops()
    local list = {}
    if g_fruitTypeManager == nil then return list end
    local fruits = nil
    if g_fruitTypeManager.getFruitTypes ~= nil then
        local ok, result = pcall(g_fruitTypeManager.getFruitTypes, g_fruitTypeManager)
        if ok then fruits = result end
    end
    for _, desc in pairs(fruits or g_fruitTypeManager.fruitTypes or {}) do
        if FFR_CropDamageManager.isInsurableFruit(desc) and desc.allowsSeeding ~= false then
            table.insert(list, tostring(desc.name))
        end
    end
    table.sort(list, function(a, b) return FFR_CropDamageManager.formatName(a) < FFR_CropDamageManager.formatName(b) end)
    return list
end

-- A policy's entry for a crop and season ({fruitName, coverage, season}), or nil.
function FFR_CropInsuranceManager.getCropEntry(policy, fruitName, season)
    if policy == nil or fruitName == nil then return nil end
    for _, entry in ipairs(policy.crops or {}) do
        if entry.fruitName == fruitName and (season == nil or entry.season == season) then return entry end
    end
    return nil
end

-- Coverage of a crop on a policy for a season, or nil when it is not insured.
function FFR_CropInsuranceManager.getCropCoverage(policy, fruitName, season)
    if policy == nil then return nil end
    if policy.allCrops then return tonumber(policy.coverage) or 0.75 end
    local entry = FFR_CropInsuranceManager.getCropEntry(policy, fruitName, season)
    return entry ~= nil and (tonumber(entry.coverage) or 0.75) or nil
end

-- The bill of one planting (record or Insurance-page row), searched in every policy.
function FFR_CropInsuranceManager.findBill(state, record)
    local _, _, serial = FFR_CropInsuranceManager.getPlanting(record)
    for _, policy in ipairs(state ~= nil and state.cropPolicies or {}) do
        for _, bill in ipairs(policy.billed or {}) do
            if bill.farmlandId == record.farmlandId and bill.fruitName == record.fruitName
                and (tonumber(bill.plantedSerial) or 0) == serial then
                return bill
            end
        end
    end
    return nil
end

-- Coverage of a standing planting: its bill's, else its crop year's policy entry; nil = not insured.
function FFR_CropInsuranceManager.getRecordCoverage(state, record)
    if record == nil then return nil end
    local bill = FFR_CropInsuranceManager.findBill(state, record)
    if bill ~= nil then return tonumber(bill.coverage) or 0.75 end
    local season, cropYear = FFR_CropInsuranceManager.getPlanting(record)
    return FFR_CropInsuranceManager.getCropCoverage(FFR_CropInsuranceManager.getPolicy(state, cropYear), record.fruitName, season)
end

-- Billed acres and premium on a policy: one crop and season, or everything (fruitName nil).
function FFR_CropInsuranceManager.getBilledTotals(policy, fruitName, season)
    local acres, premium = 0, 0
    for _, bill in ipairs(policy ~= nil and policy.billed or {}) do
        if (fruitName == nil or bill.fruitName == fruitName) and (season == nil or bill.season == season) then
            acres = acres + (tonumber(bill.acres) or 0)
            premium = premium + (tonumber(bill.premium) or 0)
        end
    end
    return acres, premium
end

-- Acres a farm has standing of a crop (optionally only plantings of one crop year and season).
function FFR_CropInsuranceManager.getPlantedAcres(state, fruitName, cropYear, season)
    local acres = 0
    for _, row in ipairs(FFR_CropInsuranceManager.getDamageRows(state)) do
        local rowSeason, rowYear = FFR_CropInsuranceManager.getPlanting(row)
        if row.fruitName == fruitName and (cropYear == nil or rowYear == cropYear) and (season == nil or rowSeason == season) then
            acres = acres + (tonumber(row.areaHa) or 0) * FFR_CropDamageManager.ACRES_PER_HA
        end
    end
    return acres
end

-- Standing plantings of insured crops not billed yet: one bill each. Read by the
-- month-end bill (server); markBilled records them once charged.
function FFR_CropInsuranceManager.getUnbilled(state)
    local list = {}
    for _, record in ipairs(FFR_CropDamageManager.getRecordsForFarm(state.farmId)) do
        local season, cropYear, serial = FFR_CropInsuranceManager.getPlanting(record)
        local policy = FFR_CropInsuranceManager.getPolicy(state, cropYear)
        if policy ~= nil and not policy.allCrops and FFR_CropInsuranceManager.findBill(state, record) == nil then
            local coverage = FFR_CropInsuranceManager.getCropCoverage(policy, record.fruitName, season)
            if coverage ~= nil then
                local acres = (tonumber(record.areaHa) or 0) * FFR_CropDamageManager.ACRES_PER_HA
                table.insert(list, {farmlandId = record.farmlandId, fruitName = record.fruitName, plantedSerial = serial,
                    season = season, cropYear = cropYear, coverage = coverage, acres = acres,
                    premium = acres * FFR_CropInsuranceManager.getRate(coverage)})
            end
        end
    end
    return list
end

function FFR_CropInsuranceManager.getUnbilledPremium(state)
    local total = 0
    for _, bill in ipairs(FFR_CropInsuranceManager.getUnbilled(state)) do total = total + bill.premium end
    return total
end

function FFR_CropInsuranceManager.markBilled(state, bills)
    for _, bill in ipairs(bills) do
        local policy = FFR_CropInsuranceManager.getPolicy(state, bill.cropYear)
        if policy ~= nil then
            policy.billed = policy.billed or {}
            table.insert(policy.billed, bill)
            policy.acres = (tonumber(policy.acres) or 0) + bill.acres
            policy.premium = (tonumber(policy.premium) or 0) + bill.premium
            Logging.info("FFR Crop Insurance: Farm %d billed Farmland %d %s (%s, crop year %d), %d ac at %d%%, $%d",
                state.farmId, bill.farmlandId, tostring(bill.fruitName), tostring(bill.season), bill.cropYear,
                math.floor(bill.acres), math.floor(bill.coverage * 100 + 0.5), math.floor(bill.premium))
        end
    end
end

-- Keeps last year's policy (its billed fall crops may still be standing), this year's and next year's.
function FFR_CropInsuranceManager.prunePolicies(state)
    local _, year = FFR_CropInsuranceManager.getCalendar()
    if year == nil or state.cropPolicies == nil then return end
    for i = #state.cropPolicies, 1, -1 do
        if (tonumber(state.cropPolicies[i].year) or 0) < year - 1 then table.remove(state.cropPolicies, i) end
    end
end

--------------------------------------------------
-- Actions (server, farm managers via FFR_Network)
--------------------------------------------------

-- Adds a crop to the open sign-up's policy or changes its coverage.
function FFR_CropInsuranceManager.insureCrop(state, fruitName, coverage)
    local season, cropYear = FFR_CropInsuranceManager.getSignup()
    if season == nil then return false, FFR_L10n.t("ffr_insure_closed") end
    fruitName = tostring(fruitName or "")
    local known = false
    for _, name in ipairs(FFR_CropInsuranceManager.getInsurableCrops()) do if name == fruitName then known = true end end
    if not known then return false, FFR_L10n.t("ffr_insure_crop_unknown") end
    local level = FFR_CropInsuranceManager.stepCoverage(coverage, 0)
    local policy = FFR_CropInsuranceManager.getPolicy(state, cropYear)
    if policy ~= nil and policy.allCrops then return false, FFR_L10n.t("ffr_insure_already") end
    if policy == nil then
        policy = {year = cropYear, crops = {}, billed = {}, acres = 0, premium = 0}
        state.cropPolicies = state.cropPolicies or {}
        table.insert(state.cropPolicies, policy)
        FFR_CropInsuranceManager.prunePolicies(state)
    end
    local cropName = FFR_CropDamageManager.formatName(fruitName)
    local entry = FFR_CropInsuranceManager.getCropEntry(policy, fruitName, season)
    if entry ~= nil then
        if FFR_CropInsuranceManager.getBilledTotals(policy, fruitName, season) > 0 and math.abs(entry.coverage - level) > 0.001 then
            return false, FFR_L10n.t("ffr_insure_crop_locked", cropName)
        end
        entry.coverage = level
    else
        table.insert(policy.crops, {fruitName = fruitName, coverage = level, season = season})
    end
    Logging.info("FFR Crop Insurance: Farm %d insures %s at %d%% (%s sign-up, crop year %d)",
        state.farmId, fruitName, math.floor(level * 100), season, cropYear)
    local rateText = FFR_CropInsuranceManager.formatMoney(FFR_L10n.perArea(FFR_CropInsuranceManager.getRate(level))) .. " / " .. FFR_L10n.getPerAreaUnit()
    if season == "FALL" then
        return true, FFR_L10n.t("ffr_insure_crop_added_fall", cropName, math.floor(level * 100 + 0.5), cropYear, rateText)
    end
    return true, FFR_L10n.t("ffr_insure_crop_added", cropName, math.floor(level * 100 + 0.5), rateText)
end

-- Takes a crop off the open sign-up's policy (nothing billed for it yet).
function FFR_CropInsuranceManager.removeCrop(state, fruitName)
    local season, cropYear = FFR_CropInsuranceManager.getSignup()
    if season == nil then return false, FFR_L10n.t("ffr_insure_closed") end
    local policy = FFR_CropInsuranceManager.getPolicy(state, cropYear)
    local cropName = FFR_CropDamageManager.formatName(fruitName)
    if policy == nil or policy.allCrops or FFR_CropInsuranceManager.getCropEntry(policy, fruitName, season) == nil then
        return false, FFR_L10n.t("ffr_insure_crop_not_on", cropName)
    end
    if FFR_CropInsuranceManager.getBilledTotals(policy, fruitName, season) > 0 then
        return false, FFR_L10n.t("ffr_insure_crop_locked", cropName)
    end
    for i, entry in ipairs(policy.crops) do
        if entry.fruitName == fruitName and entry.season == season then table.remove(policy.crops, i) break end
    end
    Logging.info("FFR Crop Insurance: Farm %d removed %s (%s, crop year %d)", state.farmId, tostring(fruitName), season, cropYear)
    return true, FFR_L10n.t("ffr_insure_crop_removed", cropName)
end

function FFR_CropInsuranceManager.fileClaim(state, farmlandId)
    local record = FFR_CropDamageManager.records[tonumber(farmlandId) or -1]
    if record == nil or record.farmId ~= state.farmId then return false, FFR_L10n.t("ffr_insure_claim_nocrop") end
    if record.claimed then return false, FFR_L10n.t("ffr_insure_claim_twice") end
    local coverage = FFR_CropInsuranceManager.getRecordCoverage(state, record)
    if coverage == nil then
        return false, FFR_L10n.t("ffr_insure_claim_not_insured", FFR_CropDamageManager.formatName(record.fruitName))
    end
    local damage = FFR_CropDamageManager.getTotal(record)
    local deductible = 1 - coverage
    if damage <= deductible then
        return false, FFR_L10n.t("ffr_insure_claim_deductible",
            math.floor(damage * 100 + 0.5), math.floor(deductible * 100 + 0.5))
    end
    -- Planted since the last month-end bill: its premium is due before the claim.
    local bills = {}
    for _, bill in ipairs(FFR_CropInsuranceManager.getUnbilled(state)) do
        if bill.farmlandId == record.farmlandId then table.insert(bills, bill) end
    end
    if #bills > 0 then
        local premium = 0
        for _, bill in ipairs(bills) do premium = premium + bill.premium end
        if not FFR_CropInsuranceManager.charge(state, premium) then return false, FFR_L10n.t("ffr_insure_charge_failed") end
        FFR_CropInsuranceManager.markBilled(state, bills)
    end
    local _, _, day = FFR_CropInsuranceManager.getCalendar()
    local delay = math.random(FFR_CropInsuranceManager.ADJUSTER_MIN, FFR_CropInsuranceManager.ADJUSTER_MAX)
    local visit = FFR_CropInsuranceManager.getAbsoluteHour() + delay
    local liters, value = FFR_CropDamageManager.getExpected(record)
    state.cropClaims = state.cropClaims or {}
    table.insert(state.cropClaims, {
        farmlandId = record.farmlandId, fruitName = record.fruitName, filedDay = day, visitHour = visit,
        status = "FILED", damage = damage, expectedValue = value, coverage = coverage, payout = 0
    })
    record.claimed = true
    Logging.info("FFR Crop Insurance: Farm %d claim filed for Farmland %d (%d%% damage), adjuster in %d hours",
        state.farmId, record.farmlandId, math.floor(damage * 100), delay)
    return true, FFR_L10n.t("ffr_insure_claim_filed_msg",
        math.floor(damage * 100 + 0.5))
end

--------------------------------------------------
-- Money
--------------------------------------------------

function FFR_CropInsuranceManager.charge(state, amount)
    if amount <= 0 then return true end
    if g_FFRMonthlyFinancialProcessor == nil or not g_FFRMonthlyFinancialProcessor:applyFarmBalance(-amount, nil, state.farmId) then
        return false
    end
    local f = state.financialManager
    f.monthlyExpenses = (tonumber(f.monthlyExpenses) or 0) + amount
    f.annualExpenses = (tonumber(f.annualExpenses) or 0) + amount
    f:updateAnnualProfit()
    state.insuranceManager.totalPremiumsPaid = (tonumber(state.insuranceManager.totalPremiumsPaid) or 0) + amount
    return true
end

function FFR_CropInsuranceManager.pay(state, amount)
    if amount <= 0 or g_FFRMonthlyFinancialProcessor == nil then return false end
    if not g_FFRMonthlyFinancialProcessor:applyFarmBalance(amount, nil, state.farmId) then return false end
    local f = state.financialManager
    f.monthlyRevenue = (tonumber(f.monthlyRevenue) or 0) + amount
    f.annualRevenue = (tonumber(f.annualRevenue) or 0) + amount
    f:updateAnnualProfit()
    state.insuranceManager.totalClaimsPaid = (tonumber(state.insuranceManager.totalClaimsPaid) or 0) + amount
    state.insuranceManager.claimCount = (tonumber(state.insuranceManager.claimCount) or 0) + 1
    return true
end

--------------------------------------------------
-- Adjuster visits (server)
--------------------------------------------------

function FFR_CropInsuranceManager.processClaims()
    local now = FFR_CropInsuranceManager.getAbsoluteHour()
    for _, state in ipairs(g_FFR:getFarmStates()) do
        for _, claim in ipairs(state.cropClaims or {}) do
            if claim.status == "FILED" and now >= FFR_CropInsuranceManager.getVisitHour(claim) then
                FFR_CropInsuranceManager.assess(state, claim)
            end
        end
    end
end

function FFR_CropInsuranceManager.assess(state, claim)
    -- The adjuster sees today's damage if the crop is still standing, else what was filed.
    local record = FFR_CropDamageManager.records[claim.farmlandId]
    local seen = record ~= nil and record.farmId == state.farmId and FFR_CropDamageManager.getTotal(record) or claim.damage
    local found = math.max(0, math.min(FFR_CropDamageManager.TOTAL_CAP, seen * FFR_CropDamageManager.random(
        FFR_CropInsuranceManager.ASSESS_MIN, FFR_CropInsuranceManager.ASSESS_MAX)))
    local deductible = 1 - (tonumber(claim.coverage) or 0.75)
    local payout = math.floor((tonumber(claim.expectedValue) or 0) * math.max(0, found - deductible) + 0.5)
    claim.assessed = found
    claim.payout = payout
    local text
    if payout > 0 and FFR_CropInsuranceManager.pay(state, payout) then
        claim.status = "PAID"
        text = FFR_L10n.t("ffr_insure_adjuster_paid",
            math.floor(found * 100 + 0.5), claim.farmlandId,
            FFR_CropDamageManager.formatName(claim.fruitName), FFR_CropInsuranceManager.formatMoney(payout))
    else
        claim.status = "DENIED"
        text = FFR_L10n.t("ffr_insure_adjuster_denied",
            math.floor(found * 100 + 0.5), claim.farmlandId, math.floor(deductible * 100 + 0.5))
    end
    Logging.info("FFR Crop Insurance: Farm %d - %s", state.farmId, text)
    FFR_CropDamageManager.notify(state.farmId, text)
    if g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

function FFR_CropInsuranceManager.formatNumber(value)
    local s = tostring(math.floor((tonumber(value) or 0) + 0.5))
    while true do
        local updated, count = string.gsub(s, "^(-?%d+)(%d%d%d)", "%1,%2")
        s = updated
        if count == 0 then break end
    end
    return s
end

--------------------------------------------------
-- Rows for the Insurance page (any machine)
--------------------------------------------------

function FFR_CropInsuranceManager.getDamageRows(state)
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return state.cropDamageRows or {} end
    return FFR_CropDamageManager.getFarmRows(state.farmId)
end

-- Latest claim per parcel, for the table's status column.
function FFR_CropInsuranceManager.getClaimByParcel(state)
    local map = {}
    for _, claim in ipairs(state.cropClaims or {}) do map[claim.farmlandId] = claim end
    return map
end

--------------------------------------------------
-- Save / load per farm (called by FFR_SaveManager)
--------------------------------------------------

FFR_CropInsuranceManager.CLAIM_FIELDS = {"farmlandId", "filedDay", "visitDay", "visitHour", "damage", "assessed", "expectedValue", "coverage", "payout"}
FFR_CropInsuranceManager.BILL_FIELDS = {"plantedSerial", "cropYear", "coverage", "acres", "premium"}

function FFR_CropInsuranceManager.savePolicy(xmlFile, base, policy)
    setXMLInt(xmlFile, base .. "#year", tonumber(policy.year) or 0)
    setXMLFloat(xmlFile, base .. "#coverage", tonumber(policy.coverage) or 0)
    setXMLFloat(xmlFile, base .. "#acres", tonumber(policy.acres) or 0)
    setXMLFloat(xmlFile, base .. "#premium", tonumber(policy.premium) or 0)
    setXMLBool(xmlFile, base .. "#allCrops", policy.allCrops == true)
    for i, entry in ipairs(policy.crops or {}) do
        local crop = string.format("%s.crop(%d)", base, i - 1)
        setXMLString(xmlFile, crop .. "#fruitName", tostring(entry.fruitName))
        setXMLFloat(xmlFile, crop .. "#coverage", tonumber(entry.coverage) or 0.75)
        setXMLString(xmlFile, crop .. "#season", tostring(entry.season or "SPRING"))
    end
    for i, bill in ipairs(policy.billed or {}) do
        local b = string.format("%s.billed(%d)", base, i - 1)
        setXMLInt(xmlFile, b .. "#farmlandId", tonumber(bill.farmlandId) or 0)
        setXMLString(xmlFile, b .. "#fruitName", tostring(bill.fruitName))
        setXMLString(xmlFile, b .. "#season", tostring(bill.season or "SPRING"))
        for _, f in ipairs(FFR_CropInsuranceManager.BILL_FIELDS) do setXMLFloat(xmlFile, b .. "#" .. f, tonumber(bill[f]) or 0) end
    end
end

function FFR_CropInsuranceManager.loadPolicy(xmlFile, base)
    local policy = {
        year = getXMLInt(xmlFile, base .. "#year") or 0,
        coverage = getXMLFloat(xmlFile, base .. "#coverage") or 0.75,
        acres = getXMLFloat(xmlFile, base .. "#acres") or 0,
        premium = getXMLFloat(xmlFile, base .. "#premium") or 0,
        crops = {}, billed = {}
    }
    local j = 0
    while hasXMLProperty(xmlFile, string.format("%s.crop(%d)", base, j)) do
        local crop = string.format("%s.crop(%d)", base, j)
        table.insert(policy.crops, {fruitName = getXMLString(xmlFile, crop .. "#fruitName") or "",
            coverage = getXMLFloat(xmlFile, crop .. "#coverage") or 0.75,
            season = getXMLString(xmlFile, crop .. "#season") or "SPRING"})
        j = j + 1
    end
    j = 0
    while hasXMLProperty(xmlFile, string.format("%s.billed(%d)", base, j)) do
        local b = string.format("%s.billed(%d)", base, j)
        local bill = {farmlandId = getXMLInt(xmlFile, b .. "#farmlandId") or 0,
            fruitName = getXMLString(xmlFile, b .. "#fruitName") or "",
            season = getXMLString(xmlFile, b .. "#season") or "SPRING"}
        for _, f in ipairs(FFR_CropInsuranceManager.BILL_FIELDS) do bill[f] = getXMLFloat(xmlFile, b .. "#" .. f) or 0 end
        if bill.coverage <= 0 then bill.coverage = 0.75 end
        if bill.cropYear <= 0 then bill.cropYear = policy.year end
        table.insert(policy.billed, bill)
        j = j + 1
    end
    -- Policies saved before v0.9.50 (no allCrops flag) covered every crop.
    local allCrops = getXMLBool(xmlFile, base .. "#allCrops")
    policy.allCrops = allCrops == true or (allCrops == nil and (tonumber(policy.coverage) or 0) > 0)
    return policy
end

function FFR_CropInsuranceManager.saveFarm(xmlFile, key, state)
    for i, policy in ipairs(state.cropPolicies or {}) do
        FFR_CropInsuranceManager.savePolicy(xmlFile, string.format("%s.policies.policy(%d)", key, i - 1), policy)
    end
    for i, claim in ipairs(state.cropClaims or {}) do
        local base = string.format("%s.claims.claim(%d)", key, i - 1)
        for _, f in ipairs(FFR_CropInsuranceManager.CLAIM_FIELDS) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(claim[f]) or 0) end
        setXMLString(xmlFile, base .. "#status", tostring(claim.status or "FILED"))
        setXMLString(xmlFile, base .. "#fruitName", tostring(claim.fruitName or ""))
    end
end

function FFR_CropInsuranceManager.loadFarm(xmlFile, key, state)
    state.cropPolicies = {}
    state.cropClaims = {}
    local p = 0
    while hasXMLProperty(xmlFile, string.format("%s.policies.policy(%d)", key, p)) do
        table.insert(state.cropPolicies, FFR_CropInsuranceManager.loadPolicy(xmlFile, string.format("%s.policies.policy(%d)", key, p)))
        p = p + 1
    end
    -- Format 4 and older: one policy at <key>.policy.
    if p == 0 and hasXMLProperty(xmlFile, key .. ".policy") then
        table.insert(state.cropPolicies, FFR_CropInsuranceManager.loadPolicy(xmlFile, key .. ".policy"))
    end
    local i = 0
    while true do
        local base = string.format("%s.claims.claim(%d)", key, i)
        if not hasXMLProperty(xmlFile, base) then break end
        local claim = {}
        for _, f in ipairs(FFR_CropInsuranceManager.CLAIM_FIELDS) do claim[f] = getXMLFloat(xmlFile, base .. "#" .. f) end
        claim.farmlandId = math.floor(claim.farmlandId or 0)
        claim.status = getXMLString(xmlFile, base .. "#status") or "FILED"
        claim.fruitName = getXMLString(xmlFile, base .. "#fruitName") or ""
        table.insert(state.cropClaims, claim)
        i = i + 1
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_CropInsuranceManager:update(dt)
    FFR_CropInsuranceManager.updateTimer = FFR_CropInsuranceManager.updateTimer + dt
    if FFR_CropInsuranceManager.updateTimer < 2000 then return end
    FFR_CropInsuranceManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    local ok, err = pcall(FFR_CropInsuranceManager.processClaims)
    if not ok then Logging.warning("FFR Crop Insurance: Claim processing failed (%s)", tostring(err)) end
end

function FFR_CropInsuranceManager:loadMap(mapName) FFR_CropInsuranceManager.updateTimer = 0 end
function FFR_CropInsuranceManager:deleteMap() end
function FFR_CropInsuranceManager:draw() end
function FFR_CropInsuranceManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_CropInsuranceManager:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_CropInsuranceManager)
Logging.info("FFR Crop Insurance: Policies and claims installed")
