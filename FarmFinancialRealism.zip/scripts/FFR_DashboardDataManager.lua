FFR_DashboardDataManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_DashboardDataManager:new()

    local self = {}

    setmetatable(
        self,
        {
            __index = FFR_DashboardDataManager
        }
    )

    self.data = {}

    self.updateTimer = 0
    self.updateInterval = 2000

    self.hasLoggedInitialData = false
    self.isActive = true

    self:resetData()

    return self

end

--------------------------------------------------
-- Safe Number
--------------------------------------------------

function FFR_DashboardDataManager:getNumber(
    value,
    defaultValue
)

    local result =
        tonumber(value)

    if result == nil then

        return defaultValue or 0

    end

    return result

end

--------------------------------------------------
-- Count Collection Entries
--------------------------------------------------

function FFR_DashboardDataManager:countEntries(
    collection
)

    if collection == nil then

        return 0

    end

    local count = 0

    for _, _ in pairs(
        collection
    ) do

        count = count + 1

    end

    return count

end

--------------------------------------------------
-- Reset Dashboard Data
--------------------------------------------------

function FFR_DashboardDataManager:resetData()

    self.data = {

        --------------------------------------------------
        -- Financial Overview
        --------------------------------------------------

        cash = 0,

        landValue = 0,

        equipmentValue = 0,

        buildingValue = 0,

        inventoryValue = 0,

        nonCashAssets = 0,

        totalAssets = 0,

        totalDebt = 0,

        netWorth = 0,

        workingCapital = 0,

        monthlyRevenue = 0,

        monthlyExpenses = 0,

        monthlyNetCashFlow = 0,

        monthlyObligations = 0,

        debtRatio = 0,

        --------------------------------------------------
        -- Asset Counts
        --------------------------------------------------

        landCount = 0,

        equipmentCount = 0,

        buildingCount = 0,

        inventoryCount = 0,

        --------------------------------------------------
        -- Credit
        --------------------------------------------------

        creditScore = 0,

        creditRating = FFR_L10n.t("ffr_common_unavailable"),

        interestRateModifier = 1.00,

        operatingLoanLimit = 0,

        expansionLoanLimit = 0,

        --------------------------------------------------
        -- Commodity Market
        --------------------------------------------------

        marketEventName =
            FFR_L10n.t("ffr_news_no_event"),

        commodityCount = 0,

        grainModifier = 1.00,

        oilseedModifier = 1.00,

        pulseModifier = 1.00,

        forageModifier = 1.00,

        vegetableModifier = 1.00,

        industrialModifier = 1.00,

        --------------------------------------------------
        -- Input Market
        --------------------------------------------------

        inputEventName =
            FFR_L10n.t("ffr_news_supplier_regular"),

        inputExpiryText =
            "",

        fertilizerModifier = 1.00,

        liquidFertilizerModifier = 1.00,

        seedModifier = 1.00,

        dieselModifier = 1.00,

        --------------------------------------------------
        -- Dashboard Status
        --------------------------------------------------

        mainInitializationReady = false,

        continuousSyncReady = false,

        buildingSyncReady = false,

        isReady = false,

        lastUpdateTime = 0

    }

end

--------------------------------------------------
-- Main FFR Initialization Status
--------------------------------------------------

function FFR_DashboardDataManager:isMainInitializationReady()

    if g_FFR == nil then

        return false

    end

    if not g_FFR.isInitialized then

        return false

    end

    if g_FFR.isDeleted then

        return false

    end

    if g_FFR.hasPrintedFinalReports ~= true then

        return false

    end

    return true

end

--------------------------------------------------
-- Continuous Asset Sync Status
--------------------------------------------------

function FFR_DashboardDataManager:isContinuousSyncReady()

    if g_FFRContinuousAssetSyncManager == nil then

        return false

    end

    local syncCount =

        self:getNumber(
            g_FFRContinuousAssetSyncManager.syncCount,
            0
        )

    return syncCount > 0

end

--------------------------------------------------
-- Building Sync Status
--------------------------------------------------

function FFR_DashboardDataManager:isBuildingSyncReady()

    if g_FFRBuildingSyncManager == nil then

        return false

    end

    local syncCount =

        self:getNumber(
            g_FFRBuildingSyncManager.syncCount,
            0
        )

    return syncCount > 0

end

--------------------------------------------------
-- Complete Dashboard Readiness
--------------------------------------------------

function FFR_DashboardDataManager:isDashboardReady()

    --------------------------------------------------
    -- A multiplayer client runs no syncs of its own;
    -- it is ready once the server's state arrives.
    --------------------------------------------------

    if FFR_Network ~= nil
        and FFR_Network.isClientOnly()
    then

        return g_FFR ~= nil
            and g_FFR.hasReceivedSync == true

    end

    local mainReady =
        self:isMainInitializationReady()

    local continuousReady =
        self:isContinuousSyncReady()

    local buildingReady =
        self:isBuildingSyncReady()

    self.data.mainInitializationReady =
        mainReady

    self.data.continuousSyncReady =
        continuousReady

    self.data.buildingSyncReady =
        buildingReady

    return

        mainReady
        and continuousReady
        and buildingReady

end

--------------------------------------------------
-- Read Financial Manager
--------------------------------------------------

function FFR_DashboardDataManager:readFinancialData()

    if g_FFR == nil
        or g_FFR.financialManager == nil
    then

        return false

    end

    local financial =
        g_FFR.financialManager

    self.data.cash =

        self:getNumber(
            financial.cashOnHand,
            0
        )

    self.data.totalDebt =

        self:getNumber(
            financial.totalDebt,
            0
        )

    self.data.workingCapital =

        self:getNumber(
            financial.workingCapital,
            self.data.cash
        )

    self.data.monthlyRevenue =

        self:getNumber(
            financial.monthlyRevenue,
            0
        )

    self.data.monthlyExpenses =

        self:getNumber(
            financial.monthlyExpenses,
            0
        )

    self.data.monthlyNetCashFlow =

        self:getNumber(
            financial.monthlyNetCashFlow,
            self.data.monthlyRevenue
                - self.data.monthlyExpenses
        )

    self.data.monthlyObligations =

        self:getNumber(
            financial.monthlyObligations,
            0
        )

    self.data.debtRatio =

        self:getNumber(
            financial.debtRatio,
            0
        )

    return true

end

--------------------------------------------------
-- Read Asset Manager
--------------------------------------------------

function FFR_DashboardDataManager:readAssetData()

    if g_FFR == nil
        or g_FFR.assetManager == nil
    then

        return false

    end

    local assets =
        g_FFR.assetManager

    --------------------------------------------------
    -- Force current totals before reading.
    --------------------------------------------------

    if assets.updateTotals ~= nil then

        assets:updateTotals()

    end

    self.data.landCount =

        self:countEntries(
            assets.landAssets
        )

    self.data.equipmentCount =

        self:countEntries(
            assets.equipmentAssets
        )

    self.data.buildingCount =

        self:countEntries(
            assets.buildingAssets
        )

    self.data.inventoryCount =

        self:countEntries(
            assets.inventoryAssets
        )

    --------------------------------------------------
    -- Multiplayer client: counts come from the server.
    --------------------------------------------------

    if assets.isRemote
        and assets.remote ~= nil
    then

        self.data.landCount = self:getNumber(assets.remote.landCount, 0)
        self.data.equipmentCount = self:getNumber(assets.remote.equipmentCount, 0)
        self.data.buildingCount = self:getNumber(assets.remote.buildingCount, 0)
        self.data.inventoryCount = self:getNumber(assets.remote.inventoryCount, 0)

    end

    self.data.landValue =

        self:getNumber(
            assets.totalLandValue,
            0
        )

    self.data.equipmentValue =

        self:getNumber(
            assets.totalEquipmentValue,
            0
        )

    self.data.buildingValue =

        self:getNumber(
            assets.totalBuildingValue,
            0
        )

    self.data.inventoryValue =

        self:getNumber(
            assets.totalInventoryValue,
            0
        )

    self.data.nonCashAssets =

        self.data.landValue
        + self.data.equipmentValue
        + self.data.buildingValue
        + self.data.inventoryValue

    self.data.totalAssets =

        self.data.cash
        + self.data.nonCashAssets

    self.data.netWorth =

        self.data.totalAssets
        - self.data.totalDebt

    --------------------------------------------------
    -- Push current asset totals back into the
    -- Financial Manager.
    --------------------------------------------------

    if g_FFR.financialManager ~= nil
        and assets.updateFinancialManager ~= nil
    then

        assets:updateFinancialManager(
            g_FFR.financialManager
        )

    end

    return true

end

--------------------------------------------------
-- Refresh Calculated Financial Totals
--------------------------------------------------

function FFR_DashboardDataManager:refreshCalculatedTotals()

    self.data.nonCashAssets =

        self.data.landValue
        + self.data.equipmentValue
        + self.data.buildingValue
        + self.data.inventoryValue

    self.data.totalAssets =

        self.data.cash
        + self.data.nonCashAssets

    self.data.netWorth =

        self.data.totalAssets
        - self.data.totalDebt

    self.data.monthlyNetCashFlow =

        self.data.monthlyRevenue
        - self.data.monthlyExpenses

    if self.data.totalAssets > 0 then

        self.data.debtRatio =

            self.data.totalDebt
            / self.data.totalAssets

    else

        self.data.debtRatio = 0

    end

end

--------------------------------------------------
-- Read Credit Manager
--------------------------------------------------

function FFR_DashboardDataManager:readCreditData()

    if g_FFR == nil
        or g_FFR.creditManager == nil
    then

        return false

    end

    local credit =
        g_FFR.creditManager

    self.data.creditScore =

        self:getNumber(
            credit.creditScore,
            0
        )

    self.data.creditRating =

        FFR_CreditManager.getRatingName(
            credit.creditRating
            or credit.rating
        )

    self.data.interestRateModifier =

        self:getNumber(
            credit.interestRateModifier,
            1.00
        )

    self.data.operatingLoanLimit =

        self:getNumber(
            credit.maxOperatingLoan,
            0
        )

    self.data.expansionLoanLimit =

        self:getNumber(
            credit.maxExpansionLoan,
            0
        )

    return true

end

--------------------------------------------------
-- Read Commodity Market
--------------------------------------------------

function FFR_DashboardDataManager:readMarketData()

    if g_FFR == nil
        or g_FFR.commodityManager == nil
        or g_FFR.marketEngine == nil
    then

        return false

    end

    local commodityManager =
        g_FFR.commodityManager

    local marketEngine =
        g_FFR.marketEngine

    self.data.commodityCount =

        self:countEntries(
            commodityManager.commodities
        )

    if marketEngine.activeEvent ~= nil then

        self.data.marketEventName =

            FFR_L10n.eventName(
                marketEngine.activeEvent.name
                or "Market event"
            )

    else

        self.data.marketEventName =
            FFR_L10n.t("ffr_news_no_event")

    end

    if marketEngine.getModifier ~= nil then

        self.data.grainModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "grain"
                ),
                1.00
            )

        self.data.oilseedModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "oilseed"
                ),
                1.00
            )

        self.data.pulseModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "pulse"
                ),
                1.00
            )

        self.data.forageModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "forage"
                ),
                1.00
            )

        self.data.vegetableModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "vegetable"
                ),
                1.00
            )

        self.data.industrialModifier =

            self:getNumber(
                marketEngine:getModifier(
                    "industrial"
                ),
                1.00
            )

    end

    return true

end

--------------------------------------------------
-- Get Input Modifier
--------------------------------------------------

function FFR_DashboardDataManager:getInputModifier(
    inputName
)

    if g_FFR == nil
        or g_FFR.inputMarket == nil
        or g_FFR.inputMarket.inputs == nil
    then

        return 1.00

    end

    local inputData =

        g_FFR.inputMarket.inputs[
            inputName
        ]

    if inputData == nil then

        return 1.00

    end

    if type(inputData) == "number" then

        return

            self:getNumber(
                inputData,
                1.00
            )

    end

    return

        self:getNumber(
            inputData.modifier,
            1.00
        )

end

--------------------------------------------------
-- Read Input Market
--------------------------------------------------

function FFR_DashboardDataManager:readInputData()

    if g_FFR == nil
        or g_FFR.inputMarket == nil
    then

        return false

    end

    local inputMarket =
        g_FFR.inputMarket

    if inputMarket.activeEvent ~= nil then

        self.data.inputEventName =

            inputMarket.getEventTitle ~= nil
                and inputMarket:getEventTitle(inputMarket.activeEvent)
                or FFR_L10n.eventName(inputMarket.activeEvent.name)

    else

        self.data.inputEventName =
            FFR_L10n.t("ffr_news_supplier_regular")

    end

    if inputMarket.getExpiryText ~= nil then

        local success,
            result =

            pcall(
                inputMarket.getExpiryText,
                inputMarket
            )

        if success
            and result ~= nil
        then

            self.data.inputExpiryText =
                tostring(result)

        end

    end

    self.data.fertilizerModifier =

        self:getInputModifier(
            "FERTILIZER"
        )

    self.data.liquidFertilizerModifier =

        self:getInputModifier(
            "LIQUIDFERTILIZER"
        )

    self.data.seedModifier =

        self:getInputModifier(
            "SEEDS"
        )

    self.data.dieselModifier =

        self:getInputModifier(
            "DIESEL"
        )

    return true

end

--------------------------------------------------
-- Refresh Dashboard
--------------------------------------------------

function FFR_DashboardDataManager:refresh()

    if g_FFR == nil
        or not g_FFR.isInitialized
        or g_FFR.isDeleted
    then

        self.data.isReady = false

        return false

    end

    --------------------------------------------------
    -- Read data on every refresh, even while waiting
    -- for the first complete synchronization.
    --------------------------------------------------

    self:readFinancialData()

    self:readAssetData()

    self:readCreditData()

    self:readMarketData()

    self:readInputData()

    self:refreshCalculatedTotals()

    local dashboardReady =

        self:isDashboardReady()

    self.data.isReady =
        dashboardReady

    self.data.lastUpdateTime =
        g_time or 0

    --------------------------------------------------
    -- Print the initial report only after all major
    -- synchronization systems have completed at least
    -- one successful scan.
    --------------------------------------------------

    if dashboardReady
        and not self.hasLoggedInitialData
    then

        self:printReport()

        self.hasLoggedInitialData = true

    end

    return dashboardReady

end

--------------------------------------------------
-- Get Dashboard Data
--------------------------------------------------

function FFR_DashboardDataManager:getData()

    return self.data

end

--------------------------------------------------
-- Format Money
--------------------------------------------------

-- The player's currency and number format (FFR_L10n / FS25 settings).
-- Every other FFR money formatter calls this one.
function FFR_DashboardDataManager:formatMoney(
    value
)

    return FFR_L10n.formatMoney(
        self:getNumber(value, 0)
    )

end

--------------------------------------------------
-- Format Modifier
--------------------------------------------------

function FFR_DashboardDataManager:formatModifier(
    modifier
)

    local safeModifier =

        self:getNumber(
            modifier,
            1.00
        )

    local percentageChange =

        (
            safeModifier - 1
        )

        * 100

    if math.abs(
        percentageChange
    ) < 0.005
    then

        return FFR_L10n.t("ffr_market_regular")

    end

    if percentageChange > 0 then

        return

            string.format(
                "+%.0f%%",
                percentageChange
            )

    end

    return

        string.format(
            "%.0f%%",
            percentageChange
        )

end

--------------------------------------------------
-- Format Ratio
--------------------------------------------------

function FFR_DashboardDataManager:formatRatio(
    ratio
)

    local safeRatio =

        self:getNumber(
            ratio,
            0
        )

    return

        string.format(
            "%.1f%%",
            safeRatio * 100
        )

end

--------------------------------------------------
-- Runtime Update
--------------------------------------------------

function FFR_DashboardDataManager:update(
    dt
)

    if not self.isActive then

        return

    end

    self.updateTimer =

        self.updateTimer + dt

    if self.updateTimer <
        self.updateInterval
    then

        return

    end

    self.updateTimer = 0

    self:refresh()

end

--------------------------------------------------
-- Load Map
--------------------------------------------------

function FFR_DashboardDataManager:loadMap(
    mapName
)

    self.updateTimer = 0

    self.hasLoggedInitialData = false

    --------------------------------------------------
    -- deleteMap switches the listener off; turn it
    -- back on for the next savegame in the same run.
    --------------------------------------------------

    self.isActive = true

    self:resetData()

end

--------------------------------------------------
-- Delete Map
--------------------------------------------------

function FFR_DashboardDataManager:deleteMap()

    self.updateTimer = 0

    self.hasLoggedInitialData = false

    self.isActive = false

    self:resetData()

end

--------------------------------------------------
-- Required Empty Listener Methods
--------------------------------------------------

function FFR_DashboardDataManager:draw()

end

function FFR_DashboardDataManager:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)

end

function FFR_DashboardDataManager:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)

end

--------------------------------------------------
-- Dashboard Report
--------------------------------------------------

function FFR_DashboardDataManager:printReport()

    local data =
        self.data

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR DASHBOARD DATA READY"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Cash: %s",
        self:formatMoney(
            data.cash
        )
    )

    Logging.info(
        "Land: %d parcels, %s",
        data.landCount,
        self:formatMoney(
            data.landValue
        )
    )

    Logging.info(
        "Equipment: %d items, %s",
        data.equipmentCount,
        self:formatMoney(
            data.equipmentValue
        )
    )

    Logging.info(
        "Buildings: %d items, %s",
        data.buildingCount,
        self:formatMoney(
            data.buildingValue
        )
    )

    Logging.info(
        "Inventory: %d items, %s",
        data.inventoryCount,
        self:formatMoney(
            data.inventoryValue
        )
    )

    Logging.info(
        "Non-Cash Assets: %s",
        self:formatMoney(
            data.nonCashAssets
        )
    )

    Logging.info(
        "Total Assets: %s",
        self:formatMoney(
            data.totalAssets
        )
    )

    Logging.info(
        "Debt: %s",
        self:formatMoney(
            data.totalDebt
        )
    )

    Logging.info(
        "Net Worth: %s",
        self:formatMoney(
            data.netWorth
        )
    )

    Logging.info(
        "Working Capital: %s",
        self:formatMoney(
            data.workingCapital
        )
    )

    Logging.info(
        "Monthly Revenue: %s",
        self:formatMoney(
            data.monthlyRevenue
        )
    )

    Logging.info(
        "Monthly Expenses: %s",
        self:formatMoney(
            data.monthlyExpenses
        )
    )

    Logging.info(
        "Monthly Net Cash Flow: %s",
        self:formatMoney(
            data.monthlyNetCashFlow
        )
    )

    Logging.info(
        "Debt Ratio: %s",
        self:formatRatio(
            data.debtRatio
        )
    )

    Logging.info(
        "Credit: %d %s",
        data.creditScore,
        data.creditRating
    )

    Logging.info(
        "Operating Loan Limit: %s",
        self:formatMoney(
            data.operatingLoanLimit
        )
    )

    Logging.info(
        "Expansion Loan Limit: %s",
        self:formatMoney(
            data.expansionLoanLimit
        )
    )

    Logging.info(
        "Market Event: %s",
        data.marketEventName
    )

    Logging.info(
        "Commodities: %d",
        data.commodityCount
    )

    Logging.info(
        "Grain: %s",
        self:formatModifier(
            data.grainModifier
        )
    )

    Logging.info(
        "Oilseed: %s",
        self:formatModifier(
            data.oilseedModifier
        )
    )

    Logging.info(
        "Pulse: %s",
        self:formatModifier(
            data.pulseModifier
        )
    )

    Logging.info(
        "Forage: %s",
        self:formatModifier(
            data.forageModifier
        )
    )

    Logging.info(
        "Vegetable: %s",
        self:formatModifier(
            data.vegetableModifier
        )
    )

    Logging.info(
        "Industrial: %s",
        self:formatModifier(
            data.industrialModifier
        )
    )

    Logging.info(
        "Input Program: %s",
        data.inputEventName
    )

    Logging.info(
        "%s",
        data.inputExpiryText
    )

    Logging.info(
        "Fertilizer: %s",
        self:formatModifier(
            data.fertilizerModifier
        )
    )

    Logging.info(
        "Liquid Fertilizer: %s",
        self:formatModifier(
            data.liquidFertilizerModifier
        )
    )

    Logging.info(
        "Seeds: %s",
        self:formatModifier(
            data.seedModifier
        )
    )

    Logging.info(
        "Diesel: %s",
        self:formatModifier(
            data.dieselModifier
        )
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Create Global Listener
--------------------------------------------------

g_FFRDashboardDataManager =

    FFR_DashboardDataManager:new()

addModEventListener(
    g_FFRDashboardDataManager
)

Logging.info(
    "FFR Dashboard Data: Listener installed"
)