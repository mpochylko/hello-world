FFR_DashboardFrame = FFR_DashboardFrame or {}
local FFR_DashboardFrame_mt = Class(FFR_DashboardFrame, TabbedMenuFrameElement)
local FFR_FRAME_MOD_DIR = g_currentModDirectory

--------------------------------------------------
-- Background fills
--
-- FS25's "gui.empty" image slice is transparent, so profile colours alone
-- draw nothing. Every element using one of these profiles gets a solid
-- rectangle drawn underneath it with the mod's white texture instead
-- (the same Overlay method the land-title and monthly windows use).
-- Buttons list {normal, hovered/focused}.
--------------------------------------------------
FFR_DashboardFrame.FILLS = {
    FFR_Surface = {0.020, 0.024, 0.022, 0.97},
    FFR_HeaderBand = {0.024, 0.029, 0.026, 1},
    FFR_TabRail = {0.024, 0.029, 0.026, 1},
    FFR_TabUnderline = {0.54, 0.86, 0.18, 1},
    FFR_Footer = {0.012, 0.015, 0.013, 1},
    FFR_KeyPill = {0.090, 0.120, 0.075, 1},
    FFR_Divider = {0.20, 0.23, 0.21, 1},
    FFR_CardBorder = {0.17, 0.20, 0.18, 1},
    FFR_Card = {0.038, 0.044, 0.041, 1},
    FFR_FieldBorder = {0.34, 0.37, 0.35, 1},
    FFR_Field = {0.016, 0.019, 0.017, 1},
    FFR_TableHeader = {0.075, 0.088, 0.081, 1},
    FFR_RowAlt = {0.052, 0.060, 0.056, 1},
    FFR_Highlight = {0.13, 0.20, 0.08, 1},
    FFR_DangerBorder = {0.62, 0.16, 0.12, 1},
    FFR_DangerFill = {0.16, 0.045, 0.035, 1},
    FFR_SliderTrack = {0.20, 0.23, 0.21, 1},
    FFR_ChartArea = {0.022, 0.026, 0.024, 1},
    FFR_LegendHealthy = {0.36, 0.78, 0.30, 1},
    FFR_LegendLight = {0.95, 0.79, 0.32, 1},
    FFR_LegendHeavy = {0.90, 0.30, 0.25, 1},
    FFR_LegendEmpty = {0.30, 0.33, 0.31, 1}
}
FFR_DashboardFrame.BUTTON_FILLS = {
    FFR_Button = {{0.11, 0.13, 0.12, 1}, {0.20, 0.30, 0.10, 1}},
    FFR_ButtonPrimary = {{0.54, 0.86, 0.18, 1}, {0.66, 0.95, 0.30, 1}}
}

function FFR_DashboardFrame:collectFills(element)
    if element == nil then return end
    local profile = element.profile
    if type(profile) == "string" then
        if FFR_DashboardFrame.FILLS[profile] ~= nil then
            table.insert(self.fillElements, {element = element, color = FFR_DashboardFrame.FILLS[profile]})
        elseif FFR_DashboardFrame.BUTTON_FILLS[profile] ~= nil then
            table.insert(self.fillElements, {element = element, button = FFR_DashboardFrame.BUTTON_FILLS[profile]})
        end
    end
    for _, child in ipairs(element.elements or {}) do self:collectFills(child) end
end

function FFR_DashboardFrame:ensureFills()
    if self.fillElements ~= nil then return self.fillOverlay ~= nil end
    self.fillElements = {}
    for _, child in ipairs(self.elements or {}) do self:collectFills(child) end
    if Overlay ~= nil and Overlay.new ~= nil then
        local texture = Utils.getFilename("gui/FFR_white.dds", FFR_FRAME_MOD_DIR)
        self.fillOverlay = Overlay.new(texture, 0, 0, 1, 1)
    end
    Logging.info("FFR Dashboard: %d background fills prepared", #self.fillElements)
    return self.fillOverlay ~= nil
end

function FFR_DashboardFrame:isButtonActive(element)
    if element.getOverlayState == nil or GuiOverlay == nil then return false end
    local ok, state = pcall(element.getOverlayState, element)
    if not ok then return false end
    return state == GuiOverlay.STATE_FOCUSED or state == GuiOverlay.STATE_HIGHLIGHTED
        or state == GuiOverlay.STATE_PRESSED or state == GuiOverlay.STATE_SELECTED
end

function FFR_DashboardFrame:drawFills()
    if not self:ensureFills() then return end
    local overlay = self.fillOverlay
    for _, entry in ipairs(self.fillElements) do
        local el = entry.element
        if el.absPosition ~= nil and el.absSize ~= nil
            and (el.getIsVisible == nil or el:getIsVisible()) then
            local color = entry.color
            if entry.button ~= nil then
                color = self:isButtonActive(el) and entry.button[2] or entry.button[1]
            end
            overlay:setPosition(el.absPosition[1], el.absPosition[2])
            overlay:setDimension(el.absSize[1], el.absSize[2])
            overlay:setColor(color[1], color[2], color[3], color[4])
            overlay:render()
        end
    end
end

-- Fills first, then the normal GUI (text, buttons) on top, then the
-- Lua-drawn marks (loan amount dots, price chart).
function FFR_DashboardFrame:draw(...)
    -- CHANGE TITLE window open: draw only the window. FS25 renders all text after all
    -- shapes, so the page's own text would show through the window's background.
    local modal = g_FFRModalOverlay
    if modal ~= nil and modal.visible and modal.overMenu and modal.drawOverMenu ~= nil then
        modal:drawOverMenu()
        return
    end
    self:drawFills()
    FFR_DashboardFrame:superClass().draw(self, ...)
    if self.fillOverlay ~= nil then
        self:drawLoanSliders()
        self:drawVolumeSlider()
        self:drawPriceChart()
        self:drawCropMap()
    end
end
if g_gui ~= nil and not g_FFRDashboardProfilesLoaded then
    g_gui:loadProfiles(Utils.getFilename("gui/FFRDashboardProfiles.xml", g_currentModDirectory))
    g_FFRDashboardProfilesLoaded = true
end
FFR_DashboardFrame.SECTIONS = {"OVERVIEW", "MARKETS", "DEALS", "NEWS", "BANK", "LAND", "INSURANCE", "ADVISOR", "FARM STATUS", "HOUSEHOLD", "OPTIONS"}
-- Tab numbers (panel N in tools/build_dashboard_xml.ps1 is tab N).
FFR_DashboardFrame.TAB = {OVERVIEW = 1, MARKETS = 2, DEALS = 3, NEWS = 4, BANK = 5, LAND = 6, INSURANCE = 7, ADVISOR = 8, STATUS = 9, HOUSEHOLD = 10, OPTIONS = 11}
FFR_DashboardFrame.MARKET_ROWS = 10
function FFR_DashboardFrame.new(target, customMt)
    local self = TabbedMenuFrameElement.new(target, customMt or FFR_DashboardFrame_mt)
    self.name="FFRDashboardFrame"; self.refreshTimer=0; self.refreshInterval=1000; self.controls={}; self.sectionPanels={}
    self.currentSection=1; self.horizontalNavKey=nil; self.verticalNavKey=nil; self.marketCommodities={}; self.marketSelectedIndex=1; self.menuButtonInfo={}; self.householdManager=nil
    return self
end
function FFR_DashboardFrame:onGuiSetupFinished()
    FFR_DashboardFrame:superClass().onGuiSetupFinished(self)
    self:convertTexts(self)
end

-- Labels in the layout are "$l10n_<key>"; FS25 normally translates them on
-- load. Any it left untranslated are translated here (FFR_L10n).
function FFR_DashboardFrame:convertTexts(element)
    if element == nil then return end
    if type(element.text) == "string" and string.sub(element.text, 1, 6) == "$l10n_" and type(element.setText) == "function" then
        pcall(element.setText, element, FFR_L10n.convert(element.text))
    end
    for _, child in ipairs(element.elements or {}) do self:convertTexts(child) end
end
function FFR_DashboardFrame:initialize() FFR_DashboardFrame:superClass().initialize(self); self.btnBack={inputAction=InputAction.MENU_BACK,text=g_i18n:getText("button_back")}; self.menuButtonInfo={self.btnBack} end
function FFR_DashboardFrame:getMenuButtonInfo() return self.menuButtonInfo end
function FFR_DashboardFrame:onCreateControl(element, controlName) if controlName==nil then return end; local n=tostring(controlName); self.controls[n]=element; local i=string.match(n,"^sectionPanel(%d+)$"); if i~=nil then self.sectionPanels[tonumber(i)]=element end end
function FFR_DashboardFrame:setControlText(name,value) local c=self.controls[name]; if c~=nil and type(c.setText)=="function" then c:setText(tostring(value or "")) end end
function FFR_DashboardFrame:setControlVisible(name,visible) local c=self.controls[name]; if c~=nil and type(c.setVisible)=="function" then c:setVisible(visible==true) end end
function FFR_DashboardFrame:formatMoney(value) if g_FFRDashboardDataManager~=nil and type(g_FFRDashboardDataManager.formatMoney)=="function" then return g_FFRDashboardDataManager:formatMoney(value) end; return FFR_L10n.formatMoney(value) end
function FFR_DashboardFrame:formatModifier(value) if g_FFRDashboardDataManager~=nil and type(g_FFRDashboardDataManager.formatModifier)=="function" then return g_FFRDashboardDataManager:formatModifier(value) end; return FFR_L10n.t("ffr_market_regular") end
function FFR_DashboardFrame:formatCommodityName(name) return FFR_L10n.fillTypeTitle(name) end
-- Page heading, description and footer hint for each tab, in tab order.
-- Translation key stems (tools/texts_lua_en.xml): ffr_page_<stem>_title / _desc / _hint.
FFR_DashboardFrame.PAGES = {"overview", "markets", "deals", "news", "bank", "land", "insurance", "advisor", "status", "household", "options"}
FFR_DashboardFrame.TAB_ACTIVE_COLOR = {0.54, 0.86, 0.18, 1}
FFR_DashboardFrame.TAB_IDLE_COLOR = {0.92, 0.93, 0.92, 1}
function FFR_DashboardFrame:setControlColor(name, color)
    local c = self.controls[name]
    if c ~= nil and type(c.setTextColor) == "function" then c:setTextColor(color[1], color[2], color[3], color[4]) end
end
function FFR_DashboardFrame:updateSectionHeader()
    local total = #FFR_DashboardFrame.SECTIONS
    for i = 1, total do
        self:setControlColor("tabLabel"..i, i == self.currentSection and FFR_DashboardFrame.TAB_ACTIVE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR)
        self:setControlVisible("tabHighlight"..i, i == self.currentSection)
        local p = self.sectionPanels[i]
        if p ~= nil and type(p.setVisible) == "function" then p:setVisible(i == self.currentSection) end
    end
    local stem = FFR_DashboardFrame.PAGES[self.currentSection]
    if stem ~= nil then
        self:setControlText("pageTitle", FFR_L10n.t("ffr_page_" .. stem .. "_title"))
        self:setControlText("pageDescription", FFR_L10n.t("ffr_page_" .. stem .. "_desc"))
        self:setControlText("footerInfo", FFR_L10n.t("ffr_page_" .. stem .. "_hint"))
    end
end
function FFR_DashboardFrame:setSection(index) local total=#FFR_DashboardFrame.SECTIONS; local n=tonumber(index) or 1; if n<1 then n=total elseif n>total then n=1 end; self.currentSection=n; self:updateSectionHeader(); self:refreshData() end
function FFR_DashboardFrame:changeSection(direction) self:setSection(self.currentSection+(tonumber(direction) or 0)) end
-- Crops and products first (A-Z), then live animals by breed (FFR_AnimalPriceManager).
-- Only products a selling station on this map accepts right now (v0.9.58): a crop no
-- one buys has no price to show or chart. Animals are always sold at the dealer.
function FFR_DashboardFrame:isSellable(c)
    if c.isAnimal then return true end
    return self:getLivePrice(c) ~= nil
end

function FFR_DashboardFrame:buildMarketCommodityList()
    local previous = self.marketCommodities ~= nil and self.marketCommodities[self.marketSelectedIndex] or nil
    self.marketCommodities = {}
    if g_FFR == nil or g_FFR.commodityManager == nil or g_FFR.commodityManager.commodities == nil then return false end
    for _, c in pairs(g_FFR.commodityManager.commodities) do
        if c ~= nil and self:isSellable(c) then table.insert(self.marketCommodities, c) end
    end
    if FFR_AnimalPriceManager ~= nil then
        local ok, animals = pcall(FFR_AnimalPriceManager.getMarketEntries)
        for _, a in ipairs(ok and animals or {}) do table.insert(self.marketCommodities, a) end
    end
    table.sort(self.marketCommodities, function(a, b)
        if (a.isAnimal == true) ~= (b.isAnimal == true) then return b.isAnimal == true end
        return tostring(a.displayName or a.name or "") < tostring(b.displayName or b.name or "")
    end)
    -- Keep the same product selected when a station starts or stops buying something.
    if previous ~= nil then
        for i, c in ipairs(self.marketCommodities) do
            if c.name == previous.name and c.subTypeIndex == previous.subTypeIndex then self.marketSelectedIndex = i end
        end
    end
    self.marketSelectedIndex = math.max(1, math.min(self.marketSelectedIndex, math.max(1, #self.marketCommodities)))
    return #self.marketCommodities > 0
end

function FFR_DashboardFrame:getMarketName(c)
    if c.displayName ~= nil then return c.displayName end
    return self:formatCommodityName(c.name)
end
-- Prices per 1,000 L in the player's units (FFR_UnitManager); animals stay per head.
function FFR_DashboardFrame:formatPriceValue(c, price)
    if c == nil or c.isAnimal or FFR_UnitManager == nil then return self:formatMoney(price) end
    return FFR_UnitManager.formatPriceValue(price, c.name)
end
function FFR_DashboardFrame:formatPriceShort(c, price)
    if c == nil or c.isAnimal or FFR_UnitManager == nil then return self:formatMoney(price) end
    local unit = FFR_UnitManager.getUnit(c.name)
    if unit == "L" then return self:formatMoney(price) end
    return FFR_L10n.t("ffr_unit_short_" .. string.lower(unit), FFR_UnitManager.formatPriceValue(price, c.name))
end
-- Liters of a product in the player's units ("1,250 bu").
function FFR_DashboardFrame:formatAmount(name, liters)
    if FFR_UnitManager == nil then return FFR_L10n.t("ffr_unit_litres", FFR_L10n.formatNumber(liters)) end
    return FFR_UnitManager.formatAmount(liters, name)
end
function FFR_DashboardFrame:formatPriceFull(c, price)
    if c == nil or c.isAnimal or FFR_UnitManager == nil then return self:formatMoney(price) end
    return FFR_UnitManager.formatPrice(price, c.name)
end
function FFR_DashboardFrame:getPriceHeader(c)
    if c == nil or c.isAnimal then return FFR_L10n.t("ffr_unit_header_head") end
    local unit = FFR_UnitManager ~= nil and FFR_UnitManager.getUnit(c.name) or "L"
    return FFR_L10n.t("ffr_unit_header_" .. string.lower(unit))
end

function FFR_DashboardFrame:changeMarketSelection(direction) local count=#self.marketCommodities; if count==0 then return end; self.marketSelectedIndex=self.marketSelectedIndex+(tonumber(direction) or 0); if self.marketSelectedIndex<1 then self.marketSelectedIndex=count elseif self.marketSelectedIndex>count then self.marketSelectedIndex=1 end; self:refreshMarketPage() end
function FFR_DashboardFrame:refreshMarketPage() self:buildMarketCommodityList(); local count=#self.marketCommodities; local rows=FFR_DashboardFrame.MARKET_ROWS; local page=count>0 and math.floor((self.marketSelectedIndex-1)/rows)+1 or 1; local pages=math.max(1,math.ceil(count/rows)); local first=(page-1)*rows+1; for row=1,rows do local idx=first+row-1; local c=self.marketCommodities[idx]; if c~=nil then self:setControlText("marketRowName"..row,self:getMarketName(c)); local live=self:getLivePrice(c); self:setControlText("marketRowPrice"..row,live~=nil and self:formatPriceShort(c,live) or "-"); self:setControlVisible("marketRowHighlight"..row,idx==self.marketSelectedIndex) else self:setControlText("marketRowName"..row,""); self:setControlText("marketRowPrice"..row,""); self:setControlVisible("marketRowHighlight"..row,false) end end; self:setControlText("marketPageValue",FFR_L10n.t("ffr_market_page",page,pages,count)); self:setControlText("marketPriceHeader",FFR_L10n.t(FFR_UnitManager~=nil and FFR_UnitManager.isConverting() and "ffr_unit_header_mixed" or "ffr_unit_header_l")); local c=self.marketCommodities[self.marketSelectedIndex]; if c==nil then self:setControlText("marketSelectedName",FFR_L10n.t("ffr_market_none")); self.chartPoints=nil; return end; self:setControlText("marketSelectedName",self:getMarketName(c)); self:setControlText("stationPriceHeader",self:getPriceHeader(c)); self:setControlText("marketSelectedModifier",self:formatModifier(c.priceModifier)); self:refreshStationRows(c); self:refreshPriceChart(c) end
FFR_DashboardFrame.STATION_ROWS = 5

--------------------------------------------------
-- Markets price chart (FFR_PriceHistoryManager)
--
-- refreshPriceChart (once a second) caches the
-- points, trend and scale and sets the labels;
-- drawPriceChart (every frame) draws them over the
-- 'chartArea' element with the fill overlay.
--------------------------------------------------

function FFR_DashboardFrame:formatMonthLabel(point)
    local cm = g_FFR ~= nil and g_FFR.contractManager or nil
    if point == nil or point.period == nil or cm == nil then return "" end
    return FFR_L10n.dateShort(point.period, point.year)
end

function FFR_DashboardFrame:refreshPriceChart(commodity)
    local history = g_FFRPriceHistory
    -- Two years on the chart; average and trend over the last 12 months and now.
    local points = history ~= nil and history:getSeries(commodity, FFR_PriceHistoryManager.CHART_MONTHS) or {}
    local statsCount = FFR_PriceHistoryManager.MONTHS_SHOWN + 1
    local trend = history ~= nil and history:getTrend(points, statsCount) or nil
    self.chartPoints, self.chartTrend = points, trend
    local low, high = math.huge, -math.huge
    for _, p in ipairs(points) do
        low = math.min(low, tonumber(p.low) or p.avg, p.avg)
        high = math.max(high, tonumber(p.high) or p.avg, p.avg)
    end
    if trend ~= nil then
        low = math.min(low, trend.startValue, trend.endValue)
        high = math.max(high, trend.startValue, trend.endValue)
    end
    if #points == 0 then low, high = 0, 1 end
    -- Some headroom, and never a flat scale.
    local pad = math.max((high - low) * 0.08, math.abs(high) * 0.03, 1)
    self.chartMin, self.chartMax = math.max(0, low - pad), high + pad
    local labels = #points > 0
    self:setControlText("chartMaxLabel", labels and self:formatPriceValue(commodity, self.chartMax) or "")
    self:setControlText("chartMidLabel", labels and self:formatPriceValue(commodity, (self.chartMin + self.chartMax) / 2) or "")
    self:setControlText("chartMinLabel", labels and self:formatPriceValue(commodity, self.chartMin) or "")
    self:setControlText("chartFirstLabel", self:formatMonthLabel(points[1]))
    self:setControlText("chartLastLabel", #points > 1 and FFR_L10n.t("ffr_chart_so_far", self:formatMonthLabel(points[#points])) or "")
    if #points < 2 then
        self:setControlText("chartEmpty", FFR_L10n.t("ffr_chart_empty"))
        self:setControlText("chartInfo", #points == 1 and FFR_L10n.t("ffr_chart_now", self:formatPriceFull(commodity, points[1].avg)) or "")
    else
        self:setControlText("chartEmpty", "")
        local sum, closed = 0, 0
        for i = math.max(1, #points - statsCount + 1), #points do
            local p = points[i]
            if not p.partial then sum, closed = sum + p.avg, closed + 1 end
        end
        local average = closed > 0 and sum / closed or points[#points].avg
        self:setControlText("chartInfo", FFR_L10n.t("ffr_chart_info",
            closed, self:formatPriceFull(commodity, average), (trend ~= nil and trend.percentPerMonth or 0) * 100, self:formatPriceFull(commodity, points[#points].avg)))
    end
end

function FFR_DashboardFrame:drawRect(x, y, w, h, color)
    local overlay = self.fillOverlay
    overlay:setColor(color[1], color[2], color[3], color[4])
    overlay:setPosition(x, y)
    overlay:setDimension(w, h)
    overlay:render()
end

-- Screen width / height, to measure lengths and angles in real pixels.
function FFR_DashboardFrame:getAspect()
    if g_screenAspectRatio ~= nil and g_screenAspectRatio > 0 then return g_screenAspectRatio end
    if g_screenWidth ~= nil and g_screenHeight ~= nil and g_screenHeight > 0 then return g_screenWidth / g_screenHeight end
    return 16 / 9
end

-- One straight bar from (x1, y1) to (x2, y2), rotated to the line's angle, so it
-- is sharp at any slope. thickness is a share of the screen height.
-- ROTATION_SIGN flips the angle if the engine turns the other way.
FFR_DashboardFrame.ROTATION_SIGN = 1
function FFR_DashboardFrame:drawSegment(x1, y1, x2, y2, color, thickness)
    local overlay = self.fillOverlay
    local aspect = self:getAspect()
    local dx, dy = (x2 - x1) * aspect, y2 - y1
    local length = math.sqrt(dx * dx + dy * dy)
    if length <= 0 then return end
    overlay:setColor(color[1], color[2], color[3], color[4])
    overlay:setPosition(x1, y1 - thickness / 2)
    overlay:setDimension(length / aspect, thickness)
    overlay:setRotation(FFR_DashboardFrame.ROTATION_SIGN * math.atan2(dy, dx), 0, thickness / 2)
    overlay:render()
    overlay:setRotation(0, 0, 0)
end

-- A line of the given thickness; dashed: 5 parts drawn, 3 skipped. Without
-- overlay rotation it falls back to thin upright columns.
FFR_DashboardFrame.LINE_COLUMN = 0.0011
FFR_DashboardFrame.DASH_PARTS = 40
function FFR_DashboardFrame:drawLine(x1, y1, x2, y2, color, thickness, dashed)
    if x2 < x1 then x1, y1, x2, y2 = x2, y2, x1, y1 end
    local width = x2 - x1
    if width <= 0 then return end
    if self.fillOverlay ~= nil and self.fillOverlay.setRotation ~= nil then
        if not dashed then
            self:drawSegment(x1, y1, x2, y2, color, thickness)
            return
        end
        local parts = FFR_DashboardFrame.DASH_PARTS
        for k = 0, parts - 1 do
            if (k % 8) < 5 then
                local a, b = k / parts, (k + 1) / parts
                self:drawSegment(x1 + (x2 - x1) * a, y1 + (y2 - y1) * a, x1 + (x2 - x1) * b, y1 + (y2 - y1) * b, color, thickness)
            end
        end
        return
    end
    local column = FFR_DashboardFrame.LINE_COLUMN
    local count = math.max(1, math.ceil(width / column))
    local slope = (y2 - y1) / width
    for k = 0, count - 1 do
        if not dashed or (k % 8) < 5 then
            local xa = x1 + k * column
            local xb = math.min(x2, xa + column)
            local ya, yb = y1 + (xa - x1) * slope, y1 + (xb - x1) * slope
            self:drawRect(xa, math.min(ya, yb) - thickness / 2, xb - xa + 0.0002, math.abs(yb - ya) + thickness, color)
        end
    end
end

FFR_DashboardFrame.CHART_GRID = {0.12, 0.14, 0.13, 1}
FFR_DashboardFrame.CHART_RANGE = {0.26, 0.30, 0.28, 1}
FFR_DashboardFrame.CHART_LINE = {0.54, 0.86, 0.18, 1}
FFR_DashboardFrame.CHART_TREND = {0.95, 0.79, 0.32, 1}
FFR_DashboardFrame.CHART_NOW = {0.92, 0.93, 0.92, 1}

function FFR_DashboardFrame:drawPriceChart()
    if self.currentSection ~= FFR_DashboardFrame.TAB.MARKETS then return end
    local area = self.controls.chartArea
    local points = self.chartPoints
    -- One point is only "now"; the empty-chart message is shown instead.
    if area == nil or area.absPosition == nil or area.absSize == nil or points == nil or #points < 2 then return end
    if area.getIsVisible ~= nil and not area:getIsVisible() then return end
    local x0, y0, w, h = area.absPosition[1], area.absPosition[2], area.absSize[1], area.absSize[2]
    local low, high, n = self.chartMin or 0, self.chartMax or 1, #points
    local function px(i)
        if n == 1 then return x0 + w / 2 end
        return x0 + w * 0.04 + w * 0.92 * (i - 1) / (n - 1)
    end
    local function py(v) return y0 + h * 0.06 + h * 0.88 * ((tonumber(v) or low) - low) / (high - low) end
    for k = 0, 2 do self:drawRect(x0, y0 + h * 0.06 + h * 0.44 * k, w, 0.001, FFR_DashboardFrame.CHART_GRID) end
    -- High / low: a thin, dim bar behind each month.
    for i, p in ipairs(points) do
        local top, bottom = py(p.high or p.avg), py(p.low or p.avg)
        self:drawRect(px(i) - 0.0007, bottom, 0.0014, math.max(0.002, top - bottom), FFR_DashboardFrame.CHART_RANGE)
    end
    local trend = self.chartTrend
    if trend ~= nil and n > 1 then
        self:drawLine(px(trend.firstIndex or 1), py(trend.startValue), px(n), py(trend.endValue), FFR_DashboardFrame.CHART_TREND, 0.0014, true)
    end
    for i = 2, n do
        self:drawLine(px(i - 1), py(points[i - 1].avg), px(i), py(points[i].avg), FFR_DashboardFrame.CHART_LINE, 0.0024, false)
    end
    -- Small square dots (square in pixels); the month so far is larger and white.
    local aspect = self:getAspect()
    for i, p in ipairs(points) do
        local size = p.partial and 0.009 or 0.006
        self:drawRect(px(i) - size / aspect / 2, py(p.avg) - size / 2, size / aspect, size,
            p.partial and FFR_DashboardFrame.CHART_NOW or FFR_DashboardFrame.CHART_LINE)
    end
end

-- What a crop sells for right now: the best station price on the map, FFR-adjusted.
-- nil when no station accepts the crop: there is no price the player could be paid.
function FFR_DashboardFrame:getLivePrice(commodity)
    -- Animals: best price per head at the dealer.
    if commodity ~= nil and commodity.isAnimal and FFR_AnimalPriceManager ~= nil then
        return FFR_AnimalPriceManager.getHeadPrice(commodity.subTypeIndex)
    end
    if commodity ~= nil and g_FFRStationPriceManager ~= nil then
        local index = tonumber(commodity.index)
        if (index == nil or index == 0) and g_fillTypeManager ~= nil and g_fillTypeManager.getFillTypeIndexByName ~= nil then
            index = g_fillTypeManager:getFillTypeIndexByName(string.upper(tostring(commodity.name or "")))
        end
        local best = index ~= nil and g_FFRStationPriceManager:getBestPrice(index) or nil
        if best ~= nil and tonumber(best.ffrPrice) ~= nil then return best.ffrPrice end
    end
    return nil
end
function FFR_DashboardFrame:refreshStationRows(commodity)
    local rows = {}
    -- Animals are traded at the animal dealer: one row, prices per head at prime age.
    if commodity ~= nil and commodity.isAnimal and FFR_AnimalPriceManager ~= nil then
        rows = {{
            name = FFR_L10n.t("ffr_market_dealer_row"),
            nativePrice = FFR_AnimalPriceManager.getNormalHeadPrice(commodity.subTypeIndex),
            ffrPrice = FFR_AnimalPriceManager.getHeadPrice(commodity.subTypeIndex)
        }}
        self:setControlText("stationCountValue", FFR_L10n.t("ffr_market_dealer_count"))
        for i = 1, FFR_DashboardFrame.STATION_ROWS do
            local r = rows[i]
            self:setControlText("stationRowName"..i, r ~= nil and r.name or "")
            self:setControlText("stationRowNative"..i, r ~= nil and self:formatMoney(r.nativePrice) or "")
            self:setControlText("stationRowFFR"..i, r ~= nil and self:formatMoney(r.ffrPrice) or "")
        end
        self:setControlText("stationPriceHeader", self:getPriceHeader(commodity))
        return
    end
    local fillTypeIndex = commodity ~= nil and tonumber(commodity.index) or nil
    -- Fall back to the fill type name when the stored index is missing.
    if (fillTypeIndex == nil or fillTypeIndex == 0) and commodity ~= nil and g_fillTypeManager ~= nil
        and g_fillTypeManager.getFillTypeIndexByName ~= nil then
        fillTypeIndex = g_fillTypeManager:getFillTypeIndexByName(string.upper(tostring(commodity.name or "")))
    end
    if fillTypeIndex ~= nil and g_FFRStationPriceManager ~= nil then
        rows = g_FFRStationPriceManager:getPriceRows(fillTypeIndex) or {}
    end
    self:setControlText("stationCountValue", FFR_L10n.t("ffr_market_stations", #rows))
    for i = 1, FFR_DashboardFrame.STATION_ROWS do
        local r = rows[i]
        self:setControlText("stationRowName"..i, r ~= nil and r.name or "")
        self:setControlText("stationRowNative"..i, r ~= nil and self:formatPriceValue(commodity, r.nativePrice) or "")
        self:setControlText("stationRowFFR"..i, r ~= nil and self:formatPriceValue(commodity, r.ffrPrice) or "")
    end
    self:setControlText("stationPriceHeader", self:getPriceHeader(commodity))
end

-- Shared helpers for the remaining pages.
function FFR_DashboardFrame:formatPercent(value) return string.format("%.2f%%", (tonumber(value) or 0) * 100) end
function FFR_DashboardFrame:setRowTexts(prefix, lines, count, emptyText)
    for i = 1, count do
        local line = lines[i]
        if line == nil and i == 1 and #lines == 0 then line = emptyText end
        self:setControlText(prefix..i, line or "")
    end
end
-- What can actually be borrowed: the credit ceiling capped by land collateral,
-- the same figure the Bank page shows.
function FFR_DashboardFrame:getExpansionLimit(d)
    if g_FFR ~= nil and g_FFR.bankingManager ~= nil and g_FFR.creditManager ~= nil then
        return g_FFR.bankingManager:getLandLimit(g_FFR.creditManager)
    end
    return d.expansionLoanLimit
end
function FFR_DashboardFrame:ensureManagers()
    if g_FFRMonthlyFinancialProcessor ~= nil and g_FFR ~= nil and g_FFR.isInitialized then
        g_FFRMonthlyFinancialProcessor:ensureManagers()
    end
end

FFR_DashboardFrame.DEAL_INPUTS = {"DIESEL", "DEF", "SEEDS", "FERTILIZER", "LIQUIDFERTILIZER", "LIME", "HERBICIDE", "FUNGICIDE", "INSECTICIDE"}
-- Supplier program card on the News page.
function FFR_DashboardFrame:refreshSupplierCard(d)
    local market = g_FFR ~= nil and g_FFR.inputMarket or nil
    self:setControlText("dealsProgramValue", d.inputEventName or FFR_L10n.t("ffr_news_supplier_regular"))
    self:setControlText("dealsExpiryValue", d.inputExpiryText or "")
    for i, name in ipairs(FFR_DashboardFrame.DEAL_INPUTS) do
        local modifier = market ~= nil and market:getModifier(name) or 1.00
        self:setControlText("dealsInput"..i, self:formatInputCell(name, modifier))
    end
end

-- An input category's price condition; a brand program on a category whose own
-- price is regular is named instead ("Corteva -15%").
function FFR_DashboardFrame:formatInputCell(category, modifier)
    local market = g_FFR ~= nil and g_FFR.inputMarket or nil
    local brand = market ~= nil and market.getBrandCell ~= nil and market:getBrandCell(category) or nil
    if brand ~= nil and math.abs((tonumber(modifier) or 1) - 1) < 0.005 then return brand end
    return self:formatModifier(modifier)
end

FFR_DashboardFrame.NEWS_ROWS = 6
function FFR_DashboardFrame:refreshNewsPage(d)
    self:refreshSupplierCard(d)
    local engine = g_FFR ~= nil and g_FFR.marketEngine or nil
    local event = engine ~= nil and engine.activeEvent or nil
    if event == nil then
        self:setControlText("newsEventName", FFR_L10n.t("ffr_news_no_event"))
        self:setControlText("newsSeverity", "-")
        self:setControlText("newsPhase", "-")
        self:setControlText("newsEnds", "-")
        self:setControlText("newsEventDescription", "")
    else
        self:setControlText("newsEventName", FFR_L10n.eventName(event.name or "Market event"))
        self:setControlText("newsSeverity", event.severity ~= nil and FFR_L10n.named("ffr_event_severity_", event.severity) or "-")
        self:setControlText("newsPhase", event.phase ~= nil and FFR_L10n.named("ffr_event_phase_", event.phase) or "-")
        local expiry = tonumber(event.expiryPeriod)
        if expiry ~= nil and expiry > 0 and g_FFR.inputMarket ~= nil then
            self:setControlText("newsEnds", g_FFR.inputMarket:getMonthName(expiry))
        else
            self:setControlText("newsEnds", "-")
        end
        self:setControlText("newsEventDescription", FFR_L10n.eventDescription(event.name, event.description))
    end
    local lines = {}
    if g_FFR ~= nil and g_FFR.newsSystem ~= nil and g_FFR.newsSystem.getLatest ~= nil then
        lines = g_FFR.newsSystem:getLatest(FFR_DashboardFrame.NEWS_ROWS)
    end
    self:setRowTexts("newsRow", lines, FFR_DashboardFrame.NEWS_ROWS, FFR_L10n.t("ffr_news_empty"))
end

function FFR_DashboardFrame:refreshBankPage(d)
    self:ensureManagers()
    if g_FFR == nil then return end
    local equipment = self.bankView == "EQUIPMENT"
    self:setControlVisible("bankLoansGroup", not equipment)
    self:setControlVisible("bankEquipmentGroup", equipment)
    if equipment then
        self:refreshEquipmentView()
        return
    end
    local bank, credit, f = g_FFR.bankingManager, g_FFR.creditManager, g_FFR.financialManager
    self:setControlText("bankCreditValue", string.format("%d   %s", d.creditScore or 0, d.creditRating or FFR_L10n.t("ffr_common_unavailable")))
    self:setControlText("bankModifierValue", string.format("x%.2f", tonumber(d.interestRateModifier) or 1))
    if bank ~= nil then
        self:setControlText("bankOperatingRate", self:formatPercent(bank:getOperatingRate(credit)))
        self:setControlText("bankLandRate", self:formatPercent(bank:getLandRate(credit)))
        self:setControlText("bankInterestPaid", self:formatMoney(bank.totalInterestPaid))
        if f ~= nil then self:setControlText("bankMonthlyInterest", self:formatMoney(bank:calculateMonthlyInterest(f, credit))) end
    end
    self:setControlText("bankOperatingLimit", self:formatMoney(d.operatingLoanLimit))
    if bank ~= nil then self:setControlText("bankLandLimit", self:formatMoney(bank:getLandLimit(credit))) end
    if credit ~= nil then self:setControlText("bankLatePayments", tostring(credit.latePayments or 0)) end
    if credit ~= nil and FFR_InsolvencyManager ~= nil then
        local stage = FFR_InsolvencyManager.getStage(credit)
        local standing = FFR_InsolvencyManager.getStageName(credit)
        if stage > 0 then standing = FFR_L10n.t("ffr_bank_standing_months", standing, tonumber(credit.monthsOverdrawn) or 0) end
        self:setControlText("bankStanding", standing)
        self:setControlColor("bankStanding", stage == 0 and FFR_DashboardFrame.PRICE_UP_COLOR or FFR_DashboardFrame.PRICE_DOWN_COLOR)
        local outlook = ""
        if stage > 0 or (tonumber(f ~= nil and f.cashOnHand) or 0) < 0 then
            outlook = FFR_L10n.t("ffr_bank_outlook", FFR_InsolvencyManager.getOutlook(credit))
        end
        self:setControlText("bankStandingOutlook", outlook)
    end
    self:setControlText("bankMessage", self.bankMessage or "")
    self:setLoanAmount("Operating", self:getLoanAmount("Operating"))
    self:setLoanAmount("Land", self:getLoanAmount("Land"))
    if f ~= nil then
        self:setControlText("bankOperatingDebt", self:formatMoney(f.operatingLoan))
        self:setControlText("bankEquipmentDebt", self:formatMoney(f.equipmentDebt))
        self:setControlText("bankLandDebt", self:formatMoney(f.landDebt))
        self:setControlText("bankTotalDebt", self:formatMoney(f.totalDebt))
        self:setControlText("bankLandPrincipal", self:formatMoney(f.monthlyLandPayment))
    end
end

-- Loan buttons. Each runs one banking action and shows its result on the page.
-- Every farm action goes through FFR_Network.perform: it runs directly in
-- singleplayer and on the host, and on a multiplayer client it is sent to the
-- server (farm managers only). setMessage(text) shows the outcome on the page.
function FFR_DashboardFrame:performAction(action, args, setMessage)
    if g_FFR == nil or not g_FFR.isInitialized or FFR_Network == nil then
        setMessage(FFR_L10n.t("ffr_msg_not_loaded"))
        return
    end
    FFR_Network.perform(action, args, function(ok, message)
        setMessage(message or "")
        self:refreshData()
    end)
end

function FFR_DashboardFrame:runLoanAction(action, amount)
    self:performAction(action, {amount = amount}, function(message) self.bankMessage = message end)
end

-- Amount bars: $0 - $500K in $10K steps, one per loan (default: the old fixed steps).
FFR_DashboardFrame.LOAN_AMOUNT_MAX = 500000
FFR_DashboardFrame.LOAN_AMOUNT_STEP = 10000
function FFR_DashboardFrame:getLoanAmount(loan)
    self.loanAmounts = self.loanAmounts or {
        Operating = FFR_BankingManager ~= nil and FFR_BankingManager.OPERATING_STEP or 100000,
        Land = FFR_BankingManager ~= nil and FFR_BankingManager.LAND_STEP or 250000
    }
    return self.loanAmounts[loan] or 0
end
function FFR_DashboardFrame:setLoanAmount(loan, amount)
    self:getLoanAmount(loan)
    local step = FFR_DashboardFrame.LOAN_AMOUNT_STEP
    local value = math.floor((tonumber(amount) or 0) / step + 0.5) * step
    self.loanAmounts[loan] = math.max(0, math.min(FFR_DashboardFrame.LOAN_AMOUNT_MAX, value))
    self:setControlText("bankAmount" .. loan, self:formatMoney(self.loanAmounts[loan]))
end
function FFR_DashboardFrame:runAmountAction(action, loan)
    local amount = self:getLoanAmount(loan)
    if amount <= 0 then
        self.bankMessage = FFR_L10n.t("ffr_bank_set_amount")
        self:refreshData()
        return
    end
    self:runLoanAction(action, amount)
end
function FFR_DashboardFrame:onClickBorrowOperating() self:runAmountAction("BORROW_OPERATING", "Operating") end
function FFR_DashboardFrame:onClickRepayOperating() self:runAmountAction("REPAY_OPERATING", "Operating") end
function FFR_DashboardFrame:onClickBorrowLand() self:runAmountAction("BORROW_LAND", "Land") end
function FFR_DashboardFrame:onClickRepayLand() self:runAmountAction("REPAY_LAND", "Land") end
function FFR_DashboardFrame:onClickPayOffOperating() self:runLoanAction("PAYOFF_OPERATING") end
function FFR_DashboardFrame:onClickPayOffLand() self:runLoanAction("PAYOFF_LAND") end
function FFR_DashboardFrame:stepLoanAmount(loan, direction, holdId)
    if self:consumeHoldClick(holdId) then return end
    self:setLoanAmount(loan, self:getLoanAmount(loan) + direction * FFR_DashboardFrame.LOAN_AMOUNT_STEP)
end
function FFR_DashboardFrame:onClickAmountDownOperating() self:stepLoanAmount("Operating", -1, "buttonAmountDownOperating") end
function FFR_DashboardFrame:onClickAmountUpOperating() self:stepLoanAmount("Operating", 1, "buttonAmountUpOperating") end
function FFR_DashboardFrame:onClickAmountDownLand() self:stepLoanAmount("Land", -1, "buttonAmountDownLand") end
function FFR_DashboardFrame:onClickAmountUpLand() self:stepLoanAmount("Land", 1, "buttonAmountUpLand") end

--------------------------------------------------
-- Bank page, equipment view: machines financed in
-- the shop (FFR_EquipmentFinanceManager). UP / DOWN
-- selects a loan; PAY OFF SELECTED pays it in full.
--------------------------------------------------

FFR_DashboardFrame.EQUIP_ROWS = 4

function FFR_DashboardFrame:onClickBankView()
    self.bankView = self.bankView == "EQUIPMENT" and "LOANS" or "EQUIPMENT"
    self.equipMessage = nil
    self:refreshData()
end

function FFR_DashboardFrame:getEquipmentLoans()
    local state = g_FFR ~= nil and g_FFR.localFarmId ~= nil and g_FFR:getFarmState(g_FFR.localFarmId) or nil
    if state == nil or FFR_EquipmentFinanceManager == nil then return {}, state end
    return FFR_EquipmentFinanceManager.getSortedLoans(state), state
end

function FFR_DashboardFrame:refreshEquipmentView()
    local m = FFR_EquipmentFinanceManager
    local list, state = self:getEquipmentLoans()
    if m == nil or state == nil then return end
    local f, bank, credit = state.financialManager, state.bankingManager, state.creditManager
    local loans, leases = 0, 0
    for _, loan in ipairs(list) do
        if m.isOpen(loan) then
            if m.isLease(loan) then leases = leases + 1 else loans = loans + 1 end
        end
    end
    self:setControlText("equipCount", string.format("%d / %d", loans, leases))
    self:setControlText("equipBalance", self:formatMoney(f.equipmentDebt))
    self:setControlText("equipLeaseLeft", self:formatMoney(f.leaseDebt))
    self:setControlText("equipMonthly", self:formatMoney((tonumber(f.monthlyEquipmentPayment) or 0) + (tonumber(f.monthlyLeaseCost) or 0)))
    self:setControlText("equipRate", self:formatPercent(bank:getEquipmentRate(credit)))
    self:setControlText("equipLimit", self:formatMoney(m.getLimit(state)))
    local rows = FFR_DashboardFrame.EQUIP_ROWS
    self.equipSelected = math.max(1, math.min(self.equipSelected or 1, math.max(1, #list)))
    local first = math.floor((self.equipSelected - 1) / rows) * rows + 1
    for r = 1, rows do
        local index = first + r - 1
        local loan = list[index]
        local cells = {"", "", "", "", "", "", ""}
        if loan ~= nil then
            local active, lease = m.isActive(loan), m.isLease(loan)
            local perMonth = "-"
            if active then
                perMonth = self:formatMoney(lease and loan.payment or math.min(tonumber(loan.principal) or 0, tonumber(loan.balance) or 0))
            end
            cells = {
                m.getDisplayName(loan), m.getKindName(loan), self:formatMoney(loan.price),
                self:formatMoney(m.isOpen(loan) and m.getOwed(loan) or 0), perMonth,
                FFR_L10n.t("ffr_equip_months_paid", math.floor(tonumber(loan.paidMonths) or 0), math.floor(tonumber(loan.term) or 0)),
                m.getStatusName(loan)
            }
            local color = FFR_DashboardFrame.TAB_IDLE_COLOR
            if active then color = FFR_DashboardFrame.PRICE_UP_COLOR
            elseif loan.status == "ENDED" or loan.status == "SOLD" or loan.status == "REPOSSESSED" then color = FFR_DashboardFrame.STATUS_DUE_COLOR end
            self:setControlColor(string.format("equipRow%dCol7", r), color)
        end
        for c = 1, #cells do self:setControlText(string.format("equipRow%dCol%d", r, c), cells[c]) end
        self:setControlVisible("equipRowHighlight" .. r, loan ~= nil and index == self.equipSelected)
    end
    self:setControlText("equipPage", #list > 0 and FFR_L10n.t("ffr_equip_paging", first, math.min(#list, first + rows - 1), #list)
        or FFR_L10n.t("ffr_equip_none"))
    self:setControlText("equipDetail", self:getEquipmentDetail(list[self.equipSelected]))
    self:setControlText("equipMessage", self.equipMessage or "")
end

-- What the selected contract costs to settle (or return) today.
function FFR_DashboardFrame:getEquipmentDetail(loan)
    local m = FFR_EquipmentFinanceManager
    if loan == nil or not m.isOpen(loan) then return "" end
    if not m.isLease(loan) then return FFR_L10n.t("ffr_equip_detail_finance", self:formatMoney(m.getSettlement(loan))) end
    if loan.status == "ENDED" then
        return FFR_L10n.t("ffr_equip_detail_ended", self:formatMoney(m.getSettlement(loan)))
    end
    return FFR_L10n.t("ffr_equip_detail_lease", self:formatMoney(m.getSettlement(loan)), self:formatMoney(m.getReturnFee(loan)))
end

function FFR_DashboardFrame:changeEquipSelection(direction)
    local count = #self:getEquipmentLoans()
    if count == 0 then return end
    self.equipSelected = (self.equipSelected or 1) + direction
    if self.equipSelected < 1 then self.equipSelected = count elseif self.equipSelected > count then self.equipSelected = 1 end
    self.equipMessage = nil
    self:refreshEquipmentView()
end

function FFR_DashboardFrame:runEquipmentAction(action, leaseOnly)
    local loan = self:getEquipmentLoans()[self.equipSelected or 1]
    local m = FFR_EquipmentFinanceManager
    if loan == nil or not m.isOpen(loan) or (leaseOnly and not m.isLease(loan)) then
        self.equipMessage = FFR_L10n.t(leaseOnly and "ffr_lease_not_lease" or "ffr_finance_no_loan")
        self:refreshEquipmentView()
        return
    end
    self:performAction(action, {loanId = loan.id}, function(message)
        self.equipMessage = message
    end)
end
function FFR_DashboardFrame:onClickEquipmentPayOff() self:runEquipmentAction("EQUIP_PAYOFF", false) end
function FFR_DashboardFrame:onClickEquipmentReturn() self:runEquipmentAction("EQUIP_RETURN", true) end

-- Lime fill up to the amount, and a dot at the amount (drawn over the track).
function FFR_DashboardFrame:drawLoanSliders()
    local overlay = self.fillOverlay
    if overlay == nil or self.currentSection ~= FFR_DashboardFrame.TAB.BANK or self.bankView == "EQUIPMENT" then return end
    for _, loan in ipairs({"Operating", "Land"}) do
        local bar = self.controls["bankSlider" .. loan]
        if bar ~= nil and bar.absPosition ~= nil and bar.absSize ~= nil and (bar.getIsVisible == nil or bar:getIsVisible()) then
            local x, y, w, h = bar.absPosition[1], bar.absPosition[2], bar.absSize[1], bar.absSize[2]
            local fraction = self:getLoanAmount(loan) / FFR_DashboardFrame.LOAN_AMOUNT_MAX
            overlay:setColor(0.54, 0.86, 0.18, 1)
            overlay:setPosition(x, y)
            overlay:setDimension(w * fraction, h)
            overlay:render()
            local dotW, dotH = 0.008, 0.016
            overlay:setColor(0.92, 0.93, 0.92, 1)
            overlay:setPosition(x + w * fraction - dotW / 2, y + h / 2 - dotH / 2)
            overlay:setDimension(dotW, dotH)
            overlay:render()
        end
    end
end

FFR_DashboardFrame.ADVISOR_ROWS = 8
FFR_DashboardFrame.GRADE_COLORS = {
    A = {0.40, 0.95, 0.52, 1}, B = {0.54, 0.86, 0.18, 1}, C = {0.95, 0.79, 0.32, 1},
    D = {1, 0.72, 0.28, 1}, F = {0.95, 0.36, 0.30, 1}
}
function FFR_DashboardFrame:refreshAdvisorPage(d)
    self:ensureManagers()
    local advisor = g_FFR ~= nil and g_FFR.advisorManager or nil
    local state = (g_FFR ~= nil and g_FFR.getFarmState ~= nil) and g_FFR:getFarmState(g_FFR.localFarmId) or nil
    local review = (advisor ~= nil and advisor.review ~= nil and state ~= nil) and advisor:review(state) or nil
    if review == nil then
        self:setRowTexts("advisorRow", {}, FFR_DashboardFrame.ADVISOR_ROWS, FFR_L10n.t("ffr_advisor_not_loaded"))
        return
    end
    local h, r = review.health, review.runway
    self:setControlText("advisorGrade", h.grade)
    self:setControlColor("advisorGrade", FFR_DashboardFrame.GRADE_COLORS[h.grade] or FFR_DashboardFrame.TAB_IDLE_COLOR)
    self:setControlText("advisorScore", FFR_L10n.t("ffr_advisor_score", h.score))
    self:setControlText("advisorVerdict", h.verdict)
    for i = 1, 5 do
        local factor = h.factors[i]
        self:setControlText("advisorFactorName" .. i, factor ~= nil and factor.label or "")
        self:setControlText("advisorFactorDetail" .. i, factor ~= nil and factor.detail or "")
        self:setControlText("advisorFactorPoints" .. i, factor ~= nil and string.format("%d / 20", factor.points) or "")
        local points = factor ~= nil and factor.points or 20
        self:setControlColor("advisorFactorPoints" .. i, points >= 15 and FFR_DashboardFrame.PRICE_UP_COLOR
            or points >= 8 and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.PRICE_DOWN_COLOR)
    end
    self:setControlText("advisorCash", self:formatMoney(r.cash))
    if r.average ~= nil then
        self:setControlText("advisorAverage", (r.average >= 0 and "+" or "") .. self:formatMoney(r.average))
        self:setControlColor("advisorAverage", r.average >= 0 and FFR_DashboardFrame.PRICE_UP_COLOR or FFR_DashboardFrame.PRICE_DOWN_COLOR)
    else
        self:setControlText("advisorAverage", "-")
    end
    if r.monthsLeft == nil then
        self:setControlText("advisorRunway", FFR_L10n.t("ffr_advisor_cash_growing"))
    elseif r.cash < 0 then
        self:setControlText("advisorRunway", FFR_L10n.t("ffr_advisor_overdrawn"))
    else
        self:setControlText("advisorRunway", FFR_L10n.t("ffr_advisor_months_left", r.monthsLeft))
    end
    local taxText = self:formatMoney(r.taxEstimate)
    if r.monthsToTax ~= nil then taxText = FFR_L10n.t("ffr_advisor_tax_in", taxText, r.monthsToTax) end
    self:setControlText("advisorTax", taxText)
    self:setControlText("advisorLoanCosts", self:formatMoney(r.interest + r.principal))
    self:setControlText("advisorHousehold", self:formatMoney(r.household))
    if r.estimated then
        self:setControlText("advisorRunwayNote", FFR_L10n.t("ffr_advisor_note_estimated"))
    else
        self:setControlText("advisorRunwayNote", (r.months == 1 and FFR_L10n.t("ffr_advisor_note_one") or FFR_L10n.t("ffr_advisor_note_many", r.months)))
    end
    local lines = {}
    for _, line in ipairs(review.advice) do table.insert(lines, "-  " .. line) end
    self:setRowTexts("advisorRow", lines, FFR_DashboardFrame.ADVISOR_ROWS, FFR_L10n.t("ffr_advisor_nothing"))
end

--------------------------------------------------
-- Deals page: forward contracts
--------------------------------------------------

FFR_DashboardFrame.CONTRACT_ROWS = 3
FFR_DashboardFrame.STATUS_DUE_COLOR = {0.98, 0.82, 0.20, 1}
FFR_DashboardFrame.STATUS_OPEN_COLOR = {0.54, 0.86, 0.18, 1}
FFR_DashboardFrame.STATUS_DONE_COLOR = {0.62, 0.66, 0.64, 1}
FFR_DashboardFrame.STATUS_DEFAULTED_COLOR = {0.95, 0.36, 0.30, 1}
FFR_DashboardFrame.STATUS_COLORS = {
    OPEN = FFR_DashboardFrame.STATUS_OPEN_COLOR,
    DUE = FFR_DashboardFrame.STATUS_DUE_COLOR,
    FULFILLED = FFR_DashboardFrame.STATUS_DONE_COLOR,
    ["BOUGHT OUT"] = FFR_DashboardFrame.STATUS_DONE_COLOR,
    DEFAULTED = FFR_DashboardFrame.STATUS_DEFAULTED_COLOR
}
FFR_DashboardFrame.PRICE_UP_COLOR = {0.40, 0.95, 0.52, 1}
FFR_DashboardFrame.PRICE_DOWN_COLOR = {0.95, 0.36, 0.30, 1}
FFR_DashboardFrame.CONTRACT_COLUMNS = {"Commodity", "Buyer", "Volume", "Delivered", "Remaining", "Price", "Deadline", "Status", "Exposure"}

function FFR_DashboardFrame:getContractManager()
    return g_FFR ~= nil and g_FFR.contractManager or nil
end

function FFR_DashboardFrame:getContractFarmId()
    if g_FFR == nil or g_FFR.gameIntegrationManager == nil then return nil end
    return g_FFR.gameIntegrationManager:getActiveFarmId()
end

function FFR_DashboardFrame:getContractDraft()
    if self.contractDraft == nil then
        self.contractDraft = {
            commodityIndex = 1,
            buyerIndex = 1,
            volume = FFR_ContractManager ~= nil and FFR_ContractManager.DEFAULT_VOLUME or 100000,
            monthsAhead = FFR_ContractManager ~= nil and FFR_ContractManager.DEFAULT_MONTHS_AHEAD or 6
        }
    end
    return self.contractDraft
end

-- The offer is a snapshot: priced once, then kept until the player changes
-- commodity, buyer, volume, month or year (or declines/accepts).
function FFR_DashboardFrame:getContractQuote()
    local cm = self:getContractManager()
    if cm == nil then return nil, nil end
    if self.contractQuote == nil then
        local list = cm:getContractableCommodities()
        self.contractCommodityCount = #list
        if #list == 0 then return cm, nil end
        local draft = self:getContractDraft()
        draft.commodityIndex = math.max(1, math.min(draft.commodityIndex, #list))
        self.contractQuote = cm:getQuote(list[draft.commodityIndex].name, draft.buyerIndex, draft.volume, draft.monthsAhead)
        if self.contractQuote ~= nil then draft.buyerIndex = self.contractQuote.buyerIndex end
    end
    return cm, self.contractQuote
end

function FFR_DashboardFrame:getSelectedContract()
    local cm = self:getContractManager()
    if cm == nil then return nil end
    local listed = cm:getListed(self:getContractFarmId())
    return listed[self.contractSelected or 1]
end

function FFR_DashboardFrame:refreshContractsPage()
    local cm, quote = self:getContractQuote()
    if cm == nil then
        self:setControlText("contractMessage", FFR_L10n.t("ffr_contract_not_loaded"))
        return
    end
    local fee = math.floor(FFR_ContractManager.BUYOUT_FEE * 100 + 0.5)
    self:setControlText("termSurcharge", string.format("%d%%", fee))
    self:setControlText("termSurchargeLine", FFR_L10n.t("ffr_contract_term_fee", fee))
    self:setControlText("termCooldownLine", FFR_L10n.t("ffr_contract_term_cooldown", FFR_L10n.months(FFR_ContractManager.DEFAULT_COOLDOWN_MONTHS)))
    -- The volume bar's range, in this crop's display unit.
    local volumeCrop = self:getVolumeCommodity()
    if volumeCrop ~= nil then
        self:setControlText("contractVolumeStep", FFR_L10n.t("ffr_contract_volume_range",
            self:formatAmount(volumeCrop, FFR_ContractManager.MIN_VOLUME), self:formatAmount(volumeCrop, FFR_ContractManager.MAX_VOLUME)))
    else
        self:setControlText("contractVolumeStep", "")
    end

    if quote ~= nil then
        local buyerLabel = quote.buyerName or "-"
        if (quote.buyerCount or 1) > 1 then buyerLabel = string.format("%s (%d/%d)", buyerLabel, quote.buyerIndex, quote.buyerCount) end
        self:setControlText("contractCommodityValue", self:formatCommodityName(quote.commodity))
        self:setControlText("contractBuyerValue", buyerLabel)
        self:setControlText("contractMarketPrice", self:formatPriceFull({name = quote.commodity}, quote.spotPrice))
        self:setControlText("contractVolumeValue", self:formatAmount(quote.commodity, quote.volume))
        self:setControlText("contractPriceValue", self:formatPriceFull({name = quote.commodity}, quote.lockedPrice))
        self:setControlText("contractPremiumValue", FFR_L10n.t("ffr_contract_vs_spot", quote.versusSpot * 100))
        self:setControlColor("contractPremiumValue", quote.versusSpot >= 0 and FFR_DashboardFrame.PRICE_UP_COLOR or FFR_DashboardFrame.PRICE_DOWN_COLOR)
        -- Months ahead shown because the FS25 year starts in March
        -- ("January, Year 2" comes after "October, Year 2").
        local monthsLabel = FFR_L10n.months(quote.monthsAhead)
        self:setControlText("contractMonthValue", FFR_L10n.t("ffr_contract_deadline_pick", FFR_L10n.date(quote.deadlinePeriod, quote.deadlineYear), monthsLabel))
        self:setControlText("contractEstimateValue", self:formatMoney(quote.value))
        self:setControlText("termDeadline", FFR_L10n.t("ffr_contract_term_deadline", FFR_L10n.date(quote.deadlinePeriod, quote.deadlineYear), monthsLabel))
        self:setControlText("termBuyer", quote.buyerName or "-")
        self:setControlText("termVolume", self:formatAmount(quote.commodity, quote.volume))
        self:setControlText("termPrice", self:formatPriceFull({name = quote.commodity}, quote.lockedPrice))
        self:setControlText("termValue", self:formatMoney(quote.value))
    else
        self:setControlText("contractCommodityValue", FFR_L10n.t("ffr_common_none"))
        self:setControlText("contractBuyerValue", FFR_L10n.t("ffr_contract_no_buyer"))
        self:setControlText("contractEstimateValue", self:formatMoney(0))
    end

    local farmId = self:getContractFarmId()
    local openCount = #cm:getActive(farmId)
    local listed = cm:getListed(farmId)
    self.contractSelected = math.max(1, math.min(self.contractSelected or 1, math.max(1, #listed)))
    -- The table shows CONTRACT_ROWS at a time; UP / DOWN pages through the rest.
    local rows = FFR_DashboardFrame.CONTRACT_ROWS
    local first = math.floor((self.contractSelected - 1) / rows) * rows + 1
    local countText = openCount == 1 and FFR_L10n.t("ffr_contract_open_one") or FFR_L10n.t("ffr_contract_open_many", openCount)
    if #listed > rows then
        countText = FFR_L10n.t("ffr_contract_paging", countText, first, math.min(#listed, first + rows - 1), #listed)
    end
    self:setControlText("contractActiveCount", countText)
    -- Lifetime record replaces the page description once there is one.
    local record = cm:getHistoryText(farmId)
    if record ~= nil then self:setControlText("pageDescription", record) end
    for r = 1, rows do
        local index = first + r - 1
        local c = listed[index]
        local prefix = "contractRow" .. r
        self:setControlVisible("contractRowHighlight" .. r, c ~= nil and index == self.contractSelected)
        if c == nil then
            for _, col in ipairs(FFR_DashboardFrame.CONTRACT_COLUMNS) do self:setControlText(prefix .. col, "") end
        else
            local status = cm:getStatusText(c)
            local statusCode = cm:getStatusCode(c)
            self:setControlText(prefix .. "Commodity", self:formatCommodityName(c.commodity))
            self:setControlText(prefix .. "Buyer", c.buyerName or FFR_L10n.t("ffr_contract_any_buyer"))
            self:setControlText(prefix .. "Volume", self:formatAmount(c.commodity, c.volume))
            self:setControlText(prefix .. "Delivered", self:formatAmount(c.commodity, c.delivered))
            self:setControlText(prefix .. "Remaining", self:formatAmount(c.commodity, cm:getRemaining(c)))
            self:setControlText(prefix .. "Price", self:formatPriceShort({name = c.commodity}, c.lockedPrice))
            -- Next delivery call (open or upcoming); contracts without calls show their deadline.
            local nextCall = cm.getNextCall ~= nil and cm:getNextCall(c) or nil
            if nextCall ~= nil then
                local callYear = math.floor(((tonumber(nextCall.serial) or 0) - 1) / 12)
                self:setControlText(prefix .. "Deadline", FFR_L10n.dateShort(nextCall.serial - callYear * 12, callYear))
            else
                self:setControlText(prefix .. "Deadline", FFR_L10n.dateShort(c.deadlinePeriod, c.deadlineYear))
            end
            self:setControlText(prefix .. "Status", status)
            self:setControlColor(prefix .. "Status", FFR_DashboardFrame.STATUS_COLORS[statusCode] or FFR_DashboardFrame.STATUS_OPEN_COLOR)
            if c.status == "OPEN" then
                self:setControlText(prefix .. "Exposure", self:formatMoney(cm:getBuyoutCost(c)))
            elseif (tonumber(c.penaltyPaid) or 0) > 0 then
                self:setControlText(prefix .. "Exposure", FFR_L10n.t("ffr_contract_paid", self:formatMoney(c.penaltyPaid)))
            else
                self:setControlText(prefix .. "Exposure", "-")
            end
        end
    end
    -- No message: the selected contract's delivery calls.
    local message = self.contractMessage
    if message == nil then
        local selected = listed[self.contractSelected]
        if selected ~= nil and selected.calls ~= nil and #selected.calls > 0 then
            message = FFR_L10n.t("ffr_contract_calls_title", cm:getCallsText(selected))
        end
    end
    self:setControlText("contractMessage", message or "")
end

function FFR_DashboardFrame:changeContractDraft(field, delta)
    local draft = self:getContractDraft()
    if field == "commodity" then
        local count = self.contractCommodityCount or 0
        if count > 0 then
            draft.commodityIndex = draft.commodityIndex + delta
            if draft.commodityIndex < 1 then draft.commodityIndex = count elseif draft.commodityIndex > count then draft.commodityIndex = 1 end
        end
        -- A new commodity starts with its best-paying buyer.
        draft.buyerIndex = 1
    elseif field == "buyer" then
        local count = self.contractQuote ~= nil and self.contractQuote.buyerCount or 1
        draft.buyerIndex = draft.buyerIndex + delta
        if draft.buyerIndex < 1 then draft.buyerIndex = count elseif draft.buyerIndex > count then draft.buyerIndex = 1 end
    elseif field == "volume" then
        draft.volume = math.max(FFR_ContractManager.MIN_VOLUME, math.min(FFR_ContractManager.MAX_VOLUME, draft.volume + delta * FFR_ContractManager.VOLUME_STEP))
    elseif field == "months" then
        draft.monthsAhead = math.max(FFR_ContractManager.MIN_MONTHS_AHEAD, math.min(FFR_ContractManager.MAX_MONTHS_AHEAD, draft.monthsAhead + delta))
    end
    self.contractMessage = nil
    self.contractQuote = nil
    self:refreshContractsPage()
    -- A new crop may use another unit: put the volume on its round steps.
    if field == "commodity" then self:setContractVolume(draft.volume) end
end
function FFR_DashboardFrame:onClickContractPrevCommodity() self:changeContractDraft("commodity", -1) end
function FFR_DashboardFrame:onClickContractNextCommodity() self:changeContractDraft("commodity", 1) end
function FFR_DashboardFrame:onClickContractPrevBuyer() self:changeContractDraft("buyer", -1) end
function FFR_DashboardFrame:onClickContractNextBuyer() self:changeContractDraft("buyer", 1) end
-- Volume slider (v0.9.60): the bar spans MIN_VOLUME..MAX_VOLUME; the amount snaps to a
-- round step in the player's unit for this crop (100 bu, 1 t, 10,000 L ...).
function FFR_DashboardFrame:getVolumeCommodity()
    local cm = self:getContractManager()
    local list = cm ~= nil and cm:getContractableCommodities() or {}
    local entry = list[self:getContractDraft().commodityIndex or 1]
    return entry ~= nil and entry.name or nil
end

-- Litres per slider step: a power of ten in the display unit, about 1/200 of the range.
function FFR_DashboardFrame:getVolumeStepLiters(name)
    local perUnit = FFR_UnitManager ~= nil and FFR_UnitManager.getLitersPerUnit(name) or 1
    local maxUnits = FFR_ContractManager.MAX_VOLUME / perUnit
    local step = 10 ^ math.floor(math.log10(math.max(1, maxUnits / 200)))
    return step * perUnit
end

function FFR_DashboardFrame:setContractVolume(liters)
    local draft = self:getContractDraft()
    local step = self:getVolumeStepLiters(self:getVolumeCommodity())
    local snapped = math.floor((tonumber(liters) or 0) / step + 0.5) * step
    -- Smallest volume: the first whole step at or above MIN_VOLUME.
    local minimum = math.ceil(FFR_ContractManager.MIN_VOLUME / step) * step
    local volume = math.max(minimum, math.min(FFR_ContractManager.MAX_VOLUME, snapped))
    if math.abs(volume - (tonumber(draft.volume) or 0)) < 0.5 then return end
    draft.volume = volume
    self.contractMessage = nil
    self.contractQuote = nil
    self:refreshContractsPage()
end

function FFR_DashboardFrame:getVolumeSliderHit(posX, posY)
    local bar = self.controls.contractVolumeSlider
    if bar == nil or bar.absPosition == nil or bar.absSize == nil then return nil end
    local x, y, w, h = bar.absPosition[1], bar.absPosition[2], bar.absSize[1], bar.absSize[2]
    if posX >= x - 0.006 and posX <= x + w + 0.006 and posY >= y - 0.012 and posY <= y + h + 0.012 then return bar end
    return nil
end

function FFR_DashboardFrame:setVolumeFromMouse(bar, posX)
    local fraction = math.max(0, math.min(1, (posX - bar.absPosition[1]) / bar.absSize[1]))
    local m = FFR_ContractManager
    self:setContractVolume(m.MIN_VOLUME + fraction * (m.MAX_VOLUME - m.MIN_VOLUME))
end

function FFR_DashboardFrame:drawVolumeSlider()
    local overlay = self.fillOverlay
    local bar = self.controls.contractVolumeSlider
    if overlay == nil or self.currentSection ~= FFR_DashboardFrame.TAB.DEALS or bar == nil or bar.absPosition == nil then return end
    if bar.getIsVisible ~= nil and not bar:getIsVisible() then return end
    local m = FFR_ContractManager
    local x, y, w, h = bar.absPosition[1], bar.absPosition[2], bar.absSize[1], bar.absSize[2]
    local fraction = ((tonumber(self:getContractDraft().volume) or m.MIN_VOLUME) - m.MIN_VOLUME) / (m.MAX_VOLUME - m.MIN_VOLUME)
    fraction = math.max(0, math.min(1, fraction))
    overlay:setColor(0.54, 0.86, 0.18, 1)
    overlay:setPosition(x, y)
    overlay:setDimension(w * fraction, h)
    overlay:render()
    local dotW, dotH = 0.008, 0.016
    overlay:setColor(0.92, 0.93, 0.92, 1)
    overlay:setPosition(x + w * fraction - dotW / 2, y + h / 2 - dotH / 2)
    overlay:setDimension(dotW, dotH)
    overlay:render()
end
function FFR_DashboardFrame:onClickContractMonthPrev() self:changeContractDraft("months", -1) end
function FFR_DashboardFrame:onClickContractMonthNext() self:changeContractDraft("months", 1) end
-- The server prices the contract again from these terms; the shown quote is a preview.
function FFR_DashboardFrame:onClickContractAccept()
    local cm, quote = self:getContractQuote()
    if cm == nil then return end
    if quote == nil then
        self.contractMessage = FFR_L10n.t("ffr_contract_no_offer")
        self:refreshContractsPage()
        return
    end
    self:performAction("CONTRACT_SIGN", {
        commodity = quote.commodity, buyerKey = quote.buyerKey,
        volume = quote.volume, monthsAhead = quote.monthsAhead
    }, function(message)
        self.contractMessage = message
        -- A signed offer is used up; the next one is priced fresh.
        self.contractQuote = nil
        self:refreshContractsPage()
    end)
end

-- Roll / buy out act on the contract selected with UP / DOWN.
function FFR_DashboardFrame:runContractAction(action)
    local contract = self:getSelectedContract()
    if contract == nil then
        self.contractMessage = FFR_L10n.t("ffr_contract_select_first")
        self:refreshContractsPage()
        return
    end
    self:performAction(action, {contractId = contract.id}, function(message)
        self.contractMessage = message
        self:refreshContractsPage()
    end)
end
function FFR_DashboardFrame:onClickContractRoll() self:runContractAction("CONTRACT_ROLL") end
function FFR_DashboardFrame:onClickContractBuyOut() self:runContractAction("CONTRACT_BUYOUT") end
function FFR_DashboardFrame:changeContractSelection(direction)
    local cm = self:getContractManager()
    if cm == nil then return end
    local count = #cm:getListed(self:getContractFarmId())
    if count == 0 then return end
    self.contractSelected = (self.contractSelected or 1) + direction
    if self.contractSelected < 1 then self.contractSelected = count elseif self.contractSelected > count then self.contractSelected = 1 end
    self:refreshContractsPage()
end

function FFR_DashboardFrame:refreshStatusPage(d)
    self:ensureManagers()
    if g_FFR == nil or g_FFR.financialManager == nil then return end
    local f, t = g_FFR.financialManager, g_FFR.taxManager
    f:updateAnnualProfit()
    local profit = tonumber(f.annualProfit) or 0
    self:setControlText("statusAnnualRevenue", self:formatMoney(f.annualRevenue))
    self:setControlText("statusAnnualExpenses", self:formatMoney(f.annualExpenses))
    self:setControlText("statusAnnualProfit", self:formatMoney(profit))
    if t ~= nil then
        t:calculateIncomeTax(math.max(0, profit))
        t:updatePropertyTax(f)
        self:setControlText("statusIncomeTax", self:formatMoney(t.incomeTaxDue))
        self:setControlText("statusPropertyTax", self:formatMoney(t.propertyTaxDue))
        self:setControlText("statusTaxesPaid", self:formatMoney(t.totalTaxesPaid))
    end
    self:setControlText("statusMonthRevenue", self:formatMoney(f.monthlyRevenue))
    self:setControlText("statusMonthExpenses", self:formatMoney(f.monthlyExpenses))
    local lastOverhead = g_FFRMonthlyFinancialProcessor ~= nil and g_FFRMonthlyFinancialProcessor:getLastMonthlyTotal() or 0
    self:setControlText("statusLastOverhead", self:formatMoney(lastOverhead))
    if g_FFR.insuranceManager ~= nil then
        g_FFR.insuranceManager:updatePremiums(f)
        self:setControlText("statusInsurancePremium", self:formatMoney(g_FFR.insuranceManager.totalPremium))
    end
    self:setControlText("statusDebtRatio", string.format("%.1f%%", (tonumber(f.debtRatio) or 0) * 100))
    if f.hasUnlimitedLiquidity then
        self:setControlText("statusLiquidity", FFR_L10n.t("ffr_status_no_obligations"))
    else
        self:setControlText("statusLiquidity", FFR_L10n.t("ffr_advisor_months_left", tonumber(f.liquidityRatio) or 0))
    end
    self:refreshStatements()
end

--------------------------------------------------
-- Farm Status statements: closed months or years
-- of the local farm, newest first, 6 rows a page.
--------------------------------------------------

FFR_DashboardFrame.STATEMENT_ROWS = 6
FFR_DashboardFrame.STATEMENT_COLUMNS = 8
FFR_DashboardFrame.STATEMENT_HEADS = {
    -- Translation keys ffr_statement_head_<name>.
    MONTHS = {"month", "revenue", "operating", "ffrcosts", "tax", "net", "cash", "networth"},
    YEARS = {"year", "revenue", "expenses", "taxes", "profit", "debt", "networth", "margin"}
}

function FFR_DashboardFrame:getStatementList()
    local state = g_FFR ~= nil and g_FFR.getFarmState ~= nil and g_FFR:getFarmState(g_FFR.localFarmId) or nil
    if state == nil then return {} end
    return (self.statementMode == "YEARS" and state.years or state.statements) or {}
end

function FFR_DashboardFrame:getStatementCells(record)
    local m = function(v) return self:formatMoney(v) end
    if self.statementMode == "YEARS" then
        -- Margin: the year's profit as a share of its revenue.
        local revenue = tonumber(record.revenue) or 0
        local margin = revenue > 0 and string.format("%.1f %%", (tonumber(record.profit) or 0) / revenue * 100) or "-"
        return {FFR_L10n.t("ffr_statement_year", math.floor(record.year or 0)), m(record.revenue), m(record.expenses), m(record.taxes),
            m(record.profit), m(record.debt), m(record.netWorth), margin}
    end
    return {FFR_L10n.dateShort(record.period or 1, record.year), m(record.revenue), m(record.expenses),
        m(record.overhead), m(record.tax), m(record.net), m(record.cash), m(record.netWorth)}
end

function FFR_DashboardFrame:refreshStatements()
    local mode = self.statementMode == "YEARS" and "YEARS" or "MONTHS"
    local list = self:getStatementList()
    local rows = FFR_DashboardFrame.STATEMENT_ROWS
    local pages = math.max(1, math.ceil(#list / rows))
    self.statementPage = math.max(1, math.min(self.statementPage or 1, pages))
    self:setControlText("statementTitle", FFR_L10n.t(mode == "YEARS" and "ffr_statement_title_years" or "ffr_statement_title_months"))
    if #list == 0 then
        self:setControlText("statementPage", FFR_L10n.t(mode == "YEARS" and "ffr_statement_no_year" or "ffr_statement_no_month"))
    else
        self:setControlText("statementPage", FFR_L10n.t("ffr_statement_page", self.statementPage, pages))
    end
    for c = 1, FFR_DashboardFrame.STATEMENT_COLUMNS do
        local head = FFR_DashboardFrame.STATEMENT_HEADS[mode][c]
        self:setControlText("statementHead" .. c, (head ~= nil and head ~= "") and FFR_L10n.t("ffr_statement_head_" .. head) or "")
    end
    for r = 1, rows do
        -- Newest first.
        local record = list[#list - ((self.statementPage - 1) * rows + r) + 1]
        local cells = record ~= nil and self:getStatementCells(record) or {}
        for c = 1, FFR_DashboardFrame.STATEMENT_COLUMNS do
            self:setControlText(string.format("statementRow%dCol%d", r, c), cells[c] or "")
        end
        local netColumn = mode == "YEARS" and 5 or 6
        local net = record ~= nil and (mode == "YEARS" and record.profit or record.net) or 0
        self:setControlColor(string.format("statementRow%dCol%d", r, netColumn),
            (tonumber(net) or 0) >= 0 and FFR_DashboardFrame.PRICE_UP_COLOR or FFR_DashboardFrame.PRICE_DOWN_COLOR)
    end
end

function FFR_DashboardFrame:onClickStatementToggle()
    self.statementMode = self.statementMode == "YEARS" and "MONTHS" or "YEARS"
    self.statementPage = 1
    self:refreshStatements()
end

function FFR_DashboardFrame:changeStatementPage(direction)
    self.statementPage = (self.statementPage or 1) + direction
    self:refreshStatements()
end

-- The local farm's household (part of its financial profile).
function FFR_DashboardFrame:getHouseholdManager()
    if g_FFR == nil then return nil end
    self.householdManager = g_FFR.familyManager
    return self.householdManager
end
function FFR_DashboardFrame:refreshHouseholdPage()
    local h=self:getHouseholdManager(); if h==nil then return false end
    h:recalculate()
    self:setControlText("householdAdultsValue",h.adults)
    self:setControlText("householdChildrenValue",h.children)
    self:setControlText("householdStudentsValue",h.universityStudents)
    self:setControlText("householdVehiclesValue",h.personalVehicles)
    self:setControlText("householdHousingValue",FFR_FamilyManager.getLevelName(h.housingLevel))
    self:setControlText("householdActivitiesValue",FFR_FamilyManager.getLevelName(h.activityLevel))
    self:setControlText("householdHousingCost",self:formatMoney(h.mortgageCost))
    self:setControlText("householdUtilitiesCost",self:formatMoney(h.utilityCost))
    self:setControlText("householdFoodCost",self:formatMoney(h.foodCost))
    self:setControlText("householdVehicleCost",self:formatMoney(h.vehicleCost))
    self:setControlText("householdHealthCost",self:formatMoney(h.healthCost))
    self:setControlText("householdRecreationCost",self:formatMoney(h.recreationCost))
    self:setControlText("householdSportsCost",self:formatMoney(h.sportsCost))
    self:setControlText("householdTuitionCost",self:formatMoney(h.tuitionCost))
    self:setControlText("householdTotalCost",self:formatMoney(h.totalMonthlyCost))
    return true
end
function FFR_DashboardFrame:changeHouseholdSetting(setting,direction)
    self:performAction("HOUSEHOLD_CHANGE", {setting = setting, direction = direction}, function(message)
        if message ~= nil and message ~= "" then self:setControlText("footerInfo", message) end
        self:refreshHouseholdPage()
    end)
end
function FFR_DashboardFrame:onClickAdultsDecrease() self:changeHouseholdSetting("ADULTS",-1) end
function FFR_DashboardFrame:onClickAdultsIncrease() self:changeHouseholdSetting("ADULTS",1) end
function FFR_DashboardFrame:onClickChildrenDecrease() self:changeHouseholdSetting("CHILDREN",-1) end
function FFR_DashboardFrame:onClickChildrenIncrease() self:changeHouseholdSetting("CHILDREN",1) end
function FFR_DashboardFrame:onClickStudentsDecrease() self:changeHouseholdSetting("STUDENTS",-1) end
function FFR_DashboardFrame:onClickStudentsIncrease() self:changeHouseholdSetting("STUDENTS",1) end
function FFR_DashboardFrame:onClickVehiclesDecrease() self:changeHouseholdSetting("VEHICLES",-1) end
function FFR_DashboardFrame:onClickVehiclesIncrease() self:changeHouseholdSetting("VEHICLES",1) end
function FFR_DashboardFrame:onClickHousingDecrease() self:changeHouseholdSetting("HOUSING",-1) end
function FFR_DashboardFrame:onClickHousingIncrease() self:changeHouseholdSetting("HOUSING",1) end
function FFR_DashboardFrame:onClickActivitiesDecrease() self:changeHouseholdSetting("ACTIVITIES",-1) end
function FFR_DashboardFrame:onClickActivitiesIncrease() self:changeHouseholdSetting("ACTIVITIES",1) end
function FFR_DashboardFrame:onClickHouseholdReset()
    self:performAction("HOUSEHOLD_RESET", nil, function(message)
        if message ~= nil and message ~= "" then self:setControlText("footerInfo", message) end
        self:refreshHouseholdPage()
    end)
end

--------------------------------------------------
-- Land page: the local farm's parcels and titles
--------------------------------------------------

FFR_DashboardFrame.LAND_ROWS = 12

-- Areas follow the player's hectares / acres setting (FFR_L10n.formatArea).
FFR_DashboardFrame.TITLED_COLOR = {0.54, 0.86, 0.18, 1}
FFR_DashboardFrame.UNTITLED_COLOR = {1, 0.72, 0.28, 1}

function FFR_DashboardFrame:refreshLandPage()
    local view = self.landView or "TITLES"
    self:setControlVisible("landTitlesGroup", view == "TITLES")
    self:setControlVisible("landRentGroup", view == "RENTALS")
    self:setControlVisible("landAuctionGroup", view == "AUCTIONS")
    -- The page line under the heading follows the land market (FFR_LandMarketManager).
    if FFR_LandMarketManager ~= nil then self:setControlText("pageDescription", FFR_LandMarketManager.getSummaryText()) end
    if view == "RENTALS" then self:refreshRentView() return end
    if view == "AUCTIONS" then self:refreshAuctionView() return end
    local registry = g_FFRLandRegistryManager
    local farmId = g_FFR ~= nil and g_FFR.localFarmId or nil
    local list = registry ~= nil and registry:getTitles(farmId) or {}
    local rows = FFR_DashboardFrame.LAND_ROWS
    local pages = math.max(1, math.ceil(#list / rows))
    -- The page follows the selected parcel (CHANGE TITLE acts on it).
    self.landSelected = math.max(1, math.min(self.landSelected or 1, math.max(1, #list)))
    self.landPage = math.floor((self.landSelected - 1) / rows) + 1
    local area, arable, book, assessed, collateral, pending = 0, 0, 0, 0, 0, 0
    for _, row in ipairs(list) do
        area = area + (tonumber(row.areaInHa) or 0)
        arable = arable + math.max(0, tonumber(row.arableHa) or 0)
        book = book + (tonumber(row.bookValue) or 0)
        assessed = assessed + (tonumber(row.assessedValue) or 0)
        collateral = collateral + (tonumber(row.collateralValue) or 0)
        if not row.titled then pending = pending + 1 end
    end
    if #list == 0 then
        self:setControlText("landSummary", FFR_L10n.t("ffr_land_none"))
    else
        self:setControlText("landSummary", FFR_L10n.t("ffr_land_summary",
            #list == 1 and FFR_L10n.t("ffr_land_parcel_one") or FFR_L10n.t("ffr_land_parcel_many", #list), FFR_L10n.formatArea(area), FFR_L10n.formatArea(arable),
            self:formatMoney(book), self:formatMoney(assessed), self:formatMoney(collateral)))
    end
    local first = (self.landPage - 1) * rows
    for r = 1, rows do
        local row = list[first + r]
        local cells = {"", "", "", "", "", "", "", ""}
        if row ~= nil then
            local arableHa = tonumber(row.arableHa) or -1
            cells = {
                FFR_L10n.t("ffr_common_farmland", row.farmlandId),
                FFR_L10n.formatArea(row.areaInHa),
                arableHa >= 0 and FFR_L10n.formatArea(arableHa) or "-",
                registry:getUseText(row),
                self:formatMoney(row.bookValue),
                row.titled and self:formatMoney(row.assessedValue) or "-",
                row.titled and self:formatMoney(row.collateralValue) or "-",
                FFR_L10n.t(row.rentedOut and "ffr_land_rented_out" or (row.titled and "ffr_land_titled" or "ffr_land_awaiting"))
            }
        end
        for c = 1, #cells do self:setControlText(string.format("landRow%dCol%d", r, c), cells[c]) end
        self:setControlColor(string.format("landRow%dCol8", r),
            (row ~= nil and not row.titled) and FFR_DashboardFrame.UNTITLED_COLOR or FFR_DashboardFrame.TITLED_COLOR)
        self:setControlVisible("landRowHighlight" .. r, row ~= nil and first + r == self.landSelected)
    end
    -- Result of a CHANGE TITLE (shown here instead of a dialog over the menu).
    if registry ~= nil and registry.changeMessage ~= nil then
        self.landMessage, registry.changeMessage = registry.changeMessage, nil
    end
    if self.landMessage ~= nil then
        self:setControlText("landPage", self.landMessage)
        return
    end
    local pageText = pages > 1 and FFR_L10n.t("ffr_land_page", self.landPage, pages) or ""
    if pending > 0 then
        local note = pending == 1 and FFR_L10n.t("ffr_land_pending_one") or FFR_L10n.t("ffr_land_pending_many", pending)
        pageText = pageText ~= "" and (note .. "   " .. pageText) or note
    end
    self:setControlText("landPage", pageText)
end

function FFR_DashboardFrame:getLandTitles()
    local registry = g_FFRLandRegistryManager
    return registry ~= nil and registry:getTitles(g_FFR ~= nil and g_FFR.localFarmId or nil) or {}
end

function FFR_DashboardFrame:changeLandSelection(direction)
    local count = #self:getLandTitles()
    if count == 0 then return end
    self.landSelected = (self.landSelected or 1) + direction
    if self.landSelected < 1 then self.landSelected = count elseif self.landSelected > count then self.landSelected = 1 end
    self.landMessage = nil
    self:refreshLandPage()
end

-- Opens the title window for the selected parcel; the new use applies from now on.
function FFR_DashboardFrame:onClickLandChangeTitle()
    local row = self:getLandTitles()[self.landSelected or 1]
    if row == nil or g_FFRLandRegistryManager == nil then return end
    local ok, message = g_FFRLandRegistryManager:requestChange(row.farmlandId)
    self.landMessage = (not ok) and message or nil
    self:refreshLandPage()
end

function FFR_DashboardFrame:onClickLandView()
    local nextView = {TITLES = "RENTALS", RENTALS = "AUCTIONS", AUCTIONS = "TITLES"}
    self.landView = nextView[self.landView or "TITLES"] or "TITLES"
    self.landMessage, self.rentMessage = nil, nil
    self:refreshLandPage()
end

--------------------------------------------------
-- Land page, rentals view (FFR_LandRentManager):
-- a new rental (type, parcel, term) and the farm's
-- rental contracts (RENEW in the decision month,
-- END EARLY any time).
--------------------------------------------------

FFR_DashboardFrame.RENT_ROWS = 5

function FFR_DashboardFrame:getRentParcels()
    local m = FFR_LandRentManager
    if m == nil then return {} end
    if (self.rentKind or "IN") == "IN" then return m.getRentableParcels() end
    return m.getRentOutParcels(g_FFR ~= nil and g_FFR.localFarmId or nil)
end

-- The local farm's contracts: open ones first, newest first.
function FFR_DashboardFrame:getRentContracts()
    local state = g_FFR ~= nil and g_FFR:getFarmState(g_FFR.localFarmId) or nil
    local list = {}
    for _, contract in ipairs(state ~= nil and state.landRentals or {}) do table.insert(list, contract) end
    local open = FFR_LandRentManager ~= nil and FFR_LandRentManager.isOpen or function() return true end
    table.sort(list, function(a, b)
        if open(a) ~= open(b) then return open(a) end
        return (tonumber(a.id) or 0) > (tonumber(b.id) or 0)
    end)
    return list
end

function FFR_DashboardFrame:refreshRentView()
    local m = FFR_LandRentManager
    if m == nil then return end
    self.rentKind = self.rentKind or "IN"
    self.rentTermIndex = math.max(1, math.min(self.rentTermIndex or 1, #m.TERMS))
    local parcels = self:getRentParcels()
    self.rentParcelIndex = math.max(1, math.min(self.rentParcelIndex or 1, math.max(1, #parcels)))
    local parcelId = parcels[self.rentParcelIndex]
    local term = m.TERMS[self.rentTermIndex]
    self:setControlText("rentKindValue", FFR_L10n.t(self.rentKind == "IN" and "ffr_rent_kind_in" or "ffr_rent_kind_out"))
    self:setControlText("rentTermValue", FFR_L10n.t(term == 12 and "ffr_rent_term_one" or "ffr_rent_term_many", term / 12))
    if parcelId ~= nil then
        local farmland = FFR_LandMarketManager.getFarmland(parcelId)
        self:setControlText("rentParcelValue", FFR_L10n.t("ffr_rent_parcel", parcelId,
            FFR_L10n.formatArea(farmland ~= nil and farmland.areaInHa or 0, 0)))
        self:setControlText("rentQuote", FFR_L10n.t("ffr_rent_quote", self:formatMoney(FFR_LandMarketManager.getMarketValue(parcelId)),
            self:formatMoney(m.getMonthlyRent(parcelId))))
    else
        self:setControlText("rentParcelValue", FFR_L10n.t("ffr_common_none"))
        self:setControlText("rentQuote", FFR_L10n.t(self.rentKind == "IN" and "ffr_rent_none_in" or "ffr_rent_none_out"))
    end
    self:setControlText("rentNote", FFR_L10n.t(self.rentKind == "IN" and "ffr_rent_note_in" or "ffr_rent_note_out"))

    local list = self:getRentContracts()
    local rows = FFR_DashboardFrame.RENT_ROWS
    self.rentSelected = math.max(1, math.min(self.rentSelected or 1, math.max(1, #list)))
    local first = math.floor((self.rentSelected - 1) / rows) * rows + 1
    for r = 1, rows do
        local index = first + r - 1
        local c = list[index]
        local cells = {"", "", "", "", "", "", ""}
        if c ~= nil then
            local lastSerial = (tonumber(c.signedSerial) or 0) + c.term - 1
            local lastYear = math.floor((lastSerial - 1) / 12)
            cells = {
                FFR_L10n.t("ffr_common_farmland", c.farmlandId),
                FFR_L10n.t(c.kind == "IN" and "ffr_rent_type_in" or "ffr_rent_type_out"),
                FFR_L10n.t(c.term == 12 and "ffr_rent_term_one" or "ffr_rent_term_many", c.term / 12),
                self:formatMoney(c.monthlyRent),
                string.format("%d / %d", math.min(c.paidMonths, c.term), c.term),
                lastSerial > 0 and FFR_L10n.dateShort(lastSerial - lastYear * 12, lastYear) or "-",
                FFR_L10n.t("ffr_rent_status_" .. string.lower(tostring(c.status)))
            }
        end
        for col = 1, #cells do self:setControlText(string.format("rentRow%dCol%d", r, col), cells[col]) end
        self:setControlColor(string.format("rentRow%dCol7", r), (c ~= nil and (c.status == "ENDING" or c.status == "HOLD"))
            and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR)
        self:setControlVisible("rentRowHighlight" .. r, c ~= nil and index == self.rentSelected)
    end
    self:setControlText("rentPage", #list > rows and FFR_L10n.t("ffr_rent_paging", first, math.min(#list, first + rows - 1), #list)
        or (#list == 0 and FFR_L10n.t("ffr_rent_no_contracts") or ""))
    self:setControlText("rentMessage", self.rentMessage or "")
end

function FFR_DashboardFrame:changeRentSelection(direction)
    local count = #self:getRentContracts()
    if count == 0 then return end
    self.rentSelected = (self.rentSelected or 1) + direction
    if self.rentSelected < 1 then self.rentSelected = count elseif self.rentSelected > count then self.rentSelected = 1 end
    self.rentMessage = nil
    self:refreshRentView()
end

function FFR_DashboardFrame:stepRentDraft(field, direction)
    if field == "kind" then
        self.rentKind = (self.rentKind or "IN") == "IN" and "OUT" or "IN"
        self.rentParcelIndex = 1
    elseif field == "parcel" then
        local count = #self:getRentParcels()
        if count > 0 then
            self.rentParcelIndex = ((self.rentParcelIndex or 1) - 1 + direction) % count + 1
        end
    else
        local count = #FFR_LandRentManager.TERMS
        self.rentTermIndex = ((self.rentTermIndex or 1) - 1 + direction) % count + 1
    end
    self.rentMessage = nil
    self:refreshRentView()
end
function FFR_DashboardFrame:onClickRentKindPrev() self:stepRentDraft("kind", -1) end
function FFR_DashboardFrame:onClickRentKindNext() self:stepRentDraft("kind", 1) end
function FFR_DashboardFrame:onClickRentParcelPrev() self:stepRentDraft("parcel", -1) end
function FFR_DashboardFrame:onClickRentParcelNext() self:stepRentDraft("parcel", 1) end
function FFR_DashboardFrame:onClickRentTermPrev() self:stepRentDraft("term", -1) end
function FFR_DashboardFrame:onClickRentTermNext() self:stepRentDraft("term", 1) end

function FFR_DashboardFrame:onClickRentSign()
    local parcelId = self:getRentParcels()[self.rentParcelIndex or 1]
    if parcelId == nil or FFR_LandRentManager == nil then return end
    local action = (self.rentKind or "IN") == "IN" and "LAND_RENT_IN" or "LAND_RENT_OUT"
    self:performAction(action, {farmlandId = parcelId, term = FFR_LandRentManager.TERMS[self.rentTermIndex or 1]}, function(message)
        self.rentMessage = message
        self:refreshRentView()
    end)
end

function FFR_DashboardFrame:runRentAction(action)
    local c = self:getRentContracts()[self.rentSelected or 1]
    if c == nil then return end
    self:performAction(action, {rentalId = c.id, term = c.term}, function(message)
        self.rentMessage = message
        self:refreshRentView()
    end)
end
function FFR_DashboardFrame:onClickRentRenew() self:runRentAction("LAND_RENT_RENEW") end
function FFR_DashboardFrame:onClickRentEnd() self:runRentAction("LAND_RENT_END") end

--------------------------------------------------
-- Land page, auctions view (FFR_LandAuctionManager)
--------------------------------------------------

function FFR_DashboardFrame:refreshAuctionView()
    local m = FFR_LandAuctionManager
    if m == nil then return end
    local a = m.auction
    local localFarm = g_FFR ~= nil and g_FFR.localFarmId or nil
    local function dash(id) self:setControlText(id, "-") end
    if not m.isEnabled() then
        self:setControlText("auctionStatus", FFR_L10n.t("ffr_auction_off_other_mod"))
    elseif a == nil then
        self:setControlText("auctionStatus", FFR_L10n.t("ffr_auction_none"))
    else
        self:setControlText("auctionStatus", FFR_L10n.t("ffr_auction_running", a.farmlandId))
    end
    if a ~= nil then
        local farmland = FFR_LandMarketManager.getFarmland(a.farmlandId)
        self:setControlText("auctionParcel", FFR_L10n.t("ffr_rent_parcel", a.farmlandId, FFR_L10n.formatArea(farmland ~= nil and farmland.areaInHa or 0, 0)))
        self:setControlText("auctionValue", self:formatMoney(a.value))
        self:setControlText("auctionOpen", self:formatMoney(a.openPrice))
        self:setControlText("auctionPrice", (tonumber(a.bidCount) or 0) > 0 and self:formatMoney(a.price) or FFR_L10n.t("ffr_auction_no_bids"))
        local high = FFR_L10n.t("ffr_auction_high_none")
        if a.highFarmId == localFarm then high = FFR_L10n.t("ffr_auction_high_you")
        elseif a.highFarmId == 0 then high = FFR_L10n.t("ffr_auction_high_npc")
        elseif (tonumber(a.highFarmId) or -1) > 0 then high = FFR_L10n.t("ffr_auction_high_farm", a.highFarmId) end
        self:setControlText("auctionHigh", high)
        self:setControlText("auctionNext", a.highFarmId == localFarm and "-" or self:formatMoney(m.getNextBid(a)))
        self:setControlText("auctionTime", FFR_L10n.t("ffr_auction_hours", math.max(0, math.ceil(a.endHour - m.getHour()))))
    else
        for _, id in ipairs({"auctionParcel", "auctionValue", "auctionOpen", "auctionPrice", "auctionHigh", "auctionNext", "auctionTime"}) do dash(id) end
    end
    if FFR_LandMarketManager ~= nil then self:setControlText("auctionMarket", FFR_LandMarketManager.getSummaryText()) end
    for r = 1, 5 do
        local h = m.history[r]
        local cells = {"", "", "", ""}
        if h ~= nil then
            local winner = FFR_L10n.t("ffr_auction_winner_none")
            if h.winnerFarmId == 0 then winner = FFR_L10n.t("ffr_auction_high_npc")
            elseif h.winnerFarmId == localFarm then winner = FFR_L10n.t("ffr_auction_high_you")
            elseif (tonumber(h.winnerFarmId) or -1) > 0 then winner = FFR_L10n.t("ffr_auction_high_farm", h.winnerFarmId) end
            local serial = tonumber(h.serial) or 0
            local year = math.floor((serial - 1) / 12)
            cells = {FFR_L10n.t("ffr_common_farmland", h.farmlandId), self:formatMoney(h.price), winner,
                serial > 0 and FFR_L10n.dateShort(serial - year * 12, year) or "-"}
        end
        for c = 1, 4 do self:setControlText(string.format("auctionRow%dCol%d", r, c), cells[c]) end
    end
    self:setControlText("auctionNote", #m.history == 0 and FFR_L10n.t("ffr_auction_no_history") or "")
end

--------------------------------------------------
-- Insurance page: the local farm's crop policy,
-- weather damage per parcel and claims
-- (FFR_CropDamageManager, FFR_CropInsuranceManager)
--------------------------------------------------

FFR_DashboardFrame.INSURE_ROWS = 6

function FFR_DashboardFrame:getInsuranceState()
    return (g_FFR ~= nil and g_FFR.getFarmState ~= nil) and g_FFR:getFarmState(g_FFR.localFarmId) or nil
end

function FFR_DashboardFrame:refreshInsurancePage()
    local state = self:getInsuranceState()
    if state == nil or FFR_CropInsuranceManager == nil then return end
    local ins = FFR_CropInsuranceManager
    local map = self.insureView == "MAP"
    local herd = self.insureView == "LIVESTOCK"
    self:setControlVisible("insureTableGroup", not map and not herd)
    self:setControlVisible("insureMapGroup", map)
    self:setControlVisible("insureHerdGroup", herd)
    if herd then
        self:refreshHerdView(state)
        return
    end
    if map then
        local rows = ins.getDamageRows(state)
        self:refreshCropMap(state, rows)
        self:refreshCropMapDetails(state, rows, ins.getClaimByParcel(state))
        return
    end
    local policy = ins.getPolicy(state)
    local _, year = ins.getCalendar()
    self:refreshCropPolicy(state)
    self:setControlText("insureClaimsPaid", self:formatMoney(state.insuranceManager.totalClaimsPaid))
    local signupSeason, signupYear = ins.getSignup()
    if signupSeason == "FALL" then
        self:setControlText("insureSignup", FFR_L10n.t("ffr_insure_signup_fall", signupYear))
    else
        self:setControlText("insureSignup", FFR_L10n.t(signupSeason == "SPRING" and "ffr_insure_signup_open" or "ffr_insure_signup_closed"))
    end

    -- Damage rows and totals.
    local rows = ins.getDamageRows(state)
    local claims = ins.getClaimByParcel(state)
    local damaged, loss, covered = 0, 0, 0
    for _, row in ipairs(rows) do
        local total = tonumber(row.total) or 0
        if total > 0 then damaged = damaged + 1 end
        loss = loss + (tonumber(row.expectedValue) or 0) * total
        local coverage = ins.getRecordCoverage(state, row)
        if coverage ~= nil then
            covered = covered + (tonumber(row.expectedValue) or 0) * math.max(0, total - (1 - coverage))
        end
    end
    self:setControlText("insureWeather", FFR_CropDamageManager ~= nil and FFR_CropDamageManager.getWeatherText() or "-")
    self:setControlText("insureParcels", tostring(#rows))
    self:setControlText("insureDamaged", tostring(damaged))
    self:setControlText("insureLoss", self:formatMoney(loss))
    self:setControlText("insureCovered", self:formatMoney(covered))

    local count = FFR_DashboardFrame.INSURE_ROWS
    self.insureSelected = math.max(1, math.min(self.insureSelected or 1, math.max(1, #rows)))
    local first = math.floor((self.insureSelected - 1) / count) * count + 1
    for r = 1, count do
        local index = first + r - 1
        local row = rows[index]
        local cells = {"", "", "", "", "", "", "", "", ""}
        if row ~= nil then
            local claim = claims[row.farmlandId]
            local claimText = "-"
            if claim ~= nil then
                claimText = claim.status == "PAID" and FFR_L10n.t("ffr_contract_paid", self:formatMoney(claim.payout))
                    or FFR_L10n.t(claim.status == "DENIED" and "ffr_insure_claim_denied" or "ffr_insure_claim_due")
            elseif row.claimed then
                claimText = FFR_L10n.t("ffr_insure_claim_filed")
            elseif ins.getRecordCoverage(state, row) == nil then
                claimText = FFR_L10n.t("ffr_insure_not_covered")
            end
            local pct = function(v) return string.format("%d%%", math.floor((tonumber(v) or 0) * 100 + 0.5)) end
            cells = {
                FFR_L10n.t("ffr_common_farmland", row.farmlandId), self:formatCommodityName(row.fruitName),
                FFR_L10n.t(row.harvesting and "ffr_insure_harvesting" or row.ready and "ffr_insure_ready" or "ffr_insure_growing"), pct(row.hail), pct(row.rain), pct(row.total),
                self:formatMoney(row.expectedValue), self:formatMoney((tonumber(row.expectedValue) or 0) * (tonumber(row.total) or 0)),
                claimText
            }
        end
        for c = 1, #cells do self:setControlText(string.format("insureRow%dCol%d", r, c), cells[c]) end
        local total = row ~= nil and (tonumber(row.total) or 0) or 0
        self:setControlColor(string.format("insureRow%dCol6", r), total >= 0.20 and FFR_DashboardFrame.PRICE_DOWN_COLOR
            or total > 0 and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR)
        self:setControlVisible("insureRowHighlight" .. r, row ~= nil and index == self.insureSelected)
    end
    if #rows == 0 then
        self:setControlText("insurePage", FFR_L10n.t("ffr_insure_no_crops"))
    else
        self:setControlText("insurePage", FFR_L10n.t("ffr_insure_paging", first, math.min(#rows, first + count - 1), #rows))
    end
    self:setControlText("insureMessage", self.insureMessage or "")
end

--------------------------------------------------
-- Crop-health map (Insurance tab, map view)
--
-- Each of the farm's fields is a block at its real
-- position (north up), sized by its area and
-- coloured by its parcel's damage. Clicking a block
-- selects it. Drawn after the GUI like the price
-- chart; labels use the engine's renderText.
--------------------------------------------------

FFR_DashboardFrame.MAP_COLORS = {
    healthy = FFR_DashboardFrame.FILLS.FFR_LegendHealthy,
    light = FFR_DashboardFrame.FILLS.FFR_LegendLight,
    heavy = FFR_DashboardFrame.FILLS.FFR_LegendHeavy,
    empty = FFR_DashboardFrame.FILLS.FFR_LegendEmpty,
    selected = {0.92, 0.93, 0.92, 1}
}
FFR_DashboardFrame.MAP_MIN_BLOCK_PX = 12

-- Crops (table) -> crop-health map -> livestock -> crops.
function FFR_DashboardFrame:onClickInsureView()
    local nextView = {TABLE = "MAP", MAP = "LIVESTOCK", LIVESTOCK = "TABLE"}
    self.insureView = nextView[self.insureView or "TABLE"] or "MAP"
    self.insureMessage = nil
    self:refreshInsurancePage()
end

--------------------------------------------------
-- Insurance tab, livestock view (FFR_HerdRiskManager,
-- FFR_LivestockInsuranceManager)
--------------------------------------------------

function FFR_DashboardFrame:getHerdRows(state)
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return state.herdRows or {} end
    return FFR_HerdRiskManager ~= nil and FFR_HerdRiskManager.getBarnRows(state.farmId) or {}
end

function FFR_DashboardFrame:refreshHerdView(state)
    local li = FFR_LivestockInsuranceManager
    if li == nil then return end
    local rows = self:getHerdRows(state)
    local head, value, healthSum, riskMax = 0, 0, 0, 0
    for _, row in ipairs(rows) do
        head, value = head + (tonumber(row.head) or 0), value + (tonumber(row.value) or 0)
        healthSum = healthSum + (tonumber(row.health) or 0) * (tonumber(row.head) or 0)
        riskMax = math.max(riskMax, tonumber(row.risk) or 0)
    end
    local scale = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("insurance")) or 1) or 1
    local premium = value * li.PREMIUM_RATE * scale
    local policy = li.getPolicy(state)
    if policy ~= nil then
        local covered = li.isCovered(policy)
        self:setControlText("herdPolicyStatus", FFR_L10n.t(covered and "ffr_herd_insured" or "ffr_herd_waiting"))
        self:setControlColor("herdPolicyStatus", covered and FFR_DashboardFrame.PRICE_UP_COLOR or FFR_DashboardFrame.STATUS_DUE_COLOR)
        self:setControlText("herdPremium", self:formatMoney(policy.premium))
    else
        self:setControlText("herdPolicyStatus", FFR_L10n.t("ffr_herd_not_insured"))
        self:setControlColor("herdPolicyStatus", FFR_DashboardFrame.PRICE_DOWN_COLOR)
        self:setControlText("herdPremium", FFR_L10n.t("ffr_insure_quote", self:formatMoney(premium)))
    end
    self:setControlText("herdHead", tostring(head))
    self:setControlText("herdValue", self:formatMoney(value))
    self:setControlText("herdCover", FFR_L10n.t("ffr_herd_cover", math.floor(li.COVERAGE * 100 + 0.5)))
    local paid = 0
    for _, claim in ipairs(state.herdClaims or {}) do paid = paid + (tonumber(claim.payout) or 0) end
    self:setControlText("herdClaimsPaid", self:formatMoney(paid))
    self:setControlText("herdBarns", tostring(#rows))
    self:setControlText("herdHealth", head > 0 and string.format("%d%%", math.floor(healthSum / head * 100 + 0.5)) or "-")
    self:setControlText("herdRisk", #rows > 0 and FFR_L10n.t("ffr_herd_risk_max", riskMax * 100) or "-")
    local events = state.herdEvents or {}
    local lost = 0
    for _, e in ipairs(events) do lost = lost + (tonumber(e.dead) or 0) end
    self:setControlText("herdOutbreaks", tostring(#events))
    self:setControlText("herdLost", tostring(lost))
    local last = events[#events]
    self:setControlText("herdLast", last ~= nil and FFR_L10n.t("ffr_herd_last", FFR_HerdRiskManager.getDiseaseName(last.disease),
        tostring(last.barn), tonumber(last.dead) or 0, FFR_HerdRiskManager.getAnimalName(last.animals)) or FFR_L10n.t("ffr_herd_no_outbreaks"))
    local count = 6
    for r = 1, count do
        local row = rows[r]
        local cells = {"", "", "", "", "", "", ""}
        if row ~= nil then
            cells = {row.name, FFR_HerdRiskManager.getAnimalName(row.animals), tostring(row.head), self:formatMoney(row.value),
                string.format("%d%%", math.floor((tonumber(row.health) or 0) * 100 + 0.5)),
                string.format("%d%%", math.floor((tonumber(row.crowding) or 0) * 100 + 0.5)),
                string.format("%.1f%%", (tonumber(row.risk) or 0) * 100)}
        end
        for c = 1, #cells do self:setControlText(string.format("herdRow%dCol%d", r, c), cells[c]) end
        local risk = row ~= nil and (tonumber(row.risk) or 0) or 0
        self:setControlColor(string.format("herdRow%dCol7", r), risk >= 0.06 and FFR_DashboardFrame.PRICE_DOWN_COLOR
            or risk > 0.035 and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR)
    end
    self:setControlText("herdPage", #rows == 0 and FFR_L10n.t("ffr_herd_no_animals") or (#rows > count and FFR_L10n.t("ffr_herd_showing", count, #rows) or ""))
    self:setControlText("herdMessage", self.insureMessage or "")
end

function FFR_DashboardFrame:onClickBuyHerdPolicy()
    self:performAction("BUY_HERD_POLICY", nil, function(message)
        self.insureMessage = message
        self:refreshInsurancePage()
    end)
end

function FFR_DashboardFrame:getMapColor(row)
    if row == nil then return FFR_DashboardFrame.MAP_COLORS.empty end
    local total = tonumber(row.total) or 0
    if total >= 0.20 then return FFR_DashboardFrame.MAP_COLORS.heavy end
    if total > 0.005 then return FFR_DashboardFrame.MAP_COLORS.light end
    return FFR_DashboardFrame.MAP_COLORS.healthy
end

-- Fields with their parcel's damage row, plus the world area to show.
function FFR_DashboardFrame:refreshCropMap(state, rows)
    local byParcel = {}
    for index, row in ipairs(rows) do byParcel[row.farmlandId] = {row = row, index = index} end
    local fields = FFR_CropDamageManager ~= nil and FFR_CropDamageManager.getFarmMapFields(state.farmId) or {}
    local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
    for _, field in ipairs(fields) do
        local entry = byParcel[field.farmlandId]
        field.row = entry ~= nil and entry.row or nil
        field.rowIndex = entry ~= nil and entry.index or nil
        field.size = math.sqrt(math.max(0.1, field.areaHa) * 10000)
        minX, maxX = math.min(minX, field.x - field.size / 2), math.max(maxX, field.x + field.size / 2)
        minZ, maxZ = math.min(minZ, field.z - field.size / 2), math.max(maxZ, field.z + field.size / 2)
    end
    self.cropMapFields = fields
    if #fields == 0 then
        self.cropMapBounds = nil
        return
    end
    -- At least 15 % of the map across, with a margin, so a small farm is not a single blob.
    local mapSize = FFR_CropDamageManager.getMapSize()
    local range = math.max(maxX - minX, maxZ - minZ, mapSize * 0.15) * 1.15
    self.cropMapBounds = {cx = (minX + maxX) / 2, cz = (minZ + maxZ) / 2, range = range}
end

function FFR_DashboardFrame:drawCropMap()
    if self.currentSection ~= FFR_DashboardFrame.TAB.INSURANCE or self.insureView ~= "MAP" then return end
    local area = self.controls.insureMapArea
    local bounds = self.cropMapBounds
    self.cropMapBlocks = {}
    if area == nil or area.absPosition == nil or bounds == nil then return end
    if area.getIsVisible ~= nil and not area:getIsVisible() then return end
    local x0, y0, w, h = area.absPosition[1], area.absPosition[2], area.absSize[1], area.absSize[2]
    local screenW, screenH = tonumber(g_screenWidth) or 1920, tonumber(g_screenHeight) or 1080
    -- Square in pixels: metres -> pixels, the same both ways.
    local pixels = math.min(w * screenW, h * screenH)
    local perMetre = pixels / bounds.range
    local cx, cy = x0 + w / 2, y0 + h / 2
    for _, field in ipairs(self.cropMapFields or {}) do
        local sizePx = math.max(FFR_DashboardFrame.MAP_MIN_BLOCK_PX, field.size * perMetre)
        local bw, bh = sizePx / screenW, sizePx / screenH
        local bx = cx + (field.x - bounds.cx) * perMetre / screenW - bw / 2
        -- World z grows southwards; the map shows north at the top.
        local by = cy - (field.z - bounds.cz) * perMetre / screenH - bh / 2
        local selected = field.farmlandId == self.insureMapFarmland
        if selected then
            local pad = 3
            self:drawRect(bx - pad / screenW, by - pad / screenH, bw + 2 * pad / screenW, bh + 2 * pad / screenH, FFR_DashboardFrame.MAP_COLORS.selected)
        end
        self:drawRect(bx, by, bw, bh, self:getMapColor(field.row))
        table.insert(self.cropMapBlocks, {x = bx, y = by, w = bw, h = bh, field = field})
    end
    self:drawCropMapLabels()
end

-- Parcel number and damage % on each block (renderText, centred).
function FFR_DashboardFrame:drawCropMapLabels()
    if renderText == nil then return end
    local labelled = {}
    if setTextAlignment ~= nil and RenderText ~= nil then setTextAlignment(RenderText.ALIGN_CENTER) end
    if setTextBold ~= nil then setTextBold(true) end
    for _, block in ipairs(self.cropMapBlocks or {}) do
        local id = block.field.farmlandId
        -- One label per parcel, on its first field.
        if not labelled[id] and block.w * (tonumber(g_screenWidth) or 1920) >= 22 then
            labelled[id] = true
            local cx, cy = block.x + block.w / 2, block.y + block.h / 2
            if setTextColor ~= nil then setTextColor(0.02, 0.03, 0.02, 1) end
            renderText(cx, cy + 0.002, 0.011, tostring(id))
            local row = block.field.row
            if row ~= nil and (tonumber(row.total) or 0) > 0.005 then
                renderText(cx, cy - 0.011, 0.010, string.format("%d%%", math.floor(row.total * 100 + 0.5)))
            end
        end
    end
    if setTextAlignment ~= nil and RenderText ~= nil then setTextAlignment(RenderText.ALIGN_LEFT) end
    if setTextBold ~= nil then setTextBold(false) end
    if setTextColor ~= nil then setTextColor(1, 1, 1, 1) end
end

-- Mouse: a click on a block selects that field.
function FFR_DashboardFrame:handleCropMapClick(posX, posY)
    for _, block in ipairs(self.cropMapBlocks or {}) do
        if posX >= block.x and posX <= block.x + block.w and posY >= block.y and posY <= block.y + block.h then
            self.insureMapFarmland = block.field.farmlandId
            if block.field.rowIndex ~= nil then self.insureSelected = block.field.rowIndex end
            self.insureMessage = nil
            self:refreshInsurancePage()
            return true
        end
    end
    return false
end

function FFR_DashboardFrame:refreshCropMapDetails(state, rows, claims)
    local fields = self.cropMapFields or {}
    if self.insureMapFarmland == nil and fields[1] ~= nil then self.insureMapFarmland = fields[1].farmlandId end
    local row = nil
    for _, r in ipairs(rows) do
        if r.farmlandId == self.insureMapFarmland then row = r end
    end
    local pct = function(v) return string.format("%d%%", math.floor((tonumber(v) or 0) * 100 + 0.5)) end
    self:setControlText("insureMapField", self.insureMapFarmland ~= nil and FFR_L10n.t("ffr_common_farmland", self.insureMapFarmland) or "-")
    self:setControlText("insureMapCrop", row ~= nil and self:formatCommodityName(row.fruitName) or FFR_L10n.t("ffr_insure_no_crop"))
    self:setControlText("insureMapStage", row == nil and "-" or FFR_L10n.t(row.harvesting and "ffr_insure_harvesting" or row.ready and "ffr_insure_ready" or "ffr_insure_growing"))
    self:setControlText("insureMapHail", row ~= nil and pct(row.hail) or "-")
    self:setControlText("insureMapRain", row ~= nil and pct(row.rain) or "-")
    self:setControlText("insureMapTotal", row ~= nil and pct(row.total) or "-")
    self:setControlText("insureMapValue", row ~= nil and self:formatMoney(row.expectedValue) or "-")
    self:setControlText("insureMapLoss", row ~= nil and self:formatMoney((tonumber(row.expectedValue) or 0) * (tonumber(row.total) or 0)) or "-")
    local claim = row ~= nil and claims[row.farmlandId] or nil
    self:setControlText("insureMapClaim", claim == nil and FFR_L10n.t((row ~= nil and row.claimed) and "ffr_insure_claim_filed" or "ffr_common_none")
        or claim.status == "PAID" and FFR_L10n.t("ffr_contract_paid", self:formatMoney(claim.payout))
        or FFR_L10n.t(claim.status == "DENIED" and "ffr_insure_claim_denied" or "ffr_insure_claim_due"))
    local damaged = 0
    for _, r in ipairs(rows) do if (tonumber(r.total) or 0) > 0.005 then damaged = damaged + 1 end end
    local weather = FFR_CropDamageManager ~= nil and FFR_CropDamageManager.getWeatherText() or "-"
    self:setControlText("insureMapStatus", #fields == 0 and FFR_L10n.t("ffr_insure_no_fields")
        or FFR_L10n.t("ffr_insure_map_status", #fields == 1 and FFR_L10n.t("ffr_insure_field_one") or FFR_L10n.t("ffr_insure_field_many", #fields), damaged, weather))
    self:setControlText("insureMapMessage", self.insureMessage or "")
end

function FFR_DashboardFrame:changeInsuranceSelection(direction)
    -- Map view: UP / DOWN steps through the farm's parcels.
    if self.insureView == "MAP" then
        local ids, seen = {}, {}
        for _, field in ipairs(self.cropMapFields or {}) do
            if not seen[field.farmlandId] then seen[field.farmlandId] = true; table.insert(ids, field.farmlandId) end
        end
        table.sort(ids)
        if #ids == 0 then return end
        local index = 1
        for i, id in ipairs(ids) do if id == self.insureMapFarmland then index = i end end
        index = index + direction
        if index < 1 then index = #ids elseif index > #ids then index = 1 end
        self.insureMapFarmland = ids[index]
        self.insureMessage = nil
        self:refreshInsurancePage()
        return
    end
    local state = self:getInsuranceState()
    local rows = (state ~= nil and FFR_CropInsuranceManager ~= nil) and FFR_CropInsuranceManager.getDamageRows(state) or {}
    if #rows == 0 then return end
    self.insureSelected = (self.insureSelected or 1) + direction
    if self.insureSelected < 1 then self.insureSelected = #rows elseif self.insureSelected > #rows then self.insureSelected = 1 end
    self.insureMessage = nil
    self:refreshInsurancePage()
end

-- Crops for the policy picker: crops the farm has standing first, then the rest (A-Z).
function FFR_DashboardFrame:getInsureCrops(state)
    local ins = FFR_CropInsuranceManager
    local planted, seen, list = {}, {}, {}
    for _, row in ipairs(ins.getDamageRows(state)) do planted[row.fruitName] = true end
    for _, pass in ipairs({true, false}) do
        for _, name in ipairs(ins.getInsurableCrops()) do
            if (planted[name] == true) == pass and not seen[name] then seen[name] = true; table.insert(list, name) end
        end
    end
    return list
end

function FFR_DashboardFrame:getSelectedInsureCrop(state)
    local list = self:getInsureCrops(state)
    if #list == 0 then return nil, list end
    -- Keep the same crop selected when planting reorders the list.
    for i, name in ipairs(list) do if name == self.insureCropName then self.insureCropIndex = i end end
    self.insureCropIndex = math.max(1, math.min(self.insureCropIndex or 1, #list))
    self.insureCropName = list[self.insureCropIndex]
    return list[self.insureCropIndex], list
end

-- The crop picker edits the policy of the open sign-up (spring: this year's
-- crops; fall: crops sown now for next year's harvest); outside sign-up it
-- shows this year's policy.
function FFR_DashboardFrame:refreshCropPolicy(state)
    local ins = FFR_CropInsuranceManager
    local season, signupYear = ins.getSignup()
    local _, currentYear = ins.getCalendar()
    local year = signupYear or currentYear or 0
    local policy = ins.getPolicy(state, year)
    local crop = self:getSelectedInsureCrop(state)
    -- Coverage shown follows the selected crop's policy entry when it has one.
    local current = ins.getCropCoverage(policy, crop, season)
    if self.insureCropShown ~= crop then
        self.insureCropShown = crop
        if current ~= nil then self.insureCoverage = current end
    end
    self.insureCoverage = self.insureCoverage or 0.75
    local insuredCount = policy ~= nil and #(policy.crops or {}) or 0
    if policy ~= nil and policy.allCrops then
        self:setControlText("insurePolicyStatus", FFR_L10n.t("ffr_insure_insured", policy.year, math.floor((tonumber(policy.coverage) or 0) * 100 + 0.5)))
        self:setControlColor("insurePolicyStatus", FFR_DashboardFrame.PRICE_UP_COLOR)
    elseif insuredCount > 0 then
        self:setControlText("insurePolicyStatus", insuredCount == 1 and FFR_L10n.t("ffr_insure_crops_one", year)
            or FFR_L10n.t("ffr_insure_crops_many", insuredCount, year))
        self:setControlColor("insurePolicyStatus", FFR_DashboardFrame.PRICE_UP_COLOR)
    else
        self:setControlText("insurePolicyStatus", FFR_L10n.t("ffr_insure_not_insured", year))
        self:setControlColor("insurePolicyStatus", FFR_DashboardFrame.PRICE_DOWN_COLOR)
    end
    local rate = ins.getRate(self.insureCoverage)
    self:setControlText("insureCropValue", crop ~= nil and self:formatCommodityName(crop) or "-")
    self:setControlText("insureCoverageValue", string.format("%d%%", math.floor(self.insureCoverage * 100 + 0.5)))
    self:setControlText("insureQuote", string.format("%s / %s", self:formatMoney(FFR_L10n.perArea(rate)), FFR_L10n.getPerAreaUnit()))
    -- The selected crop: insured or not, its plantings for this policy, billed premium or estimate.
    local status = ""
    if crop ~= nil then
        local planted = ins.getPlantedAcres(state, crop, year, season)
        local area = FFR_L10n.formatArea(planted / FFR_L10n.ACRES_PER_HA, 0)
        if current ~= nil then
            local _, billed = ins.getBilledTotals(policy, crop, season)
            status = FFR_L10n.t("ffr_insure_crop_status_on", math.floor(current * 100 + 0.5), area, self:formatMoney(billed))
        else
            status = FFR_L10n.t("ffr_insure_crop_status_off", area, self:formatMoney(planted * rate))
        end
    end
    self:setControlText("insureCropStatus", status)
    local names = {}
    for _, entry in ipairs(policy ~= nil and policy.crops or {}) do
        local label = string.format("%s %d%%", self:formatCommodityName(entry.fruitName), math.floor((tonumber(entry.coverage) or 0) * 100 + 0.5))
        if entry.season == "FALL" then label = FFR_L10n.t("ffr_insure_fall_entry", label) end
        table.insert(names, label)
    end
    self:setControlText("insureCropList", #names > 0 and FFR_L10n.t("ffr_insure_crop_list", table.concat(names, ", ")) or "")
    local _, premium = ins.getBilledTotals(policy, nil)
    if policy ~= nil and policy.allCrops then premium = tonumber(policy.premium) or 0 end
    self:setControlText("insurePremium", self:formatMoney(premium))
end

function FFR_DashboardFrame:changeInsureCrop(direction)
    local state = self:getInsuranceState()
    if state == nil or FFR_CropInsuranceManager == nil then return end
    local list = self:getInsureCrops(state)
    if #list == 0 then return end
    self.insureCropIndex = (self.insureCropIndex or 1) + direction
    if self.insureCropIndex < 1 then self.insureCropIndex = #list elseif self.insureCropIndex > #list then self.insureCropIndex = 1 end
    self.insureCropName = list[self.insureCropIndex]
    self.insureMessage = nil
    self:refreshInsurancePage()
end
function FFR_DashboardFrame:onClickInsureCropPrev() self:changeInsureCrop(-1) end
function FFR_DashboardFrame:onClickInsureCropNext() self:changeInsureCrop(1) end

function FFR_DashboardFrame:changeCoverage(direction)
    if FFR_CropInsuranceManager == nil then return end
    self.insureCoverage = FFR_CropInsuranceManager.stepCoverage(self.insureCoverage or 0.75, direction)
    self:refreshInsurancePage()
end
function FFR_DashboardFrame:onClickCoverageDown() self:changeCoverage(-1) end
function FFR_DashboardFrame:onClickCoverageUp() self:changeCoverage(1) end

function FFR_DashboardFrame:runCropPolicyAction(action)
    local state = self:getInsuranceState()
    if state == nil or FFR_CropInsuranceManager == nil then return end
    local crop = self:getSelectedInsureCrop(state)
    if crop == nil then return end
    self:performAction(action, {fruitName = crop, coverage = self.insureCoverage or 0.75}, function(message)
        self.insureMessage = message
        self:refreshInsurancePage()
    end)
end
function FFR_DashboardFrame:onClickInsureCrop() self:runCropPolicyAction("INSURE_CROP") end
function FFR_DashboardFrame:onClickRemoveCrop() self:runCropPolicyAction("UNINSURE_CROP") end

function FFR_DashboardFrame:onClickFileClaim()
    local state = self:getInsuranceState()
    local rows = (state ~= nil and FFR_CropInsuranceManager ~= nil) and FFR_CropInsuranceManager.getDamageRows(state) or {}
    local row = rows[self.insureSelected or 1]
    -- On the map, the claim is for the field clicked there (it may have no crop).
    if self.insureView == "MAP" then
        row = nil
        for _, r in ipairs(rows) do
            if r.farmlandId == self.insureMapFarmland then row = r end
        end
    end
    if row == nil then
        self.insureMessage = FFR_L10n.t("ffr_insure_select_field")
        self:refreshInsurancePage()
        return
    end
    self:performAction("FILE_CROP_CLAIM", {farmlandId = row.farmlandId}, function(message)
        self.insureMessage = message
        self:refreshInsurancePage()
    end)
end

--------------------------------------------------
-- Options page: difficulty preset (server admin)
--------------------------------------------------

function FFR_DashboardFrame:formatLadder(ladder)
    if ladder.forcedSale == nil then return FFR_L10n.t("ffr_options_ladder_nosale", ladder.freeze or 0) end
    return FFR_L10n.t("ffr_options_ladder_sale", ladder.forcedSale)
end

-- One row per setting: label shown in the XML, value per preset here.
function FFR_DashboardFrame:getPresetCells(p)
    local function times(v) return string.format("x %.2f", v) end
    return {
        times(p.household),
        times(p.eventStrength),
        string.format("%d%%", math.floor(p.calmChance * 100 + 0.5)),
        p.drasticWeight > 0 and string.format("%d%%", p.drasticWeight) or FFR_L10n.t("ffr_common_off"),
        string.format("%.2f - %.2f", p.minModifier, p.maxModifier),
        times(p.interest),
        times(p.taxes),
        self:formatLadder(p.insolvency)
    }
end

--------------------------------------------------
-- Options page, inputs view: how each product is
-- classified for supplier promotions. UP / DOWN
-- selects a product, < > changes its class
-- (server admin only; FFR_InputClassifier).
--------------------------------------------------

FFR_DashboardFrame.INPUT_ROWS = 10

function FFR_DashboardFrame:onClickOptionsToggle()
    local nextView = {DIFFICULTY = "INPUTS", INPUTS = "UNITS", UNITS = "DIFFICULTY"}
    self.optionsView = nextView[self.optionsView or "DIFFICULTY"] or "INPUTS"
    self.optionsMessage = nil
    self:refreshOptionsPage()
end

function FFR_DashboardFrame:getInputEntries()
    return FFR_InputClassifier ~= nil and FFR_InputClassifier.getEntries() or {}
end

function FFR_DashboardFrame:refreshInputsView()
    local list = self:getInputEntries()
    local rows = FFR_DashboardFrame.INPUT_ROWS
    self.inputSelected = math.max(1, math.min(self.inputSelected or 1, math.max(1, #list)))
    local first = math.floor((self.inputSelected - 1) / rows) * rows + 1
    local admin = FFR_Network == nil or FFR_Network.isLocalAdmin()
    self:setControlText("inputNote", FFR_L10n.t(admin and "ffr_options_input_note_admin" or "ffr_options_input_note_view"))
    for r = 1, rows do
        local index = first + r - 1
        local entry = list[index]
        local cells = {"", "", "", "", ""}
        if entry ~= nil then
            cells = {
                entry.name, FFR_InputClassifier.getSourceName(entry.source), entry.brandTitle or "-",
                FFR_InputClassifier.getCategoryName(entry.auto),
                FFR_InputClassifier.getCategoryName(entry.category) .. (entry.isOverride and FFR_L10n.t("ffr_options_input_set") or "")
            }
        end
        for c = 1, #cells do self:setControlText(string.format("inputRow%dCol%d", r, c), cells[c]) end
        self:setControlColor(string.format("inputRow%dCol5", r), (entry ~= nil and entry.isOverride)
            and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR)
        self:setControlVisible("inputRowHighlight" .. r, entry ~= nil and index == self.inputSelected)
    end
    local selected = list[self.inputSelected]
    self:setControlText("inputClassValue", selected ~= nil and FFR_InputClassifier.getCategoryName(selected.category) or "-")
    self:setControlText("inputPage", #list > 0 and FFR_L10n.t("ffr_options_input_paging", first, math.min(#list, first + rows - 1), #list)
        or FFR_L10n.t("ffr_options_input_none"))
    self:setControlText("inputMessage", self.inputMessage or "")
end

function FFR_DashboardFrame:changeInputSelection(direction)
    local count = #self:getInputEntries()
    if count == 0 then return end
    self.inputSelected = (self.inputSelected or 1) + direction
    if self.inputSelected < 1 then self.inputSelected = count elseif self.inputSelected > count then self.inputSelected = 1 end
    self.inputMessage = nil
    self:refreshInputsView()
end

function FFR_DashboardFrame:runInputClassAction(action, direction)
    local entry = self:getInputEntries()[self.inputSelected or 1]
    if entry == nil then return end
    self:performAction(action, {key = entry.key, direction = direction}, function(message)
        self.inputMessage = message
        self:refreshInputsView()
    end)
end
function FFR_DashboardFrame:onClickInputClassPrev() self:runInputClassAction("SET_INPUT_CLASS", -1) end
function FFR_DashboardFrame:onClickInputClassNext() self:runInputClassAction("SET_INPUT_CLASS", 1) end
function FFR_DashboardFrame:onClickInputClassReset() self:runInputClassAction("RESET_INPUT_CLASS", 0) end

function FFR_DashboardFrame:refreshOptionsPage()
    local inputs = self.optionsView == "INPUTS"
    local units = self.optionsView == "UNITS"
    self:setControlVisible("optionsDifficultyGroup", not inputs and not units)
    self:setControlVisible("optionsInputsGroup", inputs)
    self:setControlVisible("optionsUnitsGroup", units)
    self:setControlText("optionsTitle", FFR_L10n.t(units and "ffr_options_title_units"
        or inputs and "ffr_options_title_inputs" or "ffr_options_title_difficulty"))
    if units then
        self:setControlText("optionsMessage", "")
        self:refreshUnitsView()
        return
    end
    if inputs then
        self:setControlText("optionsMessage", "")
        self:refreshInputsView()
        return
    end
    if FFR_Settings == nil then return end
    local current = FFR_Settings.difficulty
    local nextDifficulty = FFR_Settings.getNextDifficulty()
    self:setControlText("optionsDifficultyValue", FFR_Settings.getName(current))
    if nextDifficulty ~= current then
        self:setControlText("optionsPendingValue", FFR_L10n.t("ffr_options_next_month", FFR_Settings.getName(nextDifficulty)))
    else
        self:setControlText("optionsPendingValue", "")
    end
    local admin = FFR_Network == nil or FFR_Network.isLocalAdmin()
    if FFR_Network ~= nil and FFR_Network.isMultiplayer() then
        self:setControlText("optionsNote", FFR_L10n.t(admin and "ffr_options_note_admin" or "ffr_options_note_view"))
    else
        self:setControlText("optionsNote", FFR_L10n.t("ffr_options_note_single"))
    end
    for c, name in ipairs(FFR_Settings.ORDER) do
        self:setControlVisible("optionsColumnHighlight" .. c, name == current)
        self:setControlColor("optionsHeader" .. c, name == current and FFR_DashboardFrame.TAB_ACTIVE_COLOR
            or (name == nextDifficulty and FFR_DashboardFrame.STATUS_DUE_COLOR or FFR_DashboardFrame.TAB_IDLE_COLOR))
        for r, text in ipairs(self:getPresetCells(FFR_Settings.PRESETS[name])) do
            self:setControlText(string.format("optionsCell%d_%d", r, c), text)
        end
    end
    self:setControlText("optionsMessage", self.optionsMessage or "")
end

--------------------------------------------------
-- Options page, units view (FFR_UnitManager):
-- display units for crops, other solids, liquids.
--------------------------------------------------

-- Example product per row, shown as 1,000 L in the chosen unit.
FFR_DashboardFrame.UNIT_EXAMPLES = {Crop = "WHEAT", Solid = "SILAGE", Liquid = "MILK"}

function FFR_DashboardFrame:refreshUnitsView()
    local u = FFR_UnitManager
    if u == nil then return end
    for row, kind in pairs({Crop = "crop", Solid = "solid", Liquid = "liquid"}) do
        self:setControlText("unit" .. row .. "Value", u.getUnitName(u.settings[kind]))
        local example = FFR_DashboardFrame.UNIT_EXAMPLES[row]
        local text = ""
        if u.getFillType(example) ~= nil then
            text = FFR_L10n.t("ffr_units_example", FFR_L10n.fillTypeTitle(example), u.formatAmount(1000, example))
        end
        self:setControlText("unit" .. row .. "Example", text)
    end
    self:setControlText("unitHudNote", FFR_L10n.t(u.isOtherConverterLoaded() and "ffr_units_hud_other" or "ffr_units_hud_on"))
end

function FFR_DashboardFrame:changeUnit(kind, direction)
    if FFR_UnitManager == nil then return end
    FFR_UnitManager.step(kind, direction)
    self:refreshUnitsView()
end
function FFR_DashboardFrame:onClickUnitCropPrev() self:changeUnit("crop", -1) end
function FFR_DashboardFrame:onClickUnitCropNext() self:changeUnit("crop", 1) end
function FFR_DashboardFrame:onClickUnitSolidPrev() self:changeUnit("solid", -1) end
function FFR_DashboardFrame:onClickUnitSolidNext() self:changeUnit("solid", 1) end
function FFR_DashboardFrame:onClickUnitLiquidPrev() self:changeUnit("liquid", -1) end
function FFR_DashboardFrame:onClickUnitLiquidNext() self:changeUnit("liquid", 1) end

function FFR_DashboardFrame:changeDifficulty(direction)
    self:performAction("SET_DIFFICULTY", {direction = direction}, function(message)
        self.optionsMessage = message
        self:refreshOptionsPage()
    end)
end
function FFR_DashboardFrame:onClickDifficultyPrev() self:changeDifficulty(-1) end
function FFR_DashboardFrame:onClickDifficultyNext() self:changeDifficulty(1) end

function FFR_DashboardFrame:refreshData()
    if g_FFRDashboardDataManager==nil then return false end; g_FFRDashboardDataManager:refresh(); local d=g_FFRDashboardDataManager:getData(); if d==nil then return false end
    self:setControlText("statusValue",FFR_L10n.t(d.isReady and "ffr_overview_live" or "ffr_overview_waiting")); self:setControlText("headerBalanceValue",self:formatMoney(d.cash)); self:setControlText("cashValue",self:formatMoney(d.cash)); self:setControlText("totalAssetsValue",self:formatMoney(d.totalAssets)); self:setControlText("totalDebtValue",self:formatMoney(d.totalDebt)); self:setControlText("netWorthValue",self:formatMoney(d.netWorth)); self:setControlText("workingCapitalValue",self:formatMoney(d.workingCapital)); self:setControlText("landValue",FFR_L10n.t("ffr_overview_parcels",d.landCount or 0,self:formatMoney(d.landValue))); self:setControlText("equipmentValue",FFR_L10n.t("ffr_overview_items",d.equipmentCount or 0,self:formatMoney(d.equipmentValue))); self:setControlText("buildingValue",FFR_L10n.t("ffr_overview_items",d.buildingCount or 0,self:formatMoney(d.buildingValue))); self:setControlText("inventoryValue",FFR_L10n.t("ffr_overview_items",d.inventoryCount or 0,self:formatMoney(d.inventoryValue))); self:setControlText("creditValue",string.format("%d   %s",d.creditScore or 0,d.creditRating or FFR_L10n.t("ffr_common_unavailable"))); self:setControlText("operatingLimitValue",self:formatMoney(d.operatingLoanLimit)); self:setControlText("expansionLimitValue",self:formatMoney(self:getExpansionLimit(d))); self:setControlText("marketEventValue",d.marketEventName or FFR_L10n.t("ffr_news_no_event")); self:setControlText("grainValue",self:formatModifier(d.grainModifier)); self:setControlText("oilseedValue",self:formatModifier(d.oilseedModifier)); self:setControlText("pulseValue",self:formatModifier(d.pulseModifier)); self:setControlText("forageValue",self:formatModifier(d.forageModifier)); self:setControlText("vegetableValue",self:formatModifier(d.vegetableModifier)); self:setControlText("inputProgramValue",d.inputEventName or FFR_L10n.t("ffr_news_supplier_regular")); self:setControlText("inputExpiryValue",(g_FFR~=nil and g_FFR.inputMarket~=nil and g_FFR.inputMarket.getExpiryText~=nil) and g_FFR.inputMarket:getExpiryText(true) or d.inputExpiryText or ""); self:setControlText("fertilizerValue",self:formatInputCell("FERTILIZER",d.fertilizerModifier)); self:setControlText("liquidFertilizerValue",self:formatInputCell("LIQUIDFERTILIZER",d.liquidFertilizerModifier)); self:setControlText("seedValue",self:formatInputCell("SEEDS",d.seedModifier)); self:setControlText("dieselValue",self:formatInputCell("DIESEL",d.dieselModifier)); local s, T = self.currentSection, FFR_DashboardFrame.TAB; if s==T.MARKETS then self:refreshMarketPage() elseif s==T.DEALS then self:refreshContractsPage() elseif s==T.NEWS then self:refreshNewsPage(d) elseif s==T.BANK then self:refreshBankPage(d) elseif s==T.LAND then self:refreshLandPage() elseif s==T.INSURANCE then self:refreshInsurancePage() elseif s==T.ADVISOR then self:refreshAdvisorPage(d) elseif s==T.STATUS then self:refreshStatusPage(d) elseif s==T.HOUSEHOLD then self:refreshHouseholdPage() elseif s==T.OPTIONS then self:refreshOptionsPage() end; return true
end
function FFR_DashboardFrame:onFrameOpen() FFR_DashboardFrame:superClass().onFrameOpen(self); self.frameOpen=true; self.refreshTimer=0; self.horizontalNavKey=nil; self.verticalNavKey=nil; self:setSection(self.currentSection); if type(self.setMenuButtonInfoDirty)=="function" then self:setMenuButtonInfoDirty() end end
function FFR_DashboardFrame:onFrameClose()
    -- A title change opened from this page is only drawn here: leaving the page keeps the current title.
    if g_FFRModalOverlay ~= nil and g_FFRModalOverlay.visible and g_FFRModalOverlay.overMenu then g_FFRModalOverlay:keepLand() end
    self.frameOpen=false; self.hold=nil; self.sliderDrag=nil; self.refreshTimer=0; self.horizontalNavKey=nil; self.verticalNavKey=nil; FFR_DashboardFrame:superClass().onFrameClose(self) end
function FFR_DashboardFrame:update(dt) FFR_DashboardFrame:superClass().update(self,dt); self:updateHold(dt); self.refreshTimer=self.refreshTimer+dt; if self.refreshTimer>=self.refreshInterval then self.refreshTimer=0; self:refreshData() end end
function FFR_DashboardFrame:keyEvent(unicode,sym,modifier,isDown)
    -- Other pause-menu pages (the map) get their keys untouched while this page is not shown.
    if Input==nil or not self:isShown() then return end
    if FFR_DashboardFrame.isModalOpen() then g_FFRModalOverlay:keyEvent(unicode, sym, modifier, isDown); return end
    local h=nil; if sym==Input.KEY_left then h=-1 elseif sym==Input.KEY_right then h=1 end
    if h~=nil then if isDown then if self.horizontalNavKey==nil then self.horizontalNavKey=sym; self:changeSection(h) end elseif self.horizontalNavKey==sym then self.horizontalNavKey=nil end; return end
    -- UP / DOWN: commodity list on Markets, contract rows on Deals, parcel pages on Land,
    -- statement pages on Farm Status.
    local v=nil; if sym==Input.KEY_up then v=-1 elseif sym==Input.KEY_down then v=1 end
    if v~=nil and self:hasVerticalList() then
        if isDown then
            if self.verticalNavKey==nil then
                self.verticalNavKey=sym
                self:navigateVertical(v)
            end
        elseif self.verticalNavKey==sym then self.verticalNavKey=nil end
    end
end

-- Tabs whose list or pages move with UP / DOWN (and the mouse wheel).
function FFR_DashboardFrame:hasVerticalList()
    local T, s = FFR_DashboardFrame.TAB, self.currentSection
    return s==T.MARKETS or s==T.DEALS or s==T.LAND or s==T.INSURANCE or s==T.STATUS or (s==T.OPTIONS and self.optionsView=="INPUTS")
        or (s==T.BANK and self.bankView=="EQUIPMENT")
end

function FFR_DashboardFrame:navigateVertical(v)
    local T, s = FFR_DashboardFrame.TAB, self.currentSection
    if s==T.MARKETS then self:changeMarketSelection(v)
    elseif s==T.DEALS then self:changeContractSelection(v)
    elseif s==T.LAND then
        if (self.landView or "TITLES") == "RENTALS" then self:changeRentSelection(v)
        elseif (self.landView or "TITLES") == "TITLES" then self:changeLandSelection(v) end
    elseif s==T.INSURANCE then self:changeInsuranceSelection(v)
    elseif s==T.OPTIONS then self:changeInputSelection(v)
    elseif s==T.BANK then self:changeEquipSelection(v)
    else self:changeStatementPage(v) end
end

--------------------------------------------------
-- Mouse: tabs, list rows and the wheel.
--------------------------------------------------

-- Clicking a tab label (or the rail around it) opens that tab.
function FFR_DashboardFrame:getTabHit(posX, posY)
    for i = 1, #FFR_DashboardFrame.SECTIONS do
        local label = self.controls["tabLabel" .. i]
        if label ~= nil and label.absPosition ~= nil and label.absSize ~= nil then
            local x, y, w, h = label.absPosition[1], label.absPosition[2], label.absSize[1], label.absSize[2]
            if posX >= x and posX <= x + w and posY >= y - 0.016 and posY <= y + h + 0.016 then return i end
        end
    end
    return nil
end

-- Selectable lists: highlight bar prefix, rows per page, selected index, entry count, step.
function FFR_DashboardFrame:getRowLists()
    local T = FFR_DashboardFrame.TAB
    return {
        {tab = T.MARKETS, prefix = "marketRowHighlight", rows = FFR_DashboardFrame.MARKET_ROWS,
            selected = function(f) return f.marketSelectedIndex end, count = function(f) return #f.marketCommodities end,
            change = function(f, d) f:changeMarketSelection(d) end},
        {tab = T.DEALS, prefix = "contractRowHighlight", rows = FFR_DashboardFrame.CONTRACT_ROWS,
            selected = function(f) return f.contractSelected end,
            count = function(f) local cm = f:getContractManager(); return cm ~= nil and #cm:getListed(f:getContractFarmId()) or 0 end,
            change = function(f, d) f:changeContractSelection(d) end},
        {tab = T.LAND, when = function(f) return (f.landView or "TITLES") == "RENTALS" end, prefix = "rentRowHighlight", rows = FFR_DashboardFrame.RENT_ROWS,
            selected = function(f) return f.rentSelected end, count = function(f) return #f:getRentContracts() end,
            change = function(f, d) f:changeRentSelection(d) end},
        {tab = T.LAND, when = function(f) return (f.landView or "TITLES") == "TITLES" end, prefix = "landRowHighlight", rows = FFR_DashboardFrame.LAND_ROWS,
            selected = function(f) return f.landSelected end, count = function(f) return #f:getLandTitles() end,
            change = function(f, d) f:changeLandSelection(d) end},
        {tab = T.BANK, when = function(f) return f.bankView == "EQUIPMENT" end, prefix = "equipRowHighlight", rows = FFR_DashboardFrame.EQUIP_ROWS,
            selected = function(f) return f.equipSelected end, count = function(f) return #f:getEquipmentLoans() end,
            change = function(f, d) f:changeEquipSelection(d) end},
        {tab = T.INSURANCE, when = function(f) return f.insureView ~= "MAP" and f.insureView ~= "LIVESTOCK" end,
            prefix = "insureRowHighlight", rows = FFR_DashboardFrame.INSURE_ROWS,
            selected = function(f) return f.insureSelected end,
            count = function(f)
                local state = f:getInsuranceState()
                return (state ~= nil and FFR_CropInsuranceManager ~= nil) and #FFR_CropInsuranceManager.getDamageRows(state) or 0
            end,
            change = function(f, d) f:changeInsuranceSelection(d) end},
        {tab = T.OPTIONS, when = function(f) return f.optionsView == "INPUTS" end, prefix = "inputRowHighlight", rows = FFR_DashboardFrame.INPUT_ROWS,
            selected = function(f) return f.inputSelected end, count = function(f) return #f:getInputEntries() end,
            change = function(f, d) f:changeInputSelection(d) end}
    }
end

-- Clicking a row selects it (rows on the page shown, as the list draws them).
function FFR_DashboardFrame:handleRowClick(posX, posY)
    for _, list in ipairs(self:getRowLists()) do
        if list.tab == self.currentSection and (list.when == nil or list.when(self)) then
            local selected = math.max(1, tonumber(list.selected(self)) or 1)
            local first = math.floor((selected - 1) / list.rows) * list.rows + 1
            for r = 1, list.rows do
                if self:isInside(self.controls[list.prefix .. r], posX, posY) then
                    local index = first + r - 1
                    if index <= list.count(self) and index ~= selected then list.change(self, index - selected) end
                    return true
                end
            end
            return false
        end
    end
    return false
end

--------------------------------------------------
-- Mouse: loan amount bars on the Bank page.
-- Pressing on a bar sets the amount; moving with
-- the button held drags it; releasing stops.
--------------------------------------------------

function FFR_DashboardFrame:getSliderHit(posX, posY)
    for _, loan in ipairs({"Operating", "Land"}) do
        local bar = self.controls["bankSlider" .. loan]
        if bar ~= nil and bar.absPosition ~= nil and bar.absSize ~= nil then
            local x, y, w, h = bar.absPosition[1], bar.absPosition[2], bar.absSize[1], bar.absSize[2]
            -- A taller hit area than the thin track itself.
            if posX >= x - 0.006 and posX <= x + w + 0.006 and posY >= y - 0.012 and posY <= y + h + 0.012 then
                return loan, bar
            end
        end
    end
    return nil, nil
end

function FFR_DashboardFrame:setSliderFromMouse(loan, bar, posX)
    local fraction = math.max(0, math.min(1, (posX - bar.absPosition[1]) / bar.absSize[1]))
    self:setLoanAmount(loan, fraction * FFR_DashboardFrame.LOAN_AMOUNT_MAX)
end

--------------------------------------------------
-- Press-and-hold repeat for step buttons (contract
-- volume, loan amount arrows). A normal click still
-- steps once through the button's onClick. Held past
-- HOLD_DELAY, the button repeats every HOLD_INTERVAL,
-- in steps of HOLD_FAST_MULTIPLIER after HOLD_FAST.
-- The click the button sends on release after a hold
-- is ignored.
--------------------------------------------------

FFR_DashboardFrame.HOLD_DELAY = 400
FFR_DashboardFrame.HOLD_INTERVAL = 80
FFR_DashboardFrame.HOLD_FAST = 1500
FFR_DashboardFrame.HOLD_FAST_MULTIPLIER = 5

function FFR_DashboardFrame:getHoldButtons()
    local T, step = FFR_DashboardFrame.TAB, FFR_DashboardFrame.LOAN_AMOUNT_STEP
    local function amount(loan, direction)
        return function(frame, m) frame:setLoanAmount(loan, frame:getLoanAmount(loan) + direction * m * step) end
    end
    return {
        buttonAmountDownOperating = {tab = T.BANK, run = amount("Operating", -1)},
        buttonAmountUpOperating = {tab = T.BANK, run = amount("Operating", 1)},
        buttonAmountDownLand = {tab = T.BANK, run = amount("Land", -1)},
        buttonAmountUpLand = {tab = T.BANK, run = amount("Land", 1)}
    }
end

function FFR_DashboardFrame:isInside(element, posX, posY)
    return element ~= nil and element.absPosition ~= nil and element.absSize ~= nil
        and posX >= element.absPosition[1] and posX <= element.absPosition[1] + element.absSize[1]
        and posY >= element.absPosition[2] and posY <= element.absPosition[2] + element.absSize[2]
end

function FFR_DashboardFrame:updateHold(dt)
    self.clockMs = (self.clockMs or 0) + dt
    local hold = self.hold
    if hold == nil then return end
    hold.elapsed = hold.elapsed + dt
    if hold.elapsed < FFR_DashboardFrame.HOLD_DELAY then return end
    hold.sinceRepeat = hold.sinceRepeat + dt
    while hold.sinceRepeat >= FFR_DashboardFrame.HOLD_INTERVAL do
        hold.sinceRepeat = hold.sinceRepeat - FFR_DashboardFrame.HOLD_INTERVAL
        local multiplier = hold.elapsed >= FFR_DashboardFrame.HOLD_FAST and FFR_DashboardFrame.HOLD_FAST_MULTIPLIER or 1
        hold.spec.run(self, multiplier)
        hold.repeats = hold.repeats + 1
    end
end

-- True if this click is the release of a hold that already repeated (skip it).
function FFR_DashboardFrame:consumeHoldClick(id)
    if self.suppressClickId == id and (self.clockMs or 0) <= (self.suppressClickUntil or 0) then
        self.suppressClickId = nil
        return true
    end
    return false
end

function FFR_DashboardFrame:handleHoldMouse(posX, posY, isDown, isUp, button)
    local left = Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT
    if isDown and left then
        for id, spec in pairs(self:getHoldButtons()) do
            if spec.tab == self.currentSection and self:isInside(self.controls[id], posX, posY) then
                self.hold = {id = id, spec = spec, elapsed = 0, sinceRepeat = 0, repeats = 0}
                return
            end
        end
    elseif isUp then
        if self.hold ~= nil and self.hold.repeats > 0 then
            self.suppressClickId = self.hold.id
            self.suppressClickUntil = (self.clockMs or 0) + 300
        end
        self.hold = nil
    elseif self.hold ~= nil and not self:isInside(self.controls[self.hold.id], posX, posY) then
        -- Moved off the button: stop repeating.
        self.hold = nil
    end
end

-- The FFR title window drawn over this page takes the mouse and keys itself.
function FFR_DashboardFrame.isModalOpen()
    return g_FFRModalOverlay ~= nil and g_FFRModalOverlay.visible == true
end

-- True only while this page is the one on screen. The menu still passes input to
-- hidden pages; acting on it took clicks and scrolling away from the map page.
function FFR_DashboardFrame:isShown()
    if not self.frameOpen then return false end
    if self.getIsVisible ~= nil and not self:getIsVisible() then return false end
    return true
end

function FFR_DashboardFrame:mouseEvent(posX, posY, isDown, isUp, button, eventUsed)
    if not self:isShown() then
        return FFR_DashboardFrame:superClass().mouseEvent(self, posX, posY, isDown, isUp, button, eventUsed)
    end
    if FFR_DashboardFrame.isModalOpen() then
        self.hold = nil
        self.sliderDrag = nil
        g_FFRModalOverlay:mouseEvent(posX, posY, isDown, isUp, button)
        return true
    end
    self:handleHoldMouse(posX, posY, isDown, isUp, button)
    local leftDown = isDown and (Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT)
    if leftDown and not eventUsed then
        local tab = self:getTabHit(posX, posY)
        if tab ~= nil then
            if tab ~= self.currentSection then self:setSection(tab) end
            eventUsed = true
        elseif self:handleRowClick(posX, posY) then
            eventUsed = true
        end
    end
    -- Mouse wheel = UP / DOWN on list tabs.
    if isDown and not eventUsed and Input ~= nil and self:hasVerticalList() then
        local v = nil
        if Input.MOUSE_BUTTON_WHEEL_UP ~= nil and button == Input.MOUSE_BUTTON_WHEEL_UP then v = -1
        elseif Input.MOUSE_BUTTON_WHEEL_DOWN ~= nil and button == Input.MOUSE_BUTTON_WHEEL_DOWN then v = 1 end
        if v ~= nil then self:navigateVertical(v); eventUsed = true end
    end
    if isDown and not eventUsed and self.currentSection == FFR_DashboardFrame.TAB.INSURANCE and self.insureView == "MAP"
        and (Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT) then
        if self:handleCropMapClick(posX, posY) then eventUsed = true end
    end
    -- Deals: the contract volume bar (press to set, drag to move, release to stop).
    if self.currentSection == FFR_DashboardFrame.TAB.DEALS and not eventUsed then
        if isDown and (Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT) then
            local bar = self:getVolumeSliderHit(posX, posY)
            if bar ~= nil then
                self.volumeDrag = true
                self:setVolumeFromMouse(bar, posX)
                eventUsed = true
            end
        elseif isUp then
            self.volumeDrag = nil
        elseif self.volumeDrag and self.controls.contractVolumeSlider ~= nil then
            self:setVolumeFromMouse(self.controls.contractVolumeSlider, posX)
            eventUsed = true
        end
    end
    if self.currentSection == FFR_DashboardFrame.TAB.BANK and not eventUsed then
        if isDown and (Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT) then
            local loan, bar = self:getSliderHit(posX, posY)
            if loan ~= nil then
                self.sliderDrag = loan
                self:setSliderFromMouse(loan, bar, posX)
                eventUsed = true
            end
        elseif isUp then
            self.sliderDrag = nil
        elseif self.sliderDrag ~= nil then
            local bar = self.controls["bankSlider" .. self.sliderDrag]
            if bar ~= nil and bar.absPosition ~= nil then
                self:setSliderFromMouse(self.sliderDrag, bar, posX)
                eventUsed = true
            end
        end
    end
    return FFR_DashboardFrame:superClass().mouseEvent(self, posX, posY, isDown, isUp, button, eventUsed)
end
function FFR_DashboardFrame:delete()
    self.controls={}; self.sectionPanels={}; self.marketCommodities={}; self.householdManager=nil
    if self.fillOverlay ~= nil and self.fillOverlay.delete ~= nil then self.fillOverlay:delete() end
    self.fillOverlay = nil; self.fillElements = nil
    FFR_DashboardFrame:superClass().delete(self)
end
