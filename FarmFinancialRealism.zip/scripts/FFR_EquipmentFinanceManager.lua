FFR_EquipmentFinanceManager = {}

--------------------------------------------------
-- Equipment finance and leases
--
-- Machines are financed or leased from the FS25
-- shop (FFR_ShopFinance: a FINANCE button next to BUY,
-- and LEASE opens FFR's lease instead of FS25's
-- pay-per-hour lease). Both are contracts on the
-- machine in state.equipmentLoans (kind FINANCE or
-- LEASE).
--
-- FINANCE: the down payment is paid in the shop; the
-- rest is a loan with equal monthly principal on the
-- month-end "Equipment loan" line and interest on the
-- balance at the bank's equipment rate (base 6.5 % x
-- credit x difficulty) with the other loan interest.
-- Pay off any time without a fee.
--
-- LEASE: 24-60 months with a residual by term
-- (RESIDUALS). A fixed monthly payment covers the
-- machine's expected loss in value plus interest at
-- the equipment rate on signing day; the first
-- payment is due in the shop, the rest on the
-- month-end "Equipment leases" line. At the end the
-- farm has one month to buy it for the residual or
-- return it; doing nothing returns it. Hours above
-- the allowance (getHoursPerYear: 25-300 a year by days
-- per month) are charged on return. Buy out early
-- (payments' value left + residual) or return early
-- (half the payments left as a fee) any time.
--
-- A machine that leaves the farm (sold, removed)
-- settles its contract from cash at once. At the
-- forced-sale stage the bank takes back every
-- financed and leased machine first (repossess).
--
-- The purchase: the client asks the server to
-- PREPARE a deal (FFR_Network action) and only after
-- approval sends FS25's own BuyVehicleEvent priced at
-- what is due today. The server matches the deal in
-- BuyVehicleData.buy, prices it again from its own
-- shop price, and opens the contract in onBought.
--
-- Totals go to financialManager.equipmentDebt and
-- monthlyEquipmentPayment (finance), monthlyLeaseCost
-- and leaseDebt (leases) in syncTotals.
--------------------------------------------------

FFR_EquipmentFinanceManager.DOWN_PAYMENTS = {0.10, 0.20, 0.30}
FFR_EquipmentFinanceManager.TERMS = {12, 24, 36, 48, 60, 72, 84}

FFR_EquipmentFinanceManager.LEASE_TERMS = {24, 36, 48, 60}
FFR_EquipmentFinanceManager.RESIDUALS = {[24] = 0.60, [36] = 0.50, [48] = 0.40, [60] = 0.30}
-- Lease hours included per year scale with the save's days per month (a machine
-- can only run as many hours as the days allow): 25 at 1 day, 300 at 28 days
-- (FS25's longest month), in a straight line between. getHoursPerYear.
FFR_EquipmentFinanceManager.HOURS_PER_YEAR_MIN = 25
FFR_EquipmentFinanceManager.HOURS_PER_YEAR_MAX = 300
FFR_EquipmentFinanceManager.MAX_DAYS_PER_MONTH = 28
-- Over-hours fee per hour, as a share of the machine's price.
FFR_EquipmentFinanceManager.OVERAGE_RATE = 0.00015
-- Early return fee: this share of the payments still to come.
FFR_EquipmentFinanceManager.EARLY_RETURN_SHARE = 0.50

-- Least down payment per credit rating (HIGH_RISK is not lent to at all).
FFR_EquipmentFinanceManager.MIN_DOWN = {CONCERNING = 0.20}
FFR_EquipmentFinanceManager.DEFAULT_MIN_DOWN = 0.10

-- A prepared deal must be matched by its purchase within this time.
FFR_EquipmentFinanceManager.PENDING_MS = 60000

FFR_EquipmentFinanceManager.KEEP_CLOSED = 5

-- Sold machines: checked every few seconds once the game has settled after
-- loading; a machine must be missing twice in a row (a reset machine is
-- removed and loaded again).
FFR_EquipmentFinanceManager.SALE_CHECK_MS = 5000
FFR_EquipmentFinanceManager.STARTUP_GRACE_MS = 20000

FFR_EquipmentFinanceManager.pending = {}
FFR_EquipmentFinanceManager.updateTimer = 0
FFR_EquipmentFinanceManager.readyTimer = 0

function FFR_EquipmentFinanceManager.formatMoney(value)
    return FFR_L10n.formatMoney(value)
end

function FFR_EquipmentFinanceManager.isServer()
    return FFR_Network == nil or FFR_Network.isServer()
end

function FFR_EquipmentFinanceManager.getSerial()
    local period, year = nil, nil
    if g_FFRMonthlyFinancialProcessor ~= nil then period, year = g_FFRMonthlyFinancialProcessor:getCalendar() end
    return (year or 0) * 12 + (period or 0), period, year
end

--------------------------------------------------
-- Terms and quotes (any machine)
--------------------------------------------------

function FFR_EquipmentFinanceManager.getMinDown(credit)
    local rating = credit ~= nil and credit.creditRating or nil
    return FFR_EquipmentFinanceManager.MIN_DOWN[rating or ""] or FFR_EquipmentFinanceManager.DEFAULT_MIN_DOWN
end

function FFR_EquipmentFinanceManager.isListed(list, value)
    for _, v in ipairs(list) do
        if math.abs(v - (tonumber(value) or -1)) < 0.0001 then return true end
    end
    return false
end

function FFR_EquipmentFinanceManager.getRate(state)
    return state.bankingManager:getEquipmentRate(state.creditManager)
end

-- How much more the bank puts into equipment (credit rating limit, finance
-- balances and lease payments still owed).
function FFR_EquipmentFinanceManager.getLimit(state)
    local f = state.financialManager
    return math.max(0, (tonumber(state.creditManager.maxExpansionLoan) or 0)
        - (tonumber(f.equipmentDebt) or 0) - (tonumber(f.leaseDebt) or 0))
end

-- What a finance deal costs. Interest follows the rate month by month; the total
-- is an estimate at today's rate on a balance that falls in equal principal steps.
function FFR_EquipmentFinanceManager.getQuote(state, price, down, term)
    price, down, term = tonumber(price) or 0, tonumber(down) or 0, tonumber(term) or 1
    local downPayment = math.floor(price * down + 0.5)
    local financed = math.max(0, price - downPayment)
    local rate = FFR_EquipmentFinanceManager.getRate(state)
    local principal = financed / term
    local firstInterest = financed * rate / 12
    return {
        price = price, downPayment = downPayment, financed = financed, rate = rate, term = term,
        principal = principal, firstInterest = firstInterest, firstPayment = principal + firstInterest,
        totalInterest = financed * rate / 12 * (term + 1) / 2
    }
end

-- Hours included per year at the save's current days per month.
function FFR_EquipmentFinanceManager.getHoursPerYear()
    local m = FFR_EquipmentFinanceManager
    local days = FFR_HerdRiskManager ~= nil and FFR_HerdRiskManager.getDaysPerMonth() or m.MAX_DAYS_PER_MONTH
    local share = (math.max(1, math.min(m.MAX_DAYS_PER_MONTH, days)) - 1) / (m.MAX_DAYS_PER_MONTH - 1)
    return math.floor(m.HOURS_PER_YEAR_MIN + (m.HOURS_PER_YEAR_MAX - m.HOURS_PER_YEAR_MIN) * share + 0.5)
end

-- What a lease costs: the payment covers the loss in value over the term plus
-- interest on the machine's average value ((price + residual) / 2).
function FFR_EquipmentFinanceManager.getLeaseQuote(state, price, term)
    price, term = tonumber(price) or 0, tonumber(term) or 24
    local residual = math.floor(price * (FFR_EquipmentFinanceManager.RESIDUALS[term] or 0.5) + 0.5)
    local rate = FFR_EquipmentFinanceManager.getRate(state)
    local depreciation = (price - residual) / term
    local payment = math.floor(depreciation + (price + residual) / 2 * rate / 12 + 0.5)
    return {
        price = price, term = term, rate = rate, residual = residual, depreciation = depreciation, payment = payment,
        dueToday = payment, totalPayments = payment * term, hours = FFR_EquipmentFinanceManager.getHoursPerYear() * term / 12,
        overageFee = price * FFR_EquipmentFinanceManager.OVERAGE_RATE
    }
end

-- Whether the bank approves the deal. kind FINANCE (down, term) or LEASE (term).
-- Returns ok, message.
function FFR_EquipmentFinanceManager.check(state, kind, price, down, term)
    local m = FFR_EquipmentFinanceManager
    local credit, f = state.creditManager, state.financialManager
    if (tonumber(price) or 0) <= 0 then return false, FFR_L10n.t("ffr_finance_unavailable") end
    if not state.bankingManager:isApproved(credit) then return false, FFR_L10n.t("ffr_bank_denied_credit") end
    if FFR_InsolvencyManager ~= nil and FFR_InsolvencyManager.isFrozen(credit) then
        return false, FFR_L10n.t(FFR_InsolvencyManager.FROZEN_MESSAGE)
    end
    local amount, dueToday
    if kind == "LEASE" then
        if not m.isListed(m.LEASE_TERMS, term) then return false, FFR_L10n.t("ffr_finance_unavailable") end
        local q = m.getLeaseQuote(state, price, term)
        amount, dueToday = q.totalPayments, q.dueToday
    else
        if not m.isListed(m.TERMS, term) or not m.isListed(m.DOWN_PAYMENTS, down) then
            return false, FFR_L10n.t("ffr_finance_unavailable")
        end
        local minDown = m.getMinDown(credit)
        if down < minDown - 0.0001 then
            return false, FFR_L10n.t("ffr_finance_min_down", math.floor(minDown * 100 + 0.5))
        end
        local q = m.getQuote(state, price, down, term)
        amount, dueToday = q.financed, q.downPayment
    end
    local limit = m.getLimit(state)
    if amount > limit then
        return false, FFR_L10n.t("ffr_finance_limit", m.formatMoney(limit))
    end
    if state.bankingManager:getCash(f) < dueToday then
        return false, FFR_L10n.t("ffr_finance_not_enough_cash", m.formatMoney(dueToday))
    end
    return true, ""
end

--------------------------------------------------
-- Contracts
--------------------------------------------------

function FFR_EquipmentFinanceManager.getLoans(state)
    state.equipmentLoans = state.equipmentLoans or {}
    return state.equipmentLoans
end

function FFR_EquipmentFinanceManager.isLease(loan)
    return loan ~= nil and loan.kind == "LEASE"
end

-- Still paying (finance or lease).
function FFR_EquipmentFinanceManager.isActive(loan)
    return loan ~= nil and loan.status == "ACTIVE"
end

-- Not settled yet: paying, or a lease waiting for buy out / return.
function FFR_EquipmentFinanceManager.isOpen(loan)
    return loan ~= nil and (loan.status == "ACTIVE" or loan.status == "ENDED")
end

-- Open contracts first (oldest first), then closed ones (newest first).
function FFR_EquipmentFinanceManager.getSortedLoans(state)
    local open, closed = {}, {}
    for _, loan in ipairs(FFR_EquipmentFinanceManager.getLoans(state)) do
        table.insert(FFR_EquipmentFinanceManager.isOpen(loan) and open or closed, loan)
    end
    for i = #closed, 1, -1 do table.insert(open, closed[i]) end
    return open
end

function FFR_EquipmentFinanceManager.findLoan(state, loanId)
    for _, loan in ipairs(FFR_EquipmentFinanceManager.getLoans(state)) do
        if loan.id == loanId then return loan end
    end
    return nil
end

-- The machine's shop name in the player's language (brand + model).
function FFR_EquipmentFinanceManager.getDisplayName(loan)
    local item = nil
    if g_storeManager ~= nil and g_storeManager.getItemByXMLFilename ~= nil and loan.xml ~= nil and loan.xml ~= "" then
        local ok, result = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, loan.xml)
        item = ok and result or nil
    end
    if item ~= nil then return FFR_EquipmentFinanceManager.getItemName(item) end
    return tostring(loan.name or "")
end

function FFR_EquipmentFinanceManager.getItemName(storeItem)
    local name = tostring(storeItem.name or "")
    if g_brandManager ~= nil and g_brandManager.getBrandByIndex ~= nil and storeItem.brandIndex ~= nil then
        local ok, brand = pcall(g_brandManager.getBrandByIndex, g_brandManager, storeItem.brandIndex)
        if ok and brand ~= nil and brand.title ~= nil and brand.title ~= "" and brand.name ~= "NONE" then
            name = brand.title .. " " .. name
        end
    end
    return name
end

function FFR_EquipmentFinanceManager.getStatusName(loan)
    return FFR_L10n.named("ffr_equip_status_", loan ~= nil and loan.status or "ACTIVE")
end

function FFR_EquipmentFinanceManager.getKindName(loan)
    return FFR_L10n.t(FFR_EquipmentFinanceManager.isLease(loan) and "ffr_equip_kind_lease" or "ffr_equip_kind_finance")
end

function FFR_EquipmentFinanceManager.getMonthsLeft(loan)
    return math.max(0, (tonumber(loan.term) or 0) - (tonumber(loan.paidMonths) or 0))
end

-- What the farm still owes: a finance balance, or a lease's payments left.
function FFR_EquipmentFinanceManager.getOwed(loan)
    if FFR_EquipmentFinanceManager.isLease(loan) then
        if loan.status ~= "ACTIVE" then return 0 end
        return (tonumber(loan.payment) or 0) * FFR_EquipmentFinanceManager.getMonthsLeft(loan)
    end
    return tonumber(loan.balance) or 0
end

-- To own the machine today: the finance balance, or for a lease the value of
-- the payments left (their loss-in-value part) plus the residual.
function FFR_EquipmentFinanceManager.getSettlement(loan)
    if not FFR_EquipmentFinanceManager.isLease(loan) then return tonumber(loan.balance) or 0 end
    local residual = tonumber(loan.residual) or 0
    if loan.status ~= "ACTIVE" then return residual end
    local term = math.max(1, tonumber(loan.term) or 1)
    local depreciation = ((tonumber(loan.price) or 0) - residual) / term
    return math.floor(residual + depreciation * FFR_EquipmentFinanceManager.getMonthsLeft(loan) + 0.5)
end

-- Fee to hand a leased machine back now (before hours): half the payments left.
function FFR_EquipmentFinanceManager.getReturnFee(loan)
    if loan.status ~= "ACTIVE" then return 0 end
    return math.floor((tonumber(loan.payment) or 0) * FFR_EquipmentFinanceManager.getMonthsLeft(loan)
        * FFR_EquipmentFinanceManager.EARLY_RETURN_SHARE + 0.5)
end

-- Copies the open contracts' totals into the farm's books.
function FFR_EquipmentFinanceManager.syncTotals(state)
    local m = FFR_EquipmentFinanceManager
    local debt, principal, leaseCost, leaseDebt = 0, 0, 0, 0
    for _, loan in ipairs(m.getLoans(state)) do
        if m.isActive(loan) then
            if m.isLease(loan) then
                leaseCost = leaseCost + (tonumber(loan.payment) or 0)
                leaseDebt = leaseDebt + m.getOwed(loan)
            else
                local balance = tonumber(loan.balance) or 0
                debt = debt + balance
                principal = principal + math.min(tonumber(loan.principal) or 0, balance)
            end
        end
    end
    local f = state.financialManager
    f.equipmentDebt, f.monthlyEquipmentPayment = debt, principal
    f.monthlyLeaseCost, f.leaseDebt = leaseCost, leaseDebt
    f:update()
end

function FFR_EquipmentFinanceManager.closeLoan(state, loan, status)
    loan.status, loan.balance = status, 0
    local loans, closed = FFR_EquipmentFinanceManager.getLoans(state), 0
    for i = #loans, 1, -1 do
        if not FFR_EquipmentFinanceManager.isOpen(loans[i]) then
            closed = closed + 1
            if closed > FFR_EquipmentFinanceManager.KEEP_CLOSED then table.remove(loans, i) end
        end
    end
end

-- After any change: books, credit, save and sync.
function FFR_EquipmentFinanceManager.afterChange(state)
    FFR_EquipmentFinanceManager.syncTotals(state)
    state.creditManager:update(state.financialManager)
    if g_FFR ~= nil and g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

function FFR_EquipmentFinanceManager.notify(state, text)
    Logging.info("FFR Equipment Finance: Farm %d - %s", state.farmId, text)
    if FFR_CropDamageManager ~= nil then FFR_CropDamageManager.notify(state.farmId, text) end
end

--------------------------------------------------
-- Machines
--------------------------------------------------

function FFR_EquipmentFinanceManager.getVehicleId(vehicle)
    if vehicle == nil then return nil end
    if vehicle.getUniqueId ~= nil then
        local ok, id = pcall(vehicle.getUniqueId, vehicle)
        if ok and id ~= nil and id ~= "" then return tostring(id) end
    end
    if vehicle.uniqueId ~= nil and vehicle.uniqueId ~= "" then return tostring(vehicle.uniqueId) end
    return nil
end

-- The contract's machines that are still in the game.
function FFR_EquipmentFinanceManager.findVehicles(loan)
    local found = {}
    local vehicles = g_currentMission ~= nil and g_currentMission.vehicleSystem ~= nil and g_currentMission.vehicleSystem.vehicles or nil
    if type(vehicles) ~= "table" or (loan.vehicleIds or "") == "" then return found end
    local wanted = {}
    for id in string.gmatch(loan.vehicleIds, "[^;]+") do wanted[id] = true end
    for _, vehicle in pairs(vehicles) do
        local id = FFR_EquipmentFinanceManager.getVehicleId(vehicle)
        if id ~= nil and wanted[id] and vehicle.isDeleted ~= true then table.insert(found, vehicle) end
    end
    return found
end

-- Operating hours of a machine (FS25 keeps operating time in milliseconds).
function FFR_EquipmentFinanceManager.getHours(vehicle)
    if vehicle == nil then return 0 end
    local ms = nil
    if vehicle.getOperatingTime ~= nil then
        local ok, value = pcall(vehicle.getOperatingTime, vehicle)
        if ok then ms = tonumber(value) end
    end
    ms = ms or tonumber(vehicle.operatingTime) or 0
    return ms / 3600000
end

-- Hours above a lease's allowance so far (allowance grows with months paid, at
-- the days per month the save uses when the machine goes back).
function FFR_EquipmentFinanceManager.getOverHours(loan, vehicles)
    local used = 0
    for _, vehicle in ipairs(vehicles) do used = math.max(used, FFR_EquipmentFinanceManager.getHours(vehicle)) end
    used = used - (tonumber(loan.startHours) or 0)
    local months = math.min(tonumber(loan.term) or 0, math.max(1, tonumber(loan.paidMonths) or 0))
    return math.max(0, used - FFR_EquipmentFinanceManager.getHoursPerYear() * months / 12)
end

function FFR_EquipmentFinanceManager.isInUse(vehicles)
    for _, vehicle in ipairs(vehicles) do
        if FFR_InsolvencyManager ~= nil and FFR_InsolvencyManager.isVehicleInUse(vehicle) then return true end
    end
    return false
end

function FFR_EquipmentFinanceManager.removeVehicles(vehicles)
    for _, vehicle in ipairs(vehicles) do
        local ok, err = pcall(FFR_InsolvencyManager.removeVehicle, vehicle)
        if not ok then Logging.warning("FFR Equipment Finance: Could not remove a machine (%s)", tostring(err)) end
    end
end

--------------------------------------------------
-- Actions (server, farm managers via FFR_Network)
--------------------------------------------------

-- Approves a deal for the purchase that follows. args: kind, xml, price, down, term.
function FFR_EquipmentFinanceManager.prepare(state, args)
    local item = nil
    if g_storeManager ~= nil and g_storeManager.getItemByXMLFilename ~= nil and args.xml ~= nil then
        local ok, result = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, args.xml)
        item = ok and result or nil
    end
    if item == nil then return false, FFR_L10n.t("ffr_finance_unavailable") end
    local kind = args.kind == "LEASE" and "LEASE" or "FINANCE"
    local down, term = tonumber(args.down) or 0, tonumber(args.term) or 0
    local ok, message = FFR_EquipmentFinanceManager.check(state, kind, args.price, down, term)
    if not ok then return false, message end
    FFR_EquipmentFinanceManager.pending[state.farmId] = {kind = kind, xml = args.xml, down = down, term = term, time = g_time or 0}
    Logging.info("FFR Equipment Finance: Farm %d %s deal prepared (%s, %d %% down, %d months)", state.farmId, kind,
        tostring(args.xml), math.floor(down * 100 + 0.5), term)
    return true, FFR_L10n.t("ffr_finance_prepared")
end

function FFR_EquipmentFinanceManager.takePending(farmId, xml)
    local deal = FFR_EquipmentFinanceManager.pending[farmId]
    if deal == nil or deal.xml ~= xml then return nil end
    FFR_EquipmentFinanceManager.pending[farmId] = nil
    if (g_time or 0) - (tonumber(deal.time) or 0) > FFR_EquipmentFinanceManager.PENDING_MS then
        Logging.warning("FFR Equipment Finance: Farm %d deal expired before the purchase", farmId)
        return nil
    end
    return deal
end

function FFR_EquipmentFinanceManager.openLoan(state, deal, vehicles)
    local m = FFR_EquipmentFinanceManager
    local ids = {}
    for _, vehicle in ipairs(vehicles or {}) do
        local id = m.getVehicleId(vehicle)
        if id ~= nil then table.insert(ids, id) end
    end
    local _, period, year = m.getSerial()
    state.nextEquipmentLoanId = (tonumber(state.nextEquipmentLoanId) or 1)
    local loan = {
        id = state.nextEquipmentLoanId, kind = deal.kind, xml = deal.xml, name = deal.name, vehicleIds = table.concat(ids, ";"),
        price = deal.fullPrice, downPayment = deal.dueToday, term = deal.term, paidMonths = 0,
        rate = m.getRate(state), startPeriod = period or 0, startYear = year or 0, status = "ACTIVE",
        startHours = vehicles ~= nil and m.getHours(vehicles[1]) or 0
    }
    local text
    if deal.kind == "LEASE" then
        local q = m.getLeaseQuote(state, deal.fullPrice, deal.term)
        -- The first payment was paid in the shop.
        loan.payment, loan.residual, loan.paidMonths = q.payment, q.residual, 1
        loan.financed, loan.balance, loan.principal = 0, 0, 0
        text = FFR_L10n.t("ffr_lease_opened", m.getDisplayName(loan), m.formatMoney(q.payment), FFR_L10n.months(deal.term),
            m.formatMoney(q.residual))
    else
        local financed = math.max(0, deal.fullPrice - deal.dueToday)
        loan.financed, loan.balance, loan.principal = financed, financed, financed / deal.term
        loan.payment, loan.residual = 0, 0
        state.bankingManager.totalBorrowed = (tonumber(state.bankingManager.totalBorrowed) or 0) + financed
        text = FFR_L10n.t("ffr_finance_opened", m.getDisplayName(loan), m.formatMoney(deal.dueToday),
            m.formatMoney(financed), FFR_L10n.months(deal.term))
    end
    state.nextEquipmentLoanId = loan.id + 1
    table.insert(m.getLoans(state), loan)
    m.afterChange(state)
    if #ids == 0 then
        Logging.warning("FFR Equipment Finance: Contract %d has no machine id; a sale will not settle it", loan.id)
    end
    m.notify(state, text)
end

-- Month end, after the bills were charged (FFR_MonthlyFinancialProcessor):
-- finance principal comes off each balance, lease payments are counted, and a
-- lease that ended a month ago without a decision goes back to the dealer.
function FFR_EquipmentFinanceManager.applyMonthlyPayments(state)
    local m = FFR_EquipmentFinanceManager
    -- Bills are charged on day 1 of the new month (period); a lease ending now
    -- may be bought out or returned until the end of this month.
    local serial, period = m.getSerial()
    -- Copies: settling a contract can drop closed ones from the farm's list.
    for _, loan in ipairs(m.getSortedLoans(state)) do
        if m.isLease(loan) and loan.status == "ENDED" and serial >= (tonumber(loan.endSerial) or 0) then
            local ok, message = m.returnLease(state, loan.id, true)
            if ok then m.notify(state, message) end
        end
    end
    for _, loan in ipairs(m.getSortedLoans(state)) do
        if m.isActive(loan) then
            loan.paidMonths = (tonumber(loan.paidMonths) or 0) + 1
            if m.isLease(loan) then
                if loan.paidMonths >= (tonumber(loan.term) or 0) then
                    loan.status, loan.endSerial = "ENDED", serial + 1
                    m.notify(state, FFR_L10n.t("ffr_lease_ended", m.getDisplayName(loan), m.formatMoney(loan.residual),
                        FFR_L10n.monthName(period or 1)))
                end
            else
                local balance = tonumber(loan.balance) or 0
                loan.balance = math.max(0, balance - math.min(tonumber(loan.principal) or 0, balance))
                if loan.balance < 0.01 then
                    m.closeLoan(state, loan, "PAID")
                    Logging.info("FFR Equipment Finance: Farm %d loan %d paid off", state.farmId, loan.id)
                end
            end
        end
    end
    m.syncTotals(state)
end

-- Pay off a finance loan, or buy out a lease (residual, plus the payments'
-- value left while it is still running).
function FFR_EquipmentFinanceManager.payOff(state, loanId)
    local m = FFR_EquipmentFinanceManager
    local loan = m.findLoan(state, loanId)
    if not m.isOpen(loan) then return false, FFR_L10n.t("ffr_finance_no_loan") end
    local amount = m.getSettlement(loan)
    if state.bankingManager:getCash(state.financialManager) < amount then
        return false, FFR_L10n.t("ffr_bank_not_enough_cash", m.formatMoney(amount))
    end
    if amount > 0 and not state.bankingManager:moveFarmMoney(-amount) then return false, FFR_L10n.t("ffr_bank_repay_failed") end
    m.closeLoan(state, loan, m.isLease(loan) and "BOUGHT" or "PAID")
    m.afterChange(state)
    Logging.info("FFR Equipment Finance: Farm %d settled contract %d ($%d)", state.farmId, loan.id, math.floor(amount))
    return true, FFR_L10n.t(m.isLease(loan) and "ffr_lease_bought" or "ffr_finance_paid_off", m.getDisplayName(loan), m.formatMoney(amount))
end

-- Hand a leased machine back: early (fee: half the payments left) or at the end,
-- plus hours above the allowance. automatic: the decision month ran out.
function FFR_EquipmentFinanceManager.returnLease(state, loanId, automatic)
    local m = FFR_EquipmentFinanceManager
    local loan = m.findLoan(state, loanId)
    if not m.isOpen(loan) or not m.isLease(loan) then return false, FFR_L10n.t("ffr_lease_not_lease") end
    local vehicles = m.findVehicles(loan)
    if not automatic and m.isInUse(vehicles) then return false, FFR_L10n.t("ffr_lease_in_use") end
    local overHours = m.getOverHours(loan, vehicles)
    local fee = m.getReturnFee(loan) + math.floor(overHours * (tonumber(loan.price) or 0) * m.OVERAGE_RATE + 0.5)
    if fee > 0 and not state.bankingManager:moveFarmMoney(-fee) then return false, FFR_L10n.t("ffr_bank_repay_failed") end
    m.closeLoan(state, loan, "RETURNED")
    m.removeVehicles(vehicles)
    m.afterChange(state)
    Logging.info("FFR Equipment Finance: Farm %d returned lease %d (fee $%d, %d hours over)", state.farmId, loan.id,
        fee, math.floor(overHours))
    return true, FFR_L10n.t(automatic and "ffr_lease_returned_auto" or "ffr_lease_returned", m.getDisplayName(loan), m.formatMoney(fee))
end

-- Forced sale (FFR_InsolvencyManager): the bank takes back every financed and
-- leased machine first. A financed machine's value pays its loan; what is left
-- goes to the farm, a shortfall is charged. A lease simply ends.
-- Returns money raised (can be negative) and contracts settled.
function FFR_EquipmentFinanceManager.repossessAll(state)
    local m = FFR_EquipmentFinanceManager
    local sync = g_FFRContinuousAssetSyncManager
    local raised, count = 0, 0
    for _, loan in ipairs(m.getSortedLoans(state)) do
        if m.isOpen(loan) then
            local vehicles = m.findVehicles(loan)
            if #vehicles > 0 and not m.isInUse(vehicles) then
                local net = 0
                if not m.isLease(loan) then
                    local value = 0
                    for _, vehicle in ipairs(vehicles) do
                        value = value + (sync ~= nil and tonumber(sync:getVehicleValue(vehicle)) or 0)
                    end
                    net = math.floor(value - (tonumber(loan.balance) or 0) + 0.5)
                end
                m.closeLoan(state, loan, "REPOSSESSED")
                m.removeVehicles(vehicles)
                if net ~= 0 and g_FFRMonthlyFinancialProcessor ~= nil then
                    g_FFRMonthlyFinancialProcessor:applyFarmBalance(net, MoneyType ~= nil and (MoneyType.SHOP_VEHICLE_SELL or MoneyType.OTHER) or nil, state.farmId)
                end
                raised, count = raised + net, count + 1
                Logging.warning("FFR Insolvency: Farm %d - bank took back %s (%s), net $%d", state.farmId,
                    tostring(loan.name), tostring(loan.kind), net)
            end
        end
    end
    if count > 0 then m.afterChange(state) end
    return raised, count
end

-- A financed or leased machine that is no longer on the farm (sold, removed)
-- settles its contract from the farm's cash, even if that overdraws the account.
function FFR_EquipmentFinanceManager.checkSales()
    local m = FFR_EquipmentFinanceManager
    local vehicles = g_currentMission ~= nil and g_currentMission.vehicleSystem ~= nil and g_currentMission.vehicleSystem.vehicles or nil
    if type(vehicles) ~= "table" then return end
    local present = {}
    for _, vehicle in pairs(vehicles) do
        local id = m.getVehicleId(vehicle)
        if id ~= nil and vehicle.isDeleted ~= true then present[id] = true end
    end
    for _, state in ipairs(g_FFR:getFarmStates()) do
        for _, loan in ipairs(m.getSortedLoans(state)) do
            if m.isOpen(loan) and (loan.vehicleIds or "") ~= "" then
                local found = false
                for id in string.gmatch(loan.vehicleIds, "[^;]+") do
                    if present[id] then found = true end
                end
                loan.missing = found and 0 or (tonumber(loan.missing) or 0) + 1
                if loan.missing >= 2 then
                    local amount = m.getSettlement(loan)
                    if amount <= 0 or state.bankingManager:moveFarmMoney(-amount) then
                        m.closeLoan(state, loan, "SOLD")
                        m.afterChange(state)
                        m.notify(state, FFR_L10n.t("ffr_finance_sold", m.getDisplayName(loan), m.formatMoney(amount)))
                    end
                end
            end
        end
    end
end

--------------------------------------------------
-- FS25 purchase hooks (server)
--------------------------------------------------

-- Before the machine is built: a prepared deal for this farm and machine is
-- priced at what is due today, from the server's own shop price.
function FFR_EquipmentFinanceManager.onBuy(buyData, ...)
    local m = FFR_EquipmentFinanceManager
    if not m.isServer() or buyData == nil or buyData.storeItem == nil or buyData.leaseVehicle then return end
    local deal = m.takePending(buyData.ownerFarmId, buyData.storeItem.xmlFilename)
    if deal == nil then return end
    if buyData.updatePrice ~= nil then pcall(buyData.updatePrice, buyData) end
    local fullPrice = tonumber(buyData.price) or 0
    local dueToday
    if deal.kind == "LEASE" then
        local state = g_FFR ~= nil and g_FFR:getFarmState(buyData.ownerFarmId) or nil
        dueToday = state ~= nil and m.getLeaseQuote(state, fullPrice, deal.term).dueToday or fullPrice
    else
        dueToday = math.floor(fullPrice * deal.down + 0.5)
    end
    if buyData.setPrice ~= nil then buyData:setPrice(dueToday) else buyData.price = dueToday end
    buyData.ffrFinance = {kind = deal.kind, xml = deal.xml, term = deal.term, fullPrice = fullPrice, dueToday = dueToday,
        name = m.getItemName(buyData.storeItem)}
    Logging.info("FFR Equipment Finance: Farm %d %s %s: $%d today of $%d", buyData.ownerFarmId, deal.kind,
        tostring(deal.xml), dueToday, math.floor(fullPrice))
end

-- After the machine is built: open the contract on it.
function FFR_EquipmentFinanceManager.onBought(buyData, vehicles, loadingState, ...)
    local deal = buyData ~= nil and buyData.ffrFinance or nil
    if deal == nil then return end
    buyData.ffrFinance = nil
    if VehicleLoadingState ~= nil and loadingState ~= nil and loadingState ~= VehicleLoadingState.OK then
        Logging.warning("FFR Equipment Finance: Purchase failed to load; no contract opened")
        return
    end
    local state = g_FFR ~= nil and g_FFR:getFarmState(buyData.ownerFarmId) or nil
    if state == nil then return end
    local ok, err = pcall(FFR_EquipmentFinanceManager.openLoan, state, deal, vehicles)
    if not ok then Logging.warning("FFR Equipment Finance: Could not open the contract (%s)", tostring(err)) end
end

function FFR_EquipmentFinanceManager.install()
    if BuyVehicleData == nil or BuyVehicleData.buy == nil or BuyVehicleData.onBought == nil then
        Logging.warning("FFR Equipment Finance: BuyVehicleData not found; shop financing is off")
        return false
    end
    BuyVehicleData.buy = Utils.prependedFunction(BuyVehicleData.buy, FFR_EquipmentFinanceManager.onBuy)
    BuyVehicleData.onBought = Utils.appendedFunction(BuyVehicleData.onBought, FFR_EquipmentFinanceManager.onBought)
    FFR_EquipmentFinanceManager.installed = true
    return true
end

--------------------------------------------------
-- Save / load per farm (called by FFR_SaveManager)
--------------------------------------------------

FFR_EquipmentFinanceManager.NUMBER_FIELDS = {
    "id", "price", "downPayment", "financed", "balance", "principal", "term", "paidMonths", "rate", "startPeriod", "startYear",
    "payment", "residual", "startHours", "endSerial"
}
FFR_EquipmentFinanceManager.STRING_FIELDS = {"kind", "xml", "name", "vehicleIds", "status"}

function FFR_EquipmentFinanceManager.saveFarm(xmlFile, key, state)
    setXMLInt(xmlFile, key .. "#nextId", math.floor(tonumber(state.nextEquipmentLoanId) or 1))
    for i, loan in ipairs(FFR_EquipmentFinanceManager.getLoans(state)) do
        local base = string.format("%s.loan(%d)", key, i - 1)
        for _, f in ipairs(FFR_EquipmentFinanceManager.STRING_FIELDS) do setXMLString(xmlFile, base .. "#" .. f, tostring(loan[f] or "")) end
        for _, f in ipairs(FFR_EquipmentFinanceManager.NUMBER_FIELDS) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(loan[f]) or 0) end
    end
end

function FFR_EquipmentFinanceManager.loadFarm(xmlFile, key, state)
    state.equipmentLoans = {}
    state.nextEquipmentLoanId = getXMLInt(xmlFile, key .. "#nextId") or 1
    local i = 0
    while hasXMLProperty(xmlFile, string.format("%s.loan(%d)", key, i)) do
        local base = string.format("%s.loan(%d)", key, i)
        local loan = {}
        for _, f in ipairs(FFR_EquipmentFinanceManager.STRING_FIELDS) do loan[f] = getXMLString(xmlFile, base .. "#" .. f) or "" end
        for _, f in ipairs(FFR_EquipmentFinanceManager.NUMBER_FIELDS) do loan[f] = getXMLFloat(xmlFile, base .. "#" .. f) or 0 end
        if loan.status == "" then loan.status = "ACTIVE" end
        -- v0.9.39 saves had finance loans only.
        if loan.kind == "" then loan.kind = "FINANCE" end
        table.insert(state.equipmentLoans, loan)
        i = i + 1
    end
    -- The contracts are the record; the financial totals follow them.
    FFR_EquipmentFinanceManager.syncTotals(state)
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_EquipmentFinanceManager:update(dt)
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted or not g_FFR.hasPrintedFinalReports then return end
    if not FFR_EquipmentFinanceManager.isServer() then return end
    if FFR_EquipmentFinanceManager.readyTimer < FFR_EquipmentFinanceManager.STARTUP_GRACE_MS then
        FFR_EquipmentFinanceManager.readyTimer = FFR_EquipmentFinanceManager.readyTimer + dt
        return
    end
    FFR_EquipmentFinanceManager.updateTimer = FFR_EquipmentFinanceManager.updateTimer + dt
    if FFR_EquipmentFinanceManager.updateTimer < FFR_EquipmentFinanceManager.SALE_CHECK_MS then return end
    FFR_EquipmentFinanceManager.updateTimer = 0
    local ok, err = pcall(FFR_EquipmentFinanceManager.checkSales)
    if not ok then Logging.warning("FFR Equipment Finance: Sale check failed (%s)", tostring(err)) end
end

function FFR_EquipmentFinanceManager:loadMap(mapName)
    FFR_EquipmentFinanceManager.pending = {}
    FFR_EquipmentFinanceManager.updateTimer = 0
    FFR_EquipmentFinanceManager.readyTimer = 0
end
function FFR_EquipmentFinanceManager:deleteMap() FFR_EquipmentFinanceManager.pending = {} end
function FFR_EquipmentFinanceManager:draw() end
function FFR_EquipmentFinanceManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_EquipmentFinanceManager:keyEvent(unicode, sym, modifier, isDown) end

FFR_EquipmentFinanceManager.install()
addModEventListener(FFR_EquipmentFinanceManager)
Logging.info("FFR Equipment Finance: Shop financing and leases installed")
