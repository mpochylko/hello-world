FFR_FamilyManager = {}

function FFR_FamilyManager:new()
    local self = {}
    setmetatable(self, {__index = FFR_FamilyManager})

    self.adults = 2
    self.children = 2
    self.universityStudents = 0
    self.personalVehicles = 2
    self.housingLevel = "STANDARD"
    self.activityLevel = "MODERATE"

    self.householdType = "custom"
    self.familyMembers = 4

    self.mortgageCost = 0
    self.utilityCost = 0
    self.foodCost = 0
    self.vehicleCost = 0
    self.healthCost = 0
    self.recreationCost = 0
    self.sportsCost = 0
    self.tuitionCost = 0
    self.totalMonthlyCost = 0

    self.totalFamilyExpenses = 0
    self.totalRandomEvents = 0
    self.lastEvent = "None"
    self.lastEventCost = 0

    self.fileName = "FFR_household.xml"
    self:recalculate()
    return self
end

function FFR_FamilyManager:clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, math.floor(tonumber(value) or minimum)))
end

function FFR_FamilyManager:getSavePath()
    if g_currentMission == nil or g_currentMission.missionInfo == nil then return nil end
    local directory = g_currentMission.missionInfo.savegameDirectory
    if directory == nil or directory == "" then return nil end
    return directory .. "/" .. self.fileName
end

function FFR_FamilyManager:getHousingValues()
    if self.housingLevel == "BASIC" then return 900, 360 end
    if self.housingLevel == "PREMIUM" then return 2200, 760 end
    return 1500, 550
end

function FFR_FamilyManager:getActivityValues()
    if self.activityLevel == "LOW" then return 250, 0 end
    if self.activityLevel == "HIGH" then return 850, 175 end
    return 500, 75
end

function FFR_FamilyManager:recalculate()
    self.adults = self:clamp(self.adults, 1, 4)
    self.children = self:clamp(self.children, 0, 6)
    self.universityStudents = self:clamp(self.universityStudents, 0, 4)
    self.personalVehicles = self:clamp(self.personalVehicles, 0, 5)
    self.familyMembers = self.adults + self.children + self.universityStudents

    self.mortgageCost, self.utilityCost = self:getHousingValues()
    self.foodCost = self.adults * 350 + self.children * 260 + self.universityStudents * 400
    self.vehicleCost = self.personalVehicles * 375
    self.healthCost = self.adults * 75 + self.children * 50 + self.universityStudents * 65

    local recreationBase, sportsPerChild = self:getActivityValues()
    self.recreationCost = recreationBase
    self.sportsCost = self.children * sportsPerChild
    self.tuitionCost = self.universityStudents * 1000

    -- Difficulty preset: every line scales, so the budget still adds up.
    local scale = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("household")) or 1) or 1
    if scale ~= 1 then
        self.mortgageCost, self.utilityCost = self.mortgageCost * scale, self.utilityCost * scale
        self.foodCost, self.vehicleCost = self.foodCost * scale, self.vehicleCost * scale
        self.healthCost, self.recreationCost = self.healthCost * scale, self.recreationCost * scale
        self.sportsCost, self.tuitionCost = self.sportsCost * scale, self.tuitionCost * scale
    end

    self.totalMonthlyCost = self.mortgageCost + self.utilityCost + self.foodCost
        + self.vehicleCost + self.healthCost + self.recreationCost
        + self.sportsCost + self.tuitionCost

    -- Each household belongs to one farm's profile (set by FFR_FarmState).
    if self.farmState ~= nil then
        self.farmState.financialManager.monthlyHouseholdCost = self.totalMonthlyCost
    end
end

-- Per-farm household, stored inside FFR_economy.xml under the farm's key.
function FFR_FamilyManager:saveToXML(xml, key)
    setXMLInt(xml, key .. "#adults", self.adults)
    setXMLInt(xml, key .. "#children", self.children)
    setXMLInt(xml, key .. "#universityStudents", self.universityStudents)
    setXMLInt(xml, key .. "#personalVehicles", self.personalVehicles)
    setXMLString(xml, key .. "#housingLevel", self.housingLevel)
    setXMLString(xml, key .. "#activityLevel", self.activityLevel)
    setXMLFloat(xml, key .. "#totalFamilyExpenses", self.totalFamilyExpenses)
    setXMLInt(xml, key .. "#totalRandomEvents", self.totalRandomEvents)
    setXMLString(xml, key .. "#lastEvent", self.lastEvent)
    setXMLFloat(xml, key .. "#lastEventCost", self.lastEventCost)
end

function FFR_FamilyManager:loadFromXML(xml, key)
    if not hasXMLProperty(xml, key) then return false end
    self.adults = getXMLInt(xml, key .. "#adults") or self.adults
    self.children = getXMLInt(xml, key .. "#children") or self.children
    self.universityStudents = getXMLInt(xml, key .. "#universityStudents") or self.universityStudents
    self.personalVehicles = getXMLInt(xml, key .. "#personalVehicles") or self.personalVehicles
    self.housingLevel = getXMLString(xml, key .. "#housingLevel") or self.housingLevel
    self.activityLevel = getXMLString(xml, key .. "#activityLevel") or self.activityLevel
    self.totalFamilyExpenses = getXMLFloat(xml, key .. "#totalFamilyExpenses") or 0
    self.totalRandomEvents = getXMLInt(xml, key .. "#totalRandomEvents") or 0
    self.lastEvent = getXMLString(xml, key .. "#lastEvent") or "None"
    self.lastEventCost = getXMLFloat(xml, key .. "#lastEventCost") or 0
    self.householdType = "custom"
    self:recalculate()
    return true
end

function FFR_FamilyManager:setHouseholdType(householdType)
    if householdType == "single" then
        self.adults, self.children, self.universityStudents, self.personalVehicles = 1, 0, 0, 1
    elseif householdType == "couple" then
        self.adults, self.children, self.universityStudents, self.personalVehicles = 2, 0, 0, 2
    elseif householdType == "family1" then
        self.adults, self.children, self.universityStudents, self.personalVehicles = 2, 1, 0, 2
    elseif householdType == "family3" then
        self.adults, self.children, self.universityStudents, self.personalVehicles = 2, 3, 0, 2
    else
        self.adults, self.children, self.universityStudents, self.personalVehicles = 2, 2, 0, 2
    end
    self.householdType = householdType or "custom"
    self.housingLevel = "STANDARD"
    self.activityLevel = "MODERATE"
    self:recalculate()
end

function FFR_FamilyManager:updateMonthlyCost()
    self:recalculate()
end

function FFR_FamilyManager:changeSetting(setting, direction)
    direction = tonumber(direction) or 0
    if setting == "ADULTS" then self.adults = self:clamp(self.adults + direction, 1, 4)
    elseif setting == "CHILDREN" then self.children = self:clamp(self.children + direction, 0, 6)
    elseif setting == "STUDENTS" then self.universityStudents = self:clamp(self.universityStudents + direction, 0, 4)
    elseif setting == "VEHICLES" then self.personalVehicles = self:clamp(self.personalVehicles + direction, 0, 5)
    elseif setting == "HOUSING" then
        local values = {"BASIC", "STANDARD", "PREMIUM"}
        local index = 2
        for i, value in ipairs(values) do if value == self.housingLevel then index = i end end
        index = index + direction
        if index < 1 then index = #values elseif index > #values then index = 1 end
        self.housingLevel = values[index]
    elseif setting == "ACTIVITIES" then
        local values = {"LOW", "MODERATE", "HIGH"}
        local index = 2
        for i, value in ipairs(values) do if value == self.activityLevel then index = i end end
        index = index + direction
        if index < 1 then index = #values elseif index > #values then index = 1 end
        self.activityLevel = values[index]
    end
    self.householdType = "custom"
    self:recalculate()
    self:markDirty()
end

-- Written with the next native save (see FFR_SaveToXMLFile in FFR.lua).
function FFR_FamilyManager:markDirty()
    if g_FFR ~= nil and g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
end

-- Default household: one adult, no children or students, one vehicle,
-- lowest spending (basic housing, low activities). New farms start here.
function FFR_FamilyManager:applyDefault()
    self.adults = 1
    self.children = 0
    self.universityStudents = 0
    self.personalVehicles = 1
    self.housingLevel = "BASIC"
    self.activityLevel = "LOW"
    self.householdType = "default"
    self:recalculate()
end

function FFR_FamilyManager:resetDefault()
    self:applyDefault()
    self:markDirty()
end

-- Households are saved per farm inside FFR_economy.xml (saveToXML). load() below
-- only reads the FFR_household.xml of saves before v0.9.9, for migration.
function FFR_FamilyManager:load()
    local path = self:getSavePath()
    if path == nil or fileExists == nil or not fileExists(path) then
        self:recalculate()
        return false
    end
    local xml = loadXMLFile("FFRHousehold", path)
    if xml == nil or xml == 0 then return false end
    self.adults = getXMLInt(xml, "ffrHousehold.profile#adults") or self.adults
    self.children = getXMLInt(xml, "ffrHousehold.profile#children") or self.children
    self.universityStudents = getXMLInt(xml, "ffrHousehold.profile#universityStudents") or self.universityStudents
    self.personalVehicles = getXMLInt(xml, "ffrHousehold.profile#personalVehicles") or self.personalVehicles
    self.housingLevel = getXMLString(xml, "ffrHousehold.profile#housingLevel") or self.housingLevel
    self.activityLevel = getXMLString(xml, "ffrHousehold.profile#activityLevel") or self.activityLevel
    self.totalFamilyExpenses = getXMLFloat(xml, "ffrHousehold.history#totalFamilyExpenses") or 0
    self.totalRandomEvents = getXMLInt(xml, "ffrHousehold.history#totalRandomEvents") or 0
    self.lastEvent = getXMLString(xml, "ffrHousehold.history#lastEvent") or "None"
    self.lastEventCost = getXMLFloat(xml, "ffrHousehold.history#lastEventCost") or 0
    delete(xml)
    self:recalculate()
    Logging.info("FFR Household: Configuration restored")
    return true
end

function FFR_FamilyManager:processMonth(financialManager)
    self:recalculate()
    if financialManager ~= nil and financialManager.removeCash ~= nil then
        financialManager:removeCash(self.totalMonthlyCost)
    end
    self.totalFamilyExpenses = self.totalFamilyExpenses + self.totalMonthlyCost
    self:markDirty()
end

function FFR_FamilyManager:getRandomEvents()
    -- name: translation key ffr_house_event_<name> (saved as lastEvent).
    local events = {
        {name="vacation", amount=5000},
        {name="roof", amount=18000},
        {name="breakdown", amount=3500},
        {name="vehicle", amount=45000},
        {name="appliance", amount=1800},
        {name="medical", amount=2500}
    }
    if self.universityStudents > 0 then table.insert(events, {name="tuition", amount=3000 * self.universityStudents}) end
    if self.children > 0 then table.insert(events, {name="sports", amount=750 * self.children}) end
    return events
end

function FFR_FamilyManager:generateRandomEvent(financialManager)
    local events = self:getRandomEvents()
    local selected = events[math.random(1, #events)]
    if financialManager ~= nil and financialManager.removeCash ~= nil then financialManager:removeCash(selected.amount) end
    self.totalRandomEvents = self.totalRandomEvents + 1
    self.lastEvent = selected.name
    self.lastEventCost = selected.amount
    self:markDirty()
    Logging.info("FFR Household Event: %s cost $%d", selected.name, selected.amount)
end

-- Housing BASIC / STANDARD / PREMIUM and activities LOW / MODERATE / HIGH, as shown.
function FFR_FamilyManager.getLevelName(level)
    return FFR_L10n.t("ffr_house_level_" .. string.lower(tostring(level or "")))
end

-- lastEvent is an event name (ffr_house_event_<name>); saves before v0.9.35
-- hold the English title, shown as it is.
function FFR_FamilyManager.getEventName(name)
    local key = "ffr_house_event_" .. string.lower(tostring(name or "none"))
    if FFR_L10n.hasText(key) then return FFR_L10n.t(key) end
    return tostring(name or "")
end

function FFR_FamilyManager:quarterlyReview(financialManager)
    if math.random(1, 100) <= 25 then self:generateRandomEvent(financialManager) end
end

function FFR_FamilyManager:printFamilyReport()
    Logging.info("FFR HOUSEHOLD: %d adults, %d children, %d students, %d vehicles, $%d monthly",
        self.adults, self.children, self.universityStudents, self.personalVehicles, math.floor(self.totalMonthlyCost))
end
