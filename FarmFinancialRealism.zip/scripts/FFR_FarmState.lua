FFR_FarmState = {}

--------------------------------------------------
-- One farm's financial profile
--
-- Every farm (not every player) has its own
-- finances, credit, assets, loans, insurance,
-- taxes, yearly history and household. Markets,
-- supplier deals, news and the contract book are
-- shared and live on g_FFR.
--
-- g_FFR.financialManager, g_FFR.creditManager, etc.
-- point at the local player's farm state so the
-- dashboard and overlay can keep using them. Server
-- logic must use g_FFR:getFarmState(farmId) instead.
--------------------------------------------------

-- Names copied onto g_FFR for the local player's farm.
FFR_FarmState.ALIASES = {
    "financialManager",
    "creditManager",
    "assetManager",
    "bankingManager",
    "insuranceManager",
    "taxManager",
    "yearManager",
    "familyManager"
}

function FFR_FarmState.new(farmId)

    local self = {
        farmId = farmId,
        financialManager = FFR_FinancialManager:new(),
        creditManager = FFR_CreditManager:new(),
        assetManager = FFR_AssetManager:new(),
        bankingManager = FFR_BankingManager:new(),
        insuranceManager = FFR_InsuranceManager:new(),
        taxManager = FFR_TaxManager:new(),
        yearManager = FFR_YearManager:new(),
        familyManager = FFR_FamilyManager:new(),

        -- Last monthly FFR charge, for the Farm Status page.
        lastMonthlyTotal = 0,
        lastBreakdown = nil,

        -- Closed monthly statements and yearly results, oldest first
        -- (FFR_MonthlyFinancialProcessor:recordStatement / closeYear).
        statements = {},
        years = {},

        -- Crop insurance: one policy per crop year, and claims (FFR_CropInsuranceManager).
        cropPolicies = {},
        -- Land rented in and out (FFR_LandRentManager).
        landRentals = {},
        nextRentalId = 0,
        cropClaims = {},

        -- Livestock: mortality policy, claims and outbreak history (FFR_LivestockInsuranceManager).
        herdPolicy = nil,
        herdClaims = {},
        herdEvents = {},

        -- Machines financed in the shop (FFR_EquipmentFinanceManager).
        equipmentLoans = {},
        nextEquipmentLoanId = 1,

        -- True once a saved household was restored for this farm.
        householdLoaded = false,

        -- Change tracking for the asset sync logs.
        sync = {}
    }

    -- Let each manager find its farm (money changes, household cost).
    self.financialManager.farmId = farmId
    self.bankingManager.farmId = farmId
    self.familyManager.farmState = self
    self.familyManager:applyDefault()

    return self

end

--------------------------------------------------
-- Real farms
--
-- Farm ids from the game's farm manager, without
-- the spectator farm and without internal/helper
-- farms (the game or mods can register farms such
-- as farm 14 that no one plays). A farm is real if
-- it is the local player's farm, has players, or
-- owns land. Singleplayer has one farm.
--------------------------------------------------

-- Farms that own at least one farmland parcel.
function FFR_FarmState.getLandOwners()

    local owners = {}

    if g_farmlandManager == nil
        or g_farmlandManager.farmlands == nil
        or g_farmlandManager.getFarmlandOwner == nil
    then

        return owners

    end

    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do

        local ok, owner = pcall(
            g_farmlandManager.getFarmlandOwner,
            g_farmlandManager,
            type(farmland) == "table" and farmland.id or farmlandId
        )

        owner = ok and tonumber(owner) or nil

        if owner ~= nil and owner > 0 then
            owners[owner] = true
        end

    end

    return owners

end

function FFR_FarmState.hasPlayers(farm)

    for _, list in ipairs({farm.players, farm.activeUsers, farm.userIdToPlayer}) do

        if type(list) == "table" and next(list) ~= nil then
            return true
        end

    end

    return false

end

function FFR_FarmState.getGameFarmIds()

    local ids = {}

    if g_farmManager == nil then
        return ids
    end

    local spectator = 0

    if FarmManager ~= nil and FarmManager.SPECTATOR_FARM_ID ~= nil then
        spectator = FarmManager.SPECTATOR_FARM_ID
    end

    local farms = nil

    if g_farmManager.getFarms ~= nil then

        local ok, result = pcall(g_farmManager.getFarms, g_farmManager)

        if ok then
            farms = result
        end

    end

    farms = farms or g_farmManager.farms

    if type(farms) ~= "table" then
        return ids
    end

    local landOwners = FFR_FarmState.getLandOwners()

    local localFarmId = nil

    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then

        local ok, id = pcall(g_currentMission.getFarmId, g_currentMission)

        localFarmId = ok and tonumber(id) or nil

    end

    for _, farm in pairs(farms) do

        local farmId = type(farm) == "table" and tonumber(farm.farmId) or nil

        if farmId ~= nil
            and farmId > 0
            and farmId ~= spectator
            and (farmId == localFarmId
                or landOwners[farmId]
                or FFR_FarmState.hasPlayers(farm))
        then

            table.insert(ids, farmId)

        end

    end

    table.sort(ids)

    return ids

end

-- Default farm when the local player has none (dedicated server, early load).
function FFR_FarmState.getDefaultFarmId()

    if FarmManager ~= nil and FarmManager.SINGLEPLAYER_FARM_ID ~= nil then
        return FarmManager.SINGLEPLAYER_FARM_ID
    end

    return 1

end
