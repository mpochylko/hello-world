FFR_FinancialManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_FinancialManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_FinancialManager}
    )

    --------------------------------------------------
    -- Cash and Liquidity
    --------------------------------------------------

    self.cashOnHand = 0

    self.availableCredit = 0

    self.workingCapital = 0

    --------------------------------------------------
    -- Debt
    --------------------------------------------------

    self.operatingLoan = 0

    self.equipmentDebt = 0

    -- Lease payments still owed (FFR_EquipmentFinanceManager).
    self.leaseDebt = 0

    self.landDebt = 0

    self.totalDebt = 0

    --------------------------------------------------
    -- Non-Cash Assets
    --------------------------------------------------

    self.landValue = 0

    self.equipmentValue = 0

    self.buildingValue = 0

    self.inventoryValue = 0

    self.totalNonCashAssets = 0

    --------------------------------------------------
    -- Total Assets and Equity
    --------------------------------------------------

    self.totalAssets = 0

    self.netWorth = 0

    --------------------------------------------------
    -- Monthly Obligations
    --------------------------------------------------

    self.monthlyLandPayment = 0

    self.monthlyEquipmentPayment = 0

    self.monthlyInterestCost = 0

    self.monthlyHouseholdCost = 0

    self.monthlyInsuranceCost = 0

    self.monthlyLeaseCost = 0

    self.monthlyTaxCost = 0

    self.totalMonthlyObligations = 0

    --------------------------------------------------
    -- Ratios
    --------------------------------------------------

    self.debtRatio = 0

    self.liquidityRatio = 0

    self.hasUnlimitedLiquidity = false

    --------------------------------------------------
    -- Revenue and Expense Tracking
    --------------------------------------------------

    self.monthlyRevenue = 0

    self.monthlyExpenses = 0

    self.monthlyNetCashFlow = 0

    self.annualRevenue = 0

    self.annualExpenses = 0

    self.annualProfit = 0

    return self

end

--------------------------------------------------
-- Safe Number Helper
--------------------------------------------------

function FFR_FinancialManager:getNumber(
    value
)

    return tonumber(value) or 0

end

--------------------------------------------------
-- Debt Calculation
--------------------------------------------------

function FFR_FinancialManager:updateDebt()

    self.totalDebt =

        self:getNumber(
            self.operatingLoan
        )

        + self:getNumber(
            self.equipmentDebt
        )

        + self:getNumber(
            self.leaseDebt
        )

        + self:getNumber(
            self.landDebt
        )

end

--------------------------------------------------
-- Asset Calculation
--------------------------------------------------

function FFR_FinancialManager:updateAssets()

    self.totalNonCashAssets =

        self:getNumber(
            self.landValue
        )

        + self:getNumber(
            self.equipmentValue
        )

        + self:getNumber(
            self.buildingValue
        )

        + self:getNumber(
            self.inventoryValue
        )

    self.totalAssets =

        self:getNumber(
            self.cashOnHand
        )

        + self.totalNonCashAssets

end

--------------------------------------------------
-- Net Worth
--------------------------------------------------

function FFR_FinancialManager:updateNetWorth()

    self.netWorth =

        self:getNumber(
            self.totalAssets
        )

        - self:getNumber(
            self.totalDebt
        )

end

--------------------------------------------------
-- Monthly Obligations
--------------------------------------------------

function FFR_FinancialManager:updateMonthlyObligations()

    self.totalMonthlyObligations =

        self:getNumber(
            self.monthlyLandPayment
        )

        + self:getNumber(
            self.monthlyEquipmentPayment
        )

        + self:getNumber(
            self.monthlyInterestCost
        )

        + self:getNumber(
            self.monthlyHouseholdCost
        )

        + self:getNumber(
            self.monthlyInsuranceCost
        )

        + self:getNumber(
            self.monthlyLeaseCost
        )

        + self:getNumber(
            self.monthlyTaxCost
        )

end

--------------------------------------------------
-- Working Capital
--------------------------------------------------

function FFR_FinancialManager:updateWorkingCapital()

    self.workingCapital =

        self:getNumber(
            self.cashOnHand
        )

        - self:getNumber(
            self.totalMonthlyObligations
        )

end

--------------------------------------------------
-- Liquidity
--------------------------------------------------

function FFR_FinancialManager:updateLiquidity()

    local obligations =

        self:getNumber(
            self.totalMonthlyObligations
        )

    if obligations <= 0 then

        self.liquidityRatio = 0

        self.hasUnlimitedLiquidity =

            self:getNumber(
                self.cashOnHand
            ) > 0

        return

    end

    self.hasUnlimitedLiquidity = false

    self.liquidityRatio =

        self:getNumber(
            self.cashOnHand
        )

        / obligations

end

--------------------------------------------------
-- Debt Ratio
--------------------------------------------------

function FFR_FinancialManager:updateDebtRatio()

    local assets =

        self:getNumber(
            self.totalAssets
        )

    if assets <= 0 then

        if self.totalDebt > 0 then

            self.debtRatio = 1.00

        else

            self.debtRatio = 0

        end

        return

    end

    self.debtRatio =

        self:getNumber(
            self.totalDebt
        )

        / assets

end

--------------------------------------------------
-- Cash Flow Calculation
--------------------------------------------------

function FFR_FinancialManager:updateCashFlow()

    self.monthlyNetCashFlow =

        self:getNumber(
            self.monthlyRevenue
        )

        - self:getNumber(
            self.monthlyExpenses
        )

        - self:getNumber(
            self.totalMonthlyObligations
        )

end

--------------------------------------------------
-- Full Financial Update
--------------------------------------------------

function FFR_FinancialManager:update()

    self:updateDebt()

    self:updateAssets()

    self:updateNetWorth()

    self:updateMonthlyObligations()

    self:updateWorkingCapital()

    self:updateLiquidity()

    self:updateDebtRatio()

    self:updateCashFlow()

end

--------------------------------------------------
-- Household Profile
--------------------------------------------------

function FFR_FinancialManager:setHouseholdProfile(
    profile
)

    if profile == "single" then

        self.monthlyHouseholdCost = 2500

    elseif profile == "couple" then

        self.monthlyHouseholdCost = 4000

    elseif profile == "family1" then

        self.monthlyHouseholdCost = 5500

    elseif profile == "family2" then

        self.monthlyHouseholdCost = 6500

    elseif profile == "family3" then

        self.monthlyHouseholdCost = 8000

    else

        self.monthlyHouseholdCost = 6500

    end

    self:update()

end

--------------------------------------------------
-- Cash Adjustments
--------------------------------------------------

function FFR_FinancialManager:addCash(
    amount
)

    local safeAmount =
        self:getNumber(
            amount
        )

    self.cashOnHand =

        self:getNumber(
            self.cashOnHand
        )

        + safeAmount

end

function FFR_FinancialManager:removeCash(
    amount
)

    local safeAmount =
        self:getNumber(
            amount
        )

    self.cashOnHand =

        self:getNumber(
            self.cashOnHand
        )

        - safeAmount

end

--------------------------------------------------
-- Revenue Tracking
--------------------------------------------------

function FFR_FinancialManager:addRevenue(
    amount
)

    local safeAmount =
        self:getNumber(
            amount
        )

    self.monthlyRevenue =

        self:getNumber(
            self.monthlyRevenue
        )

        + safeAmount

    self.annualRevenue =

        self:getNumber(
            self.annualRevenue
        )

        + safeAmount

    self:addCash(
        safeAmount
    )

end

--------------------------------------------------
-- Expense Tracking
--------------------------------------------------

function FFR_FinancialManager:addExpense(
    amount
)

    local safeAmount =
        self:getNumber(
            amount
        )

    self.monthlyExpenses =

        self:getNumber(
            self.monthlyExpenses
        )

        + safeAmount

    self.annualExpenses =

        self:getNumber(
            self.annualExpenses
        )

        + safeAmount

    self:removeCash(
        safeAmount
    )

end

--------------------------------------------------
-- Annual Profit
--------------------------------------------------

function FFR_FinancialManager:updateAnnualProfit()

    self.annualProfit =

        self:getNumber(
            self.annualRevenue
        )

        - self:getNumber(
            self.annualExpenses
        )

end

--------------------------------------------------
-- Reset Monthly Tracking
--------------------------------------------------

function FFR_FinancialManager:resetMonthlyTracking()

    self.monthlyRevenue = 0

    self.monthlyExpenses = 0

    self.monthlyNetCashFlow = 0

end

--------------------------------------------------
-- Reset Annual Tracking
--------------------------------------------------

function FFR_FinancialManager:resetAnnualTracking()

    self.annualRevenue = 0

    self.annualExpenses = 0

    self.annualProfit = 0

end

--------------------------------------------------
-- Monthly Financial Statement
--------------------------------------------------

function FFR_FinancialManager:printFinancialStatement()

    self:update()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR MONTHLY FINANCIAL STATEMENT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Cash: $%d",
        math.floor(
            self.cashOnHand
        )
    )

    Logging.info(
        "Land Value: $%d",
        math.floor(
            self.landValue
        )
    )

    Logging.info(
        "Equipment Value: $%d",
        math.floor(
            self.equipmentValue
        )
    )

    Logging.info(
        "Building Value: $%d",
        math.floor(
            self.buildingValue
        )
    )

    Logging.info(
        "Inventory Value: $%d",
        math.floor(
            self.inventoryValue
        )
    )

    Logging.info(
        "Non-Cash Assets: $%d",
        math.floor(
            self.totalNonCashAssets
        )
    )

    Logging.info(
        "Total Assets: $%d",
        math.floor(
            self.totalAssets
        )
    )

    Logging.info(
        "Total Debt: $%d",
        math.floor(
            self.totalDebt
        )
    )

    Logging.info(
        "Net Worth: $%d",
        math.floor(
            self.netWorth
        )
    )

    Logging.info(
        "Working Capital: $%d",
        math.floor(
            self.workingCapital
        )
    )

    Logging.info(
        "Monthly Obligations: $%d",
        math.floor(
            self.totalMonthlyObligations
        )
    )

    Logging.info(
        "Monthly Revenue: $%d",
        math.floor(
            self.monthlyRevenue
        )
    )

    Logging.info(
        "Monthly Expenses: $%d",
        math.floor(
            self.monthlyExpenses
        )
    )

    Logging.info(
        "Monthly Net Cash Flow: $%d",
        math.floor(
            self.monthlyNetCashFlow
        )
    )

    Logging.info(
        "Debt Ratio: %.2f",
        self.debtRatio
    )

    if self.hasUnlimitedLiquidity then

        Logging.info(
            "Liquidity Ratio: N/A (no monthly obligations)"
        )

    else

        Logging.info(
            "Liquidity Ratio: %.2f",
            self.liquidityRatio
        )

    end

    Logging.info(
        "========================================"
    )

end