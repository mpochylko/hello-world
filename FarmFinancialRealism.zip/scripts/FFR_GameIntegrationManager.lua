FFR_GameIntegrationManager = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_GameIntegrationManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_GameIntegrationManager}
    )

    --------------------------------------------------
    -- Sync Status
    --------------------------------------------------

    self.landSynced = false
    self.vehiclesSynced = false
    self.animalsSynced = false
    self.moneySynced = false

    --------------------------------------------------
    -- Sync Timing
    --------------------------------------------------

    self.syncActive = false

    self.syncFinished = false

    self.syncTimer = 0

    self.syncInterval = 2000

    self.syncAttempts = 0

    self.maxSyncAttempts = 15

    --------------------------------------------------
    -- Totals
    --------------------------------------------------

    self.totalFarmlandValue = 0

    self.totalVehicleValue = 0

    self.totalAnimalValue = 0

    --------------------------------------------------
    -- Farm
    --------------------------------------------------

    self.activeFarmId = nil

    return self

end

--------------------------------------------------
-- Begin Deferred Synchronization
--------------------------------------------------

function FFR_GameIntegrationManager:beginDeferredSync()

    self.syncActive = true

    self.syncFinished = false

    self.syncTimer = 0

    self.syncAttempts = 0

    Logging.info(
        "FFR: Deferred game-data synchronization started"
    )

end

--------------------------------------------------
-- Get Active Farm ID
--------------------------------------------------

function FFR_GameIntegrationManager:getActiveFarmId()

    if g_currentMission == nil then
        return nil
    end

    local farmId = nil

    if g_currentMission.getFarmId ~= nil then

        farmId =
            g_currentMission:getFarmId()

    end

    if farmId == nil
        and g_currentMission.player ~= nil
    then

        farmId =
            g_currentMission.player.farmId

    end

    if farmId == nil
        and g_currentMission.playerSystem ~= nil
        and g_currentMission.playerSystem.getLocalPlayer ~= nil
    then

        local player =
            g_currentMission.playerSystem:getLocalPlayer()

        if player ~= nil then
            farmId = player.farmId
        end

    end

    if farmId ~= nil
        and farmId > 0
    then

        self.activeFarmId = farmId

        return farmId

    end

    return nil

end

--------------------------------------------------
-- Clear Asset Collections
--------------------------------------------------

function FFR_GameIntegrationManager:clearLandAssets(
    assetManager
)

    if assetManager == nil then
        return
    end

    assetManager.landAssets = {}

end

function FFR_GameIntegrationManager:clearEquipmentAssets(
    assetManager
)

    if assetManager == nil then
        return
    end

    assetManager.equipmentAssets = {}

end

--------------------------------------------------
-- Farmland Ownership Check
--------------------------------------------------

function FFR_GameIntegrationManager:isFarmlandOwnedByFarm(
    farmland,
    farmId,
    farmlandId
)

    if farmland == nil
        or farmId == nil
    then

        return false

    end

    --------------------------------------------------
    -- FS25 tracks ownership in the farmland manager,
    -- not on the farmland object itself.
    --------------------------------------------------

    if g_farmlandManager ~= nil
        and g_farmlandManager.getFarmlandOwner ~= nil
    then

        local success,
            ownerFarmId =

            pcall(
                g_farmlandManager.getFarmlandOwner,
                g_farmlandManager,
                farmland.id or farmlandId
            )

        if success
            and ownerFarmId ~= nil
        then

            -- Rented-out land stays the owner's asset; rented-in land is nobody's
            -- (FFR_LandRentManager).
            local holder = tonumber(ownerFarmId)

            if FFR_LandRentManager ~= nil then
                holder = FFR_LandRentManager.getAssetOwner(tonumber(farmland.id or farmlandId), holder)
            end

            return holder == farmId

        end

    end

    if farmland.farmId ~= nil then

        return farmland.farmId == farmId

    end

    if farmland.ownerFarmId ~= nil then

        return farmland.ownerFarmId == farmId

    end

    return false

end

--------------------------------------------------
-- Farmland Sync
--------------------------------------------------

function FFR_GameIntegrationManager:syncFarmland(
    assetManager
)

    if self.landSynced then
        return true
    end

    if assetManager == nil then
        return false
    end

    if g_farmlandManager == nil then
        return false
    end

    local farmlands =
        g_farmlandManager.farmlands

    if farmlands == nil then
        return false
    end

    local farmId =
        self:getActiveFarmId()

    if farmId == nil then
        return false
    end

    self:clearLandAssets(
        assetManager
    )

    local ownedCount = 0

    local totalValue = 0

    for farmlandId, farmland in pairs(
        farmlands
    ) do

        if self:isFarmlandOwnedByFarm(
            farmland,
            farmId,
            farmlandId
        ) then

            local price =
                tonumber(
                    farmland.price
                )
                or 0

            assetManager:addLandAsset(
                farmlandId,
                0,
                price
            )

            totalValue =
                totalValue + price

            ownedCount =
                ownedCount + 1

        end

    end

    self.totalFarmlandValue =
        totalValue

    self.landSynced = true

    Logging.info(
        "FFR Land Sync Complete: %d owned parcels, $%d",
        ownedCount,
        math.floor(totalValue)
    )

    return true

end

--------------------------------------------------
-- Get Mission Vehicles
--------------------------------------------------

function FFR_GameIntegrationManager:getMissionVehicles()

    if g_currentMission == nil then
        return nil
    end

    if g_currentMission.vehicleSystem ~= nil
        and g_currentMission.vehicleSystem.vehicles ~= nil
    then

        return g_currentMission.vehicleSystem.vehicles

    end

    if g_currentMission.vehicles ~= nil then

        return g_currentMission.vehicles

    end

    return nil

end

--------------------------------------------------
-- Vehicle Ownership Check
--------------------------------------------------

function FFR_GameIntegrationManager:isVehicleOwnedByFarm(
    vehicle,
    farmId
)

    if vehicle == nil
        or farmId == nil
    then

        return false
    end

    --------------------------------------------------
    -- Use the continuous sync rules so the first scan
    -- also skips pallets, leased and mission vehicles.
    --------------------------------------------------

    if g_FFRContinuousAssetSyncManager ~= nil
        and g_FFRContinuousAssetSyncManager.isVehicleOwnedByFarm ~= nil
    then

        return g_FFRContinuousAssetSyncManager:isVehicleOwnedByFarm(
            vehicle,
            farmId
        )

    end

    if vehicle.getOwnerFarmId ~= nil then

        local ownerFarmId =
            vehicle:getOwnerFarmId()

        return ownerFarmId == farmId

    end

    if vehicle.ownerFarmId ~= nil then

        return vehicle.ownerFarmId == farmId

    end

    return false

end

--------------------------------------------------
-- Vehicle Value
--------------------------------------------------

function FFR_GameIntegrationManager:getVehicleValue(
    vehicle
)

    if vehicle == nil then
        return 0
    end

    if vehicle.getSellPrice ~= nil then

        local success, value =
            pcall(
                vehicle.getSellPrice,
                vehicle
            )

        if success
            and value ~= nil
        then

            return tonumber(value) or 0

        end

    end

    if vehicle.price ~= nil then

        return tonumber(vehicle.price) or 0

    end

    if vehicle.configFileName ~= nil
        and g_storeManager ~= nil
        and g_storeManager.getItemByXMLFilename ~= nil
    then

        local storeItem =
            g_storeManager:getItemByXMLFilename(
                vehicle.configFileName
            )

        if storeItem ~= nil then

            return tonumber(
                storeItem.price
            )
            or 0

        end

    end

    return 0

end

--------------------------------------------------
-- Vehicle Sync
--------------------------------------------------

function FFR_GameIntegrationManager:syncVehicles(
    assetManager
)

    if self.vehiclesSynced then
        return true
    end

    if assetManager == nil then
        return false
    end

    local vehicles =
        self:getMissionVehicles()

    if vehicles == nil then
        return false
    end

    local farmId =
        self:getActiveFarmId()

    if farmId == nil then
        return false
    end

    self:clearEquipmentAssets(
        assetManager
    )

    local vehicleCount = 0

    local totalValue = 0

    for vehicleIndex, vehicle in pairs(
        vehicles
    ) do

        if self:isVehicleOwnedByFarm(
            vehicle,
            farmId
        ) then

            local name =
                "UNKNOWN"

            if vehicle.getName ~= nil then

                local success, result =
                    pcall(
                        vehicle.getName,
                        vehicle
                    )

                if success
                    and result ~= nil
                then

                    name =
                        tostring(result)

                end

            end

            local value =
                self:getVehicleValue(
                    vehicle
                )

            local assetId =
                tostring(vehicleIndex)

            if vehicle.id ~= nil then

                assetId =
                    tostring(vehicle.id)

            end

            assetManager:addEquipmentAsset(
                assetId,
                name,
                value
            )

            totalValue =
                totalValue + value

            vehicleCount =
                vehicleCount + 1

        end

    end

    self.totalVehicleValue =
        totalValue

    self.vehiclesSynced = true

    Logging.info(
        "FFR Vehicle Sync Complete: %d vehicles, $%d",
        vehicleCount,
        math.floor(totalValue)
    )

    return true

end

--------------------------------------------------
-- Animal Sync
--------------------------------------------------

function FFR_GameIntegrationManager:syncAnimals(
    livestockManager
)

    if self.animalsSynced then
        return true
    end

    --------------------------------------------------
    -- Livestock integration is optional in v0.5.1
    --------------------------------------------------

    if livestockManager == nil then

        self.animalsSynced = true

        Logging.info(
            "FFR Animal Sync Skipped: livestock manager not active"
        )

        return true

    end

    if g_currentMission == nil then
        return false
    end

    local husbandrySystem =
        g_currentMission.husbandrySystem

    if husbandrySystem == nil then
        return false
    end

    local husbandries =
        husbandrySystem.items

    if husbandries == nil then
        return false
    end

    local herdCount = 0

    for husbandryId, husbandry in pairs(
        husbandries
    ) do

        local animalCount = 0

        if husbandry.getNumOfAnimals ~= nil then

            local success, result =
                pcall(
                    husbandry.getNumOfAnimals,
                    husbandry
                )

            if success
                and result ~= nil
            then

                animalCount =
                    tonumber(result) or 0

            end

        end

        if animalCount > 0 then

            herdCount =
                herdCount + 1

            livestockManager:registerHerd(
                husbandryId,
                "CATTLE",
                animalCount
            )

        end

    end

    self.animalsSynced = true

    Logging.info(
        "FFR Animal Sync Complete: %d herds",
        herdCount
    )

    return true

end

--------------------------------------------------
-- Money Sync
--------------------------------------------------

function FFR_GameIntegrationManager:syncMoney(
    financialManager
)

    if self.moneySynced then
        return true
    end

    if financialManager == nil then
        return false
    end

    if g_farmManager == nil then
        return false
    end

    local farmId =
        self:getActiveFarmId()

    if farmId == nil then
        return false
    end

    if g_farmManager.getFarmById == nil then
        return false
    end

    local farm =
        g_farmManager:getFarmById(
            farmId
        )

    if farm == nil
        or farm.money == nil
    then

        return false
    end

    financialManager.cashOnHand =
        tonumber(farm.money) or 0

    self.moneySynced = true

    Logging.info(
        "FFR Money Sync Complete: $%d",
        math.floor(
            financialManager.cashOnHand
        )
    )

    return true

end

--------------------------------------------------
-- Run One Synchronization Attempt
--------------------------------------------------

function FFR_GameIntegrationManager:runSyncAttempt(
    assetManager,
    livestockManager,
    financialManager
)

    self.syncAttempts =
        self.syncAttempts + 1

    Logging.info(
        "FFR Game Sync Attempt: %d of %d",
        self.syncAttempts,
        self.maxSyncAttempts
    )

    if not self.landSynced then

        self:syncFarmland(
            assetManager
        )

    end

    if not self.vehiclesSynced then

        self:syncVehicles(
            assetManager
        )

    end

    if not self.animalsSynced then

        self:syncAnimals(
            livestockManager
        )

    end

    if not self.moneySynced then

        self:syncMoney(
            financialManager
        )

    end

    if assetManager ~= nil then

        assetManager:updateTotals()

        assetManager:updateFinancialManager(
            financialManager
        )

    end

    if self:isFullySynced() then

        self.syncActive = false

        self.syncFinished = true

        Logging.info(
            "FFR: All enabled game-data systems synchronized"
        )

    elseif self.syncAttempts >=
        self.maxSyncAttempts
    then

        self.syncActive = false

        self.syncFinished = true

        Logging.warning(
            "FFR: Deferred synchronization ended with unavailable systems"
        )

    end

end

--------------------------------------------------
-- Deferred Synchronization Update
--------------------------------------------------

function FFR_GameIntegrationManager:updateDeferredSync(
    dt,
    assetManager,
    livestockManager,
    financialManager
)

    if not self.syncActive then
        return
    end

    self.syncTimer =
        self.syncTimer + dt

    if self.syncTimer <
        self.syncInterval
    then

        return

    end

    self.syncTimer = 0

    self:runSyncAttempt(
        assetManager,
        livestockManager,
        financialManager
    )

end

--------------------------------------------------
-- Synchronization Status
--------------------------------------------------

function FFR_GameIntegrationManager:isFullySynced()

    return

        self.landSynced

        and self.vehiclesSynced

        and self.animalsSynced

        and self.moneySynced

end

function FFR_GameIntegrationManager:isSyncFinished()

    return self.syncFinished

end

--------------------------------------------------
-- Integration Report
--------------------------------------------------

function FFR_GameIntegrationManager:printReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR GAME INTEGRATION REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Sync Attempts: %d",
        self.syncAttempts
    )

    Logging.info(
        "Land Synced: %s",
        tostring(
            self.landSynced
        )
    )

    Logging.info(
        "Vehicles Synced: %s",
        tostring(
            self.vehiclesSynced
        )
    )

    Logging.info(
        "Animals Synced: %s",
        tostring(
            self.animalsSynced
        )
    )

    Logging.info(
        "Money Synced: %s",
        tostring(
            self.moneySynced
        )
    )

    Logging.info(
        "Land Value: $%d",
        math.floor(
            self.totalFarmlandValue
        )
    )

    Logging.info(
        "Equipment Value: $%d",
        math.floor(
            self.totalVehicleValue
        )
    )

    Logging.info(
        "========================================"
    )

end