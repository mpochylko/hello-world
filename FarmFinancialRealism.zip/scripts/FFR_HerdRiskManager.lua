FFR_HerdRiskManager = {}

--------------------------------------------------
-- Herd risk: disease outbreaks (server)
--
-- Once per in-game day (06:00) every barn a farm
-- owns (placeables with animals) may have a disease
-- outbreak. The chance per month is OUTBREAK_MONTHLY
-- x the difficulty's event strength, raised for a
-- poorly kept herd (low health) and a crowded barn,
-- and spread over the days of the month.
--
-- An outbreak is real: MORTALITY_MIN..MAX of the
-- barn's animals die (FS25's own changeNumAnimals),
-- surviving animals lose health, and the farm pays
-- a vet bill per head. Losses are valued at FS25's
-- own sell price per animal, and a livestock policy
-- (FFR_LivestockInsuranceManager) pays its share.
--
-- Barns are read with the functions FS25 gives
-- animal groups (getNumAnimals, getHealthFactor,
-- getSellPrice, changeNumAnimals, changeHealth),
-- confirmed by the v0.9.30 diagnostic.
--------------------------------------------------

FFR_HerdRiskManager.OUTBREAK_MONTHLY = 0.03
FFR_HerdRiskManager.MORTALITY_MIN = 0.03
FFR_HerdRiskManager.MORTALITY_MAX = 0.12
FFR_HerdRiskManager.HEALTH_LOSS = 15
FFR_HerdRiskManager.CHECK_HOUR = 6

-- Disease names and vet bill per head by animal type. The names are kept in
-- saves in English and shown through ffr_herd_animals_<name> / ffr_herd_disease_<disease>.
FFR_HerdRiskManager.TYPES = {
    COW = {name = "cattle", disease = "bovine respiratory disease", vet = 40},
    WATERBUFFALO = {name = "buffalo", disease = "bovine respiratory disease", vet = 40},
    PIG = {name = "pigs", disease = "swine influenza", vet = 15},
    SHEEP = {name = "sheep", disease = "foot rot", vet = 12},
    GOAT = {name = "goats", disease = "foot rot", vet = 12},
    CHICKEN = {name = "poultry", disease = "avian influenza", vet = 1},
    HORSE = {name = "horses", disease = "equine influenza", vet = 60}
}

function FFR_HerdRiskManager.getAnimalName(name)
    return FFR_L10n.named("ffr_herd_animals_", name or "animals")
end

function FFR_HerdRiskManager.getDiseaseName(disease)
    return FFR_L10n.named("ffr_herd_disease_", disease or "disease")
end

FFR_HerdRiskManager.updateTimer = 0
FFR_HerdRiskManager.lastDay = nil
FFR_HerdRiskManager.hasLoggedValue = false

--------------------------------------------------
-- Barns and animals
--------------------------------------------------

function FFR_HerdRiskManager.call(object, name, ...)
    if object == nil or type(object[name]) ~= "function" then return nil end
    local ok, result = pcall(object[name], object, ...)
    return ok and result or nil
end

function FFR_HerdRiskManager.getClusters(placeable)
    local spec = placeable.spec_husbandryAnimals
    local system = spec ~= nil and spec.clusterSystem or nil
    local clusters = FFR_HerdRiskManager.call(system, "getClusters")
    if type(clusters) ~= "table" and system ~= nil then clusters = system.clusters end
    return type(clusters) == "table" and clusters or {}
end

function FFR_HerdRiskManager.getTypeKey(cluster)
    if FFR_AnimalPriceManager == nil then return nil end
    local system = FFR_AnimalPriceManager.getAnimalSystem()
    local subType = system ~= nil and FFR_HerdRiskManager.call(system, "getSubTypeByIndex", cluster.subTypeIndex) or nil
    return subType ~= nil and FFR_AnimalPriceManager.getTypeName(subType) or nil
end

-- Value of one animal in a group, from FS25's own sell price.
-- getSellPrice may be per animal or for the whole group; a value far above the
-- breed's best price per head is taken as a group total and divided.
function FFR_HerdRiskManager.getAnimalValue(cluster)
    local value = tonumber(FFR_HerdRiskManager.call(cluster, "getSellPrice")) or 0
    local count = tonumber(FFR_HerdRiskManager.call(cluster, "getNumAnimals")) or 1
    local best = FFR_AnimalPriceManager ~= nil and cluster.subTypeIndex ~= nil
        and FFR_AnimalPriceManager.getHeadPrice(cluster.subTypeIndex) or 0
    local perAnimal = value
    if best > 0 and count > 1 and value > best * 1.5 then perAnimal = value / count end
    if not FFR_HerdRiskManager.hasLoggedValue then
        FFR_HerdRiskManager.hasLoggedValue = true
        Logging.info("FFR Herd Risk: diagnostic getSellPrice %s for a group of %d (best per head %s); using %s per animal",
            tostring(value), count, tostring(best), tostring(perAnimal))
    end
    return perAnimal
end

-- Every barn with animals, per farm: animals, value, health, crowding, risk.
function FFR_HerdRiskManager.getBarns(farmId)
    local list = {}
    local system = g_currentMission ~= nil and g_currentMission.placeableSystem or nil
    for _, placeable in pairs(system ~= nil and system.placeables or {}) do
        if placeable.spec_husbandryAnimals ~= nil and FFR_HerdRiskManager.call(placeable, "getOwnerFarmId") == farmId then
            local barn = {placeable = placeable, farmId = farmId, clusters = {}, head = 0, value = 0, healthSum = 0}
            barn.name = tostring(FFR_HerdRiskManager.call(placeable, "getName") or FFR_L10n.t("ffr_herd_barn"))
            for _, cluster in pairs(FFR_HerdRiskManager.getClusters(placeable)) do
                local count = tonumber(FFR_HerdRiskManager.call(cluster, "getNumAnimals")) or tonumber(cluster.numAnimals) or 0
                if count > 0 then
                    local health = tonumber(FFR_HerdRiskManager.call(cluster, "getHealthFactor")) or 1
                    table.insert(barn.clusters, {cluster = cluster, count = count, health = health})
                    barn.head = barn.head + count
                    barn.value = barn.value + count * FFR_HerdRiskManager.getAnimalValue(cluster)
                    barn.healthSum = barn.healthSum + health * count
                    barn.typeKey = barn.typeKey or FFR_HerdRiskManager.getTypeKey(cluster)
                end
            end
            if barn.head > 0 then
                barn.health = barn.healthSum / barn.head
                local capacity = tonumber(FFR_HerdRiskManager.call(placeable, "getMaxNumOfAnimals")) or 0
                barn.crowding = capacity > 0 and barn.head / capacity or 0
                barn.risk = FFR_HerdRiskManager.getMonthlyRisk(barn)
                table.insert(list, barn)
            end
        end
    end
    table.sort(list, function(a, b) return a.name < b.name end)
    return list
end

-- Outbreak chance this month: base x difficulty, higher for poor health or a crowded barn.
function FFR_HerdRiskManager.getMonthlyRisk(barn)
    local strength = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("eventStrength")) or 1) or 1
    local factor = 1
    if barn.health < 0.4 then factor = factor * 2.5 elseif barn.health < 0.7 then factor = factor * 1.5 end
    if barn.crowding >= 0.95 then factor = factor * 1.3 end
    return math.min(0.5, FFR_HerdRiskManager.OUTBREAK_MONTHLY * strength * factor)
end

-- Rows for the Insurance page and the snapshot (no game objects).
function FFR_HerdRiskManager.getBarnRows(farmId)
    local rows = {}
    for _, barn in ipairs(FFR_HerdRiskManager.getBarns(farmId)) do
        local info = FFR_HerdRiskManager.TYPES[barn.typeKey or ""] or {name = "animals"}
        table.insert(rows, {name = barn.name, animals = info.name, head = barn.head, value = barn.value,
            health = barn.health, crowding = barn.crowding, risk = barn.risk})
    end
    return rows
end

--------------------------------------------------
-- Outbreaks
--------------------------------------------------

function FFR_HerdRiskManager.getDaysPerMonth()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    return math.max(1, tonumber(env ~= nil and (env.daysPerPeriod or env.plannedDaysPerPeriod)) or 1)
end

function FFR_HerdRiskManager.dailyCheck()
    local days = FFR_HerdRiskManager.getDaysPerMonth()
    for _, state in ipairs(g_FFR:getFarmStates()) do
        for _, barn in ipairs(FFR_HerdRiskManager.getBarns(state.farmId)) do
            if math.random() < barn.risk / days then
                FFR_HerdRiskManager.outbreak(state, barn)
            end
        end
    end
end

-- Kills a share of the barn's animals, hurts the rest, charges the vet.
function FFR_HerdRiskManager.outbreak(state, barn)
    local info = FFR_HerdRiskManager.TYPES[barn.typeKey or ""] or {name = "animals", disease = "disease", vet = 10}
    local strength = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("eventStrength")) or 1) or 1
    local share = math.min(0.4, (FFR_HerdRiskManager.MORTALITY_MIN + math.random() *
        (FFR_HerdRiskManager.MORTALITY_MAX - FFR_HerdRiskManager.MORTALITY_MIN)) * strength)
    -- Deaths are a share of the whole barn (FS25 often keeps each animal in its own
    -- group of 1, so rounding per group would kill every animal). At least one dies,
    -- never more than the barn has; groups are picked at random.
    local target = math.min(barn.head, math.max(1, math.floor(barn.head * share + 0.5)))
    local pool = {}
    for _, entry in ipairs(barn.clusters) do
        entry.remaining = entry.count
        table.insert(pool, entry)
    end
    local dead, lost = 0, 0
    while dead < target and #pool > 0 do
        local i = math.random(1, #pool)
        local entry = pool[i]
        local value = FFR_HerdRiskManager.getAnimalValue(entry.cluster)
        local ok = pcall(entry.cluster.changeNumAnimals, entry.cluster, -1)
        if ok then
            dead, lost = dead + 1, lost + value
            entry.remaining = entry.remaining - 1
        end
        if not ok or entry.remaining <= 0 then table.remove(pool, i) end
    end
    -- The survivors are weakened.
    for _, entry in ipairs(barn.clusters) do
        if (entry.remaining or 0) > 0 then
            pcall(entry.cluster.changeHealth, entry.cluster, -FFR_HerdRiskManager.HEALTH_LOSS)
        end
    end
    -- Let the barn notice the change (removes emptied groups, syncs players).
    local spec = barn.placeable.spec_husbandryAnimals
    if spec ~= nil and spec.clusterSystem ~= nil then
        FFR_HerdRiskManager.call(spec.clusterSystem, "updateNow")
    end
    FFR_HerdRiskManager.call(barn.placeable, "raiseActive")
    local vetBill = barn.head * (info.vet or 10)
    if g_FFRMonthlyFinancialProcessor ~= nil and vetBill > 0 and g_FFRMonthlyFinancialProcessor:applyFarmBalance(-vetBill, nil, state.farmId) then
        local f = state.financialManager
        f.monthlyExpenses = (tonumber(f.monthlyExpenses) or 0) + vetBill
        f.annualExpenses = (tonumber(f.annualExpenses) or 0) + vetBill
        f:updateAnnualProfit()
    end
    local event = {
        barn = barn.name, animals = info.name, disease = info.disease, dead = dead, value = lost,
        vetBill = vetBill, hour = FFR_CropInsuranceManager ~= nil and FFR_CropInsuranceManager.getAbsoluteHour() or 0
    }
    state.herdEvents = state.herdEvents or {}
    table.insert(state.herdEvents, event)
    while #state.herdEvents > 12 do table.remove(state.herdEvents, 1) end
    local text = FFR_L10n.t("ffr_herd_outbreak",
        FFR_HerdRiskManager.getDiseaseName(info.disease), barn.name, dead, FFR_HerdRiskManager.getAnimalName(info.name), FFR_HerdRiskManager.formatMoney(lost), FFR_HerdRiskManager.formatMoney(vetBill))
    Logging.warning("FFR Herd Risk: Farm %d - %s", state.farmId, text)
    if FFR_LivestockInsuranceManager ~= nil then
        text = text .. " " .. FFR_LivestockInsuranceManager.onLoss(state, event)
    end
    if FFR_CropDamageManager ~= nil then FFR_CropDamageManager.notify(state.farmId, text) end
    if g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

function FFR_HerdRiskManager.formatMoney(value)
    if g_FFRDashboardDataManager ~= nil and g_FFRDashboardDataManager.formatMoney ~= nil then
        return g_FFRDashboardDataManager:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_HerdRiskManager:update(dt)
    FFR_HerdRiskManager.updateTimer = FFR_HerdRiskManager.updateTimer + dt
    if FFR_HerdRiskManager.updateTimer < 2000 then return end
    FFR_HerdRiskManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    local env = g_currentMission.environment
    if env == nil then return end
    local day = tonumber(env.currentMonotonicDay) or tonumber(env.currentDay) or 0
    local hour = tonumber(env.currentHour) or math.floor((tonumber(env.dayTime) or 0) / 3600000) % 24
    if FFR_HerdRiskManager.lastDay == nil then
        FFR_HerdRiskManager.lastDay = day
        return
    end
    if day ~= FFR_HerdRiskManager.lastDay and hour >= FFR_HerdRiskManager.CHECK_HOUR then
        FFR_HerdRiskManager.lastDay = day
        local ok, err = pcall(FFR_HerdRiskManager.dailyCheck)
        if not ok then Logging.warning("FFR Herd Risk: Daily check failed (%s)", tostring(err)) end
    end
end

function FFR_HerdRiskManager:loadMap(mapName)
    FFR_HerdRiskManager.lastDay = nil
    FFR_HerdRiskManager.updateTimer = 0
    FFR_HerdRiskManager.hasLoggedValue = false
end

function FFR_HerdRiskManager:deleteMap() end
function FFR_HerdRiskManager:draw() end
function FFR_HerdRiskManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_HerdRiskManager:keyEvent(unicode, sym, modifier, isDown) end

-- Testing: "ffrTestOutbreak" in the developer console starts an outbreak in the
-- local farm's first barn (server / singleplayer only).
function FFR_HerdRiskManager:consoleTestOutbreak()
    if g_FFR == nil or not g_FFR.isInitialized then return "FFR is not ready." end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return "Only the server can start an outbreak." end
    local state = g_FFR:getFarmState(g_FFR.localFarmId)
    local barns = state ~= nil and FFR_HerdRiskManager.getBarns(state.farmId) or {}
    if barns[1] == nil then return "Your farm has no barn with animals." end
    FFR_HerdRiskManager.outbreak(state, barns[1])
    return "Outbreak started at " .. barns[1].name .. "."
end

if addConsoleCommand ~= nil then
    addConsoleCommand("ffrTestOutbreak", "FFR: start a disease outbreak in your first barn", "consoleTestOutbreak", FFR_HerdRiskManager)
end

addModEventListener(FFR_HerdRiskManager)
Logging.info("FFR Herd Risk: Disease outbreak checks installed")
