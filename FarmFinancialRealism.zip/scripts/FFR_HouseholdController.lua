FFR_HouseholdController = {}

function FFR_HouseholdController:new()
    local self = {}
    setmetatable(self, {__index = FFR_HouseholdController})

    self.initialized = false
    self.pendingOpen = false
    self.openDelay = 0

    return self
end

function FFR_HouseholdController:ensureManager()
    if g_FFR == nil then
        return nil
    end

    if g_FFR.familyManager == nil
        and FFR_FamilyManager ~= nil
    then
        g_FFR.familyManager = FFR_FamilyManager:new()
    end

    return g_FFR.familyManager
end

function FFR_HouseholdController:open()
    if self.pendingOpen then
        return false
    end

    if g_FFRModalOverlay ~= nil
        and g_FFRModalOverlay.visible
    then
        return false
    end

    self.pendingOpen = true
    self.openDelay = 300

    Logging.info(
        "FFR Household: Configuration window queued"
    )

    return true
end

function FFR_HouseholdController:openNow()
    self.pendingOpen = false
    self.openDelay = 0

    local manager = self:ensureManager()

    if manager == nil
        or g_FFRModalOverlay == nil
    then
        Logging.error(
            "FFR Household: Configuration window unavailable"
        )

        return false
    end

    if g_FFRModalOverlay.visible then
        return false
    end

    return g_FFRModalOverlay:showHousehold(
        manager,
        function()
            if g_FFR ~= nil
                and g_FFR.saveManager ~= nil
            then
                g_FFR.saveManager:requestSave(g_FFR)
            end

            Logging.info(
                "FFR Household: Configuration applied at $%d per month",
                math.floor(
                    manager.totalMonthlyCost or 0
                )
            )
        end,
        self
    )
end

function FFR_HouseholdController:loadMap(mapName)
    self.initialized = false
    self.pendingOpen = false
    self.openDelay = 0
end

function FFR_HouseholdController:update(dt)
    if not self.initialized then
        if g_FFR == nil
            or not g_FFR.isInitialized
        then
            return
        end

        -- Households are restored per farm by the save manager; reading the
        -- old FFR_household.xml here would overwrite the local farm's.
        self.initialized = true
    end

    if self.pendingOpen then
        self.openDelay = self.openDelay - dt

        if self.openDelay <= 0 then
            self:openNow()
        end
    end
end

function FFR_HouseholdController:deleteMap()
    self.pendingOpen = false
    self.openDelay = 0

    -- The household file is written with the native savegame only.
    -- The next mission re-reads it on startup.
    self.initialized = false
end

function FFR_HouseholdController:draw()
end

function FFR_HouseholdController:mouseEvent(
    posX,
    posY,
    isDown,
    isUp,
    button
)
end

function FFR_HouseholdController:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)
end

g_FFRHouseholdController =
    FFR_HouseholdController:new()

addModEventListener(
    g_FFRHouseholdController
)

Logging.info(
    "FFR Household: Controller installed"
)
