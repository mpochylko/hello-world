FFR_InputClassifier = {}

--------------------------------------------------
-- Input classification
--
-- Decides which supplier category (SEEDS,
-- FERTILIZER, ... or NONE) a purchased product
-- belongs to, so promotions reach products from
-- maps and mods too:
--
-- * fill types bought by the litre ("FT:UREA"),
-- * shop items such as bags, pallets and tanks
--   ("ITEM:bigBag_seeds.xml").
--
-- Automatic detection matches names against RULES.
-- The server admin can override any product on the
-- Options page; overrides are saved and synced.
--------------------------------------------------

FFR_InputClassifier.CATEGORIES = {
    "SEEDS", "FERTILIZER", "LIQUIDFERTILIZER", "LIME",
    "HERBICIDE", "FUNGICIDE", "INSECTICIDE", "DIESEL", "DEF", "NONE"
}

-- Shown as ffr_input_cat_<category>; sources as ffr_input_source_<source>.

-- Checked in order; the first match wins. word = true: must be a whole word
-- of the name (short codes like UAN or DEF would match inside other names).
FFR_InputClassifier.RULES = {
    {"HERBICIDE", "HERBICIDE"}, {"GLYPHOSATE", "HERBICIDE"},
    {"FUNGICIDE", "FUNGICIDE"},
    {"INSECTICIDE", "INSECTICIDE"}, {"PESTICIDE", "INSECTICIDE"},
    {"LIQUIDFERTILIZER", "LIQUIDFERTILIZER"}, {"LIQUIDFERTILISER", "LIQUIDFERTILIZER"},
    {"FERTILIZERTANK", "LIQUIDFERTILIZER"}, {"ANHYDROUS", "LIQUIDFERTILIZER"},
    {"NH3", "LIQUIDFERTILIZER", word = true}, {"UAN", "LIQUIDFERTILIZER", word = true},
    {"UREA", "FERTILIZER"}, {"POTASH", "FERTILIZER"}, {"PHOSPHATE", "FERTILIZER"},
    {"FERTILIZER", "FERTILIZER"}, {"FERTILISER", "FERTILIZER"},
    {"LIME", "LIME"},
    {"SEED", "SEEDS"}, {"PIONEER", "SEEDS"}, {"DEKALB", "SEEDS"},
    {"DIESEL", "DIESEL"},
    {"DEF", "DEF", word = true}, {"ADBLUE", "DEF"}
}

-- Shop finance categories that hold field inputs, with their fallback category.
FFR_InputClassifier.STORE_CATEGORIES = {
    PURCHASE_FERTILIZER = "FERTILIZER",
    PURCHASE_SEEDS = "SEEDS"
}

FFR_InputClassifier.overrides = {}
FFR_InputClassifier.seenFillTypes = {}
FFR_InputClassifier.storeEntries = nil
FFR_InputClassifier.version = 0

--------------------------------------------------
-- Automatic detection
--------------------------------------------------

function FFR_InputClassifier.autoClassify(name)
    local upper = string.upper(tostring(name or ""))
    local compact = upper:gsub("[^%w]", "")
    local words = {}
    for word in upper:gmatch("%w+") do words[word] = true end
    for _, rule in ipairs(FFR_InputClassifier.RULES) do
        if rule.word then
            if words[rule[1]] then return rule[2] end
        elseif string.find(compact, rule[1], 1, true) then
            return rule[2]
        end
    end
    return nil
end

function FFR_InputClassifier.getBaseName(path)
    local text = tostring(path or "")
    return text:match("([^/\\]+)$") or text
end

function FFR_InputClassifier.getStoreKey(storeItem)
    return "ITEM:" .. FFR_InputClassifier.getBaseName(storeItem.xmlFilename or storeItem.name)
end

function FFR_InputClassifier.getBrandName(storeItem)
    if type(storeItem) ~= "table" or g_brandManager == nil then return nil end
    local brand = nil
    if storeItem.brandIndex ~= nil and g_brandManager.getBrandByIndex ~= nil then
        local ok, result = pcall(g_brandManager.getBrandByIndex, g_brandManager, storeItem.brandIndex)
        if ok then brand = result end
    end
    if brand == nil or brand.name == nil or string.upper(brand.name) == "NONE" then return nil end
    return string.upper(brand.name), brand.title or brand.name
end

--------------------------------------------------
-- Classification (overrides first)
--------------------------------------------------

-- Category for a fill type bought by the litre, or nil.
function FFR_InputClassifier.classifyFillType(fillTypeName)
    if fillTypeName == nil then return nil end
    local name = string.upper(tostring(fillTypeName))
    local override = FFR_InputClassifier.overrides["FT:" .. name]
    if override ~= nil then return override ~= "NONE" and override or nil end
    return FFR_InputClassifier.autoClassify(name)
end

-- Automatic category for a shop item: file name first, then its finance category.
function FFR_InputClassifier.autoClassifyStoreItem(storeItem)
    local fallback = FFR_InputClassifier.STORE_CATEGORIES[tostring(storeItem.financeCategory or "")]
    if fallback == nil then return nil end
    return FFR_InputClassifier.autoClassify(FFR_InputClassifier.getBaseName(storeItem.xmlFilename)) or fallback
end

function FFR_InputClassifier.classifyStoreItem(storeItem)
    if type(storeItem) ~= "table" then return nil end
    local override = FFR_InputClassifier.overrides[FFR_InputClassifier.getStoreKey(storeItem)]
    if override ~= nil then return override ~= "NONE" and override or nil end
    return FFR_InputClassifier.autoClassifyStoreItem(storeItem)
end

-- Remembers fill types bought by the litre (server), for the Options list.
function FFR_InputClassifier.markSeen(fillTypeName)
    if fillTypeName == nil or FFR_InputClassifier.seenFillTypes[fillTypeName] then return end
    FFR_InputClassifier.seenFillTypes[fillTypeName] = true
    FFR_InputClassifier.version = FFR_InputClassifier.version + 1
end

--------------------------------------------------
-- Options list
--------------------------------------------------

-- Shop items in input finance categories (built once per session).
function FFR_InputClassifier.getStoreEntries()
    if FFR_InputClassifier.storeEntries ~= nil then return FFR_InputClassifier.storeEntries end
    local entries = {}
    local items = nil
    if g_storeManager ~= nil and g_storeManager.getItems ~= nil then
        local ok, result = pcall(g_storeManager.getItems, g_storeManager)
        if ok then items = result end
    end
    local seen = {}
    for _, storeItem in pairs(items or {}) do
        local auto = type(storeItem) == "table" and FFR_InputClassifier.autoClassifyStoreItem(storeItem) or nil
        local key = auto ~= nil and FFR_InputClassifier.getStoreKey(storeItem) or nil
        if key ~= nil and not seen[key] then
            seen[key] = true
            local brand, brandTitle = FFR_InputClassifier.getBrandName(storeItem)
            table.insert(entries, {
                key = key, name = tostring(storeItem.name or key), source = "SHOP",
                brand = brand, brandTitle = brandTitle, auto = auto
            })
        end
    end
    if items ~= nil then FFR_InputClassifier.storeEntries = entries end
    return entries
end

-- Fill types that look like inputs, plus any bought by the litre.
function FFR_InputClassifier.getFillTypeEntries()
    local entries = {}
    if g_fillTypeManager == nil then return entries end
    local fillTypes = g_fillTypeManager.fillTypes
    if g_fillTypeManager.getFillTypes ~= nil then
        local ok, result = pcall(g_fillTypeManager.getFillTypes, g_fillTypeManager)
        if ok and type(result) == "table" then fillTypes = result end
    end
    for _, fillType in pairs(fillTypes or {}) do
        local name = type(fillType) == "table" and fillType.name ~= nil and string.upper(fillType.name) or nil
        if name ~= nil then
            local auto = FFR_InputClassifier.autoClassify(name)
            if auto ~= nil or FFR_InputClassifier.seenFillTypes[name] or FFR_InputClassifier.overrides["FT:" .. name] ~= nil then
                table.insert(entries, {
                    key = "FT:" .. name, name = tostring(fillType.title or name), source = "LITRE",
                    auto = auto or "NONE"
                })
            end
        end
    end
    return entries
end

-- Every classifiable product with its current category, for the Options page.
function FFR_InputClassifier.getEntries()
    local list = {}
    for _, entry in ipairs(FFR_InputClassifier.getFillTypeEntries()) do table.insert(list, entry) end
    for _, entry in ipairs(FFR_InputClassifier.getStoreEntries()) do table.insert(list, entry) end
    for _, entry in ipairs(list) do
        entry.category = FFR_InputClassifier.overrides[entry.key] or entry.auto
        entry.isOverride = FFR_InputClassifier.overrides[entry.key] ~= nil
    end
    table.sort(list, function(a, b)
        if a.source ~= b.source then return a.source < b.source end
        return string.lower(a.name) < string.lower(b.name)
    end)
    return list
end

function FFR_InputClassifier.getCategoryName(category)
    return FFR_L10n.named("ffr_input_cat_", category or "NONE")
end

function FFR_InputClassifier.isCategory(category)
    for _, name in ipairs(FFR_InputClassifier.CATEGORIES) do
        if name == category then return true end
    end
    return false
end

-- LITRE (bought by the litre) or SHOP (pallets and bags).
function FFR_InputClassifier.getSourceName(source)
    return FFR_L10n.named("ffr_input_source_", source or "")
end

--------------------------------------------------
-- Changes (server, admin only via FFR_Network)
--------------------------------------------------

function FFR_InputClassifier.step(key, direction)
    if type(key) ~= "string" or (key:sub(1, 3) ~= "FT:" and key:sub(1, 5) ~= "ITEM:") then
        return false, FFR_L10n.t("ffr_input_unknown")
    end
    local current = FFR_InputClassifier.overrides[key]
    if current == nil then
        for _, entry in ipairs(FFR_InputClassifier.getEntries()) do
            if entry.key == key then current = entry.auto end
        end
    end
    local list = FFR_InputClassifier.CATEGORIES
    local index = #list
    for i, category in ipairs(list) do
        if category == current then index = i end
    end
    index = index + (tonumber(direction) or 0)
    if index < 1 then index = #list elseif index > #list then index = 1 end
    FFR_InputClassifier.overrides[key] = list[index]
    FFR_InputClassifier.version = FFR_InputClassifier.version + 1
    Logging.info("FFR Input Classes: %s set to %s", key, list[index])
    return true, FFR_L10n.t("ffr_input_classed", FFR_InputClassifier.getCategoryName(list[index]))
end

function FFR_InputClassifier.reset(key)
    if FFR_InputClassifier.overrides[key] == nil then return true, FFR_L10n.t("ffr_input_already_auto") end
    FFR_InputClassifier.overrides[key] = nil
    FFR_InputClassifier.version = FFR_InputClassifier.version + 1
    return true, FFR_L10n.t("ffr_input_back_auto")
end

--------------------------------------------------
-- Save / load and snapshot
--------------------------------------------------

function FFR_InputClassifier.saveToXML(xmlFile, key)
    local i = 0
    for itemKey, category in pairs(FFR_InputClassifier.overrides) do
        local base = string.format("%s.override(%d)", key, i)
        setXMLString(xmlFile, base .. "#key", itemKey)
        setXMLString(xmlFile, base .. "#category", category)
        i = i + 1
    end
    i = 0
    for name in pairs(FFR_InputClassifier.seenFillTypes) do
        setXMLString(xmlFile, string.format("%s.seen(%d)#name", key, i), name)
        i = i + 1
    end
end

function FFR_InputClassifier.loadFromXML(xmlFile, key)
    FFR_InputClassifier.overrides = {}
    FFR_InputClassifier.seenFillTypes = {}
    local i = 0
    while true do
        local base = string.format("%s.override(%d)", key, i)
        if not hasXMLProperty(xmlFile, base) then break end
        local itemKey = getXMLString(xmlFile, base .. "#key")
        local category = getXMLString(xmlFile, base .. "#category")
        if itemKey ~= nil and FFR_InputClassifier.isCategory(category) then
            FFR_InputClassifier.overrides[itemKey] = category
        end
        i = i + 1
    end
    i = 0
    while true do
        local name = getXMLString(xmlFile, string.format("%s.seen(%d)#name", key, i))
        if name == nil then break end
        FFR_InputClassifier.seenFillTypes[name] = true
        i = i + 1
    end
    FFR_InputClassifier.version = FFR_InputClassifier.version + 1
end

function FFR_InputClassifier.getSnapshot()
    return {overrides = FFR_InputClassifier.overrides, seen = FFR_InputClassifier.seenFillTypes}
end

function FFR_InputClassifier.applySnapshot(data)
    if type(data) ~= "table" then return end
    if type(data.overrides) == "table" then FFR_InputClassifier.overrides = data.overrides end
    if type(data.seen) == "table" then FFR_InputClassifier.seenFillTypes = data.seen end
end

--------------------------------------------------
-- Listener: each savegame starts with no overrides.
--------------------------------------------------

function FFR_InputClassifier:loadMap(mapName)
    FFR_InputClassifier.overrides = {}
    FFR_InputClassifier.seenFillTypes = {}
    FFR_InputClassifier.storeEntries = nil
end

function FFR_InputClassifier:deleteMap() FFR_InputClassifier.storeEntries = nil end
function FFR_InputClassifier:update(dt) end
function FFR_InputClassifier:draw() end
function FFR_InputClassifier:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_InputClassifier:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_InputClassifier)
Logging.info("FFR Input Classes: Product classifier installed")
