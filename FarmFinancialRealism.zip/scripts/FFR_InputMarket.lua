FFR_InputMarket = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_InputMarket:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_InputMarket}
    )

    self.activeEvent = nil

    self.currentPeriod = 0
    self.currentYear = 0

    self.lastProcessedPeriod = 0
    self.lastProcessedYear = 0

    self.inputs = {

        DIESEL = {
            modifier = 1.00
        },

        DEF = {
            modifier = 1.00
        },

        SEEDS = {
            modifier = 1.00
        },

        FERTILIZER = {
            modifier = 1.00
        },

        LIQUIDFERTILIZER = {
            modifier = 1.00
        },

        LIME = {
            modifier = 1.00
        },

        HERBICIDE = {
            modifier = 1.00
        },

        FUNGICIDE = {
            modifier = 1.00
        },

        INSECTICIDE = {
            modifier = 1.00
        }

    }

    return self

end

--------------------------------------------------
-- Month Names
--------------------------------------------------

function FFR_InputMarket:getMonthName(
    period
)

    -- Period 1 = March (ffr_month_1).
    return FFR_L10n.monthName(period)

end

--------------------------------------------------
-- Event Definitions
--------------------------------------------------

function FFR_InputMarket:getEvents()

    return {

        {
            name = "Regular Supplier Pricing",

            weight = 40,

            minimumDurationMonths = 1,

            maximumDurationMonths = 1,

            targets = {}
        },

        {
            name = "Fuel Surplus",

            weight = 12,

            minimumDurationMonths = 1,

            maximumDurationMonths = 2,

            targets = {

                DIESEL = {
                    minimumDiscount = 5,
                    maximumDiscount = 15
                },

                DEF = {
                    minimumDiscount = 5,
                    maximumDiscount = 12
                }

            }

        },

        {
            name = "Spring Fertilizer Promotion",

            weight = 14,

            minimumDurationMonths = 1,

            maximumDurationMonths = 2,

            targets = {

                FERTILIZER = {
                    minimumDiscount = 5,
                    maximumDiscount = 18
                },

                LIQUIDFERTILIZER = {
                    minimumDiscount = 5,
                    maximumDiscount = 16
                }

            }

        },

        {
            name = "Seed Company Rebate",

            weight = 10,

            minimumDurationMonths = 1,

            maximumDurationMonths = 2,

            targets = {

                SEEDS = {
                    minimumDiscount = 8,
                    maximumDiscount = 20
                }

            }

        },

        {
            name = "Chemical Promotion",

            weight = 12,

            minimumDurationMonths = 1,

            maximumDurationMonths = 2,

            targets = {

                HERBICIDE = {
                    minimumDiscount = 5,
                    maximumDiscount = 20
                },

                FUNGICIDE = {
                    minimumDiscount = 5,
                    maximumDiscount = 18
                },

                INSECTICIDE = {
                    minimumDiscount = 5,
                    maximumDiscount = 15
                }

            }

        },

        {
            name = "Lime Overstock",

            weight = 12,

            minimumDurationMonths = 1,

            maximumDurationMonths = 2,

            targets = {

                LIME = {
                    minimumDiscount = 5,
                    maximumDiscount = 15
                }

            }

        },

        --------------------------------------------------
        -- Shortages (understock): negative discounts
        -- raise prices above the map/mod baseline.
        --------------------------------------------------

        {
            name = "Fertilizer Shortage",
            weight = 8,
            minimumDurationMonths = 1,
            maximumDurationMonths = 3,
            targets = {
                FERTILIZER = {minimumDiscount = -22, maximumDiscount = -6},
                LIQUIDFERTILIZER = {minimumDiscount = -20, maximumDiscount = -5}
            }
        },

        {
            name = "Seed Supply Shortage",
            weight = 6,
            minimumDurationMonths = 1,
            maximumDurationMonths = 2,
            targets = {
                SEEDS = {minimumDiscount = -18, maximumDiscount = -5}
            }
        },

        {
            name = "Diesel Price Spike",
            weight = 8,
            minimumDurationMonths = 1,
            maximumDurationMonths = 2,
            targets = {
                DIESEL = {minimumDiscount = -25, maximumDiscount = -6},
                DEF = {minimumDiscount = -15, maximumDiscount = -4}
            }
        },

        {
            name = "Chemical Supply Disruption",
            weight = 6,
            minimumDurationMonths = 1,
            maximumDurationMonths = 3,
            targets = {
                HERBICIDE = {minimumDiscount = -20, maximumDiscount = -5},
                FUNGICIDE = {minimumDiscount = -18, maximumDiscount = -5},
                INSECTICIDE = {minimumDiscount = -15, maximumDiscount = -5}
            }
        },

        {
            name = "Lime Haulage Shortage",
            weight = 5,
            minimumDurationMonths = 1,
            maximumDurationMonths = 2,
            targets = {
                LIME = {minimumDiscount = -15, maximumDiscount = -5}
            }
        }

    }

end

--------------------------------------------------
-- Brand Programs
--
-- A supplier deal on one brand's products in one
-- category (a Pioneer seed promotion, a DEKALB
-- preseason rebate, a HELM fertilizer program).
-- Candidates are the brands of the shop's input
-- items (FFR_InputClassifier), so mod brands work.
-- The discount applies to that brand's shop items
-- and to fill types named after it (DEKALB_SEEDS).
--------------------------------------------------

FFR_InputMarket.BRAND_EVENT_WEIGHT = 14
FFR_InputMarket.BRAND_MIN_DISCOUNT = 8
FFR_InputMarket.BRAND_MAX_DISCOUNT = 22

-- Real-world program names for well-known brands; others get "<Brand> <Category> Program".
FFR_InputMarket.BRAND_EVENT_NAMES = {
    DEKALB = "DEKALB Preseason Rebate",
    PIONEER = "Pioneer Seed Promotion",
    CORTEVA = "Corteva Crop Inputs Program",
    HELM = "HELM Early Order Program"
}

-- The program's name in the player's language. Saved names stay English;
-- brand programs without a known name are built from brand and category.
function FFR_InputMarket:getEventTitle(event)
    event = event or self.activeEvent
    if event == nil then return FFR_L10n.t("ffr_news_supplier_regular") end
    if event.brand ~= nil and FFR_InputMarket.BRAND_EVENT_NAMES[event.brand] == nil then
        local categoryName = FFR_InputClassifier ~= nil and FFR_InputClassifier.getCategoryName(event.brandCategory) or tostring(event.brandCategory)
        return FFR_L10n.t("ffr_event_brand_program", tostring(event.brandTitle or event.brand), categoryName)
    end
    return FFR_L10n.eventName(event.name)
end

function FFR_InputMarket:isRegular(event)
    event = event or self.activeEvent
    return event == nil or event.name == "Regular Supplier Pricing"
end

function FFR_InputMarket:getBrandCandidates()
    local list, seen = {}, {}
    if FFR_InputClassifier == nil then return list end
    for _, entry in ipairs(FFR_InputClassifier.getStoreEntries()) do
        local category = FFR_InputClassifier.overrides[entry.key] or entry.auto
        if entry.brand ~= nil and category ~= nil and category ~= "NONE" then
            local key = entry.brand .. "|" .. category
            if not seen[key] then
                seen[key] = true
                table.insert(list, {brand = entry.brand, title = entry.brandTitle or entry.brand, category = category})
            end
        end
    end
    return list
end

function FFR_InputMarket:createBrandEvent(candidate)
    local categoryName = FFR_InputClassifier ~= nil and FFR_InputClassifier.getCategoryName(candidate.category) or candidate.category
    local discount = math.random(FFR_InputMarket.BRAND_MIN_DISCOUNT, FFR_InputMarket.BRAND_MAX_DISCOUNT)
    return {
        name = FFR_InputMarket.BRAND_EVENT_NAMES[candidate.brand]
            or string.format("%s %s Program", tostring(candidate.title), categoryName),
        minimumDurationMonths = 1,
        maximumDurationMonths = 2,
        expiryMonth = 0, expiryYear = 0, durationMonths = 0, durationDays = 0,
        targets = {},
        brand = candidate.brand,
        brandTitle = candidate.title,
        brandCategory = candidate.category,
        brandDiscount = discount,
        brandModifier = 1 - discount / 100
    }
end

-- Extra modifier for one brand's product in a category (1.0 without a brand deal).
function FFR_InputMarket:getBrandModifier(brand, category)
    local event = self.activeEvent
    if event == nil or event.brand == nil or brand == nil then return 1.00 end
    if string.upper(tostring(brand)) ~= event.brand then return 1.00 end
    if category ~= nil and event.brandCategory ~= nil and category ~= event.brandCategory then return 1.00 end
    return tonumber(event.brandModifier) or 1.00
end

-- Price factor for a purchase: the category's promotion times any brand deal.
-- For fill types, the brand is found in the fill type name (DEKALB_SEEDS).
function FFR_InputMarket:getPurchaseModifier(category, brand, fillTypeName)
    local modifier = self:getModifier(category)
    local event = self.activeEvent
    if brand == nil and fillTypeName ~= nil and event ~= nil and event.brand ~= nil
        and string.find(string.upper(tostring(fillTypeName)), event.brand, 1, true) then
        brand = event.brand
    end
    return modifier * self:getBrandModifier(brand, category)
end

--------------------------------------------------
-- Reset Input Modifiers
--------------------------------------------------

function FFR_InputMarket:resetModifiers()

    for _, inputData in pairs(
        self.inputs
    ) do

        inputData.modifier = 1.00

    end

end

--------------------------------------------------
-- Weighted Event Selection
--------------------------------------------------

function FFR_InputMarket:selectRandomEvent()

    local events =
        self:getEvents()

    -- One weighted slot for a brand program, when the shop has branded inputs.
    if #self:getBrandCandidates() > 0 then
        table.insert(events, {name = "BRAND_PROGRAM", isBrand = true, weight = FFR_InputMarket.BRAND_EVENT_WEIGHT, targets = {}})
    end
    if events == nil
        or #events == 0
    then

        return nil

    end

    local totalWeight = 0

    for _, event in ipairs(events) do

        totalWeight =

            totalWeight

            + (
                tonumber(
                    event.weight
                )
                or 1
            )

    end

    if totalWeight <= 0 then

        return events[1]

    end

    local roll =

        math.random(
            1,
            totalWeight
        )

    local runningWeight = 0

    for _, event in ipairs(events) do

        runningWeight =

            runningWeight

            + (
                tonumber(
                    event.weight
                )
                or 1
            )

        if roll <= runningWeight then

            return event

        end

    end

    return events[#events]

end

--------------------------------------------------
-- Clone Event
--------------------------------------------------

function FFR_InputMarket:cloneEvent(
    event
)

    if event == nil then
        return nil
    end

    local clonedEvent = {

        name =
            event.name,

        weight =
            event.weight,

        minimumDurationMonths =
            event.minimumDurationMonths,

        maximumDurationMonths =
            event.maximumDurationMonths,

        expiryMonth = 0,

        expiryYear = 0,

        durationMonths = 0,

        durationDays = 0,

        targets = {}

    }

    if event.targets ~= nil then

        for inputName, targetData in pairs(
            event.targets
        ) do

            clonedEvent.targets[
                inputName
            ] = {

                minimumDiscount =
                    targetData.minimumDiscount,

                maximumDiscount =
                    targetData.maximumDiscount

            }

        end

    end

    return clonedEvent

end

--------------------------------------------------
-- Add Calendar Months
--------------------------------------------------

function FFR_InputMarket:addMonths(
    currentPeriod,
    currentYear,
    monthsToAdd
)

    local period =
        tonumber(currentPeriod) or 1

    local year =
        tonumber(currentYear) or 1

    local months =
        tonumber(monthsToAdd) or 0

    if period < 1 then
        period = 1
    end

    if period > 12 then
        period = 12
    end

    for _ = 1, months do

        period =
            period + 1

        if period > 12 then

            period = 1

            year =
                year + 1

        end

    end

    return period, year

end

--------------------------------------------------
-- Calendar Serial Value
--------------------------------------------------

function FFR_InputMarket:getCalendarSerial(
    period,
    year
)

    local safePeriod =
        tonumber(period) or 0

    local safeYear =
        tonumber(year) or 0

    return

        safeYear * 12

        + safePeriod

end

--------------------------------------------------
-- Randomize Event Discounts
--------------------------------------------------

function FFR_InputMarket:randomizeDiscounts(
    event
)

    if event == nil
        or event.targets == nil
    then

        return

    end

    for inputName, targetData in pairs(
        event.targets
    ) do

        local minimumDiscount =

            tonumber(
                targetData.minimumDiscount
            )
            or 0

        local maximumDiscount =

            tonumber(
                targetData.maximumDiscount
            )
            or minimumDiscount

        if maximumDiscount <
            minimumDiscount
        then

            maximumDiscount =
                minimumDiscount

        end

        local discount =

            math.random(
                minimumDiscount,
                maximumDiscount
            )

        --------------------------------------------------
        -- The difficulty preset scales how far input
        -- prices move, both deals and shortages
        -- (Easy x0.75, Normal x1, Hard x1.5).
        --------------------------------------------------

        local strength = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("eventStrength")) or 1) or 1

        discount = math.floor(discount * strength + (discount >= 0 and 0.5 or -0.5))

        discount = math.max(-40, math.min(40, discount))

        local modifier =

            1

            - (
                discount / 100
            )

        if self.inputs[inputName] ~= nil then

            self.inputs[
                inputName
            ].modifier = modifier

        end

        targetData.discountPercent =
            discount

        targetData.modifier =
            modifier

    end

end

--------------------------------------------------
-- Assign Event Expiry
--------------------------------------------------

function FFR_InputMarket:assignExpiry(
    event,
    currentPeriod,
    currentYear
)

    if event == nil then
        return
    end

    local minimumDuration =

        tonumber(
            event.minimumDurationMonths
        )
        or 1

    local maximumDuration =

        tonumber(
            event.maximumDurationMonths
        )
        or minimumDuration

    if minimumDuration < 1 then
        minimumDuration = 1
    end

    if maximumDuration <
        minimumDuration
    then

        maximumDuration =
            minimumDuration

    end

    local duration =

        math.random(
            minimumDuration,
            maximumDuration
        )

    --------------------------------------------------
    -- Duration 1 means valid through current month.
    --------------------------------------------------

    local monthsToAdd =
        duration - 1

    local expiryMonth,
        expiryYear =

        self:addMonths(
            currentPeriod,
            currentYear,
            monthsToAdd
        )

    event.durationMonths =
        duration

    event.durationDays = 0

    event.expiryMonth =
        expiryMonth

    event.expiryYear =
        expiryYear

end

--------------------------------------------------
-- Create Random Event
--------------------------------------------------

function FFR_InputMarket:createRandomEvent(
    currentPeriod,
    currentYear
)

    local selectedTemplate =
        self:selectRandomEvent()

    if selectedTemplate == nil then

        Logging.warning(
            "FFR: No input market events are available"
        )

        return false

    end

    local selectedEvent = nil

    if selectedTemplate.isBrand then

        local candidates = self:getBrandCandidates()

        selectedEvent = self:createBrandEvent(candidates[math.random(1, #candidates)])

    else

        selectedEvent =
            self:cloneEvent(
                selectedTemplate
            )

    end

    self:resetModifiers()

    self:randomizeDiscounts(
        selectedEvent
    )

    self:assignExpiry(
        selectedEvent,
        currentPeriod,
        currentYear
    )

    self.activeEvent =
        selectedEvent

    self.currentPeriod =
        tonumber(currentPeriod) or 0

    self.currentYear =
        tonumber(currentYear) or 0

    self.lastProcessedPeriod =
        self.currentPeriod

    self.lastProcessedYear =
        self.currentYear

    self:printActiveEvent()

    return true

end

--------------------------------------------------
-- Repair Older Saved Event Expiry
--------------------------------------------------

function FFR_InputMarket:ensureCalendarExpiry(
    currentPeriod,
    currentYear
)

    if self.activeEvent == nil then

        return self:createRandomEvent(
            currentPeriod,
            currentYear
        )

    end

    local expiryMonth =

        tonumber(
            self.activeEvent.expiryMonth
        )
        or 0

    local expiryYear =

        tonumber(
            self.activeEvent.expiryYear
        )
        or 0

    if expiryMonth <= 0
        or expiryYear <= 0
    then

        Logging.info(
            "FFR Input Market: Assigning calendar expiry to existing promotion"
        )

        --------------------------------------------------
        -- Keep loaded discounts unchanged.
        --------------------------------------------------

        self:assignExpiry(
            self.activeEvent,
            currentPeriod,
            currentYear
        )

    end

    self.currentPeriod =
        tonumber(currentPeriod) or 0

    self.currentYear =
        tonumber(currentYear) or 0

    self.lastProcessedPeriod =
        self.currentPeriod

    self.lastProcessedYear =
        self.currentYear

    return true

end

--------------------------------------------------
-- Determine Whether Event Expired
--------------------------------------------------

function FFR_InputMarket:isEventExpired(
    currentPeriod,
    currentYear
)

    if self.activeEvent == nil then
        return true
    end

    local expiryPeriod =

        tonumber(
            self.activeEvent.expiryMonth
        )
        or 0

    local expiryYear =

        tonumber(
            self.activeEvent.expiryYear
        )
        or 0

    if expiryPeriod <= 0
        or expiryYear <= 0
    then

        return false

    end

    local currentSerial =

        self:getCalendarSerial(
            currentPeriod,
            currentYear
        )

    local expirySerial =

        self:getCalendarSerial(
            expiryPeriod,
            expiryYear
        )

    --------------------------------------------------
    -- Event remains valid throughout expiry month.
    --------------------------------------------------

    return currentSerial >
        expirySerial

end

--------------------------------------------------
-- Calendar Update
--------------------------------------------------

function FFR_InputMarket:updateCalendar(
    currentPeriod,
    currentYear
)

    local safePeriod =
        tonumber(currentPeriod) or 0

    local safeYear =
        tonumber(currentYear) or 0

    if safePeriod <= 0
        or safeYear <= 0
    then

        return false

    end

    if safePeriod ==
        self.lastProcessedPeriod
        and safeYear ==
        self.lastProcessedYear
    then

        return false

    end

    self.currentPeriod =
        safePeriod

    self.currentYear =
        safeYear

    self.lastProcessedPeriod =
        safePeriod

    self.lastProcessedYear =
        safeYear

    if self:isEventExpired(
        safePeriod,
        safeYear
    ) then

        local previousEventName =
            "Unknown"

        if self.activeEvent ~= nil
            and self.activeEvent.name ~= nil
        then

            previousEventName =
                tostring(
                    self.activeEvent.name
                )

        end

        Logging.info(
            "FFR Input Market: %s expired",
            previousEventName
        )

        return self:createRandomEvent(
            safePeriod,
            safeYear
        )

    end

    return false

end

--------------------------------------------------
-- Get Input Modifier
--------------------------------------------------

function FFR_InputMarket:getModifier(
    fillTypeName
)

    if fillTypeName == nil then
        return 1.00
    end

    local inputName =

        string.upper(
            tostring(fillTypeName)
        )

    local inputData =
        self.inputs[inputName]

    if inputData == nil then
        return 1.00
    end

    return

        tonumber(
            inputData.modifier
        )

        or 1.00

end

--------------------------------------------------
-- Discount Check
--------------------------------------------------

function FFR_InputMarket:isDiscounted(
    fillTypeName
)

    return

        self:getModifier(
            fillTypeName
        )

        < 1.00

end

--------------------------------------------------
-- Discount Percentage
--------------------------------------------------

function FFR_InputMarket:getDiscountPercent(
    fillTypeName
)

    local modifier =

        self:getModifier(
            fillTypeName
        )

    return

        math.floor(
            (
                1
                - modifier
            )
            * 100
            + 0.5
        )

end

--------------------------------------------------
-- Expiry Text
--------------------------------------------------

-- Short "Brand X cell" for an input category a brand program covers ("Corteva -15%"),
-- else nil. The program lowers only that brand's shop products, not the category's
-- per-litre price, so the category's own modifier stays "Regular".
function FFR_InputMarket:getBrandCell(category)
    local event = self.activeEvent
    if event == nil or event.brand == nil or event.brandCategory ~= category then return nil end
    return FFR_L10n.t("ffr_input_brand_cell", tostring(event.brandTitle or event.brand), tonumber(event.brandDiscount) or 0)
end

function FFR_InputMarket:getExpiryText(short)

    if self.activeEvent == nil then

        return FFR_L10n.t("ffr_input_no_program")

    end

    local expiryMonth =

        tonumber(
            self.activeEvent.expiryMonth
        )
        or 0

    if expiryMonth <= 0 then

        return FFR_L10n.t("ffr_input_no_expiry")

    end

    local text = FFR_L10n.t("ffr_input_valid_until", self:getMonthName(expiryMonth))

    -- Brand programs only cover that brand's products, so say which
    -- (short: the expiry alone, where the row already names the brand).
    if self.activeEvent.brand ~= nil and not short then

        local category = FFR_InputClassifier ~= nil
            and FFR_InputClassifier.getCategoryName(self.activeEvent.brandCategory)
            or tostring(self.activeEvent.brandCategory)

        text = FFR_L10n.t(
            "ffr_input_brand_off",
            tostring(self.activeEvent.brandTitle or self.activeEvent.brand),
            category,
            tonumber(self.activeEvent.brandDiscount) or 0,
            text
        )

    end

    return text

end

--------------------------------------------------
-- Print Active Event
--------------------------------------------------

function FFR_InputMarket:printActiveEvent()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR INPUT EVENT"
    )

    if self.activeEvent == nil then

        Logging.info(
            "No active supplier program"
        )

        Logging.info(
            "========================================"
        )

        return

    end

    Logging.info(
        "%s",
        tostring(
            self.activeEvent.name
        )
    )

    local discountFound = false

    for inputName, inputData in pairs(
        self.inputs
    ) do

        local modifier =

            tonumber(
                inputData.modifier
            )
            or 1.00

        if modifier < 1.00 then

            local discount =

                math.floor(
                    (
                        1
                        - modifier
                    )
                    * 100
                    + 0.5
                )

            Logging.info(
                "%s %d%% OFF",
                tostring(inputName),
                discount
            )

            discountFound = true

        end

    end

    if not discountFound then

        Logging.info(
            "No supplier discounts are currently active"
        )

    end

    Logging.info(
        "%s",
        self:getExpiryText()
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Print Market Status
--------------------------------------------------

function FFR_InputMarket:printMarket()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR INPUT MARKET STATUS"
    )

    Logging.info(
        "========================================"
    )

    if self.activeEvent ~= nil then

        Logging.info(
            "Program: %s",
            tostring(
                self.activeEvent.name
            )
        )

        Logging.info(
            "%s",
            self:getExpiryText()
        )

    end

    for inputName, inputData in pairs(
        self.inputs
    ) do

        local modifier =

            tonumber(
                inputData.modifier
            )
            or 1.00

        local discount =

            math.floor(
                (
                    1
                    - modifier
                )
                * 100
                + 0.5
            )

        if discount > 0 then

            Logging.info(
                "%s: modifier %.2f, discount %d%%",
                tostring(inputName),
                modifier,
                discount
            )

        else

            Logging.info(
                "%s: modifier %.2f, regular price",
                tostring(inputName),
                modifier
            )

        end

    end

    Logging.info(
        "========================================"
    )

end