FFR_InputPriceManager = {}

--------------------------------------------------
-- Input prices (FFR owns them)
--
-- FFR sets the per-litre price of every product
-- classed as an input (seeds, fertilizer, lime,
-- chemicals, fuel; FFR_InputClassifier), so every
-- seller follows it: shop, base-game and modded
-- buying stations, bulk and pallets.
--
-- * Baseline: the price the map or mod gives the
--   fill type, read once per session before FFR
--   changes it.
-- * Current: baseline x the input market's
--   condition for that category (a deal lowers it,
--   a shortage raises it; FFR_InputMarket).
--
-- The current price is written into the fill type
-- (fillType.pricePerLiter) whenever conditions
-- change, on the server and on every client, and
-- the baseline is put back when the map unloads.
--
-- Shop items with a fixed store price (bags,
-- pallets, tanks) get the same condition, plus any
-- brand program, through the shop price hook.
--------------------------------------------------

FFR_InputPriceManager.isInstalled = false

-- fillTypeIndex -> map/mod baseline price per litre (this session).
FFR_InputPriceManager.baselines = {}

-- fillTypeIndex -> category currently written, for restoring removed ones.
FFR_InputPriceManager.applied = {}

-- Changes when conditions or classes change; prices are rewritten then.
FFR_InputPriceManager.appliedSignature = nil

FFR_InputPriceManager.updateTimer = 0

FFR_InputPriceManager.loggedPrices = {}

--------------------------------------------------
-- Fill types
--------------------------------------------------

function FFR_InputPriceManager.getFillTypes()
    if g_fillTypeManager == nil then return {} end
    if g_fillTypeManager.getFillTypes ~= nil then
        local ok, result = pcall(g_fillTypeManager.getFillTypes, g_fillTypeManager)
        if ok and type(result) == "table" then return result end
    end
    return g_fillTypeManager.fillTypes or {}
end

function FFR_InputPriceManager.formatMoney(value)
    if g_FFRDashboardDataManager ~= nil and g_FFRDashboardDataManager.formatMoney ~= nil then
        return g_FFRDashboardDataManager:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

-- What the market says about every category right now, plus the classifier
-- version: if this text changes, prices are rewritten.
function FFR_InputPriceManager.getSignature(market)
    local parts = {}
    for name, data in pairs(market.inputs or {}) do
        table.insert(parts, name .. "=" .. string.format("%.4f", tonumber(data.modifier) or 1))
    end
    table.sort(parts)
    table.insert(parts, "classes=" .. tostring(FFR_InputClassifier ~= nil and FFR_InputClassifier.version or 0))
    return table.concat(parts, ";")
end

--------------------------------------------------
-- Writing prices
--------------------------------------------------

function FFR_InputPriceManager.applyPrices()
    local market = g_FFR ~= nil and g_FFR.inputMarket or nil
    if market == nil or FFR_InputClassifier == nil then return end
    local seen = {}
    for _, fillType in pairs(FFR_InputPriceManager.getFillTypes()) do
        local index = type(fillType) == "table" and fillType.index or nil
        if index ~= nil and fillType.name ~= nil then
            local category = FFR_InputClassifier.classifyFillType(fillType.name)
            local baseline = FFR_InputPriceManager.baselines[index]
            if category ~= nil then
                if baseline == nil then
                    -- First time FFR prices this fill type: what the map or mod set.
                    baseline = tonumber(fillType.pricePerLiter)
                    FFR_InputPriceManager.baselines[index] = baseline
                end
                if baseline ~= nil and baseline > 0 then
                    local modifier = tonumber(market:getModifier(category)) or 1
                    fillType.pricePerLiter = baseline * modifier
                    FFR_InputPriceManager.applied[index] = category
                    seen[index] = true
                    FFR_InputPriceManager.logPrice(fillType, baseline, modifier, market)
                end
            end
        end
    end
    -- Products no longer classed as inputs go back to their map/mod price.
    for index in pairs(FFR_InputPriceManager.applied) do
        if not seen[index] then
            FFR_InputPriceManager.restore(index)
        end
    end
end

function FFR_InputPriceManager.restore(index)
    local baseline = FFR_InputPriceManager.baselines[index]
    local fillType = g_fillTypeManager ~= nil and g_fillTypeManager:getFillTypeByIndex(index) or nil
    if fillType ~= nil and baseline ~= nil then fillType.pricePerLiter = baseline end
    FFR_InputPriceManager.applied[index] = nil
end

function FFR_InputPriceManager.restoreAll()
    for index in pairs(FFR_InputPriceManager.applied) do
        FFR_InputPriceManager.restore(index)
    end
    FFR_InputPriceManager.applied = {}
end

-- Once per fill type and condition, so log.txt shows what FFR set.
function FFR_InputPriceManager.logPrice(fillType, baseline, modifier, market)
    local event = market.activeEvent
    local key = tostring(fillType.name) .. "|" .. string.format("%.4f", modifier)
    if FFR_InputPriceManager.loggedPrices[key] then return end
    FFR_InputPriceManager.loggedPrices[key] = true
    if math.abs(modifier - 1) < 0.0001 then return end
    Logging.info("FFR Input Prices: %s now %s / 1,000 L (baseline %s, %+d%%, %s)",
        tostring(fillType.name),
        FFR_InputPriceManager.formatMoney(baseline * modifier * 1000),
        FFR_InputPriceManager.formatMoney(baseline * 1000),
        math.floor((modifier - 1) * 100 + (modifier >= 1 and 0.5 or -0.5)),
        tostring(event ~= nil and event.name or "condition"))
end

--------------------------------------------------
-- Fill types bought by the litre are remembered for
-- the Options list (prices come from the fill type).
--------------------------------------------------

function FFR_InputPriceManager.getCostPerLiter(economyManager, superFunc, fillTypeIndex, ...)
    if FFR_InputClassifier ~= nil and g_fillTypeManager ~= nil then
        local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
        if fillType ~= nil and fillType.name ~= nil then
            FFR_InputClassifier.markSeen(string.upper(fillType.name))
        end
    end
    return superFunc(economyManager, fillTypeIndex, ...)
end

--------------------------------------------------
-- Shop Price Hook
--
-- Bags, pallets and tanks in the shop have a fixed
-- store price, so the category condition (and any
-- brand program for the item's brand) is applied to
-- their buy price here.
--------------------------------------------------

function FFR_InputPriceManager.getBuyPrice(economyManager, superFunc, storeItem, ...)
    local results = {superFunc(economyManager, storeItem, ...)}
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.inputMarket == nil or FFR_InputClassifier == nil then
        return unpack(results)
    end
    local category = FFR_InputClassifier.classifyStoreItem(storeItem)
    if category == nil then return unpack(results) end
    local brand = FFR_InputClassifier.getBrandName(storeItem)
    local modifier = g_FFR.inputMarket:getPurchaseModifier(category, brand)
    if modifier == nil or modifier <= 0 or modifier == 1.00 then return unpack(results) end
    for index = 1, #results do
        if type(results[index]) == "number" then results[index] = results[index] * modifier end
    end
    if not FFR_InputPriceManager.hasLoggedShopPrice then
        FFR_InputPriceManager.hasLoggedShopPrice = true
        Logging.info("FFR Input Prices: Shop price set (%s%s x%.2f, %s)", tostring(category),
            brand ~= nil and (" " .. brand) or "", modifier, tostring(storeItem.xmlFilename))
    end
    return unpack(results)
end

--------------------------------------------------
-- Listener: rewrite prices when conditions change
--------------------------------------------------

function FFR_InputPriceManager:update(dt)
    FFR_InputPriceManager.updateTimer = FFR_InputPriceManager.updateTimer + dt
    if FFR_InputPriceManager.updateTimer < 1000 then return end
    FFR_InputPriceManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted or g_FFR.inputMarket == nil then return end
    local signature = FFR_InputPriceManager.getSignature(g_FFR.inputMarket)
    if signature == FFR_InputPriceManager.appliedSignature then return end
    local ok, err = pcall(FFR_InputPriceManager.applyPrices)
    if ok then
        FFR_InputPriceManager.appliedSignature = signature
    else
        Logging.warning("FFR Input Prices: Could not set input prices (%s)", tostring(err))
    end
end

function FFR_InputPriceManager:loadMap(mapName)
    FFR_InputPriceManager.baselines = {}
    FFR_InputPriceManager.applied = {}
    FFR_InputPriceManager.appliedSignature = nil
    FFR_InputPriceManager.loggedPrices = {}
    FFR_InputPriceManager.updateTimer = 0
end

-- The map's own prices come back before the next savegame loads.
function FFR_InputPriceManager:deleteMap()
    pcall(FFR_InputPriceManager.restoreAll)
    FFR_InputPriceManager.baselines = {}
    FFR_InputPriceManager.appliedSignature = nil
end

function FFR_InputPriceManager:draw() end
function FFR_InputPriceManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_InputPriceManager:keyEvent(unicode, sym, modifier, isDown) end

--------------------------------------------------
-- Install
--------------------------------------------------

function FFR_InputPriceManager:install()
    if self.isInstalled then return true end
    if EconomyManager ~= nil and EconomyManager.getBuyPrice ~= nil then
        EconomyManager.getBuyPrice = Utils.overwrittenFunction(EconomyManager.getBuyPrice, FFR_InputPriceManager.getBuyPrice)
        Logging.info("FFR Input Prices: Shop price hook installed")
    else
        Logging.warning("FFR Input Prices: EconomyManager.getBuyPrice unavailable; shop bags and pallets keep store prices")
    end
    if EconomyManager ~= nil and EconomyManager.getCostPerLiter ~= nil then
        EconomyManager.getCostPerLiter = Utils.overwrittenFunction(EconomyManager.getCostPerLiter, FFR_InputPriceManager.getCostPerLiter)
    end
    addModEventListener(FFR_InputPriceManager)
    self.isInstalled = true
    Logging.info("FFR Input Prices: FFR sets input prices (map and mod prices are the baseline)")
    return true
end

FFR_InputPriceManager:install()
