FFR_InsolvencyManager = {}

--------------------------------------------------
-- Insolvency ladder
--
-- Checked per farm on the server after each month's
-- bills. The farm climbs one rung per month it ends
-- overdrawn, at the month counts set by the
-- difficulty preset (FFR_Settings ... insolvency):
--
--   1 Warning        late payment on the credit file
--   2 Credit freeze  no new borrowing, +2 % on all loans
--   3 Loans called   the operating line is taken back
--                    out of the account, +4 % on all loans
--   4 Forced sale    lenders take back every financed
--                    and leased machine (FFR_Equipment-
--                    FinanceManager.repossessAll), then
--                    the bank sells machines (the
--                    cheapest one that covers the
--                    shortfall, else the most valuable,
--                    and repeats), then the cheapest land
--                    at 80 % of its value, until the
--                    account is back above $0
--
-- A month that ends with cash >= $0 drops the farm
-- one rung. Easy stops at credit freeze, so it never
-- forces a sale. Land with the farm's buildings on it
-- is never sold, so the farm always survives.
--
-- State lives on each farm's credit manager
-- (insolvencyStage, monthsOverdrawn, insolvencyNotice,
-- forcedSaleTotal), so it is saved and synced with it.
--------------------------------------------------

FFR_InsolvencyManager.NONE = 0
FFR_InsolvencyManager.WARNING = 1
FFR_InsolvencyManager.FREEZE = 2
FFR_InsolvencyManager.CALLED = 3
FFR_InsolvencyManager.FORCED_SALE = 4

-- Preset ladder keys, in stage order.
FFR_InsolvencyManager.LADDER_KEYS = {"warning", "freeze", "called", "forcedSale"}

-- English stage names for the log; players see ffr_insolvency_stage_<n>.
FFR_InsolvencyManager.STAGE_NAMES = {
    [0] = "Good standing",
    [1] = "Warning",
    [2] = "Credit frozen",
    [3] = "Loans called",
    [4] = "Forced sale"
}

function FFR_InsolvencyManager.getStageText(stage)
    local n = math.max(0, math.min(4, math.floor(tonumber(stage) or 0)))
    return FFR_L10n.t("ffr_insolvency_stage_" .. n)
end

FFR_InsolvencyManager.PENALTY_RATES = {
    [2] = 0.02,
    [3] = 0.04,
    [4] = 0.04
}

FFR_InsolvencyManager.LAND_SALE_SHARE = 0.80

-- Translation key of the refusal while credit is frozen.
FFR_InsolvencyManager.FROZEN_MESSAGE = "ffr_insolvency_frozen"

--------------------------------------------------
-- Queries (any machine; clients read synced state)
--------------------------------------------------

function FFR_InsolvencyManager.getStage(creditManager)
    return creditManager ~= nil and (tonumber(creditManager.insolvencyStage) or 0) or 0
end

function FFR_InsolvencyManager.getStageName(creditManager)
    return FFR_InsolvencyManager.getStageText(FFR_InsolvencyManager.getStage(creditManager))
end

function FFR_InsolvencyManager.isFrozen(creditManager)
    return FFR_InsolvencyManager.getStage(creditManager) >= FFR_InsolvencyManager.FREEZE
end

function FFR_InsolvencyManager.getPenaltyRate(creditManager)
    return FFR_InsolvencyManager.PENALTY_RATES[FFR_InsolvencyManager.getStage(creditManager)] or 0
end

function FFR_InsolvencyManager.getLadder()
    local ladder = FFR_Settings ~= nil and FFR_Settings.getValue("insolvency") or nil
    return ladder or {warning = 1, freeze = 3, called = 5, forcedSale = 6}
end

-- Highest stage reached after this many months overdrawn in a row.
function FFR_InsolvencyManager.getStageForMonths(months)
    local ladder = FFR_InsolvencyManager.getLadder()
    local stage = 0
    for index, key in ipairs(FFR_InsolvencyManager.LADDER_KEYS) do
        local threshold = tonumber(ladder[key])
        if threshold ~= nil and months >= threshold then stage = index end
    end
    return stage
end

-- Months overdrawn that puts a farm at the start of a stage (0 for good standing).
function FFR_InsolvencyManager.getMonthsForStage(stage)
    if stage <= 0 then return 0 end
    local key = FFR_InsolvencyManager.LADDER_KEYS[stage]
    return tonumber(FFR_InsolvencyManager.getLadder()[key]) or 0
end

-- Short text for the Bank page: what happens next if the account stays overdrawn.
function FFR_InsolvencyManager.getOutlook(creditManager)
    local stage = FFR_InsolvencyManager.getStage(creditManager)
    local months = tonumber(creditManager ~= nil and creditManager.monthsOverdrawn) or 0
    local ladder = FFR_InsolvencyManager.getLadder()
    for index = stage + 1, #FFR_InsolvencyManager.LADDER_KEYS do
        local threshold = tonumber(ladder[FFR_InsolvencyManager.LADDER_KEYS[index]])
        if threshold ~= nil then
            local left = math.max(1, threshold - months)
            return FFR_L10n.t("ffr_insolvency_outlook", FFR_InsolvencyManager.getStageText(index), FFR_L10n.months(left))
        end
    end
    if stage >= FFR_InsolvencyManager.FORCED_SALE then return FFR_L10n.t("ffr_insolvency_sales_continue") end
    return FFR_L10n.t("ffr_insolvency_no_further")
end

--------------------------------------------------
-- Monthly check (server)
--------------------------------------------------

function FFR_InsolvencyManager.formatMoney(value)
    if g_FFRMonthlyFinancialProcessor ~= nil then
        return g_FFRMonthlyFinancialProcessor:formatMoney(value)
    end
    return FFR_L10n.formatMoney(value)
end

function FFR_InsolvencyManager.getCash(state)
    if g_FFRMonthlyFinancialProcessor ~= nil then
        g_FFRMonthlyFinancialProcessor:refreshCash(state.farmId)
    end
    return tonumber(state.financialManager.cashOnHand) or 0
end

-- Runs after the month's bills. Returns a short bank notice for the
-- monthly window, or nil when there is nothing to say.
function FFR_InsolvencyManager.processFarm(state)
    local credit = state.creditManager
    local oldStage = FFR_InsolvencyManager.getStage(credit)
    local months = tonumber(credit.monthsOverdrawn) or 0
    local cash = FFR_InsolvencyManager.getCash(state)
    local stage

    if cash < 0 then
        months = months + 1
        -- Never above the preset's last stage (the difficulty may have been lowered).
        stage = math.min(math.max(oldStage, FFR_InsolvencyManager.getStageForMonths(months)),
            FFR_InsolvencyManager.getStageForMonths(math.huge))
    elseif oldStage > 0 then
        stage = oldStage - 1
        months = FFR_InsolvencyManager.getMonthsForStage(stage)
    else
        stage, months = 0, 0
    end

    credit.monthsOverdrawn = months
    credit.insolvencyStage = stage

    local notice = nil

    if stage > oldStage then
        Logging.warning("FFR Insolvency: Farm %d is %s (%d month%s overdrawn)", state.farmId,
            FFR_InsolvencyManager.STAGE_NAMES[stage], months, months == 1 and "" or "s")
        -- The first overdrawn month goes on the credit file, unless a loan
        -- payment already did that this month (monthly processor).
        local breakdown = state.lastBreakdown or {}
        local loanPaymentLate = ((tonumber(breakdown.interest) or 0) + (tonumber(breakdown.landPayment) or 0)) > 0
        if oldStage == 0 and not loanPaymentLate then
            credit:addLatePayment()
        end
        notice = FFR_L10n.t("ffr_insolvency_notice_stage", FFR_InsolvencyManager.getStageText(stage), FFR_L10n.months(months))
    elseif stage < oldStage then
        Logging.info("FFR Insolvency: Farm %d back to %s", state.farmId, FFR_InsolvencyManager.STAGE_NAMES[stage])
        notice = FFR_L10n.t("ffr_insolvency_notice_back", FFR_InsolvencyManager.getStageText(stage))
    elseif stage > 0 and cash < 0 then
        notice = FFR_L10n.t("ffr_insolvency_notice_still", FFR_InsolvencyManager.getStageText(stage), FFR_L10n.months(months))
    end

    if stage >= FFR_InsolvencyManager.CALLED and cash < 0 then
        local called = FFR_InsolvencyManager.callOperatingLine(state)
        if called > 0 then
            notice = FFR_L10n.t("ffr_insolvency_notice_called", FFR_InsolvencyManager.formatMoney(called))
        end
    end

    if stage >= FFR_InsolvencyManager.FORCED_SALE and FFR_InsolvencyManager.getCash(state) < 0 then
        local raised, items = FFR_InsolvencyManager.forcedSale(state)
        if items > 0 then
            notice = FFR_L10n.t(items == 1 and "ffr_insolvency_notice_sale_one" or "ffr_insolvency_notice_sale_many",
                items, FFR_InsolvencyManager.formatMoney(raised))
        end
    end

    if notice ~= nil then
        credit.insolvencyNotice = notice
    elseif stage == 0 then
        credit.insolvencyNotice = ""
    end

    return notice
end

-- Loans called: the operating line comes out of the account in full.
function FFR_InsolvencyManager.callOperatingLine(state)
    local f = state.financialManager
    local balance = tonumber(f.operatingLoan) or 0
    if balance <= 0 or g_FFRMonthlyFinancialProcessor == nil then return 0 end
    local moneyType = MoneyType ~= nil and (MoneyType.LOAN or MoneyType.OTHER) or nil
    if not g_FFRMonthlyFinancialProcessor:applyFarmBalance(-balance, moneyType, state.farmId) then return 0 end
    f.operatingLoan = 0
    f:update()
    Logging.warning("FFR Insolvency: Farm %d operating line of $%d called in", state.farmId, math.floor(balance))
    return balance
end

--------------------------------------------------
-- Forced sale (server)
--------------------------------------------------

function FFR_InsolvencyManager.isVehicleInUse(vehicle)
    local root = vehicle.rootVehicle or vehicle
    for _, v in ipairs({vehicle, root}) do
        if v.getIsControlled ~= nil then
            local ok, controlled = pcall(v.getIsControlled, v)
            if ok and controlled then return true end
        end
    end
    return false
end

function FFR_InsolvencyManager.canSellVehicle(vehicle)
    local typeName = string.lower(tostring(vehicle.typeName or ""))
    if string.find(typeName, "locomotive", 1, true) or string.find(typeName, "train", 1, true) then return false end
    if g_storeManager ~= nil and g_storeManager.getItemByXMLFilename ~= nil and vehicle.configFileName ~= nil then
        local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, vehicle.configFileName)
        if ok and item ~= nil and item.canBeSold == false then return false end
    end
    return not FFR_InsolvencyManager.isVehicleInUse(vehicle)
end

-- The farm's owned, sellable machines, cheapest first.
function FFR_InsolvencyManager.getSellableVehicles(farmId)
    local sync = g_FFRContinuousAssetSyncManager
    local list = {}
    if sync == nil then return list end
    for _, vehicle in pairs(sync:getMissionVehicles() or {}) do
        if sync:isVehicleOwnedByFarm(vehicle, farmId) and FFR_InsolvencyManager.canSellVehicle(vehicle) then
            local value = tonumber(sync:getVehicleValue(vehicle)) or 0
            if value > 0 then
                table.insert(list, {vehicle = vehicle, value = value, name = sync:getVehicleName(vehicle)})
            end
        end
    end
    table.sort(list, function(a, b) return a.value < b.value end)
    return list
end

function FFR_InsolvencyManager.removeVehicle(vehicle)
    local mission = g_currentMission
    if mission.vehicleSystem ~= nil and mission.vehicleSystem.removeVehicle ~= nil then
        mission.vehicleSystem:removeVehicle(vehicle)
    elseif mission.removeVehicle ~= nil then
        mission:removeVehicle(vehicle, false)
    end
    if not vehicle.isDeleted and vehicle.delete ~= nil then
        vehicle:delete()
    end
end

function FFR_InsolvencyManager.sellVehicle(state, entry)
    local ok, err = pcall(FFR_InsolvencyManager.removeVehicle, entry.vehicle)
    if not ok then
        Logging.warning("FFR Insolvency: Could not sell %s (%s)", tostring(entry.name), tostring(err))
        return false
    end
    local moneyType = MoneyType ~= nil and (MoneyType.SHOP_VEHICLE_SELL or MoneyType.OTHER) or nil
    g_FFRMonthlyFinancialProcessor:applyFarmBalance(entry.value, moneyType, state.farmId)
    Logging.warning("FFR Insolvency: Farm %d forced sale of %s for $%d", state.farmId, tostring(entry.name), math.floor(entry.value))
    return true
end

-- Farmland ids where the farm has buildings; never sold.
function FFR_InsolvencyManager.getBuiltOnFarmlands(farmId)
    local built = {}
    local placeables = g_currentMission.placeableSystem ~= nil and g_currentMission.placeableSystem.placeables or {}
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return built end
    for _, placeable in pairs(placeables) do
        local owner = placeable.getOwnerFarmId ~= nil and placeable:getOwnerFarmId() or placeable.ownerFarmId
        if owner == farmId and placeable.rootNode ~= nil then
            local ok, x, _, z = pcall(getWorldTranslation, placeable.rootNode)
            if ok and x ~= nil then
                local found, id = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
                if found and id ~= nil then built[id] = true end
            end
        end
    end
    return built
end

-- The farm's land without buildings, cheapest first.
function FFR_InsolvencyManager.getSellableLand(farmId)
    local list = {}
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return list end
    local built = FFR_InsolvencyManager.getBuiltOnFarmlands(farmId)
    for key, farmland in pairs(g_farmlandManager.farmlands) do
        local id = type(farmland) == "table" and farmland.id or key
        local ok, owner = pcall(g_farmlandManager.getFarmlandOwner, g_farmlandManager, id)
        local price = type(farmland) == "table" and tonumber(farmland.price) or nil
        -- Rented-in land is not the farm's to sell (FFR_LandRentManager).
        local rented = FFR_LandRentManager ~= nil and FFR_LandRentManager.isRentedIn(id)
        if ok and owner == farmId and not rented and not built[id] and price ~= nil and price > 0 then
            table.insert(list, {id = id, value = price * FFR_InsolvencyManager.LAND_SALE_SHARE})
        end
    end
    table.sort(list, function(a, b) return a.value < b.value end)
    return list
end

function FFR_InsolvencyManager.sellLand(state, entry)
    local noOwner = FarmlandManager ~= nil and FarmlandManager.NO_OWNER_FARM_ID or 0
    local ok, err = pcall(g_farmlandManager.setLandOwnership, g_farmlandManager, entry.id, noOwner)
    if not ok then
        Logging.warning("FFR Insolvency: Could not sell farmland %s (%s)", tostring(entry.id), tostring(err))
        return false
    end
    -- Tell the players' machines about the new owner.
    if g_server ~= nil and FarmlandStateEvent ~= nil and FFR_Network ~= nil and FFR_Network.isMultiplayer() then
        pcall(function() g_server:broadcastEvent(FarmlandStateEvent.new(entry.id, noOwner, 0)) end)
    end
    local moneyType = MoneyType ~= nil and (MoneyType.FIELD_SELL or MoneyType.OTHER) or nil
    g_FFRMonthlyFinancialProcessor:applyFarmBalance(entry.value, moneyType, state.farmId)
    Logging.warning("FFR Insolvency: Farm %d forced sale of farmland %d for $%d (80%% of value)", state.farmId, entry.id, math.floor(entry.value))
    return true
end

-- From a list sorted cheapest first: the cheapest entry that covers the
-- shortfall on its own, or the most valuable one if none does. Removes it.
function FFR_InsolvencyManager.takeToCover(list, shortfall)
    for index, entry in ipairs(list) do
        if entry.value >= shortfall then return table.remove(list, index) end
    end
    return table.remove(list)
end

-- Sells until the account is back above $0. Returns money raised, items sold.
-- Machines go first, picked so the bank sells as little as possible; land
-- (cheapest first) only once no machine is left.
function FFR_InsolvencyManager.forcedSale(state)
    if g_currentMission == nil or g_FFRMonthlyFinancialProcessor == nil then return 0, 0 end
    local raised, items = 0, 0
    -- The lenders take back financed and leased machines first.
    if FFR_EquipmentFinanceManager ~= nil then
        local ok, net, count = pcall(FFR_EquipmentFinanceManager.repossessAll, state)
        if ok then
            raised, items = raised + net, items + count
        else
            Logging.warning("FFR Insolvency: Taking back financed machines failed (%s)", tostring(net))
        end
    end
    local vehicles = FFR_InsolvencyManager.getSellableVehicles(state.farmId)
    while #vehicles > 0 do
        local cash = FFR_InsolvencyManager.getCash(state)
        if cash >= 0 then break end
        local entry = FFR_InsolvencyManager.takeToCover(vehicles, -cash)
        if FFR_InsolvencyManager.sellVehicle(state, entry) then
            raised, items = raised + entry.value, items + 1
        end
    end
    for _, entry in ipairs(FFR_InsolvencyManager.getSellableLand(state.farmId)) do
        if FFR_InsolvencyManager.getCash(state) >= 0 then break end
        if FFR_InsolvencyManager.sellLand(state, entry) then
            raised, items = raised + entry.value, items + 1
        end
    end
    local credit = state.creditManager
    credit.forcedSaleTotal = (tonumber(credit.forcedSaleTotal) or 0) + raised
    if items > 0 then
        Logging.warning("FFR Insolvency: Farm %d forced sale raised $%d from %d item(s); cash now $%d",
            state.farmId, math.floor(raised), items, math.floor(FFR_InsolvencyManager.getCash(state)))
    end
    return raised, items
end

Logging.info("FFR Insolvency: Bank ladder installed")
