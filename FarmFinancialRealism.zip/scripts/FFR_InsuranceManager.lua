FFR_InsuranceManager = {}

function FFR_InsuranceManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_InsuranceManager}
    )

    --------------------------------------------------
    -- Policies
    --------------------------------------------------

    self.cropInsuranceActive = true

    self.equipmentInsuranceActive = true

    self.liabilityInsuranceActive = true

    --------------------------------------------------
    -- Coverage Values
    --------------------------------------------------

    self.cropCoveragePercent = 0.80

    self.equipmentCoveragePercent = 0.90

    self.liabilityCoverageAmount = 1000000

    --------------------------------------------------
    -- Premiums
    --------------------------------------------------

    self.cropPremium = 0

    self.equipmentPremium = 0

    self.liabilityPremium = 250

    self.totalPremium = 0

    --------------------------------------------------
    -- Claims
    --------------------------------------------------

    self.totalClaimsPaid = 0

    self.totalPremiumsPaid = 0

    self.claimCount = 0

    --------------------------------------------------
    -- Risk
    --------------------------------------------------

    self.riskLevel = "NORMAL"

    return self

end

--------------------------------------------------
-- Premium Calculation
--------------------------------------------------

function FFR_InsuranceManager:updatePremiums(

    financialManager

)

    if financialManager == nil then
        return
    end

    --------------------------------------------------
    -- Crop cover is a real policy now, bought once a
    -- year on the Insurance page and paid at purchase
    -- (FFR_CropInsuranceManager). Nothing is charged
    -- here for crops.
    --------------------------------------------------

    self.cropPremium = 0

    self.equipmentPremium =

        financialManager.equipmentValue
        * 0.0010

    self.totalPremium =

        self.cropPremium

        + self.equipmentPremium

        + self.liabilityPremium

end

--------------------------------------------------
-- Monthly Premium Charge
--------------------------------------------------

function FFR_InsuranceManager:processMonth(

    financialManager

)

    self:updatePremiums(
        financialManager
    )

    local monthlyCost =

        self.totalPremium
        / 12

    financialManager:removeCash(
        monthlyCost
    )

    financialManager.monthlyInsuranceCost =
        monthlyCost

    self.totalPremiumsPaid =

        self.totalPremiumsPaid
        + monthlyCost

    Logging.info(

        "FFR Insurance Premium: $"

        .. tostring(
            math.floor(
                monthlyCost
            )
        )

    )

end

--------------------------------------------------
-- Crop Claim
--------------------------------------------------

function FFR_InsuranceManager:fileCropClaim(

    lossAmount,

    financialManager

)

    if self.cropInsuranceActive == false then

        return 0

    end

    local payment =

        lossAmount
        * self.cropCoveragePercent

    financialManager:addCash(
        payment
    )

    self.totalClaimsPaid =
        self.totalClaimsPaid
        + payment

    self.claimCount =
        self.claimCount + 1

    Logging.info(

        "FFR Crop Claim Paid: $"

        .. tostring(
            math.floor(
                payment
            )
        )

    )

    return payment

end

--------------------------------------------------
-- Equipment Claim
--------------------------------------------------

function FFR_InsuranceManager:fileEquipmentClaim(

    lossAmount,

    financialManager

)

    if self.equipmentInsuranceActive == false then

        return 0

    end

    local payment =

        lossAmount
        * self.equipmentCoveragePercent

    financialManager:addCash(
        payment
    )

    self.totalClaimsPaid =

        self.totalClaimsPaid
        + payment

    self.claimCount =
        self.claimCount + 1

    Logging.info(

        "FFR Equipment Claim Paid: $"

        .. tostring(
            math.floor(
                payment
            )
        )

    )

    return payment

end

--------------------------------------------------
-- Risk Evaluation
--------------------------------------------------

function FFR_InsuranceManager:updateRisk(

    creditManager

)

    if creditManager == nil then
        return
    end

    local rating =
        creditManager.creditRating

    if rating == "EXCELLENT" then

        self.riskLevel = "LOW"

    elseif rating == "GOOD" then

        self.riskLevel = "NORMAL"

    elseif rating == "FAIR" then

        self.riskLevel = "ELEVATED"

    elseif rating == "CONCERNING" then

        self.riskLevel = "HIGH"

    else

        self.riskLevel = "SEVERE"

    end

end

--------------------------------------------------
-- Insurance Requirement Check
--------------------------------------------------

function FFR_InsuranceManager:isBankCompliant()

    if self.liabilityInsuranceActive == false then
        return false
    end

    if self.equipmentInsuranceActive == false then
        return false
    end

    return true

end

--------------------------------------------------
-- Enable / Disable Policies
--------------------------------------------------

function FFR_InsuranceManager:setCropInsurance(
    state
)

    self.cropInsuranceActive = state

end

function FFR_InsuranceManager:setEquipmentInsurance(
    state
)

    self.equipmentInsuranceActive = state

end

function FFR_InsuranceManager:setLiabilityInsurance(
    state
)

    self.liabilityInsuranceActive = state

end

--------------------------------------------------
-- Insurance Report
--------------------------------------------------

function FFR_InsuranceManager:printInsuranceReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR INSURANCE REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Risk Level: "
        .. self.riskLevel
    )

    Logging.info(
        "Crop Insurance: "
        .. tostring(
            self.cropInsuranceActive
        )
    )

    Logging.info(
        "Equipment Insurance: "
        .. tostring(
            self.equipmentInsuranceActive
        )
    )

    Logging.info(
        "Liability Insurance: "
        .. tostring(
            self.liabilityInsuranceActive
        )
    )

    Logging.info(
        "Annual Premium: $"
        .. tostring(
            math.floor(
                self.totalPremium
            )
        )
    )

    Logging.info(
        "Claims Paid: $"
        .. tostring(
            math.floor(
                self.totalClaimsPaid
            )
        )
    )

    Logging.info(
        "Claim Count: "
        .. tostring(
            self.claimCount
        )
    )

    Logging.info(
        "========================================"
    )

end