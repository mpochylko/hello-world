FFR_InventorySyncManager = {}

function FFR_InventorySyncManager:new()
    local self = {}
    setmetatable(self, {__index = FFR_InventorySyncManager})
    self.updateTimer = 0
    self.updateInterval = 10000
    self.lastInventoryValue = -1
    self.lastInventoryVolume = -1
    self.lastInventoryTypes = -1
    self.syncCount = 0
    self.changeCount = 0
    self.isActive = true
    return self
end

function FFR_InventorySyncManager:getActiveFarmId()
    if g_FFR ~= nil and g_FFR.gameIntegrationManager ~= nil and g_FFR.gameIntegrationManager.getActiveFarmId ~= nil then
        local farmId = g_FFR.gameIntegrationManager:getActiveFarmId()
        if farmId ~= nil and farmId > 0 then return farmId end
    end
    if g_currentMission ~= nil and g_currentMission.getFarmId ~= nil then
        local farmId = g_currentMission:getFarmId()
        if farmId ~= nil and farmId > 0 then return farmId end
    end
    return nil
end

function FFR_InventorySyncManager:getOwnerFarmId(object)
    if object == nil then return nil end
    if object.getOwnerFarmId ~= nil then
        local ok, value = pcall(object.getOwnerFarmId, object)
        if ok then return tonumber(value) end
    end
    if object.ownerFarmId ~= nil then return tonumber(object.ownerFarmId) end
    if object.farmId ~= nil then return tonumber(object.farmId) end
    if object.owningPlaceable ~= nil then return self:getOwnerFarmId(object.owningPlaceable) end
    return nil
end

function FFR_InventorySyncManager:getFillTypeName(fillTypeIndex)
    if g_fillTypeManager == nil or g_fillTypeManager.getFillTypeByIndex == nil then
        return tostring(fillTypeIndex)
    end
    local fillType = g_fillTypeManager:getFillTypeByIndex(fillTypeIndex)
    if fillType == nil then return tostring(fillTypeIndex) end
    return tostring(fillType.name or fillType.title or fillTypeIndex)
end

function FFR_InventorySyncManager:isFFRCommodity(fillTypeIndex)
    if g_FFR == nil or g_FFR.commodityManager == nil
        or type(g_FFR.commodityManager.commodities) ~= "table" then
        return false
    end

    local fillTypeName = self:getFillTypeName(fillTypeIndex)
    return g_FFR.commodityManager.commodities[fillTypeName] ~= nil
        or g_FFR.commodityManager.commodities[string.upper(fillTypeName)] ~= nil
end

function FFR_InventorySyncManager:getPricePerLiter(fillTypeIndex)
    -- One lookup per fill type per sync; getBestPrice walks every selling station.
    if self.priceCache ~= nil and self.priceCache[fillTypeIndex] ~= nil then
        return self.priceCache[fillTypeIndex]
    end
    local price = self:lookupPricePerLiter(fillTypeIndex)
    if self.priceCache ~= nil then self.priceCache[fillTypeIndex] = price end
    return price
end

function FFR_InventorySyncManager:lookupPricePerLiter(fillTypeIndex)
    -- Selling stations are valid only for commodities registered in FFR.
    -- Inputs and chemicals stay in inventory without being offered to sell points.
    if self:isFFRCommodity(fillTypeIndex) and g_FFRStationPriceManager ~= nil then
        local best = g_FFRStationPriceManager:getBestPrice(fillTypeIndex)
        if best ~= nil and tonumber(best.ffrPrice) ~= nil then
            return tonumber(best.ffrPrice) / 1000
        end
    end

    -- Use the native economy value when available without scanning sell points.
    if g_currentMission ~= nil and g_currentMission.economyManager ~= nil
        and g_currentMission.economyManager.getPricePerLiter ~= nil then
        local ok, value = pcall(
            g_currentMission.economyManager.getPricePerLiter,
            g_currentMission.economyManager,
            fillTypeIndex,
            0
        )
        if ok then return math.max(0, tonumber(value) or 0) end
    end

    return 0
end

function FFR_InventorySyncManager:addInventory(inventory, fillTypeIndex, liters, source)
    fillTypeIndex = tonumber(fillTypeIndex)
    liters = tonumber(liters) or 0
    if fillTypeIndex == nil or liters <= 0 then return end

    local key = tostring(fillTypeIndex)
    local item = inventory[key]
    if item == nil then
        item = {
            id = key,
            fillTypeIndex = fillTypeIndex,
            name = self:getFillTypeName(fillTypeIndex),
            liters = 0,
            marketValue = 0,
            sourceCount = 0
        }
        inventory[key] = item
    end

    item.liters = item.liters + liters
    item.marketValue = item.marketValue + liters * self:getPricePerLiter(fillTypeIndex)
    item.sourceCount = item.sourceCount + 1
    item.lastSource = source
end

function FFR_InventorySyncManager:addFillLevelTable(inventory, fillLevels, source)
    if type(fillLevels) ~= "table" then return end
    for fillTypeIndex, liters in pairs(fillLevels) do
        if type(liters) == "number" then
            self:addInventory(inventory, fillTypeIndex, liters, source)
        elseif type(liters) == "table" then
            local value = liters.fillLevel or liters.level or liters.amount
            self:addInventory(inventory, fillTypeIndex, value, source)
        end
    end
end

function FFR_InventorySyncManager:scanStorage(inventory, storage, farmId, source)
    if storage == nil then return end
    -- Production point storages are also registered in the storage system;
    -- count each storage object once per sync.
    if self.seenStorages ~= nil then
        if self.seenStorages[storage] then return end
        self.seenStorages[storage] = true
    end
    local ownerFarmId = self:getOwnerFarmId(storage)
    if ownerFarmId ~= nil and ownerFarmId ~= farmId then return end

    if storage.getFillLevels ~= nil then
        local ok, fillLevels = pcall(storage.getFillLevels, storage, farmId)
        if ok and type(fillLevels) == "table" then
            self:addFillLevelTable(inventory, fillLevels, source)
            return
        end
    end
    self:addFillLevelTable(inventory, storage.fillLevels, source)
end

function FFR_InventorySyncManager:scanRegisteredStorages(inventory, farmId)
    if g_currentMission == nil or g_currentMission.storageSystem == nil then return end
    local storageSystem = g_currentMission.storageSystem
    local storages = nil

    if storageSystem.getStorages ~= nil then
        local ok, result = pcall(storageSystem.getStorages, storageSystem)
        if ok then storages = result end
    end
    storages = storages or storageSystem.storages
    if type(storages) ~= "table" then return end

    for key, value in pairs(storages) do
        local storage = value
        if type(key) == "table" then storage = key end
        if type(storage) == "table" then
            self:scanStorage(inventory, storage, farmId, "storage")
        end
    end
end

function FFR_InventorySyncManager:scanProductionStorage(inventory, farmId)
    if g_currentMission == nil or g_currentMission.productionChainManager == nil then return end
    local points = g_currentMission.productionChainManager.productionPoints
    if type(points) ~= "table" then return end

    for _, point in pairs(points) do
        if type(point) == "table" then
            local ownerFarmId = self:getOwnerFarmId(point)
            if ownerFarmId == nil or ownerFarmId == farmId then
                self:scanStorage(inventory, point.storage, farmId, "production")
                self:scanStorage(inventory, point.inputStorage, farmId, "productionInput")
                self:scanStorage(inventory, point.outputStorage, farmId, "productionOutput")
            end
        end
    end
end

function FFR_InventorySyncManager:isLooseInventoryObject(vehicle, farmId)
    if vehicle == nil or self:getOwnerFarmId(vehicle) ~= farmId then return false end
    local typeName = string.lower(tostring(vehicle.typeName or ""))
    return typeName == "pallet"
        or typeName == "bigbag"
        or string.find(typeName, "pallet", 1, true) ~= nil
        or string.find(typeName, "bigbag", 1, true) ~= nil
end

function FFR_InventorySyncManager:scanLooseInventory(inventory, farmId)
    if g_currentMission == nil then return end
    local vehicles = g_currentMission.vehicles
    if vehicles == nil and g_currentMission.vehicleSystem ~= nil then
        vehicles = g_currentMission.vehicleSystem.vehicles
    end
    if type(vehicles) ~= "table" then return end

    for _, vehicle in pairs(vehicles) do
        if self:isLooseInventoryObject(vehicle, farmId) and vehicle.getFillUnits ~= nil then
            local ok, fillUnits = pcall(vehicle.getFillUnits, vehicle)
            if ok and type(fillUnits) == "table" then
                for fillUnitIndex, _ in pairs(fillUnits) do
                    local fillTypeIndex = nil
                    local fillLevel = nil
                    if vehicle.getFillUnitFillType ~= nil then
                        local success, value = pcall(vehicle.getFillUnitFillType, vehicle, fillUnitIndex)
                        if success then fillTypeIndex = value end
                    end
                    if vehicle.getFillUnitFillLevel ~= nil then
                        local success, value = pcall(vehicle.getFillUnitFillLevel, vehicle, fillUnitIndex)
                        if success then fillLevel = value end
                    end
                    self:addInventory(inventory, fillTypeIndex, fillLevel, "looseObject")
                end
            end
        end
    end
end

-- Every farm's stored goods, each into its own financial profile.
function FFR_InventorySyncManager:syncInventory()
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.getFarmStates == nil then return false end
    for _, state in ipairs(g_FFR:getFarmStates()) do
        self:syncFarmInventory(state.farmId, state)
    end
    self.syncCount = self.syncCount + 1
    return true
end

function FFR_InventorySyncManager:syncFarmInventory(farmId, state)
    local inventory = {}
    self.seenStorages = {}
    self.priceCache = {}
    self:scanRegisteredStorages(inventory, farmId)
    self:scanProductionStorage(inventory, farmId)
    self:scanLooseInventory(inventory, farmId)
    self.seenStorages = nil
    self.priceCache = nil

    local totalValue = 0
    local totalVolume = 0
    local typeCount = 0
    for _, item in pairs(inventory) do
        totalValue = totalValue + (tonumber(item.marketValue) or 0)
        totalVolume = totalVolume + (tonumber(item.liters) or 0)
        typeCount = typeCount + 1
    end

    state.assetManager.inventoryAssets = inventory
    state.assetManager:updateTotals()
    state.assetManager:updateFinancialManager(state.financialManager)
    state.financialManager:update()

    local last = state.sync
    local changed = typeCount ~= (last.lastInventoryTypes or -1)
        or math.abs(totalVolume - (last.lastInventoryVolume or -1)) >= 1
        or math.abs(totalValue - (last.lastInventoryValue or -1)) >= 1

    if changed then
        Logging.info(
            "FFR Inventory Sync: Farm %d, %d fill types, %d L, $%d",
            farmId,
            typeCount,
            math.floor(totalVolume),
            math.floor(totalValue)
        )
        self.changeCount = self.changeCount + 1
    end

    last.lastInventoryTypes = typeCount
    last.lastInventoryVolume = totalVolume
    last.lastInventoryValue = totalValue
    return true
end

function FFR_InventorySyncManager:update(dt)
    if not self.isActive then return end
    -- Inventory is valued on the server; clients receive the totals.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer < self.updateInterval then return end
    self.updateTimer = 0
    self:syncInventory()
end

function FFR_InventorySyncManager:loadMap(mapName)
    self.updateTimer = 0
    self.lastInventoryValue = -1
    self.lastInventoryVolume = -1
    self.lastInventoryTypes = -1
end

function FFR_InventorySyncManager:deleteMap()
    self.updateTimer = 0
end

function FFR_InventorySyncManager:draw() end
function FFR_InventorySyncManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_InventorySyncManager:keyEvent(unicode, sym, modifier, isDown) end

g_FFRInventorySyncManager = FFR_InventorySyncManager:new()
addModEventListener(g_FFRInventorySyncManager)
Logging.info("FFR Inventory Sync: Listener installed")
