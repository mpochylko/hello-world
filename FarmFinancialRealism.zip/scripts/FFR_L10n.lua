FFR_L10n = {}

--------------------------------------------------
-- Text, money and area for the player's language
-- and FS25 settings
--
-- * t(key, ...) - a text from translations/
--   translation_<language>.xml (FS25 picks the
--   player's language, English when a text is not
--   translated), with string.format arguments.
-- * formatMoney(value) - FS25's own money format:
--   the player's currency (USD / EUR / GBP, with the
--   game's conversion) and separators.
-- * formatArea(ha) / getAreaUnit() - hectares or
--   acres, as set in the player's game settings.
--
-- Every FFR text and amount a player sees goes
-- through these, never a hard-coded "$" or "ac".
--------------------------------------------------

FFR_L10n.MOD_NAME = g_currentModName

function FFR_L10n.hasText(key)
    if g_i18n == nil or key == nil then return false end
    if g_i18n.hasText ~= nil then
        local ok, has = pcall(g_i18n.hasText, g_i18n, key)
        if ok then return has == true end
    end
    return false
end

function FFR_L10n.t(key, ...)
    local text = nil
    if FFR_L10n.hasText(key) then
        local ok, value = pcall(g_i18n.getText, g_i18n, key)
        if ok and type(value) == "string" then text = value end
    end
    text = text or tostring(key)
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, text, ...)
        if ok then return formatted end
    end
    return text
end

-- Upper case that also works for accented and Cyrillic letters
-- (string.upper only knows A-Z).
function FFR_L10n.upper(text)
    local s = tostring(text or "")
    if utf8ToUpper ~= nil then
        local ok, upper = pcall(utf8ToUpper, s)
        if ok and type(upper) == "string" then return upper end
    end
    return string.upper(s)
end

-- "Global Drought" -> "global_drought" (part of a translation key).
function FFR_L10n.slug(text)
    local s = string.lower(tostring(text or "")):gsub("[^%w]+", "_")
    return (s:gsub("^_+", ""):gsub("_+$", ""))
end

-- Names kept in saves and synced data stay English (or codes); they are
-- translated when shown: prefix .. slug(name), or the name itself when
-- there is no such text (a mod's or an older save's own name).
function FFR_L10n.named(prefix, name)
    if name == nil then return "" end
    local key = prefix .. FFR_L10n.slug(name)
    if FFR_L10n.hasText(key) then return FFR_L10n.t(key) end
    return tostring(name)
end

-- Market and supplier events: ffr_event_<name> and ffr_event_<name>_desc.
function FFR_L10n.eventName(name)
    return FFR_L10n.named("ffr_event_", name)
end

function FFR_L10n.eventDescription(name, fallback)
    local key = "ffr_event_" .. FFR_L10n.slug(name) .. "_desc"
    if name ~= nil and FFR_L10n.hasText(key) then return FFR_L10n.t(key) end
    return tostring(fallback or "")
end

-- "$l10n_key" -> its text; anything else unchanged.
function FFR_L10n.convert(text)
    if type(text) ~= "string" or string.sub(text, 1, 6) ~= "$l10n_" then return text end
    return FFR_L10n.t(string.sub(text, 7))
end

--------------------------------------------------
-- Money
--------------------------------------------------

function FFR_L10n.fallbackMoney(value)
    local n = math.floor((tonumber(value) or 0) + 0.5)
    local s = tostring(math.abs(n))
    while true do
        local updated, count = string.gsub(s, "^(%d+)(%d%d%d)", "%1,%2")
        s = updated
        if count == 0 then break end
    end
    return (n < 0 and "-$" or "$") .. s
end

function FFR_L10n.formatMoney(value)
    local number = tonumber(value) or 0
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        -- FS25 formats the absolute value; FFR puts the minus sign in front.
        local ok, text = pcall(g_i18n.formatMoney, g_i18n, math.abs(number), 0, true, true)
        if ok and type(text) == "string" and text ~= "" then
            return (number < -0.5 and "-" or "") .. text
        end
    end
    return FFR_L10n.fallbackMoney(number)
end

-- Whole numbers with thousands separators (litres, head counts).
function FFR_L10n.formatNumber(value)
    local number = math.floor((tonumber(value) or 0) + 0.5)
    if g_i18n ~= nil and g_i18n.formatNumber ~= nil then
        local ok, text = pcall(g_i18n.formatNumber, g_i18n, number, 0)
        if ok and type(text) == "string" and text ~= "" then return text end
    end
    local s = tostring(math.abs(number))
    while true do
        local updated, count = string.gsub(s, "^(%d+)(%d%d%d)", "%1,%2")
        s = updated
        if count == 0 then break end
    end
    return (number < 0 and "-" or "") .. s
end

-- A product's name in the player's language: FS25's fill type title
-- ("WHEAT" -> "Wheat" / "Weizen"), else the name in title case.
function FFR_L10n.fillTypeTitle(name)
    local raw = tostring(name or "")
    if g_fillTypeManager ~= nil and g_fillTypeManager.getFillTypeByName ~= nil and raw ~= "" then
        local ok, fillType = pcall(g_fillTypeManager.getFillTypeByName, g_fillTypeManager, string.upper(raw))
        if ok and fillType ~= nil and type(fillType.title) == "string" and fillType.title ~= "" then
            return fillType.title
        end
    end
    local text = string.lower(raw):gsub("_", " ")
    return (text:gsub("(%a)([%w']*)", function(a, b) return string.upper(a) .. b end))
end

--------------------------------------------------
-- Months (FS25 period 1 = March)
--------------------------------------------------

function FFR_L10n.monthName(period)
    local p = math.floor(tonumber(period) or 0)
    if p < 1 or p > 12 then return "?" end
    return FFR_L10n.t("ffr_month_" .. p)
end

-- Three-letter form, its own text (cutting a translated name could split a letter).
function FFR_L10n.monthShort(period)
    local p = math.floor(tonumber(period) or 0)
    if p < 1 or p > 12 then return "?" end
    return FFR_L10n.t("ffr_month_short_" .. p)
end

-- "July, Year 2"
function FFR_L10n.date(period, year)
    return FFR_L10n.t("ffr_date", FFR_L10n.monthName(period), math.floor(tonumber(year) or 0))
end

-- "Jul, Y2"
function FFR_L10n.dateShort(period, year)
    return FFR_L10n.t("ffr_date_short", FFR_L10n.monthShort(period), math.floor(tonumber(year) or 0))
end

-- "1 month" / "5 months"
function FFR_L10n.months(count)
    local n = math.floor(tonumber(count) or 0)
    if n == 1 then return FFR_L10n.t("ffr_common_month_one") end
    return FFR_L10n.t("ffr_common_months", n)
end

--------------------------------------------------
-- Area
--------------------------------------------------

FFR_L10n.ACRES_PER_HA = 2.47105

-- Hectares converted to the player's unit (ha or acres).
function FFR_L10n.getArea(ha)
    local value = tonumber(ha) or 0
    if g_i18n ~= nil and g_i18n.getArea ~= nil then
        local ok, converted = pcall(g_i18n.getArea, g_i18n, value)
        if ok and tonumber(converted) ~= nil then return tonumber(converted) end
    end
    return value * FFR_L10n.ACRES_PER_HA
end

function FFR_L10n.getAreaUnit()
    if g_i18n ~= nil and g_i18n.getAreaUnit ~= nil then
        local ok, unit = pcall(g_i18n.getAreaUnit, g_i18n, true)
        if ok and type(unit) == "string" and unit ~= "" then return unit end
    end
    return "ac"
end

-- e.g. "1,132.4 ac" or "458.4 ha"
function FFR_L10n.formatArea(ha, decimals)
    local value = FFR_L10n.getArea(ha)
    local d = decimals or 1
    local scale = 10 ^ d
    local rounded = math.floor(value * scale + 0.5) / scale
    local whole = math.floor(rounded)
    local s = tostring(whole)
    while true do
        local updated, count = string.gsub(s, "^(%d+)(%d%d%d)", "%1,%2")
        s = updated
        if count == 0 then break end
    end
    if d > 0 then
        local fraction = math.floor((rounded - whole) * scale + 0.5)
        s = s .. "." .. string.format("%0" .. d .. "d", fraction)
    end
    return s .. " " .. FFR_L10n.getAreaUnit()
end

-- One unit after a price ("$ 44 / acre"): singular, unlike getAreaUnit's "Acres".
function FFR_L10n.getPerAreaUnit()
    return FFR_L10n.t(FFR_L10n.getArea(1) > 2 and "ffr_area_per_acre" or "ffr_area_per_ha")
end

-- A price per acre shown per the player's area unit.
function FFR_L10n.perArea(valuePerAcre)
    local perHa = (tonumber(valuePerAcre) or 0) * FFR_L10n.ACRES_PER_HA
    local unitValue = FFR_L10n.getArea(1)
    return unitValue > 0 and perHa / unitValue or perHa
end

Logging.info("FFR Localization: Text, money and area helpers installed")
