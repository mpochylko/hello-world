FFR_LandAuctionManager = {}

--------------------------------------------------
-- Land auctions (v0.9.59, user)
--
-- Every 2-6 in-game days an auction opens on a
-- random unowned parcel (not rented, not held by a
-- neighbour) and runs 48 in-game hours. It opens at
-- 75-90 % of market value (FFR_LandMarketManager).
-- Stand on the parcel and press B to bid the next
-- step (2 % of value, at least $1,000). A bid in the
-- last hour extends the close by an hour.
--
-- NPC neighbours bid against you up to a hidden
-- limit of 90-115 % of market value, answering a
-- few hours after you. At the close the high bidder
-- pays (FS25 land purchase) and gets the parcel and
-- its title window. A farm that cannot pay loses it
-- to the next bidder and gets a credit mark (contract
-- default). Land a neighbour wins is off the market
-- for 12 months (it cannot be bought or rented).
--
-- Off while FS25_FarmlandAuctions is loaded, so the
-- two mods never both run auctions or both use B.
-- Shared state; the server runs it.
--------------------------------------------------

FFR_LandAuctionManager.DURATION_HOURS = 48
FFR_LandAuctionManager.GAP_MIN_HOURS = 48
FFR_LandAuctionManager.GAP_MAX_HOURS = 144
FFR_LandAuctionManager.OPEN_MIN = 0.75
FFR_LandAuctionManager.OPEN_MAX = 0.90
FFR_LandAuctionManager.NPC_LIMIT_MIN = 0.90
FFR_LandAuctionManager.NPC_LIMIT_MAX = 1.15
FFR_LandAuctionManager.STEP_SHARE = 0.02
FFR_LandAuctionManager.STEP_MIN = 1000
FFR_LandAuctionManager.NPC_DELAY_MIN = 1
FFR_LandAuctionManager.NPC_DELAY_MAX = 4
FFR_LandAuctionManager.SOFT_CLOSE_HOURS = 1
FFR_LandAuctionManager.OFF_MARKET_MONTHS = 12
FFR_LandAuctionManager.BID_COOLDOWN_MS = 3000
FFR_LandAuctionManager.KEEP_HISTORY = 5

FFR_LandAuctionManager.auction = nil
FFR_LandAuctionManager.nextStartHour = nil
FFR_LandAuctionManager.offMarket = {}
FFR_LandAuctionManager.history = {}
FFR_LandAuctionManager.updateTimer = 0
FFR_LandAuctionManager.cooldowns = {}

--------------------------------------------------
-- Helpers
--------------------------------------------------

function FFR_LandAuctionManager.isEnabled()
    return not (g_modIsLoaded ~= nil and g_modIsLoaded["FS25_FarmlandAuctions"])
end

function FFR_LandAuctionManager.getHour()
    return FFR_CropInsuranceManager ~= nil and FFR_CropInsuranceManager.getAbsoluteHour() or 0
end

function FFR_LandAuctionManager.getStep(auction)
    local step = (tonumber(auction.value) or 0) * FFR_LandAuctionManager.STEP_SHARE
    return math.max(FFR_LandAuctionManager.STEP_MIN, math.floor(step / 500 + 0.5) * 500)
end

-- The next bid: the opening price while nobody has bid, else current + step.
function FFR_LandAuctionManager.getNextBid(auction)
    if auction == nil then return 0 end
    if (tonumber(auction.bidCount) or 0) == 0 then return auction.price end
    return auction.price + FFR_LandAuctionManager.getStep(auction)
end

-- Purchase / rent blocked: the auction's parcel, or land a neighbour holds.
function FFR_LandAuctionManager.isBlocked(farmlandId)
    farmlandId = tonumber(farmlandId)
    local a = FFR_LandAuctionManager.auction
    if a ~= nil and a.farmlandId == farmlandId then return true end
    local untilSerial = FFR_LandAuctionManager.offMarket[farmlandId]
    return untilSerial ~= nil and FFR_LandRentManager.getSerial() < untilSerial
end

-- The farmland under the local player (on foot or in a vehicle), or nil.
function FFR_LandAuctionManager.getPlayerFarmlandId()
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil or getWorldTranslation == nil then return nil end
    local node = nil
    if g_currentMission ~= nil and g_currentMission.controlledVehicle ~= nil then node = g_currentMission.controlledVehicle.rootNode end
    if node == nil and g_localPlayer ~= nil then node = g_localPlayer.rootNode end
    if node == nil and g_currentMission ~= nil and g_currentMission.player ~= nil then node = g_currentMission.player.rootNode end
    if node == nil then return nil end
    local ok, x, _, z = pcall(getWorldTranslation, node)
    if not ok or x == nil then return nil end
    local found, id = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
    return found and tonumber(id) or nil
end

function FFR_LandAuctionManager.isOnFoot()
    if g_currentMission ~= nil and g_currentMission.controlledVehicle ~= nil then return false end
    if g_localPlayer ~= nil and g_localPlayer.getIsInVehicle ~= nil then
        local ok, inVehicle = pcall(g_localPlayer.getIsInVehicle, g_localPlayer)
        if ok and inVehicle then return false end
    end
    return true
end

function FFR_LandAuctionManager.notifyAll(text)
    Logging.info("FFR Land Auction: %s", tostring(text))
    if FFR_Network == nil or g_FFR == nil then return end
    for _, state in ipairs(g_FFR:getFarmStates()) do FFR_Network.sendNotice("CROP_DAMAGE", state.farmId, {text = text}) end
end

function FFR_LandAuctionManager.notifyFarm(farmId, text)
    Logging.info("FFR Land Auction: Farm %d - %s", farmId, tostring(text))
    if FFR_Network ~= nil then FFR_Network.sendNotice("CROP_DAMAGE", farmId, {text = text}) end
end

--------------------------------------------------
-- Start (server)
--------------------------------------------------

function FFR_LandAuctionManager.scheduleNext(fromHour)
    local m = FFR_LandAuctionManager
    m.nextStartHour = fromHour + math.random(m.GAP_MIN_HOURS, m.GAP_MAX_HOURS)
end

-- Unowned parcels that can go to auction; parcels with fields first.
function FFR_LandAuctionManager.pickParcel()
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return nil end
    local fields, others = {}, {}
    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
        local id = tonumber(farmland.id or farmlandId)
        if id ~= nil and FFR_LandRentManager.canRentIn(id) then
            if farmland.field ~= nil or (tonumber(farmland.totalFieldArea) or 0) > 0 then table.insert(fields, id) else table.insert(others, id) end
        end
    end
    local pool = #fields > 0 and fields or others
    if #pool == 0 then return nil end
    return pool[math.random(1, #pool)]
end

function FFR_LandAuctionManager.start(farmlandId)
    local m = FFR_LandAuctionManager
    local value = FFR_LandMarketManager.getMarketValue(farmlandId)
    if value <= 0 then return false end
    local now = m.getHour()
    local open = math.floor(value * (m.OPEN_MIN + math.random() * (m.OPEN_MAX - m.OPEN_MIN)) / 500 + 0.5) * 500
    m.auction = {
        farmlandId = farmlandId, value = value, price = open, openPrice = open, bidCount = 0,
        highFarmId = -1, startHour = now, endHour = now + m.DURATION_HOURS,
        npcLimit = value * (m.NPC_LIMIT_MIN + math.random() * (m.NPC_LIMIT_MAX - m.NPC_LIMIT_MIN)),
        nextNpcHour = now + math.random(m.NPC_DELAY_MIN, m.NPC_DELAY_MAX * 3), bids = {}
    }
    m.nextStartHour = nil
    m.notifyAll(FFR_L10n.t("ffr_auction_started", farmlandId, FFR_L10n.formatMoney(open), m.DURATION_HOURS))
    if FFR_Network ~= nil then FFR_Network.markDirty() end
    return true
end

--------------------------------------------------
-- Bids
--------------------------------------------------

function FFR_LandAuctionManager.recordBid(farmId, amount)
    local m = FFR_LandAuctionManager
    local a = m.auction
    a.price = amount
    a.highFarmId = farmId
    a.bidCount = (tonumber(a.bidCount) or 0) + 1
    if farmId > 0 then
        a.bids[#a.bids + 1] = {farmId = farmId, amount = amount}
    else
        a.npcPrice = amount
    end
    -- Soft close: a late bid keeps the auction open another hour.
    local now = m.getHour()
    if a.endHour - now < m.SOFT_CLOSE_HOURS then a.endHour = now + m.SOFT_CLOSE_HOURS end
    if farmId > 0 then a.nextNpcHour = now + math.random(m.NPC_DELAY_MIN, m.NPC_DELAY_MAX) end
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

-- Server: a farm's bid (B on the parcel). Returns ok, message.
function FFR_LandAuctionManager.bid(state, farmlandId)
    local m = FFR_LandAuctionManager
    local a = m.auction
    if a == nil or a.farmlandId ~= tonumber(farmlandId) then return false, FFR_L10n.t("ffr_auction_none_here") end
    if a.highFarmId == state.farmId then return false, FFR_L10n.t("ffr_auction_already_high") end
    local now = tonumber(g_time) or 0
    if (m.cooldowns[state.farmId] or 0) > now then return false, FFR_L10n.t("ffr_auction_wait") end
    local amount = m.getNextBid(a)
    if (tonumber(state.financialManager.cashOnHand) or 0) < amount then
        return false, FFR_L10n.t("ffr_auction_no_cash", FFR_L10n.formatMoney(amount))
    end
    m.cooldowns[state.farmId] = now + m.BID_COOLDOWN_MS
    local outbid = a.highFarmId
    m.recordBid(state.farmId, amount)
    if outbid ~= nil and outbid > 0 and outbid ~= state.farmId then
        m.notifyFarm(outbid, FFR_L10n.t("ffr_auction_outbid", a.farmlandId, FFR_L10n.formatMoney(amount)))
    end
    Logging.info("FFR Land Auction: Farm %d bids $%d on Farmland %d", state.farmId, amount, a.farmlandId)
    return true, FFR_L10n.t("ffr_auction_bid_placed", FFR_L10n.formatMoney(amount), a.farmlandId)
end

function FFR_LandAuctionManager.npcTurn(now)
    local m = FFR_LandAuctionManager
    local a = m.auction
    if a.highFarmId == 0 or now < a.nextNpcHour then return end
    local amount = m.getNextBid(a)
    if amount > a.npcLimit then
        a.nextNpcHour = a.endHour + 1
        return
    end
    local outbid = a.highFarmId
    m.recordBid(0, amount)
    a.nextNpcHour = now + math.random(m.NPC_DELAY_MIN, m.NPC_DELAY_MAX)
    if outbid ~= nil and outbid > 0 then
        m.notifyFarm(outbid, FFR_L10n.t("ffr_auction_outbid_npc", a.farmlandId, FFR_L10n.formatMoney(amount)))
    end
end

--------------------------------------------------
-- Close (server)
--------------------------------------------------

function FFR_LandAuctionManager.close()
    local m = FFR_LandAuctionManager
    local a = m.auction
    m.auction = nil
    local id = a.farmlandId
    -- Highest bid first; a farm that cannot pay drops out with a credit mark.
    local bids = {}
    for _, b in ipairs(a.bids or {}) do bids[#bids + 1] = b end
    table.sort(bids, function(x, y) return x.amount > y.amount end)
    local tried = {}
    local winner, price = nil, nil
    -- A neighbour holding the top bid wins outright; else farms in bid order.
    if a.highFarmId ~= 0 then
        for _, b in ipairs(bids) do
            if not tried[b.farmId] then
                tried[b.farmId] = true
                local state = g_FFR:getFarmState(b.farmId)
                if state ~= nil and (tonumber(state.financialManager.cashOnHand) or 0) >= b.amount then
                    winner, price = state, b.amount
                    break
                elseif state ~= nil then
                    state.creditManager:addContractDefault()
                    m.notifyFarm(b.farmId, FFR_L10n.t("ffr_auction_default", id, FFR_L10n.formatMoney(b.amount)))
                end
            end
        end
    end
    -- The neighbour's own last bid stands if it was the top bid or no farm could pay.
    local npcPrice = a.highFarmId == 0 and a.price or (tonumber(a.npcPrice) or 0)
    if winner == nil and npcPrice > 0 then
        m.offMarket[id] = FFR_LandRentManager.getSerial() + m.OFF_MARKET_MONTHS
        m.addHistory(id, npcPrice, 0)
        m.notifyAll(FFR_L10n.t("ffr_auction_won_npc", id, FFR_L10n.formatMoney(npcPrice)))
    elseif winner == nil then
        m.addHistory(id, a.price, -1)
        m.notifyAll(FFR_L10n.t("ffr_auction_no_sale", id))
    else
        g_currentMission:addMoney(-price, winner.farmId, MoneyType.FIELD_BUY, true, true)
        FFR_LandRentManager.setOwner(id, winner.farmId)
        m.addHistory(id, price, winner.farmId)
        m.notifyFarm(winner.farmId, FFR_L10n.t("ffr_auction_won", id, FFR_L10n.formatMoney(price)))
        Logging.info("FFR Land Auction: Farm %d won Farmland %d for $%d", winner.farmId, id, price)
    end
    m.scheduleNext(m.getHour())
    if FFR_Network ~= nil then FFR_Network.markDirty() end
    if g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
end

function FFR_LandAuctionManager.addHistory(farmlandId, price, winnerFarmId)
    local m = FFR_LandAuctionManager
    table.insert(m.history, 1, {farmlandId = farmlandId, price = price, winnerFarmId = winnerFarmId, serial = FFR_LandRentManager.getSerial()})
    while #m.history > m.KEEP_HISTORY do table.remove(m.history) end
end

function FFR_LandAuctionManager.tick()
    local m = FFR_LandAuctionManager
    local now = m.getHour()
    if now <= 0 then return end
    if m.auction ~= nil then
        if now >= m.auction.endHour then m.close() else m.npcTurn(now) end
        return
    end
    if m.nextStartHour == nil then m.scheduleNext(now) return end
    if now >= m.nextStartHour then
        local id = m.pickParcel()
        if id == nil or not m.start(id) then m.scheduleNext(now) end
    end
    -- Neighbours' holdings come back on the market.
    local serial = FFR_LandRentManager.getSerial()
    for fid, untilSerial in pairs(m.offMarket) do
        if serial >= untilSerial then m.offMarket[fid] = nil end
    end
end

--------------------------------------------------
-- B to bid, and the on-field panel (any machine)
--------------------------------------------------

function FFR_LandAuctionManager.isGuiOpen()
    return FFR_ModalOverlay ~= nil and FFR_ModalOverlay.isGameGuiOpen() or false
end

function FFR_LandAuctionManager:keyEvent(unicode, sym, modifier, isDown)
    if not isDown or Input == nil or Input.KEY_b == nil or sym ~= Input.KEY_b then return end
    local m = FFR_LandAuctionManager
    local a = m.auction
    if a == nil or not m.isEnabled() or m.isGuiOpen() or not m.isOnFoot() then return end
    if g_FFRModalOverlay ~= nil and g_FFRModalOverlay.visible then return end
    if m.getPlayerFarmlandId() ~= a.farmlandId or FFR_Network == nil then return end
    FFR_Network.perform("LAND_BID", {farmlandId = a.farmlandId}, function(ok, message)
        if message ~= nil and FFR_CropDamageManager ~= nil then FFR_CropDamageManager.showNotice(message) end
    end)
end

function FFR_LandAuctionManager:draw()
    local m = FFR_LandAuctionManager
    local a = m.auction
    if a == nil or renderText == nil or m.isGuiOpen() or m.getPlayerFarmlandId() ~= a.farmlandId then return end
    local localFarm = g_FFR ~= nil and g_FFR.localFarmId or nil
    local high
    if a.highFarmId == localFarm then high = FFR_L10n.t("ffr_auction_high_you")
    elseif a.highFarmId == 0 then high = FFR_L10n.t("ffr_auction_high_npc")
    elseif (tonumber(a.highFarmId) or -1) > 0 then high = FFR_L10n.t("ffr_auction_high_farm", a.highFarmId)
    else high = FFR_L10n.t("ffr_auction_high_none") end
    local hours = math.max(0, math.ceil(a.endHour - m.getHour()))
    local lines = {
        FFR_L10n.t("ffr_auction_panel_title", a.farmlandId, FFR_L10n.formatMoney(a.value)),
        FFR_L10n.t("ffr_auction_panel_price", FFR_L10n.formatMoney(a.price), high),
        a.highFarmId == localFarm and FFR_L10n.t("ffr_auction_panel_leading", hours)
            or FFR_L10n.t("ffr_auction_panel_bid", FFR_L10n.formatMoney(m.getNextBid(a)), hours)
    }
    setTextAlignment(RenderText.ALIGN_CENTER)
    for i, line in ipairs(lines) do
        setTextBold(i == 1)
        setTextColor(0, 0, 0, 0.8)
        renderText(0.5015, 0.8985 - (i - 1) * 0.026, i == 1 and 0.020 or 0.016, line)
        if i == 1 then setTextColor(0.54, 0.86, 0.18, 1) else setTextColor(0.95, 0.96, 0.95, 1) end
        renderText(0.5, 0.9 - (i - 1) * 0.026, i == 1 and 0.020 or 0.016, line)
    end
    setTextBold(false)
    setTextColor(1, 1, 1, 1)
    setTextAlignment(RenderText.ALIGN_LEFT)
end

--------------------------------------------------
-- Save / sync
--------------------------------------------------

FFR_LandAuctionManager.AUCTION_FIELDS = {"farmlandId", "value", "price", "openPrice", "bidCount", "highFarmId", "startHour", "endHour", "npcLimit", "nextNpcHour", "npcPrice"}

function FFR_LandAuctionManager.saveToXML(xmlFile, key)
    local m = FFR_LandAuctionManager
    if m.nextStartHour ~= nil then setXMLFloat(xmlFile, key .. "#nextStartHour", m.nextStartHour) end
    if m.auction ~= nil then
        for _, f in ipairs(m.AUCTION_FIELDS) do setXMLFloat(xmlFile, key .. ".auction#" .. f, tonumber(m.auction[f]) or 0) end
        for i, b in ipairs(m.auction.bids or {}) do
            local base = string.format("%s.auction.bid(%d)", key, i - 1)
            setXMLInt(xmlFile, base .. "#farmId", b.farmId)
            setXMLFloat(xmlFile, base .. "#amount", b.amount)
        end
    end
    local i = 0
    for fid, untilSerial in pairs(m.offMarket) do
        setXMLInt(xmlFile, string.format("%s.offMarket(%d)#farmlandId", key, i), fid)
        setXMLInt(xmlFile, string.format("%s.offMarket(%d)#until", key, i), untilSerial)
        i = i + 1
    end
    for j, h in ipairs(m.history) do
        local base = string.format("%s.result(%d)", key, j - 1)
        setXMLInt(xmlFile, base .. "#farmlandId", h.farmlandId)
        setXMLFloat(xmlFile, base .. "#price", h.price)
        setXMLInt(xmlFile, base .. "#winner", h.winnerFarmId)
        setXMLInt(xmlFile, base .. "#serial", tonumber(h.serial) or 0)
    end
end

function FFR_LandAuctionManager.loadFromXML(xmlFile, key)
    local m = FFR_LandAuctionManager
    m.nextStartHour = getXMLFloat(xmlFile, key .. "#nextStartHour")
    m.auction, m.offMarket, m.history = nil, {}, {}
    if hasXMLProperty(xmlFile, key .. ".auction") then
        local a = {bids = {}}
        for _, f in ipairs(m.AUCTION_FIELDS) do a[f] = getXMLFloat(xmlFile, key .. ".auction#" .. f) or 0 end
        a.farmlandId, a.highFarmId = math.floor(a.farmlandId), math.floor(a.highFarmId)
        local i = 0
        while hasXMLProperty(xmlFile, string.format("%s.auction.bid(%d)", key, i)) do
            local base = string.format("%s.auction.bid(%d)", key, i)
            table.insert(a.bids, {farmId = getXMLInt(xmlFile, base .. "#farmId") or 0, amount = getXMLFloat(xmlFile, base .. "#amount") or 0})
            i = i + 1
        end
        m.auction = a
    end
    local i = 0
    while hasXMLProperty(xmlFile, string.format("%s.offMarket(%d)", key, i)) do
        local fid = getXMLInt(xmlFile, string.format("%s.offMarket(%d)#farmlandId", key, i))
        if fid ~= nil then m.offMarket[fid] = getXMLInt(xmlFile, string.format("%s.offMarket(%d)#until", key, i)) or 0 end
        i = i + 1
    end
    i = 0
    while hasXMLProperty(xmlFile, string.format("%s.result(%d)", key, i)) do
        local base = string.format("%s.result(%d)", key, i)
        table.insert(m.history, {farmlandId = getXMLInt(xmlFile, base .. "#farmlandId") or 0, price = getXMLFloat(xmlFile, base .. "#price") or 0,
            winnerFarmId = getXMLInt(xmlFile, base .. "#winner") or -1, serial = getXMLInt(xmlFile, base .. "#serial") or 0})
        i = i + 1
    end
end

-- Clients see the auction without the neighbours' hidden limit.
function FFR_LandAuctionManager.getSnapshot()
    local m = FFR_LandAuctionManager
    local auction = nil
    if m.auction ~= nil then
        auction = {}
        for _, f in ipairs(m.AUCTION_FIELDS) do auction[f] = m.auction[f] end
        auction.npcLimit = nil
        auction.bids = {}
    end
    local offMarket = {}
    for fid, untilSerial in pairs(m.offMarket) do table.insert(offMarket, {farmlandId = fid, untilSerial = untilSerial}) end
    return {auction = auction, offMarket = offMarket, history = m.history}
end

function FFR_LandAuctionManager.applySnapshot(data)
    if type(data) ~= "table" then return end
    local m = FFR_LandAuctionManager
    m.auction = type(data.auction) == "table" and data.auction or nil
    m.offMarket = {}
    for _, entry in ipairs(data.offMarket or {}) do m.offMarket[entry.farmlandId] = entry.untilSerial end
    if type(data.history) == "table" then m.history = data.history end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_LandAuctionManager:loadMap(mapName)
    local m = FFR_LandAuctionManager
    m.auction, m.nextStartHour, m.offMarket, m.history, m.cooldowns = nil, nil, {}, {}, {}
    m.updateTimer = 0
    if not m.isEnabled() then Logging.info("FFR Land Auction: FS25_FarmlandAuctions is loaded; FFR land auctions are off") end
end

function FFR_LandAuctionManager:update(dt)
    local m = FFR_LandAuctionManager
    m.updateTimer = m.updateTimer + dt
    if m.updateTimer < 1000 then return end
    m.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted or not m.isEnabled() then return end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    local ok, err = pcall(m.tick)
    if not ok then Logging.warning("FFR Land Auction: update failed (%s)", tostring(err)) end
end

function FFR_LandAuctionManager:deleteMap() FFR_LandAuctionManager.auction = nil end
function FFR_LandAuctionManager:mouseEvent(posX, posY, isDown, isUp, button) end

addModEventListener(FFR_LandAuctionManager)
Logging.info("FFR Land Auction: Auctions installed (B to bid on the parcel)")
