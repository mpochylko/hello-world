FFR_LandMarketManager = {}

--------------------------------------------------
-- Land market (v0.9.59, user)
--
-- One map-wide land index moves every farmland's
-- price between 80 % and 120 % of its map price.
-- Each month (server, at the month-end bill):
--
--   target   = 1 + event push (x phase x difficulty)
--   momentum = 0.6 x momentum + random (-1.5 %..1.5 %)
--   index   += 12 % of (target - index) + momentum
--
-- and it always moves at least 0.2 %. Global Drought
-- and Export Restrictions push land down, Record
-- Harvest and Biofuel Expansion push it up; with no
-- event it drifts back toward 100 %.
--
-- The index is written into FS25's farmland prices
-- (map price x index), so buying, selling, FFR land
-- values, collateral and property tax follow. The map
-- price is read once per session as the baseline.
--
-- The land rent, land auction and title managers
-- read prices through getPrice / getMarketValue.
--------------------------------------------------

FFR_LandMarketManager.MIN_INDEX = 0.80
FFR_LandMarketManager.MAX_INDEX = 1.20
FFR_LandMarketManager.PULL = 0.12
FFR_LandMarketManager.NOISE = 0.015
FFR_LandMarketManager.MOMENTUM_KEEP = 0.6
FFR_LandMarketManager.MIN_STEP = 0.002
FFR_LandMarketManager.HISTORY_MONTHS = 24

-- Push on land at an event's peak (before phase and difficulty).
FFR_LandMarketManager.EVENT_PUSH = {
    GLOBAL_DROUGHT = -0.12,
    EXPORT_RESTRICTIONS = -0.07,
    RECORD_HARVEST = 0.12,
    BIOFUEL_EXPANSION = 0.06
}

FFR_LandMarketManager.index = 1.0
FFR_LandMarketManager.momentum = 0
FFR_LandMarketManager.history = {}
FFR_LandMarketManager.basePrices = {}

--------------------------------------------------
-- Prices
--------------------------------------------------

function FFR_LandMarketManager.getFarmland(farmlandId)
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return nil end
    return g_farmlandManager.farmlands[tonumber(farmlandId) or -1]
end

-- The map's own price of a parcel (before the land index).
function FFR_LandMarketManager.getBasePrice(farmlandId)
    local base = FFR_LandMarketManager.basePrices[tonumber(farmlandId) or -1]
    if base ~= nil then return base end
    local farmland = FFR_LandMarketManager.getFarmland(farmlandId)
    return farmland ~= nil and (tonumber(farmland.price) or 0) or 0
end

-- Today's market value of a parcel (map price x land index).
function FFR_LandMarketManager.getMarketValue(farmlandId)
    return FFR_LandMarketManager.getBasePrice(farmlandId) * FFR_LandMarketManager.index
end

-- Writes base x index into every farmland (any machine; clients get the index by sync).
function FFR_LandMarketManager.applyToFarmlands()
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return end
    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
        local id = tonumber(farmland.id or farmlandId)
        if id ~= nil then
            if FFR_LandMarketManager.basePrices[id] == nil then
                FFR_LandMarketManager.basePrices[id] = tonumber(farmland.price) or 0
            end
            farmland.price = math.floor(FFR_LandMarketManager.basePrices[id] * FFR_LandMarketManager.index + 0.5)
        end
    end
end

-- FS25 can recompute a farmland's price (economic difficulty); keep the index on top.
function FFR_LandMarketManager.installPriceHook()
    if FFR_LandMarketManager.hookInstalled or Farmland == nil or Farmland.updatePrice == nil then return end
    FFR_LandMarketManager.hookInstalled = true
    Farmland.updatePrice = Utils.appendedFunction(Farmland.updatePrice, function(farmland)
        local id = tonumber(farmland.id)
        if id ~= nil and tonumber(farmland.price) ~= nil then
            FFR_LandMarketManager.basePrices[id] = farmland.price
            farmland.price = math.floor(farmland.price * FFR_LandMarketManager.index + 0.5)
        end
    end)
end

--------------------------------------------------
-- Monthly move (server)
--------------------------------------------------

function FFR_LandMarketManager.getEventPush()
    local engine = g_FFR ~= nil and g_FFR.marketEngine or nil
    local event = engine ~= nil and engine.activeEvent or nil
    if event == nil then return 0, nil end
    local push = FFR_LandMarketManager.EVENT_PUSH[tostring(event.id or "")]
    if push == nil then return 0, event end
    local factors = engine.getPhaseFactors ~= nil and engine:getPhaseFactors() or {}
    local phase = factors[event.phase or "PEAK"] or 1
    local strength = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("eventStrength")) or 1) or 1
    return push * phase * strength, event
end

function FFR_LandMarketManager.processMonth(serial)
    local push = FFR_LandMarketManager.getEventPush()
    local m = FFR_LandMarketManager
    local target = 1 + push
    local noise = (math.random() * 2 - 1) * m.NOISE
    m.momentum = m.MOMENTUM_KEEP * m.momentum + (1 - m.MOMENTUM_KEEP) * noise
    local step = m.PULL * (target - m.index) + m.momentum
    -- Always moving: never less than MIN_STEP, in the direction it was going.
    if math.abs(step) < m.MIN_STEP then step = (step < 0 and -1 or 1) * m.MIN_STEP end
    local old = m.index
    m.index = math.max(m.MIN_INDEX, math.min(m.MAX_INDEX, m.index + step))
    table.insert(m.history, {serial = serial, index = m.index})
    while #m.history > m.HISTORY_MONTHS do table.remove(m.history, 1) end
    m.applyToFarmlands()
    Logging.info("FFR Land Market: index %.1f %% -> %.1f %% (target %.1f %%)", old * 100, m.index * 100, target * 100)
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

-- Direction over the last three months: 1 rising, -1 falling, 0 flat.
function FFR_LandMarketManager.getTrend()
    local h = FFR_LandMarketManager.history
    if #h < 2 then return 0 end
    local first = h[math.max(1, #h - 3)].index
    local change = FFR_LandMarketManager.index - first
    if change > 0.003 then return 1 elseif change < -0.003 then return -1 end
    return 0
end

-- One line for the Land tab: index, trend and what is pushing it.
function FFR_LandMarketManager.getSummaryText()
    local trend = FFR_LandMarketManager.getTrend()
    local key = trend > 0 and "ffr_landmarket_rising" or (trend < 0 and "ffr_landmarket_falling" or "ffr_landmarket_steady")
    local text = FFR_L10n.t(key, FFR_LandMarketManager.index * 100)
    local push, event = FFR_LandMarketManager.getEventPush()
    if event ~= nil and push ~= 0 then
        text = text .. "  " .. FFR_L10n.t(push < 0 and "ffr_landmarket_event_down" or "ffr_landmarket_event_up",
            FFR_L10n.eventName(event.name))
    end
    return text
end

--------------------------------------------------
-- Purchase rules: land on auction, held by a
-- neighbour or rented out cannot be bought; rented
-- land cannot be sold. Checked on the server
-- (FarmlandStateEvent) and on the map page's buttons.
--------------------------------------------------

-- Text key of why a buy (farmId > 0) or sell (farmId 0) is refused, or nil.
function FFR_LandMarketManager.getBlockReason(farmlandId, farmId)
    farmlandId = tonumber(farmlandId)
    if farmlandId == nil then return nil end
    if (tonumber(farmId) or 0) > 0 then
        if FFR_LandAuctionManager ~= nil and FFR_LandAuctionManager.auction ~= nil
            and FFR_LandAuctionManager.auction.farmlandId == farmlandId then return "ffr_land_block_auction" end
        if FFR_LandAuctionManager ~= nil and FFR_LandAuctionManager.isBlocked(farmlandId) then return "ffr_land_block_neighbour" end
        if FFR_LandRentManager ~= nil and FFR_LandRentManager.getLandlord(farmlandId) ~= nil then return "ffr_land_block_rented_out" end
    elseif FFR_LandRentManager ~= nil and FFR_LandRentManager.isRentedIn(farmlandId) then
        return "ffr_land_block_rented_in"
    end
    return nil
end

function FFR_LandMarketManager.installPurchaseHooks()
    if FFR_LandMarketManager.purchaseHooks then return end
    FFR_LandMarketManager.purchaseHooks = true
    if FarmlandStateEvent ~= nil and FarmlandStateEvent.run ~= nil then
        FarmlandStateEvent.run = Utils.overwrittenFunction(FarmlandStateEvent.run, function(event, superFunc, connection)
            -- Only requests from players (to the server) are checked; the server's own
            -- broadcasts (rent, auctions) reach clients unchanged.
            local fromPlayer = connection ~= nil and (connection.getIsServer == nil or not connection:getIsServer())
            if fromPlayer and FFR_Network ~= nil and FFR_Network.isServer() then
                local farmlandId = tonumber(event.farmlandId or event.id)
                local farmId = tonumber(event.farmId) or 0
                local reason = FFR_LandMarketManager.getBlockReason(farmlandId, farmId)
                if reason ~= nil then
                    Logging.info("FFR Land Market: %s of Farmland %s refused (%s)", farmId > 0 and "purchase" or "sale", tostring(farmlandId), reason)
                    if farmId > 0 then FFR_Network.sendNotice("CROP_DAMAGE", farmId, {text = FFR_L10n.t(reason, farmlandId)}) end
                    return
                end
            end
            return superFunc(event, connection)
        end)
    end
    if InGameMenuMapFrame == nil then return end
    local function selected(frame)
        return frame ~= nil and frame.selectedFarmland ~= nil and tonumber(frame.selectedFarmland.id) or nil
    end
    local function farmId()
        return g_FFR ~= nil and g_FFR.localFarmId or 1
    end
    if InGameMenuMapFrame.setMapInputContext ~= nil then
        InGameMenuMapFrame.setMapInputContext = Utils.overwrittenFunction(InGameMenuMapFrame.setMapInputContext,
            function(frame, superFunc, enterVehicle, resetVehicle, sellVehicle, visitPlace, setMarker, removeMarker, buyFarmland, sellFarmland, ...)
                local id = selected(frame)
                if id ~= nil and FFR_LandMarketManager.getBlockReason(id, farmId()) ~= nil then buyFarmland = false end
                if id ~= nil and FFR_LandMarketManager.getBlockReason(id, 0) ~= nil then sellFarmland = false end
                return superFunc(frame, enterVehicle, resetVehicle, sellVehicle, visitPlace, setMarker, removeMarker, buyFarmland, sellFarmland, ...)
            end)
    end
    local function guard(name, buyer)
        if InGameMenuMapFrame[name] == nil then return end
        InGameMenuMapFrame[name] = Utils.overwrittenFunction(InGameMenuMapFrame[name], function(frame, superFunc, ...)
            local id = selected(frame)
            local reason = id ~= nil and FFR_LandMarketManager.getBlockReason(id, buyer and farmId() or 0) or nil
            if reason ~= nil then
                if FFR_CropDamageManager ~= nil then FFR_CropDamageManager.showNotice(FFR_L10n.t(reason, id)) end
                return false
            end
            return superFunc(frame, ...)
        end)
    end
    guard("onClickBuyFarmland", true)
    guard("onClickSellFarmland", false)
end

--------------------------------------------------
-- Save / sync
--------------------------------------------------

function FFR_LandMarketManager.saveToXML(xmlFile, key)
    setXMLFloat(xmlFile, key .. "#index", FFR_LandMarketManager.index)
    setXMLFloat(xmlFile, key .. "#momentum", FFR_LandMarketManager.momentum)
    for i, entry in ipairs(FFR_LandMarketManager.history) do
        local base = string.format("%s.month(%d)", key, i - 1)
        setXMLInt(xmlFile, base .. "#serial", tonumber(entry.serial) or 0)
        setXMLFloat(xmlFile, base .. "#index", tonumber(entry.index) or 1)
    end
end

function FFR_LandMarketManager.loadFromXML(xmlFile, key)
    local m = FFR_LandMarketManager
    m.index = math.max(m.MIN_INDEX, math.min(m.MAX_INDEX, getXMLFloat(xmlFile, key .. "#index") or 1))
    m.momentum = getXMLFloat(xmlFile, key .. "#momentum") or 0
    m.history = {}
    local i = 0
    while hasXMLProperty(xmlFile, string.format("%s.month(%d)", key, i)) do
        local base = string.format("%s.month(%d)", key, i)
        table.insert(m.history, {serial = getXMLInt(xmlFile, base .. "#serial") or 0, index = getXMLFloat(xmlFile, base .. "#index") or 1})
        i = i + 1
    end
    m.applyToFarmlands()
end

function FFR_LandMarketManager.getSnapshot()
    return {index = FFR_LandMarketManager.index, history = FFR_LandMarketManager.history}
end

function FFR_LandMarketManager.applySnapshot(data)
    if type(data) ~= "table" then return end
    FFR_LandMarketManager.index = tonumber(data.index) or 1
    if type(data.history) == "table" then FFR_LandMarketManager.history = data.history end
    FFR_LandMarketManager.applyToFarmlands()
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_LandMarketManager:loadMap(mapName)
    FFR_LandMarketManager.index = 1.0
    FFR_LandMarketManager.momentum = 0
    FFR_LandMarketManager.history = {}
    FFR_LandMarketManager.basePrices = {}
    FFR_LandMarketManager.applied = false
    FFR_LandMarketManager.installPriceHook()
end

function FFR_LandMarketManager:update(dt)
    -- Once FFR is up (the save is loaded), make sure every farmland carries the index.
    if not FFR_LandMarketManager.applied and g_FFR ~= nil and g_FFR.isInitialized then
        FFR_LandMarketManager.applied = true
        FFR_LandMarketManager.applyToFarmlands()
        Logging.info("FFR Land Market: index %.1f %% applied to farmland prices", FFR_LandMarketManager.index * 100)
    end
end

-- Map prices back when the map closes.
function FFR_LandMarketManager:deleteMap()
    if g_farmlandManager ~= nil and g_farmlandManager.farmlands ~= nil then
        for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
            local base = FFR_LandMarketManager.basePrices[tonumber(farmland.id or farmlandId) or -1]
            if base ~= nil then farmland.price = base end
        end
    end
    FFR_LandMarketManager.basePrices = {}
end
function FFR_LandMarketManager:draw() end
function FFR_LandMarketManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_LandMarketManager:keyEvent(unicode, sym, modifier, isDown) end

FFR_LandMarketManager.installPurchaseHooks()
addModEventListener(FFR_LandMarketManager)
Logging.info("FFR Land Market: Land price index installed")
