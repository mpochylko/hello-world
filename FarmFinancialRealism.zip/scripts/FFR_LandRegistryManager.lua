FFR_LandRegistryManager = {}
local FFR_MOD_DIR = g_currentModDirectory

function FFR_LandRegistryManager:new()
    local self = {}
    setmetatable(self, {__index = FFR_LandRegistryManager})
    self.updateTimer = 0
    self.updateInterval = 2000
    self.initialized = false
    self.knownOwned = {}
    self.registrations = {}
    self.queue = {}
    self.activeParcel = nil
    self.dialogOpen = false
    self.registrationScreen = nil
    self.guiLoaded = false
    self.fileName = "FFR_landRegistry.xml"
    self.valueFactors = {
        AGRICULTURAL = 1.00,
        FARMSTEAD = 1.00,
        COMBINED = 1.00,
        ACCESS = 0.10
    }
    self.collateralFactors = {
        AGRICULTURAL = 0.85,
        FARMSTEAD = 0.75,
        COMBINED = 0.80,
        ACCESS = 0.00
    }
    self.taxFactors = {
        AGRICULTURAL = 0.25,
        FARMSTEAD = 0.75,
        COMBINED = 0.50,
        ACCESS = 0.10
    }
    return self
end

function FFR_LandRegistryManager:getMapId()
    if g_currentMission ~= nil then
        if g_currentMission.loadingMapModName ~= nil and g_currentMission.loadingMapModName ~= "" then
            return tostring(g_currentMission.loadingMapModName)
        end
        if g_currentMission.missionInfo ~= nil and g_currentMission.missionInfo.mapId ~= nil then
            return tostring(g_currentMission.missionInfo.mapId)
        end
    end
    return "UNKNOWN_MAP"
end

function FFR_LandRegistryManager:getFarmId()
    if g_FFR ~= nil and g_FFR.gameIntegrationManager ~= nil then
        return tonumber(g_FFR.gameIntegrationManager:getActiveFarmId())
    end
    return g_currentMission ~= nil and tonumber(g_currentMission:getFarmId()) or nil
end

function FFR_LandRegistryManager:getKey(farmlandId)
    return self:getMapId() .. ":" .. tostring(farmlandId)
end

function FFR_LandRegistryManager:getFilePath()
    if g_currentMission == nil or g_currentMission.missionInfo == nil then return nil end
    local dir = g_currentMission.missionInfo.savegameDirectory
    if dir == nil or dir == "" then return nil end
    return dir .. "/" .. self.fileName
end

function FFR_LandRegistryManager:formatMoney(value)
    return FFR_L10n.formatMoney(value)
end

-- Titles are saved inside FFR_economy.xml (FFR_SaveManager, format 3+).
function FFR_LandRegistryManager:saveToXML(xml, root)
    setXMLString(xml, root .. "#mapId", self:getMapId())
    local i = 0
    for key, record in pairs(self.registrations) do
        local base = string.format("%s.parcels.parcel(%d)", root, i)
        setXMLString(xml, base .. "#key", key)
        setXMLInt(xml, base .. "#farmlandId", tonumber(record.farmlandId) or 0)
        setXMLInt(xml, base .. "#farmId", tonumber(record.farmId) or 0)
        setXMLString(xml, base .. "#use", tostring(record.use or "AGRICULTURAL"))
        setXMLFloat(xml, base .. "#bookValue", tonumber(record.bookValue) or 0)
        setXMLFloat(xml, base .. "#assessedValue", tonumber(record.assessedValue) or 0)
        setXMLFloat(xml, base .. "#collateralValue", tonumber(record.collateralValue) or 0)
        setXMLFloat(xml, base .. "#areaInHa", tonumber(record.areaInHa) or 0)
        setXMLInt(xml, base .. "#agriculturalPercent", tonumber(record.agriculturalPercent) or 0)
        i = i + 1
    end
    return i
end

-- Saves before format 3 kept titles in FFR_landRegistry.xml; read at map load,
-- then replaced by the titles in FFR_economy.xml when that has them.
function FFR_LandRegistryManager:load()
    local path = self:getFilePath()
    if path == nil or _G.fileExists == nil or not _G.fileExists(path) then return false end
    local xml = loadXMLFile("FFRLandRegistry", path)
    if xml == nil or xml == 0 then return false end
    local count = self:loadFromXML(xml, "ffrLandRegistry")
    delete(xml)
    Logging.info("FFR Land Registry: %d titles read from the old FFR_landRegistry.xml", count)
    return true
end

function FFR_LandRegistryManager:loadFromXML(xml, root)
    self.registrations = {}
    local i = 0
    while true do
        local base = string.format("%s.parcels.parcel(%d)", root, i)
        if not hasXMLProperty(xml, base) then break end
        local key = getXMLString(xml, base .. "#key")
        if key ~= nil then
            local savedFarmId = getXMLInt(xml, base .. "#farmId")
            self.registrations[key] = {
                key = key,
                -- Saves before v0.9.9 have no farm; the ownership scan fills it in.
                farmId = (savedFarmId ~= nil and savedFarmId > 0) and savedFarmId or nil,
                farmlandId = getXMLInt(xml, base .. "#farmlandId") or 0,
                use = getXMLString(xml, base .. "#use") or "AGRICULTURAL",
                bookValue = getXMLFloat(xml, base .. "#bookValue") or 0,
                assessedValue = getXMLFloat(xml, base .. "#assessedValue") or 0,
                collateralValue = getXMLFloat(xml, base .. "#collateralValue") or 0,
                areaInHa = getXMLFloat(xml, base .. "#areaInHa") or 0,
                agriculturalPercent = getXMLInt(xml, base .. "#agriculturalPercent") or 0
            }
        end
        i = i + 1
    end
    return i
end

function FFR_LandRegistryManager:isOwned(farmland, farmId, farmlandId)
    if farmland == nil or farmId == nil then return false end
    -- FS25 tracks ownership in the farmland manager, not on the farmland object.
    if g_farmlandManager ~= nil and g_farmlandManager.getFarmlandOwner ~= nil then
        local ok, owner = pcall(g_farmlandManager.getFarmlandOwner, g_farmlandManager, farmland.id or farmlandId)
        if ok and owner ~= nil then return tonumber(owner) == farmId end
    end
    return tonumber(farmland.farmId or farmland.ownerFarmId) == farmId
end

function FFR_LandRegistryManager:queueParcel(farmlandId, farmland, farmId)
    local key = self:getKey(farmlandId)
    if self.registrations[key] ~= nil then return end
    for _, pending in ipairs(self.queue) do
        if pending.key == key then return end
    end
    table.insert(self.queue, {
        key = key,
        farmId = farmId,
        farmlandId = tonumber(farmlandId) or 0,
        name = tostring(farmland.name or FFR_L10n.t("ffr_common_farmland", tonumber(farmlandId) or 0)),
        bookValue = tonumber(farmland.price) or 0,
        areaInHa = tonumber(farmland.areaInHa) or 0
    })
    Logging.info("FFR Land Registry: Farmland %s queued for registration", tostring(farmlandId))
end

-- Sets a title's declared use and the values that follow from it.
function FFR_LandRegistryManager:applyUse(parcel, useCode, agriculturalPercent)
    local factor = self.valueFactors[useCode] or 1
    local collateralFactor = self.collateralFactors[useCode] or 0
    if useCode == "COMBINED" then
        local pct = math.max(0, math.min(100, tonumber(agriculturalPercent) or 50))
        factor = 1.00
        collateralFactor = (pct / 100 * 0.85) + ((100 - pct) / 100 * 0.75)
        parcel.agriculturalPercent = pct
    else
        parcel.agriculturalPercent = useCode == "AGRICULTURAL" and 100 or 0
    end
    parcel.use = useCode
    parcel.assessedValue = (tonumber(parcel.bookValue) or 0) * factor
    parcel.collateralValue = (tonumber(parcel.bookValue) or 0) * collateralFactor
    parcel.taxFactor = self.taxFactors[useCode] or 0.25
    return parcel
end

-- Server: a farm manager's declaration (from the dialog on any machine).
function FFR_LandRegistryManager:declareUse(farmId, farmlandId, useCode, agriculturalPercent)
    if self.valueFactors[useCode] == nil then return false, FFR_L10n.t("ffr_land_unknown_use") end
    local farmland = g_farmlandManager ~= nil and g_farmlandManager.farmlands ~= nil and g_farmlandManager.farmlands[farmlandId] or nil
    if farmland == nil or self:getOwnerFarmId(farmland, farmlandId) ~= farmId then
        return false, FFR_L10n.t("ffr_land_not_owned")
    end
    local record = self:applyUse(self:createRecord(farmlandId, farmland, farmId, useCode), useCode, agriculturalPercent)
    self.registrations[record.key] = record
    self:applyValuations()
    Logging.info("FFR Land Registry: Farmland %d (farm %d) declared %s, assessed $%d", farmlandId, farmId, useCode, math.floor(record.assessedValue))
    return true, FFR_L10n.t("ffr_land_registered", farmlandId, FFR_LandRegistryManager.getUseName(useCode))
end

-- Client: a land-title prompt from the server for this player's farm.
function FFR_LandRegistryManager:queueRemoteParcel(payload)
    if payload == nil or payload.key == nil then return end
    if self.activeParcel ~= nil and self.activeParcel.key == payload.key then return end
    for _, pending in ipairs(self.queue) do
        if pending.key == payload.key then return end
    end
    table.insert(self.queue, payload)
    Logging.info("FFR Land Registry: Farmland %s awaiting your declaration", tostring(payload.farmlandId))
end

function FFR_LandRegistryManager:register(useCode, agriculturalPercent)
    local parcel = self.activeParcel
    if parcel == nil then return end
    -- On a client the server records the title; the dialog only sends the choice.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then
        self.activeParcel = nil
        self.dialogOpen = false
        FFR_Network.perform("LAND_DECLARE", {
            farmlandId = parcel.farmlandId, use = useCode, agriculturalPercent = agriculturalPercent
        }, function(ok, message)
            if ok ~= nil then Logging.info("FFR Land Registry: %s", tostring(message)) end
        end)
        return
    end
    local factor = self.valueFactors[useCode] or 1
    local collateralFactor = self.collateralFactors[useCode] or 0
    if useCode == "COMBINED" then
        local pct = math.max(0, math.min(100, tonumber(agriculturalPercent) or 50))
        factor = 1.00
        collateralFactor = (pct / 100 * 0.85) + ((100 - pct) / 100 * 0.75)
        parcel.agriculturalPercent = pct
    else
        parcel.agriculturalPercent = useCode == "AGRICULTURAL" and 100 or 0
    end
    parcel.use = useCode
    parcel.assessedValue = parcel.bookValue * factor
    parcel.collateralValue = parcel.bookValue * collateralFactor
    parcel.taxFactor = self.taxFactors[useCode] or 0.25
    self.registrations[parcel.key] = parcel
    self.activeParcel = nil
    self.dialogOpen = false
    self:applyValuations()
    -- Written with the next native save (see FFR_SaveToXMLFile).
    Logging.info("FFR Land Registry: Farmland %d registered as %s, assessed $%d", parcel.farmlandId, useCode, math.floor(parcel.assessedValue))
    -- A change made on the Land tab: no FS25 dialog over the pause menu (it is not
    -- shown there but still takes every click); the Land tab shows the result.
    if parcel.isChange then
        self.changeMessage = FFR_L10n.t("ffr_land_registered", parcel.farmlandId, FFR_LandRegistryManager.getUseName(useCode))
        return
    end
    self:showConfirmation(parcel)
end

function FFR_LandRegistryManager:showConfirmation(parcel)
    if InfoDialog == nil or InfoDialog.show == nil then return end
    local text = table.concat({
        FFR_L10n.t("ffr_land_confirm_title"),
        "",
        FFR_L10n.t("ffr_land_confirm_property", tonumber(parcel.farmlandId) or 0),
        FFR_L10n.t("ffr_land_confirm_use", FFR_LandRegistryManager.getUseName(parcel.use)),
        FFR_L10n.t("ffr_land_confirm_book", self:formatMoney(parcel.bookValue)),
        FFR_L10n.t("ffr_land_confirm_assessed", self:formatMoney(parcel.assessedValue)),
        FFR_L10n.t("ffr_land_confirm_collateral", self:formatMoney(parcel.collateralValue)),
        "",
        FFR_L10n.t("ffr_land_confirm_done")
    }, "\n")
    InfoDialog.show(text, nil, self, DialogElement ~= nil and DialogElement.TYPE_INFO or nil, FFR_L10n.t("button_ok"))
end

function FFR_LandRegistryManager:showRegistration()
    if self.dialogOpen or self.activeParcel ~= nil or #self.queue == 0 then return end
    -- Titles bought in the pause menu (or the confirmation of the last one) wait
    -- until every game menu and dialog is closed, then open one after another.
    if FFR_ModalOverlay ~= nil and FFR_ModalOverlay.isGameGuiOpen() then return end
    if g_FFRModalOverlay == nil then
        Logging.error("FFR Land Registry: Modal overlay unavailable")
        return
    end
    self.activeParcel = table.remove(self.queue, 1)
    self.dialogOpen = true
    if not g_FFRModalOverlay:showLand(self, self.activeParcel) then
        table.insert(self.queue, 1, self.activeParcel)
        self.activeParcel = nil
        self.dialogOpen = false
    end
end

-- Land page CHANGE TITLE: reopens the title window over the menu for a parcel the
-- local farm owns and has titled. The choice goes through register() like a new one.
function FFR_LandRegistryManager:requestChange(farmlandId)
    if g_FFRModalOverlay == nil then return false, FFR_L10n.t("ffr_land_change_busy") end
    if self.dialogOpen or self.activeParcel ~= nil or g_FFRModalOverlay.visible then
        return false, FFR_L10n.t("ffr_land_change_busy")
    end
    local farmId = self:getFarmId()
    local row = nil
    for _, title in ipairs(self:getTitles(farmId)) do
        if title.farmlandId == tonumber(farmlandId) then row = title end
    end
    if row == nil then return false, FFR_L10n.t("ffr_land_not_owned") end
    if not row.titled then return false, FFR_L10n.t("ffr_land_change_untitled") end
    if FFR_Network ~= nil and not FFR_Network.canManageLocalFarm() then
        return false, FFR_L10n.t("ffr_land_change_manager")
    end
    self.activeParcel = {
        key = self:getKey(row.farmlandId), farmId = farmId, farmlandId = row.farmlandId,
        name = FFR_L10n.t("ffr_common_farmland", row.farmlandId), bookValue = row.bookValue, areaInHa = row.areaInHa,
        isChange = true, currentUse = self:getUseText(row)
    }
    self.dialogOpen = true
    if not g_FFRModalOverlay:showLand(self, self.activeParcel, true) then
        self.activeParcel = nil
        self.dialogOpen = false
        return false, FFR_L10n.t("ffr_land_change_busy")
    end
    return true
end

-- KEEP CURRENT TITLE in a change window.
function FFR_LandRegistryManager:cancelChange()
    self.activeParcel = nil
    self.dialogOpen = false
end

-- The farm that owns a farmland parcel, or nil if nobody does.
function FFR_LandRegistryManager:getOwnerFarmId(farmland, farmlandId)
    if g_farmlandManager ~= nil and g_farmlandManager.getFarmlandOwner ~= nil then
        local ok, owner = pcall(g_farmlandManager.getFarmlandOwner, g_farmlandManager, farmland.id or farmlandId)
        if ok then
            owner = tonumber(owner)
            if owner ~= nil and owner > 0 then return owner end
            return nil
        end
    end
    local owner = tonumber(farmland.farmId or farmland.ownerFarmId)
    if owner ~= nil and owner > 0 then return owner end
    return nil
end

function FFR_LandRegistryManager:createRecord(farmlandId, farmland, farmId, useCode)
    local bookValue = tonumber(farmland.price) or 0
    return {
        key = self:getKey(farmlandId),
        farmId = farmId,
        farmlandId = tonumber(farmlandId) or 0,
        use = useCode,
        bookValue = bookValue,
        assessedValue = bookValue * (self.valueFactors[useCode] or 1),
        collateralValue = bookValue * (self.collateralFactors[useCode] or 0),
        areaInHa = tonumber(farmland.areaInHa) or 0,
        agriculturalPercent = useCode == "AGRICULTURAL" and 100 or 0,
        taxFactor = self.taxFactors[useCode] or 0.25
    }
end

-- Tracks who owns every parcel. A newly bought parcel gets a title: the local
-- player declares its use in the dialog; parcels bought by other farms are
-- registered as agricultural until stage 3 can send them the dialog.
function FFR_LandRegistryManager:scanOwnership()
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return end
    local localFarmId = self:getFarmId()
    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
        local owner = self:getOwnerFarmId(farmland, farmlandId)
        local key = self:getKey(farmlandId)
        if owner ~= self.knownOwned[farmlandId] then
            self.knownOwned[farmlandId] = owner
            local record = self.registrations[key]
            -- Rented land (FFR_LandRentManager): a rented-out parcel keeps its owner's
            -- title while a tenant has it; rented-in land gets no title at all.
            local landlord = FFR_LandRentManager ~= nil and FFR_LandRentManager.getLandlord(farmlandId) or nil
            local rentedIn = FFR_LandRentManager ~= nil and FFR_LandRentManager.isRentedIn(farmlandId)
            if landlord ~= nil and record ~= nil and record.farmId == landlord then
                -- Title kept; nothing else to do for this parcel.
            elseif rentedIn then
                if record ~= nil then
                    self.registrations[key] = nil
                    Logging.info("FFR Land Registry: Farmland %s is rented; no title", tostring(farmlandId))
                end
            -- Sold, or moved to another farm: the old title no longer applies.
            elseif record ~= nil and record.farmId ~= nil and record.farmId ~= owner then
                self.registrations[key] = nil
                record = nil
                Logging.info("FFR Land Registry: Farmland %s changed hands; title cleared", tostring(farmlandId))
            end
            if landlord ~= nil or rentedIn then
                -- Handled above.
            elseif owner ~= nil and record == nil then
                if not self.initialized and farmland.field ~= nil then
                    -- First load: existing field parcels are registered as agricultural
                    -- without interrupting anyone. Parcels without a field still need a declaration.
                    self.registrations[key] = self:createRecord(farmlandId, farmland, owner, "AGRICULTURAL")
                    Logging.info("FFR Land Registry: Existing farmland %s (farm %d) migrated as AGRICULTURAL", tostring(farmlandId), owner)
                elseif owner == localFarmId then
                    self:queueParcel(farmlandId, farmland, owner)
                else
                    -- Another farm (multiplayer): provisionally agricultural, and its
                    -- managers get the dialog; their choice comes back via declareUse.
                    local record = self:createRecord(farmlandId, farmland, owner, "AGRICULTURAL")
                    self.registrations[key] = record
                    Logging.info("FFR Land Registry: Farmland %s bought by farm %d; declaration requested", tostring(farmlandId), owner)
                    if FFR_Network ~= nil then
                        FFR_Network.sendNotice("LAND_PROMPT", owner, {
                            key = key, farmId = owner, farmlandId = record.farmlandId,
                            name = tostring(farmland.name or FFR_L10n.t("ffr_common_farmland", tonumber(farmlandId) or 0)),
                            bookValue = record.bookValue, areaInHa = record.areaInHa
                        })
                    end
                end
            elseif record ~= nil and record.farmId == nil then
                -- Titles from before v0.9.9 have no farm; adopt the current owner.
                record.farmId = owner
            end
        end
    end
    self.initialized = true
end

-- Display name for a declared use (ffr_land_use_<code>).
function FFR_LandRegistryManager.getUseName(useCode)
    return FFR_L10n.named("ffr_land_use_", useCode or "")
end

-- Every parcel a farm owns, with its title (Land page). Parcels still waiting for
-- a declaration are listed too. On a multiplayer client the server's list arrives
-- in the snapshot (state.landTitles).
function FFR_LandRegistryManager:getTitles(farmId)
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then
        local state = g_FFR ~= nil and g_FFR:getFarmState(farmId) or nil
        return state ~= nil and state.landTitles or {}
    end
    local list = {}
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil or farmId == nil then return list end
    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
        -- Rented-out parcels stay on the owner's list; rented-in ones are not the farm's.
        local fsOwner = self:getOwnerFarmId(farmland, farmlandId)
        local id = tonumber(farmland.id or farmlandId) or 0
        local holder = fsOwner
        if FFR_LandRentManager ~= nil then holder = FFR_LandRentManager.getAssetOwner(id, fsOwner) end
        if holder == farmId then
            local record = self.registrations[self:getKey(id)]
            local row = {
                rentedOut = FFR_LandRentManager ~= nil and FFR_LandRentManager.getLandlord(id) == farmId,
                farmlandId = id,
                areaInHa = tonumber(farmland.areaInHa) or 0,
                -- -1: the map gives no field area for this parcel.
                arableHa = self:getArableHa(farmland, id) or -1,
                bookValue = tonumber(farmland.price) or 0,
                assessedValue = 0, collateralValue = 0, agriculturalPercent = 0,
                use = "", titled = false
            }
            if record ~= nil then
                row.use = tostring(record.use or "AGRICULTURAL")
                row.bookValue = tonumber(record.bookValue) or row.bookValue
                row.assessedValue = tonumber(record.assessedValue) or 0
                row.collateralValue = tonumber(record.collateralValue) or 0
                row.agriculturalPercent = tonumber(record.agriculturalPercent) or 0
                row.titled = true
            end
            table.insert(list, row)
        end
    end
    table.sort(list, function(a, b) return a.farmlandId < b.farmlandId end)
    return list
end

-- Cropland on a parcel in hectares: the field area FS25 records for it, or the
-- sum of the map's fields on that farmland. nil when neither is available.
function FFR_LandRegistryManager:getArableHa(farmland, farmlandId)
    local total = tonumber(farmland.totalFieldArea)
    if total ~= nil then return total end
    if g_fieldManager == nil then return nil end
    local fields = nil
    if g_fieldManager.getFields ~= nil then
        local ok, result = pcall(g_fieldManager.getFields, g_fieldManager)
        if ok then fields = result end
    end
    fields = fields or g_fieldManager.fields
    if type(fields) ~= "table" then return nil end
    -- linked: at least one field told us its farmland, so a parcel with no
    -- matching field really has no cropland (0) rather than unknown (nil).
    local sum, linked = 0, false
    for _, field in pairs(fields) do
        local owner = nil
        if field.getFarmland ~= nil then
            local ok, result = pcall(field.getFarmland, field)
            if ok then owner = result end
        end
        owner = owner or field.farmland
        if owner ~= nil then linked = true end
        if owner ~= nil and (owner == farmland or tonumber(owner.id) == farmlandId) then
            local area = nil
            if field.getAreaHa ~= nil then
                local ok, result = pcall(field.getAreaHa, field)
                if ok then area = tonumber(result) end
            end
            area = area or tonumber(field.fieldArea) or tonumber(field.areaHa)
            if area ~= nil then sum = sum + area end
        end
    end
    return linked and sum or nil
end

-- Title use of the farmland at a world position (nil when untitled or unknown).
function FFR_LandRegistryManager:getUseAt(x, z)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandIdAtWorldPosition == nil then return nil end
    local ok, farmlandId = pcall(g_farmlandManager.getFarmlandIdAtWorldPosition, g_farmlandManager, x, z)
    if not ok or tonumber(farmlandId) == nil then return nil end
    local record = self.registrations[self:getKey(tonumber(farmlandId))]
    return record ~= nil and record.use or nil
end

function FFR_LandRegistryManager:getUseText(row)
    if not row.titled then return FFR_L10n.t("ffr_land_not_declared") end
    local name = FFR_LandRegistryManager.getUseName(row.use)
    if row.use == "COMBINED" then
        return FFR_L10n.t("ffr_land_use_combined_pct", name, math.floor(tonumber(row.agriculturalPercent) or 0))
    end
    return name
end

-- Assessed and collateral values follow today's land market (FFR_LandMarketManager);
-- the book value stays what the parcel cost when it was titled.
function FFR_LandRegistryManager:refreshMarketValues(record)
    if FFR_LandMarketManager == nil then return end
    local market = FFR_LandMarketManager.getMarketValue(record.farmlandId)
    if market <= 0 then return end
    local use = record.use or "AGRICULTURAL"
    local factor = self.valueFactors[use] or 1
    local collateral = self.collateralFactors[use] or 0
    if use == "COMBINED" then
        local pct = math.max(0, math.min(100, tonumber(record.agriculturalPercent) or 50))
        factor = 1.00
        collateral = (pct / 100 * 0.85) + ((100 - pct) / 100 * 0.75)
    end
    record.assessedValue = market * factor
    record.collateralValue = market * collateral
end

-- Applies title values to each farm's own land assets.
function FFR_LandRegistryManager:applyValuations()
    if g_FFR == nil or g_FFR.getFarmStates == nil then return end
    for _, state in ipairs(g_FFR:getFarmStates()) do
        local changed = false
        for farmlandId, asset in pairs(state.assetManager.landAssets or {}) do
            local record = self.registrations[self:getKey(farmlandId)]
            if record ~= nil then
                self:refreshMarketValues(record)
                local value = tonumber(record.assessedValue) or tonumber(asset.marketValue) or 0
                if math.abs((tonumber(asset.marketValue) or 0) - value) >= 1 then changed = true end
                asset.marketValue = value
                asset.originalValue = tonumber(record.bookValue) or asset.originalValue
                asset.landUse = record.use
                asset.collateralValue = record.collateralValue
            end
        end
        if changed then
            state.assetManager:updateTotals()
            state.assetManager:updateFinancialManager(state.financialManager)
            state.financialManager:update()
            -- The asset sync resets land to book value every cycle, so only log
            -- when the farm's assessed land total itself has changed.
            local total = math.floor(tonumber(state.assetManager.totalLandValue) or 0)
            if state.sync.loggedAssessedLand ~= total then
                state.sync.loggedAssessedLand = total
                Logging.info("FFR Land Registry: Farm %d assessed land value now $%d", state.farmId, total)
            end
        end
    end
end

function FFR_LandRegistryManager:update(dt)
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    -- Every frame, so the next waiting title opens as soon as the menu closes.
    self:showRegistration()
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer < self.updateInterval then return end
    self.updateTimer = 0
    -- Clients only show prompts the server sent; titles are kept on the server.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    self:scanOwnership()
    self:applyValuations()
end

function FFR_LandRegistryManager:loadMap(mapName)
    self.updateTimer = 0
    self.initialized = false
    self.knownOwned = {}
    -- Clear titles from a previously loaded savegame before reading this one.
    self.registrations = {}
    self.queue = {}
    self.activeParcel = nil
    self.dialogOpen = false
    self.registrationScreen = nil
    self.guiLoaded = false
    self:load()
end
-- No save here: quitting without saving must not keep titles for land the savegame never bought.
function FFR_LandRegistryManager:deleteMap()
    self.registrations = {}
    self.queue = {}
    self.activeParcel = nil
    self.dialogOpen = false
end
function FFR_LandRegistryManager:draw() end
function FFR_LandRegistryManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_LandRegistryManager:keyEvent(unicode, sym, modifier, isDown) end

g_FFRLandRegistryManager = FFR_LandRegistryManager:new()
addModEventListener(g_FFRLandRegistryManager)
Logging.info("FFR Land Titles Registration Office: Listener installed")
