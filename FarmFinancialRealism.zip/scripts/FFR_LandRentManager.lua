FFR_LandRentManager = {}

--------------------------------------------------
-- Land rent (v0.9.59, user)
--
-- Cash rent, as in real farmland leases: 4 % a year
-- of the land's market value at signing (FFR_Land-
-- MarketManager), paid monthly, fixed for the whole
-- term (1, 3 or 5 years) while land prices move.
--
-- RENT IN  (unowned map land): FS25 hands the parcel
--   to the farm for the term. It gets no title, is
--   not an asset and gives no collateral; it cannot
--   be sold. The first month is paid at signing, the
--   rest on the month-end bill ("Land rent"). No
--   buildings: a parcel with buildings on it at the
--   end stays rented month to month until they go.
-- RENT OUT (own titled parcel, no buildings): the
--   parcel goes to an NPC tenant (FS25 shows it as
--   not owned and it cannot be bought); the farm
--   keeps its title, value and collateral and is paid
--   the rent monthly ("Land rent received").
--
-- End of term: one decision month (rent paid) to
-- RENEW at the new market rent, else the parcel goes
-- back (to the map, or to the owner). Ending early
-- costs EARLY_MONTHS of rent (or what is left, if less).
--
-- Per farm: state.landRentals; server only changes them.
--------------------------------------------------

FFR_LandRentManager.RATE = 0.04
FFR_LandRentManager.TERMS = {12, 36, 60}
FFR_LandRentManager.EARLY_MONTHS = 3
FFR_LandRentManager.KEEP_CLOSED = 5

--------------------------------------------------
-- Lookups (any machine)
--------------------------------------------------

function FFR_LandRentManager.getSerial()
    local env = g_currentMission ~= nil and g_currentMission.environment or nil
    if env == nil or env.currentPeriod == nil or env.currentYear == nil then return 0 end
    return env.currentYear * 12 + env.currentPeriod
end

function FFR_LandRentManager.isOpen(contract)
    return contract.status == "ACTIVE" or contract.status == "ENDING" or contract.status == "HOLD"
end

-- The open contract on a parcel (any farm), and its farm state.
function FFR_LandRentManager.findOpen(farmlandId)
    farmlandId = tonumber(farmlandId)
    if g_FFR == nil or farmlandId == nil then return nil, nil end
    for _, state in ipairs(g_FFR:getFarmStates()) do
        for _, contract in ipairs(state.landRentals or {}) do
            if contract.farmlandId == farmlandId and FFR_LandRentManager.isOpen(contract) then return contract, state end
        end
    end
    return nil, nil
end

function FFR_LandRentManager.isRentedIn(farmlandId)
    local contract = FFR_LandRentManager.findOpen(farmlandId)
    return contract ~= nil and contract.kind == "IN"
end

-- The farm that rented a parcel out, or nil.
function FFR_LandRentManager.getLandlord(farmlandId)
    local contract, state = FFR_LandRentManager.findOpen(farmlandId)
    if contract ~= nil and contract.kind == "OUT" then return state.farmId end
    return nil
end

-- Which farm holds a parcel as an asset: the landlord of rented-out land, nobody for
-- rented-in land, else FS25's owner. Used by the asset syncs and land titles.
function FFR_LandRentManager.getAssetOwner(farmlandId, fsOwner)
    local contract, state = FFR_LandRentManager.findOpen(farmlandId)
    if contract == nil then return fsOwner end
    if contract.kind == "OUT" then return state.farmId end
    return nil
end

function FFR_LandRentManager.getMonthlyRent(farmlandId)
    local value = FFR_LandMarketManager ~= nil and FFR_LandMarketManager.getMarketValue(farmlandId) or 0
    return math.floor(value * FFR_LandRentManager.RATE / 12 + 0.5)
end

function FFR_LandRentManager.getFsOwner(farmlandId)
    if g_farmlandManager == nil or g_farmlandManager.getFarmlandOwner == nil then return nil end
    local ok, owner = pcall(g_farmlandManager.getFarmlandOwner, g_farmlandManager, farmlandId)
    return ok and tonumber(owner) or nil
end

-- Buildings a farm has standing on a parcel.
function FFR_LandRentManager.countBuildings(farmlandId, farmId)
    local sync = g_FFRBuildingSyncManager
    local placeables = sync ~= nil and sync:getMissionPlaceables() or nil
    local count = 0
    for _, placeable in pairs(placeables or {}) do
        if sync:isOwnedByFarm(placeable, farmId) and sync:getFarmlandId(placeable) == farmlandId then count = count + 1 end
    end
    return count
end

-- Unowned parcels a farm can rent in (sorted by id).
function FFR_LandRentManager.getRentableParcels()
    local list = {}
    if g_farmlandManager == nil or g_farmlandManager.farmlands == nil then return list end
    for farmlandId, farmland in pairs(g_farmlandManager.farmlands) do
        local id = tonumber(farmland.id or farmlandId)
        if id ~= nil and FFR_LandRentManager.canRentIn(id) then table.insert(list, id) end
    end
    table.sort(list)
    return list
end

-- Parcels a farm owns that it could rent out.
function FFR_LandRentManager.getRentOutParcels(farmId)
    local list = {}
    if g_FFRLandRegistryManager == nil then return list end
    for _, row in ipairs(g_FFRLandRegistryManager:getTitles(farmId)) do
        if row.titled and not row.rentedOut and FFR_LandRentManager.findOpen(row.farmlandId) == nil then
            table.insert(list, row.farmlandId)
        end
    end
    return list
end

function FFR_LandRentManager.canRentIn(farmlandId)
    local farmland = FFR_LandMarketManager.getFarmland(farmlandId)
    if farmland == nil or farmland.isBuyable == false or (tonumber(farmland.price) or 0) <= 0 then return false end
    if FFR_LandRentManager.getFsOwner(farmlandId) ~= 0 then return false end
    if FFR_LandRentManager.findOpen(farmlandId) ~= nil then return false end
    if FFR_LandAuctionManager ~= nil and FFR_LandAuctionManager.isBlocked(farmlandId) then return false end
    return true
end

--------------------------------------------------
-- Ownership (server)
--------------------------------------------------

function FFR_LandRentManager.setOwner(farmlandId, farmId)
    if g_farmlandManager == nil then return end
    if g_server ~= nil and FarmlandStateEvent ~= nil and FarmlandStateEvent.new ~= nil then
        pcall(function() g_server:broadcastEvent(FarmlandStateEvent.new(farmlandId, farmId, 0), false) end)
    end
    local previous = FFR_LandRentManager.getFsOwner(farmlandId)
    g_farmlandManager:setLandOwnership(farmlandId, farmId)
    if g_messageCenter ~= nil and MessageType ~= nil and MessageType.FARM_PROPERTY_CHANGED ~= nil then
        if previous ~= nil and previous > 0 then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, previous) end
        if farmId > 0 then g_messageCenter:publish(MessageType.FARM_PROPERTY_CHANGED, farmId) end
    end
end

--------------------------------------------------
-- Money (server)
--------------------------------------------------

function FFR_LandRentManager.charge(state, amount)
    if amount <= 0 then return true end
    if g_FFRMonthlyFinancialProcessor == nil or not g_FFRMonthlyFinancialProcessor:applyFarmBalance(-amount, nil, state.farmId) then return false end
    local f = state.financialManager
    f.monthlyExpenses = (tonumber(f.monthlyExpenses) or 0) + amount
    f.annualExpenses = (tonumber(f.annualExpenses) or 0) + amount
    f:updateAnnualProfit()
    return true
end

function FFR_LandRentManager.pay(state, amount)
    if amount <= 0 or g_FFRMonthlyFinancialProcessor == nil then return false end
    if not g_FFRMonthlyFinancialProcessor:applyFarmBalance(amount, nil, state.farmId) then return false end
    local f = state.financialManager
    f.monthlyRevenue = (tonumber(f.monthlyRevenue) or 0) + amount
    f.annualRevenue = (tonumber(f.annualRevenue) or 0) + amount
    f:updateAnnualProfit()
    return true
end

function FFR_LandRentManager.newContract(state, kind, farmlandId, term, monthlyRent)
    state.landRentals = state.landRentals or {}
    state.nextRentalId = (tonumber(state.nextRentalId) or 0) + 1
    local contract = {id = state.nextRentalId, kind = kind, farmlandId = farmlandId, term = term, monthlyRent = monthlyRent,
        paidMonths = 1, signedSerial = FFR_LandRentManager.getSerial(), status = "ACTIVE"}
    table.insert(state.landRentals, contract)
    return contract
end

function FFR_LandRentManager.validTerm(term)
    for _, t in ipairs(FFR_LandRentManager.TERMS) do if t == tonumber(term) then return t end end
    return nil
end

--------------------------------------------------
-- Actions (server, farm managers via FFR_Network)
--------------------------------------------------

function FFR_LandRentManager.rentIn(state, farmlandId, term)
    farmlandId = tonumber(farmlandId)
    term = FFR_LandRentManager.validTerm(term)
    if farmlandId == nil or term == nil then return false, FFR_L10n.t("ffr_rent_invalid") end
    if not FFR_LandRentManager.canRentIn(farmlandId) then return false, FFR_L10n.t("ffr_rent_not_available", farmlandId) end
    local rent = FFR_LandRentManager.getMonthlyRent(farmlandId)
    if (tonumber(state.financialManager.cashOnHand) or 0) < rent then return false, FFR_L10n.t("ffr_rent_no_cash") end
    if not FFR_LandRentManager.charge(state, rent) then return false, FFR_L10n.t("ffr_rent_no_cash") end
    -- Contract first, so the land registry sees rented land (no title prompt) when ownership changes.
    FFR_LandRentManager.newContract(state, "IN", farmlandId, term, rent)
    FFR_LandRentManager.setOwner(farmlandId, state.farmId)
    Logging.info("FFR Land Rent: Farm %d rents Farmland %d for %d months at $%d a month", state.farmId, farmlandId, term, rent)
    return true, FFR_L10n.t("ffr_rent_in_done", farmlandId, FFR_L10n.months(term), FFR_L10n.formatMoney(rent))
end

function FFR_LandRentManager.rentOut(state, farmlandId, term)
    farmlandId = tonumber(farmlandId)
    term = FFR_LandRentManager.validTerm(term)
    if farmlandId == nil or term == nil then return false, FFR_L10n.t("ffr_rent_invalid") end
    local allowed = false
    for _, id in ipairs(FFR_LandRentManager.getRentOutParcels(state.farmId)) do if id == farmlandId then allowed = true end end
    if not allowed or FFR_LandRentManager.getFsOwner(farmlandId) ~= state.farmId then
        return false, FFR_L10n.t("ffr_rent_out_not_yours", farmlandId)
    end
    if FFR_LandRentManager.countBuildings(farmlandId, state.farmId) > 0 then
        return false, FFR_L10n.t("ffr_rent_out_buildings", farmlandId)
    end
    local rent = FFR_LandRentManager.getMonthlyRent(farmlandId)
    FFR_LandRentManager.newContract(state, "OUT", farmlandId, term, rent)
    FFR_LandRentManager.pay(state, rent)
    FFR_LandRentManager.setOwner(farmlandId, 0)
    Logging.info("FFR Land Rent: Farm %d rents out Farmland %d for %d months at $%d a month", state.farmId, farmlandId, term, rent)
    return true, FFR_L10n.t("ffr_rent_out_done", farmlandId, FFR_L10n.months(term), FFR_L10n.formatMoney(rent))
end

function FFR_LandRentManager.findContract(state, id)
    for _, contract in ipairs(state.landRentals or {}) do
        if contract.id == tonumber(id) then return contract end
    end
    return nil
end

-- Renew in the decision month: a new term at today's market rent.
function FFR_LandRentManager.renew(state, id, term)
    local contract = FFR_LandRentManager.findContract(state, id)
    term = FFR_LandRentManager.validTerm(term) or (contract ~= nil and contract.term) or nil
    if contract == nil or contract.status ~= "ENDING" then return false, FFR_L10n.t("ffr_rent_renew_not_now") end
    contract.status = "RENEWED"
    local rent = FFR_LandRentManager.getMonthlyRent(contract.farmlandId)
    -- The decision month is already paid: it is month 1 of the new term.
    FFR_LandRentManager.newContract(state, contract.kind, contract.farmlandId, term, rent)
    Logging.info("FFR Land Rent: Farm %d renewed Farmland %d (%s) for %d months at $%d", state.farmId, contract.farmlandId, contract.kind, term, rent)
    FFR_LandRentManager.trim(state)
    return true, FFR_L10n.t("ffr_rent_renewed", contract.farmlandId, FFR_L10n.months(term), FFR_L10n.formatMoney(rent))
end

-- Give the parcel back now (renter) or take it back now (landlord).
function FFR_LandRentManager.endNow(state, id)
    local contract = FFR_LandRentManager.findContract(state, id)
    if contract == nil or not FFR_LandRentManager.isOpen(contract) then return false, FFR_L10n.t("ffr_rent_invalid") end
    if contract.kind == "IN" and FFR_LandRentManager.countBuildings(contract.farmlandId, state.farmId) > 0 then
        return false, FFR_L10n.t("ffr_rent_buildings_first", contract.farmlandId)
    end
    local fee = 0
    if contract.status == "ACTIVE" then
        fee = contract.monthlyRent * math.min(FFR_LandRentManager.EARLY_MONTHS, math.max(0, contract.term - contract.paidMonths))
    end
    if fee > 0 and not FFR_LandRentManager.charge(state, fee) then return false, FFR_L10n.t("ffr_rent_no_cash") end
    FFR_LandRentManager.finish(state, contract, "ENDED")
    Logging.info("FFR Land Rent: Farm %d ended Farmland %d (%s) early, fee $%d", state.farmId, contract.farmlandId, contract.kind, math.floor(fee))
    return true, FFR_L10n.t(fee > 0 and "ffr_rent_ended_fee" or "ffr_rent_ended", contract.farmlandId, FFR_L10n.formatMoney(fee))
end

-- The parcel goes back: to the map (rented in) or to its owner (rented out).
function FFR_LandRentManager.finish(state, contract, status)
    contract.status = status or "ENDED"
    FFR_LandRentManager.setOwner(contract.farmlandId, contract.kind == "OUT" and state.farmId or 0)
    FFR_LandRentManager.trim(state)
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

-- Keep the open contracts and the last few closed ones.
function FFR_LandRentManager.trim(state)
    local closed = 0
    for i = #(state.landRentals or {}), 1, -1 do
        if not FFR_LandRentManager.isOpen(state.landRentals[i]) then
            closed = closed + 1
            if closed > FFR_LandRentManager.KEEP_CLOSED then table.remove(state.landRentals, i) end
        end
    end
end

--------------------------------------------------
-- Month end (server, FFR_MonthlyFinancialProcessor)
--------------------------------------------------

-- Rent the farm pays on this bill: each rented-in parcel it keeps next month.
function FFR_LandRentManager.getMonthlyRentDue(state)
    local total = 0
    for _, contract in ipairs(state.landRentals or {}) do
        if contract.kind == "IN" and (contract.status == "ACTIVE" or contract.status == "HOLD") then total = total + contract.monthlyRent end
    end
    return total
end

-- After the bill: count paid months, pay landlords, open decision months, hand parcels back.
function FFR_LandRentManager.applyMonthly(state)
    local income = 0
    for _, contract in ipairs(state.landRentals or {}) do
        local id = contract.farmlandId
        if contract.status == "ENDING" then
            -- Decision month over without a renewal.
            if contract.kind == "IN" and FFR_LandRentManager.countBuildings(id, state.farmId) > 0 then
                contract.status = "HOLD"
                FFR_LandRentManager.notify(state.farmId, FFR_L10n.t("ffr_rent_hold", id))
            else
                FFR_LandRentManager.notify(state.farmId, FFR_L10n.t(contract.kind == "IN" and "ffr_rent_returned" or "ffr_rent_back", id))
                FFR_LandRentManager.finish(state, contract, "ENDED")
            end
        elseif contract.status == "HOLD" then
            if FFR_LandRentManager.countBuildings(id, state.farmId) == 0 then
                FFR_LandRentManager.notify(state.farmId, FFR_L10n.t("ffr_rent_returned", id))
                FFR_LandRentManager.finish(state, contract, "ENDED")
            end
        elseif contract.status == "ACTIVE" then
            if contract.kind == "OUT" then income = income + contract.monthlyRent end
            contract.paidMonths = contract.paidMonths + 1
            if contract.paidMonths > contract.term then
                contract.status = "ENDING"
                FFR_LandRentManager.notify(state.farmId, FFR_L10n.t("ffr_rent_ending", id))
            end
        end
    end
    if income > 0 then FFR_LandRentManager.pay(state, income) end
    state.lastRentIncome = income
    return income
end

function FFR_LandRentManager.notify(farmId, text)
    Logging.info("FFR Land Rent: Farm %d - %s", farmId, tostring(text))
    if FFR_Network ~= nil then FFR_Network.sendNotice("CROP_DAMAGE", farmId, {text = text}) end
end

--------------------------------------------------
-- Save / load per farm (FFR_SaveManager)
--------------------------------------------------

FFR_LandRentManager.NUMBER_FIELDS = {"id", "farmlandId", "term", "monthlyRent", "paidMonths", "signedSerial"}

function FFR_LandRentManager.saveFarm(xmlFile, key, state)
    setXMLInt(xmlFile, key .. "#nextId", tonumber(state.nextRentalId) or 0)
    for i, contract in ipairs(state.landRentals or {}) do
        local base = string.format("%s.rental(%d)", key, i - 1)
        for _, f in ipairs(FFR_LandRentManager.NUMBER_FIELDS) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(contract[f]) or 0) end
        setXMLString(xmlFile, base .. "#kind", tostring(contract.kind))
        setXMLString(xmlFile, base .. "#status", tostring(contract.status))
    end
end

function FFR_LandRentManager.loadFarm(xmlFile, key, state)
    state.landRentals = {}
    state.nextRentalId = getXMLInt(xmlFile, key .. "#nextId") or 0
    local i = 0
    while hasXMLProperty(xmlFile, string.format("%s.rental(%d)", key, i)) do
        local base = string.format("%s.rental(%d)", key, i)
        local contract = {}
        for _, f in ipairs(FFR_LandRentManager.NUMBER_FIELDS) do contract[f] = getXMLFloat(xmlFile, base .. "#" .. f) or 0 end
        contract.id = math.floor(contract.id)
        contract.farmlandId = math.floor(contract.farmlandId)
        contract.kind = getXMLString(xmlFile, base .. "#kind") or "IN"
        contract.status = getXMLString(xmlFile, base .. "#status") or "ACTIVE"
        table.insert(state.landRentals, contract)
        i = i + 1
    end
end

function FFR_LandRentManager.countOpen(state)
    local n = 0
    for _, contract in ipairs(state.landRentals or {}) do if FFR_LandRentManager.isOpen(contract) then n = n + 1 end end
    return n
end

Logging.info("FFR Land Rent: Cash rent installed")
