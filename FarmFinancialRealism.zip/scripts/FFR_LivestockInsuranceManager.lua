FFR_LivestockInsuranceManager = {}

--------------------------------------------------
-- Livestock mortality insurance
--
-- One policy per farm, bought any time on the
-- Insurance page, running for 12 months. The
-- premium is PREMIUM_RATE of the herd's value at
-- purchase (x the difficulty's insurance scale),
-- charged once. Cover starts after WAITING_HOURS,
-- so a policy cannot be bought once an outbreak has
-- started.
--
-- When an outbreak kills insured animals
-- (FFR_HerdRiskManager), a claim opens on its own;
-- the adjuster confirms it ADJUSTER_MIN..MAX in-game
-- hours later and pays COVERAGE of the value lost.
-- Vet bills are not covered.
--
-- Per farm: state.herdPolicy and state.herdClaims.
--------------------------------------------------

FFR_LivestockInsuranceManager.PREMIUM_RATE = 0.025
FFR_LivestockInsuranceManager.COVERAGE = 0.80
FFR_LivestockInsuranceManager.WAITING_HOURS = 24
FFR_LivestockInsuranceManager.ADJUSTER_MIN = 6
FFR_LivestockInsuranceManager.ADJUSTER_MAX = 24

FFR_LivestockInsuranceManager.updateTimer = 0

function FFR_LivestockInsuranceManager.now()
    return FFR_CropInsuranceManager ~= nil and FFR_CropInsuranceManager.getAbsoluteHour() or 0
end

-- A policy runs one in-game year: 12 months of the save's month length.
function FFR_LivestockInsuranceManager.getTermHours()
    local days = FFR_HerdRiskManager ~= nil and FFR_HerdRiskManager.getDaysPerMonth() or 1
    return days * 12 * 24
end

function FFR_LivestockInsuranceManager.getPolicy(state)
    local policy = state ~= nil and state.herdPolicy or nil
    if policy == nil or FFR_LivestockInsuranceManager.now() >= (tonumber(policy.endHour) or 0) then return nil end
    return policy
end

function FFR_LivestockInsuranceManager.isCovered(policy)
    return policy ~= nil and FFR_LivestockInsuranceManager.now() >= (tonumber(policy.startHour) or 0)
end

function FFR_LivestockInsuranceManager.getHerdValue(farmId)
    local value, head = 0, 0
    if FFR_HerdRiskManager == nil then return 0, 0 end
    for _, barn in ipairs(FFR_HerdRiskManager.getBarns(farmId)) do
        value, head = value + barn.value, head + barn.head
    end
    return value, head
end

function FFR_LivestockInsuranceManager.getQuote(farmId)
    local value, head = FFR_LivestockInsuranceManager.getHerdValue(farmId)
    local scale = FFR_Settings ~= nil and (tonumber(FFR_Settings.getValue("insurance")) or 1) or 1
    return {value = value, head = head, premium = value * FFR_LivestockInsuranceManager.PREMIUM_RATE * scale}
end

--------------------------------------------------
-- Actions (server, farm managers via FFR_Network)
--------------------------------------------------

function FFR_LivestockInsuranceManager.buyPolicy(state)
    if FFR_LivestockInsuranceManager.getPolicy(state) ~= nil then return false, FFR_L10n.t("ffr_herd_already") end
    local quote = FFR_LivestockInsuranceManager.getQuote(state.farmId)
    if quote.head <= 0 then return false, FFR_L10n.t("ffr_herd_no_animals_insure") end
    if FFR_CropInsuranceManager == nil or not FFR_CropInsuranceManager.charge(state, quote.premium) then
        return false, FFR_L10n.t("ffr_insure_charge_failed")
    end
    local now = FFR_LivestockInsuranceManager.now()
    state.herdPolicy = {
        startHour = now + FFR_LivestockInsuranceManager.WAITING_HOURS,
        endHour = now + FFR_LivestockInsuranceManager.getTermHours(),
        premium = quote.premium, value = quote.value, head = quote.head
    }
    Logging.info("FFR Livestock Insurance: Farm %d insured %d head ($%d) for $%d", state.farmId, quote.head,
        math.floor(quote.value), math.floor(quote.premium))
    return true, FFR_L10n.t("ffr_herd_bought",
        FFR_HerdRiskManager.formatMoney(quote.premium))
end

-- Called by an outbreak; returns a sentence for the notice.
function FFR_LivestockInsuranceManager.onLoss(state, event)
    local policy = FFR_LivestockInsuranceManager.getPolicy(state)
    if policy == nil then return FFR_L10n.t("ffr_herd_loss_uninsured") end
    if not FFR_LivestockInsuranceManager.isCovered(policy) then return FFR_L10n.t("ffr_herd_loss_waiting") end
    if (tonumber(event.value) or 0) <= 0 then return "" end
    local visit = FFR_LivestockInsuranceManager.now() + math.random(FFR_LivestockInsuranceManager.ADJUSTER_MIN, FFR_LivestockInsuranceManager.ADJUSTER_MAX)
    state.herdClaims = state.herdClaims or {}
    table.insert(state.herdClaims, {barn = event.barn, dead = event.dead, value = event.value, visitHour = visit, status = "FILED", payout = 0})
    while #state.herdClaims > 12 do table.remove(state.herdClaims, 1) end
    return FFR_L10n.t("ffr_herd_loss_claim")
end

function FFR_LivestockInsuranceManager.processClaims()
    local now = FFR_LivestockInsuranceManager.now()
    for _, state in ipairs(g_FFR:getFarmStates()) do
        for _, claim in ipairs(state.herdClaims or {}) do
            if claim.status == "FILED" and now >= (tonumber(claim.visitHour) or 0) then
                local payout = math.floor((tonumber(claim.value) or 0) * FFR_LivestockInsuranceManager.COVERAGE + 0.5)
                if payout > 0 and FFR_CropInsuranceManager ~= nil and FFR_CropInsuranceManager.pay(state, payout) then
                    claim.status, claim.payout = "PAID", payout
                    local text = FFR_L10n.t("ffr_herd_claim_paid",
                        tonumber(claim.dead) or 0, tostring(claim.barn), FFR_HerdRiskManager.formatMoney(payout),
                        math.floor(FFR_LivestockInsuranceManager.COVERAGE * 100))
                    Logging.info("FFR Livestock Insurance: Farm %d - %s", state.farmId, text)
                    if FFR_CropDamageManager ~= nil then FFR_CropDamageManager.notify(state.farmId, text) end
                else
                    claim.status = "DENIED"
                end
                if FFR_Network ~= nil then FFR_Network.markDirty() end
            end
        end
    end
end

--------------------------------------------------
-- Save / load per farm (called by FFR_SaveManager)
--------------------------------------------------

function FFR_LivestockInsuranceManager.saveFarm(xmlFile, key, state)
    local p = state.herdPolicy
    if p ~= nil then
        for _, f in ipairs({"startHour", "endHour", "premium", "value", "head"}) do
            setXMLFloat(xmlFile, key .. ".policy#" .. f, tonumber(p[f]) or 0)
        end
    end
    for i, c in ipairs(state.herdClaims or {}) do
        local base = string.format("%s.claims.claim(%d)", key, i - 1)
        setXMLString(xmlFile, base .. "#barn", tostring(c.barn or ""))
        setXMLString(xmlFile, base .. "#status", tostring(c.status or "FILED"))
        for _, f in ipairs({"dead", "value", "visitHour", "payout"}) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(c[f]) or 0) end
    end
    for i, e in ipairs(state.herdEvents or {}) do
        local base = string.format("%s.outbreaks.outbreak(%d)", key, i - 1)
        for _, f in ipairs({"barn", "animals", "disease"}) do setXMLString(xmlFile, base .. "#" .. f, tostring(e[f] or "")) end
        for _, f in ipairs({"dead", "value", "vetBill", "hour"}) do setXMLFloat(xmlFile, base .. "#" .. f, tonumber(e[f]) or 0) end
    end
end

function FFR_LivestockInsuranceManager.loadFarm(xmlFile, key, state)
    state.herdPolicy, state.herdClaims, state.herdEvents = nil, {}, {}
    if hasXMLProperty(xmlFile, key .. ".policy") then
        state.herdPolicy = {}
        for _, f in ipairs({"startHour", "endHour", "premium", "value", "head"}) do
            state.herdPolicy[f] = getXMLFloat(xmlFile, key .. ".policy#" .. f) or 0
        end
    end
    local i = 0
    while hasXMLProperty(xmlFile, string.format("%s.claims.claim(%d)", key, i)) do
        local base = string.format("%s.claims.claim(%d)", key, i)
        local c = {barn = getXMLString(xmlFile, base .. "#barn"), status = getXMLString(xmlFile, base .. "#status") or "FILED"}
        for _, f in ipairs({"dead", "value", "visitHour", "payout"}) do c[f] = getXMLFloat(xmlFile, base .. "#" .. f) or 0 end
        table.insert(state.herdClaims, c)
        i = i + 1
    end
    i = 0
    while hasXMLProperty(xmlFile, string.format("%s.outbreaks.outbreak(%d)", key, i)) do
        local base = string.format("%s.outbreaks.outbreak(%d)", key, i)
        local e = {}
        for _, f in ipairs({"barn", "animals", "disease"}) do e[f] = getXMLString(xmlFile, base .. "#" .. f) end
        for _, f in ipairs({"dead", "value", "vetBill", "hour"}) do e[f] = getXMLFloat(xmlFile, base .. "#" .. f) or 0 end
        table.insert(state.herdEvents, e)
        i = i + 1
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_LivestockInsuranceManager:update(dt)
    FFR_LivestockInsuranceManager.updateTimer = FFR_LivestockInsuranceManager.updateTimer + dt
    if FFR_LivestockInsuranceManager.updateTimer < 2000 then return end
    FFR_LivestockInsuranceManager.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    local ok, err = pcall(FFR_LivestockInsuranceManager.processClaims)
    if not ok then Logging.warning("FFR Livestock Insurance: Claim processing failed (%s)", tostring(err)) end
end

function FFR_LivestockInsuranceManager:loadMap(mapName) FFR_LivestockInsuranceManager.updateTimer = 0 end
function FFR_LivestockInsuranceManager:deleteMap() end
function FFR_LivestockInsuranceManager:draw() end
function FFR_LivestockInsuranceManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_LivestockInsuranceManager:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_LivestockInsuranceManager)
Logging.info("FFR Livestock Insurance: Mortality policies installed")
