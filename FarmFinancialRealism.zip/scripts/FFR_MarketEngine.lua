FFR_MarketEngine = {}

function FFR_MarketEngine:new()
    local self = {}
    setmetatable(self, {__index = FFR_MarketEngine})

    self.activeEvent = nil
    self.eventHistory = {}
    self.cooldowns = {}
    self.recoveryProtection = {}
    self.lastProcessedPeriod = 0
    self.lastProcessedYear = 0

    self.categoryModifiers = {
        grain = 1.00,
        oilseed = 1.00,
        pulse = 1.00,
        forage = 1.00,
        industrial = 1.00,
        vegetable = 1.00,
        cattle = 1.00,
        dairy = 1.00,
        pig = 1.00,
        sheep = 1.00,
        poultry = 1.00,
        animalProducts = 1.00
    }

    -- Normal-preset values; FFR_Settings.applyToGame replaces them with the active preset.
    self.settings = {
        drasticEventsEnabled = true,
        drasticWeight = 5,
        eventStrength = 1.00,
        calmChance = 0.30,
        maximumNegativeModifier = 0.65,
        maximumPositiveModifier = 1.40,
        severeCooldownMonths = 3,
        drasticCooldownMonths = 5,
        recoveryProtectionMonths = 2
    }

    return self
end

-- Difficulty preset (FFR_Settings): strength and drastic odds apply to new events;
-- the price range applies to the active event straight away.
function FFR_MarketEngine:applyPreset(preset)
    if preset == nil then return end
    self.settings.drasticWeight = tonumber(preset.drasticWeight) or 0
    self.settings.drasticEventsEnabled = self.settings.drasticWeight > 0
    self.settings.eventStrength = tonumber(preset.eventStrength) or 1.00
    self.settings.calmChance = tonumber(preset.calmChance) or 0
    self.settings.maximumNegativeModifier = tonumber(preset.minModifier) or 0.65
    self.settings.maximumPositiveModifier = tonumber(preset.maxModifier) or 1.40
    if self.activeEvent ~= nil and self.activeEvent.peakAdjustments ~= nil then
        self:recalculateCurrentAdjustments()
    end
end

function FFR_MarketEngine:getNumber(value, defaultValue)
    local result = tonumber(value)
    if result == nil then return defaultValue or 0 end
    return result
end

function FFR_MarketEngine:clamp(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

function FFR_MarketEngine:getCalendarSerial(period, year)
    return (tonumber(year) or 0) * 12 + (tonumber(period) or 0)
end

function FFR_MarketEngine:addMonths(period, year, months)
    local serial = self:getCalendarSerial(period, year) + (tonumber(months) or 0)
    local resultYear = math.floor((serial - 1) / 12)
    local resultPeriod = serial - resultYear * 12
    return resultPeriod, resultYear
end

function FFR_MarketEngine:resetModifiers()
    for category, _ in pairs(self.categoryModifiers) do
        self.categoryModifiers[category] = 1.00
    end
end

function FFR_MarketEngine:getSeverityDefinitions()
    return {
        LIGHT = {weight = 46, cropMin = 0.02, cropMax = 0.06, animalMin = 0.02, animalMax = 0.05, forageMin = 0.01, forageMax = 0.03},
        MODERATE = {weight = 32, cropMin = 0.07, cropMax = 0.14, animalMin = 0.05, animalMax = 0.10, forageMin = 0.03, forageMax = 0.06},
        SEVERE = {weight = 17, cropMin = 0.15, cropMax = 0.24, animalMin = 0.10, animalMax = 0.18, forageMin = 0.06, forageMax = 0.10},
        DRASTIC = {weight = self.settings.drasticWeight or 5, cropMin = 0.25, cropMax = 0.35, animalMin = 0.18, animalMax = 0.25, forageMin = 0.10, forageMax = 0.15}
    }
end

function FFR_MarketEngine:getPhaseFactors()
    return {
        DEVELOPING = 0.45,
        ESCALATING = 0.75,
        PEAK = 1.00,
        RECOVERING = 0.50,
        RESOLVED = 0.00
    }
end

function FFR_MarketEngine:getEvents()
    return {
        {
            id = "GLOBAL_DROUGHT",
            name = "Global Drought",
            direction = 1,
            minimumDurationMonths = 4,
            maximumDurationMonths = 6,
            targets = {grain = 1.00, oilseed = 0.90, pulse = 0.85, forage = 0.65, cattle = -0.35, dairy = -0.25},
            description = "Dry conditions are reducing crop supplies while increasing livestock feed pressure."
        },
        {
            id = "RECORD_HARVEST",
            name = "Record Harvest",
            direction = -1,
            minimumDurationMonths = 3,
            maximumDurationMonths = 5,
            targets = {grain = 1.00, oilseed = 0.70, pulse = 0.55, forage = 0.35, cattle = 0.20, pig = 0.20},
            description = "Large supplies are weighing on crop prices while easing some feed costs."
        },
        {
            id = "BIOFUEL_EXPANSION",
            name = "Biofuel Expansion",
            direction = 1,
            minimumDurationMonths = 3,
            maximumDurationMonths = 5,
            targets = {oilseed = 1.00, grain = 0.35, industrial = 0.45},
            description = "Higher renewable-fuel demand is supporting oilseed and selected industrial markets."
        },
        {
            id = "LIVESTOCK_EXPANSION",
            name = "Livestock Expansion",
            direction = 1,
            minimumDurationMonths = 3,
            maximumDurationMonths = 5,
            targets = {cattle = 0.80, dairy = 0.45, pig = 0.70, sheep = 0.40, grain = 0.35, forage = 0.30},
            description = "Herd expansion is strengthening livestock and feed demand."
        },
        {
            id = "EXPORT_RESTRICTIONS",
            name = "Export Restrictions",
            direction = -1,
            minimumDurationMonths = 3,
            maximumDurationMonths = 6,
            targets = {grain = 1.00, oilseed = 0.80, pulse = 0.55},
            description = "Reduced export access is weakening affected crop categories."
        },
        {
            id = "ANIMAL_PROCESSING_SHORTAGE",
            name = "Animal Processing Shortage",
            direction = -1,
            minimumDurationMonths = 2,
            maximumDurationMonths = 4,
            targets = {cattle = 1.00, pig = 0.90, sheep = 0.55, poultry = 0.45},
            description = "Limited processing capacity is reducing livestock demand."
        },
        {
            id = "PROTEIN_DEMAND_SURGE",
            name = "Protein Demand Surge",
            direction = 1,
            minimumDurationMonths = 2,
            maximumDurationMonths = 4,
            targets = {cattle = 1.00, pig = 0.80, poultry = 0.65, dairy = 0.35, animalProducts = 0.40},
            description = "Strong consumer demand is supporting livestock and animal-product prices."
        },
        {
            id = "REGIONAL_FORAGE_SHORTAGE",
            name = "Regional Forage Shortage",
            direction = 1,
            minimumDurationMonths = 2,
            maximumDurationMonths = 4,
            targets = {forage = 1.00, cattle = -0.25, dairy = -0.20, sheep = -0.15},
            description = "Tight hay, grass, and straw supplies are raising feed values and livestock costs."
        }
    }
end

function FFR_MarketEngine:isAnimalCategory(category)
    return category == "cattle" or category == "dairy" or category == "pig" or category == "sheep" or category == "poultry" or category == "animalProducts"
end

function FFR_MarketEngine:isForageCategory(category)
    return category == "forage"
end

function FFR_MarketEngine:selectSeverity()
    local definitions = self:getSeverityDefinitions()
    local totalWeight = 0
    for name, data in pairs(definitions) do
        if name ~= "DRASTIC" or self.settings.drasticEventsEnabled then
            totalWeight = totalWeight + data.weight
        end
    end

    local roll = math.random(1, totalWeight)
    local running = 0
    for _, name in ipairs({"LIGHT", "MODERATE", "SEVERE", "DRASTIC"}) do
        local data = definitions[name]
        if name ~= "DRASTIC" or self.settings.drasticEventsEnabled then
            running = running + data.weight
            if roll <= running then return name, data end
        end
    end

    return "LIGHT", definitions.LIGHT
end

function FFR_MarketEngine:isEventEligible(event, currentPeriod, currentYear)
    local serial = self:getCalendarSerial(currentPeriod, currentYear)
    for category, _ in pairs(event.targets or {}) do
        if (self.cooldowns[category] or 0) > serial then return false end
        if event.direction < 0 and (self.recoveryProtection[category] or 0) > serial then return false end
    end
    return true
end

function FFR_MarketEngine:selectEvent(currentPeriod, currentYear)
    local eligible = {}
    for _, event in ipairs(self:getEvents()) do
        if self:isEventEligible(event, currentPeriod, currentYear) then
            table.insert(eligible, event)
        end
    end

    if #eligible == 0 then
        return self:getStableTemplate()
    end

    return eligible[math.random(1, #eligible)]
end

-- A calm spell with no price adjustment.
function FFR_MarketEngine:getStableTemplate()
    return {
        id = "STABLE_MARKETS",
        name = "Stable Markets",
        direction = 0,
        minimumDurationMonths = 1,
        maximumDurationMonths = 2,
        targets = {},
        description = "No major temporary market disruption is currently active."
    }
end

function FFR_MarketEngine:getRangeForCategory(severityData, category)
    if self:isForageCategory(category) then
        return severityData.forageMin, severityData.forageMax
    end
    if self:isAnimalCategory(category) then
        return severityData.animalMin, severityData.animalMax
    end
    return severityData.cropMin, severityData.cropMax
end

function FFR_MarketEngine:buildEventState(template, severityName, severityData, currentPeriod, currentYear)
    local duration = math.random(template.minimumDurationMonths or 3, template.maximumDurationMonths or 5)
    local expiryPeriod, expiryYear = self:addMonths(currentPeriod, currentYear, duration - 1)
    local peakAdjustments = {}

    for category, strength in pairs(template.targets or {}) do
        local minimum, maximum = self:getRangeForCategory(severityData, category)
        local magnitude = (minimum + math.random() * (maximum - minimum)) * (tonumber(self.settings.eventStrength) or 1.00)
        local directionalStrength = tonumber(strength) or 1.00
        local direction = template.direction or 0

        if directionalStrength < 0 then
            direction = -direction
            directionalStrength = math.abs(directionalStrength)
        end

        peakAdjustments[category] = direction * magnitude * directionalStrength
    end

    return {
        id = template.id,
        name = template.name,
        description = template.description,
        severity = severityName,
        phase = "DEVELOPING",
        direction = template.direction or 0,
        startPeriod = currentPeriod,
        startYear = currentYear,
        expiryPeriod = expiryPeriod,
        expiryYear = expiryYear,
        durationMonths = duration,
        elapsedMonths = 0,
        peakAdjustments = peakAdjustments,
        currentAdjustments = {}
    }
end

function FFR_MarketEngine:determinePhase(event)
    local elapsed = tonumber(event.elapsedMonths) or 0
    local duration = math.max(1, tonumber(event.durationMonths) or 1)
    if elapsed >= duration then return "RESOLVED" end
    if duration == 1 then return "PEAK" end

    local progress = elapsed / math.max(duration - 1, 1)
    if progress < 0.25 then return "DEVELOPING" end
    if progress < 0.50 then return "ESCALATING" end
    if progress < 0.75 then return "PEAK" end
    return "RECOVERING"
end

function FFR_MarketEngine:recalculateCurrentAdjustments()
    self:resetModifiers()
    if self.activeEvent == nil then return end

    local factors = self:getPhaseFactors()
    local phase = self.activeEvent.phase or "DEVELOPING"
    local factor = factors[phase] or 0
    self.activeEvent.currentAdjustments = {}

    for category, peakAdjustment in pairs(self.activeEvent.peakAdjustments or {}) do
        local adjustment = peakAdjustment * factor
        local modifier = self:clamp(1.00 + adjustment, self.settings.maximumNegativeModifier, self.settings.maximumPositiveModifier)
        self.activeEvent.currentAdjustments[category] = modifier - 1.00
        if self.categoryModifiers[category] ~= nil then
            self.categoryModifiers[category] = modifier
        end
    end
end

function FFR_MarketEngine:createRandomEvent(currentPeriod, currentYear)
    currentPeriod = tonumber(currentPeriod) or 1
    currentYear = tonumber(currentYear) or 1

    -- The difficulty preset sets how often a calm spell comes instead of an event.
    local template
    if math.random() < (tonumber(self.settings.calmChance) or 0) then
        template = self:getStableTemplate()
    else
        template = self:selectEvent(currentPeriod, currentYear)
    end
    local severityName, severityData = self:selectSeverity()
    if template.direction == 0 then
        severityName = "NEUTRAL"
        severityData = self:getSeverityDefinitions().LIGHT
    end

    self.activeEvent = self:buildEventState(template, severityName, severityData, currentPeriod, currentYear)
    self.lastProcessedPeriod = currentPeriod
    self.lastProcessedYear = currentYear
    self.activeEvent.phase = self:determinePhase(self.activeEvent)
    self:recalculateCurrentAdjustments()
    self:printReport()
    return true
end

function FFR_MarketEngine:applyEvent(event)
    if event == nil then return false end

    if event.peakAdjustments ~= nil then
        self.activeEvent = event
        self.activeEvent.phase = self.activeEvent.phase or self:determinePhase(self.activeEvent)
        self:recalculateCurrentAdjustments()
        return true
    end

    self:resetModifiers()
    self.activeEvent = event
    for category, modifier in pairs(event.modifiers or {}) do
        if self.categoryModifiers[category] ~= nil then
            self.categoryModifiers[category] = self:getNumber(modifier, 1.00)
        end
    end
    return true
end

function FFR_MarketEngine:restoreEventByName(eventName)
    for _, event in ipairs(self:getEvents()) do
        if event.name == eventName or event.id == eventName then
            self.activeEvent = event
            return true
        end
    end
    return false
end

function FFR_MarketEngine:finishActiveEvent(currentPeriod, currentYear)
    if self.activeEvent == nil then return end

    local severity = self.activeEvent.severity or "LIGHT"
    local serial = self:getCalendarSerial(currentPeriod, currentYear)
    local cooldownMonths = 1
    if severity == "SEVERE" then cooldownMonths = self.settings.severeCooldownMonths end
    if severity == "DRASTIC" then cooldownMonths = self.settings.drasticCooldownMonths end

    for category, peakAdjustment in pairs(self.activeEvent.peakAdjustments or {}) do
        self.cooldowns[category] = serial + cooldownMonths
        if peakAdjustment < 0 and (severity == "SEVERE" or severity == "DRASTIC") then
            self.recoveryProtection[category] = serial + self.settings.recoveryProtectionMonths
        end
    end

    table.insert(self.eventHistory, {
        id = self.activeEvent.id,
        name = self.activeEvent.name,
        severity = severity,
        resolvedPeriod = currentPeriod,
        resolvedYear = currentYear
    })
end

function FFR_MarketEngine:updateCalendar(currentPeriod, currentYear)
    currentPeriod = tonumber(currentPeriod) or 0
    currentYear = tonumber(currentYear) or 0
    if currentPeriod <= 0 or currentYear <= 0 then return false end

    if self.lastProcessedPeriod == currentPeriod and self.lastProcessedYear == currentYear then
        return false
    end

    self.lastProcessedPeriod = currentPeriod
    self.lastProcessedYear = currentYear

    if self.activeEvent == nil then
        return self:createRandomEvent(currentPeriod, currentYear)
    end

    self.activeEvent.elapsedMonths = (tonumber(self.activeEvent.elapsedMonths) or 0) + 1
    self.activeEvent.phase = self:determinePhase(self.activeEvent)

    if self.activeEvent.phase == "RESOLVED" then
        self:finishActiveEvent(currentPeriod, currentYear)
        return self:createRandomEvent(currentPeriod, currentYear)
    end

    self:recalculateCurrentAdjustments()
    self:printReport()
    return true
end

function FFR_MarketEngine:getModifier(category)
    if category == nil then return 1.00 end
    return self:getNumber(self.categoryModifiers[category], 1.00)
end

-- Expected FFR modifier for a category a number of months from now, following the
-- active event through its phases. Once the event would have resolved, the outlook is
-- neutral (1.0): the next event is unknown. Used to price forward contracts.
function FFR_MarketEngine:getProjectedModifier(category, monthsAhead)
    local event = self.activeEvent
    if category == nil or event == nil or event.peakAdjustments == nil then return 1.00 end
    local peak = tonumber(event.peakAdjustments[category])
    if peak == nil then return 1.00 end
    local projected = {
        elapsedMonths = (tonumber(event.elapsedMonths) or 0) + (tonumber(monthsAhead) or 0),
        durationMonths = event.durationMonths
    }
    local factor = self:getPhaseFactors()[self:determinePhase(projected)] or 0
    return self:clamp(1.00 + peak * factor, self.settings.maximumNegativeModifier, self.settings.maximumPositiveModifier)
end

function FFR_MarketEngine:getAdjustment(category)
    return self:getModifier(category) - 1.00
end

function FFR_MarketEngine:getActiveEventDescription(category)
    if self.activeEvent == nil then return FFR_L10n.t("ffr_news_no_event") end
    local modifier = self:getModifier(category)
    local percent = math.floor(math.abs(modifier - 1.00) * 100 + 0.5)
    if percent == 0 then return FFR_L10n.t("ffr_market_no_adjustment") end
    if modifier > 1.00 then return FFR_L10n.t("ffr_market_increased", FFR_L10n.named("ffr_market_cat_", category), percent) end
    return FFR_L10n.t("ffr_market_reduced", FFR_L10n.named("ffr_market_cat_", category), percent)
end

function FFR_MarketEngine:applyToCommodityManager(commodityManager)
    if commodityManager == nil or commodityManager.applyCategoryModifier == nil then return false end
    for category, modifier in pairs(self.categoryModifiers) do
        commodityManager:applyCategoryModifier(category, modifier)
    end
    return true
end

function FFR_MarketEngine:recalculatePrices(commodityManager)
    return self:applyToCommodityManager(commodityManager)
end

function FFR_MarketEngine:printReport()
    Logging.info("========================================")
    Logging.info("FFR MARKET EVENT REPORT")
    Logging.info("========================================")

    if self.activeEvent == nil then
        Logging.info("Active Event: None")
    else
        Logging.info("Event: %s", tostring(self.activeEvent.name or "Unknown"))
        Logging.info("Severity: %s", tostring(self.activeEvent.severity or "LEGACY"))
        Logging.info("Phase: %s", tostring(self.activeEvent.phase or "ACTIVE"))
        Logging.info("Description: %s", tostring(self.activeEvent.description or ""))
        for category, modifier in pairs(self.categoryModifiers) do
            if math.abs(modifier - 1.00) > 0.0001 then
                Logging.info("%s adjustment: %+.1f%%", tostring(category), (modifier - 1.00) * 100)
            end
        end
    end

    Logging.info("========================================")
end
