FFR_MarketEventController = {}

function FFR_MarketEventController:new()
    local self = {}
    setmetatable(self, {__index = FFR_MarketEventController})
    self.lastPeriod = 0
    self.lastYear = 0
    self.updateTimer = 0
    self.updateInterval = 1000
    self.initialized = false
    return self
end

function FFR_MarketEventController:getCalendar()
    if g_currentMission == nil or g_currentMission.environment == nil then return nil, nil end
    return tonumber(g_currentMission.environment.currentPeriod), tonumber(g_currentMission.environment.currentYear)
end

function FFR_MarketEventController:initialize()
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.marketEngine == nil then return false end
    local period, year = self:getCalendar()
    if period == nil or year == nil then return false end

    self.lastPeriod = period
    self.lastYear = year

    local engine = g_FFR.marketEngine
    -- The difficulty preset decides event strength, calm chance and price range.
    if FFR_Settings ~= nil then engine:applyPreset(FFR_Settings.get()) end
    if engine.activeEvent == nil then
        engine:createRandomEvent(period, year)
    elseif engine.activeEvent.peakAdjustments == nil then
        Logging.info("FFR Market Events: Migrating legacy fixed event on next event cycle")
        engine.lastProcessedPeriod = period
        engine.lastProcessedYear = year
    else
        engine.lastProcessedPeriod = period
        engine.lastProcessedYear = year
        engine:recalculateCurrentAdjustments()
    end

    engine:applyToCommodityManager(g_FFR.commodityManager)
    self.initialized = true
    Logging.info("FFR Market Events: Shared event controller initialized")
    return true
end

function FFR_MarketEventController:update(dt)
    -- Market events are decided on the server; clients receive them in the sync.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer < self.updateInterval then return end
    self.updateTimer = 0

    if not self.initialized then
        self:initialize()
        return
    end

    if g_FFR == nil or g_FFR.marketEngine == nil then return end
    local period, year = self:getCalendar()
    if period == nil or year == nil then return end
    if period == self.lastPeriod and year == self.lastYear then return end

    self.lastPeriod = period
    self.lastYear = year

    -- A difficulty chosen last month starts now, before the new month's event.
    if FFR_Settings ~= nil then FFR_Settings.applyPending() end

    local previousEvent = g_FFR.marketEngine.activeEvent
    local changed = g_FFR.marketEngine:updateCalendar(period, year)
    if changed then
        g_FFR.marketEngine:applyToCommodityManager(g_FFR.commodityManager)
        -- A brand-new event (not just a phase step) gets a headline.
        if g_FFR.marketEngine.activeEvent ~= previousEvent and g_FFR.newsSystem ~= nil then
            g_FFR.newsSystem:createMarketStory(g_FFR.marketEngine.activeEvent)
        end
        if g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
    end
end

function FFR_MarketEventController:loadMap(mapName)
    self.initialized = false
    self.updateTimer = 0
end

function FFR_MarketEventController:deleteMap()
    self.initialized = false
end

function FFR_MarketEventController:draw() end
function FFR_MarketEventController:keyEvent(unicode, sym, modifier, isDown) end
function FFR_MarketEventController:mouseEvent(posX, posY, isDown, isUp, button) end

g_FFRMarketEventController = FFR_MarketEventController:new()
addModEventListener(g_FFRMarketEventController)
Logging.info("FFR Market Events: Controller installed")
