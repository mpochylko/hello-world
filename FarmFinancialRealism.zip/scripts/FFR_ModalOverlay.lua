FFR_ModalOverlay = {}

local FFR_MODAL_MOD_DIR = g_currentModDirectory

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_ModalOverlay:new()
    local self = {}

    setmetatable(
        self,
        {
            __index = FFR_ModalOverlay
        }
    )

    self.visible = false
    self.mode = nil
    self.data = nil
    self.callback = nil
    self.target = nil

    self.whiteOverlay = nil
    self.ownsMenuContext = false
    self.householdSelectedIndex = 1

    -- A monthly summary that arrives while another
    -- window is open waits here instead of replacing it.
    self.pendingMonthly = nil

    return self
end

--------------------------------------------------
-- Create Reusable White Overlay
--------------------------------------------------

function FFR_ModalOverlay:ensureOverlay()
    if self.whiteOverlay ~= nil then
        return true
    end

    if Overlay == nil
        or Overlay.new == nil
    then
        Logging.error(
            "FFR Modal Overlay: Overlay class unavailable"
        )

        return false
    end

    local texture = Utils.getFilename(
        "gui/FFR_white.dds",
        FFR_MODAL_MOD_DIR
    )

    if fileExists ~= nil
        and not fileExists(texture)
    then
        Logging.error(
            "FFR Modal Overlay: White texture missing at %s",
            tostring(texture)
        )

        return false
    end

    self.whiteOverlay = Overlay.new(
        texture,
        0,
        0,
        1,
        1
    )

    if self.whiteOverlay == nil
        or self.whiteOverlay.overlayId == nil
        or self.whiteOverlay.overlayId == 0
    then
        Logging.error(
            "FFR Modal Overlay: Failed to create overlay object"
        )

        self.whiteOverlay = nil

        return false
    end

    Logging.info(
        "FFR Modal Overlay: Overlay object created"
    )

    return true
end

--------------------------------------------------
-- Capture Gameplay Input
--------------------------------------------------

function FFR_ModalOverlay:captureInput()
    if g_gui ~= nil
        and g_gui.enterMenuContext ~= nil
    then
        local guiVisible = false

        if g_gui.getIsGuiVisible ~= nil then
            guiVisible = g_gui:getIsGuiVisible() == true
        end

        if not guiVisible then
            g_gui:enterMenuContext()
            self.ownsMenuContext = true
        end
    end

    -- Only take the cursor when this window took the input too. Over an open menu
    -- (CHANGE TITLE) the menu owns the cursor; showing it here would leave it on
    -- in gameplay, unclickable, once the menu closes.
    if self.ownsMenuContext
        and g_inputBinding ~= nil
        and g_inputBinding.setShowMouseCursor ~= nil
    then
        g_inputBinding:setShowMouseCursor(
            true,
            true
        )
    end
end

--------------------------------------------------
-- Release Gameplay Input
--------------------------------------------------

function FFR_ModalOverlay:releaseInput()
    local owned = self.ownsMenuContext

    if owned
        and g_gui ~= nil
        and g_gui.leaveMenuContext ~= nil
    then
        g_gui:leaveMenuContext()
    end

    self.ownsMenuContext = false

    -- Hide only the cursor this window showed, and never under an open menu.
    -- (guiCountsSelf: the menu check counted this window's own input context, so it says nothing.)
    if owned
        and g_inputBinding ~= nil
        and g_inputBinding.setShowMouseCursor ~= nil
        and (self.guiCountsSelf or not FFR_ModalOverlay.isGameGuiOpen())
    then
        g_inputBinding:setShowMouseCursor(
            false,
            true
        )
    end
end

--------------------------------------------------
-- Show Land Registration
--------------------------------------------------

function FFR_ModalOverlay:showLand(
    manager,
    parcel,
    overMenu
)
    -- The land registry re-queues the parcel and retries.
    if self.visible then
        return false
    end

    if not self:ensureOverlay() then
        return false
    end

    self.mode = "LAND"
    self.data = parcel
    self.target = manager
    self.openedAt = g_time or 0
    self.pressedOption = nil

    self.callback = function(
        choice,
        percent
    )
        manager:register(
            choice,
            percent
        )
    end

    self.visible = true
    self:captureInput()

    -- The land registry opens new titles only with no game menu on screen; if the
    -- check still says "open" now, it counts this window's own input context,
    -- so never suspend this window. A title change is opened from the FFR page
    -- on purpose and stays on top of the menu (the page ignores input meanwhile).
    self.overMenu = overMenu == true
    self.guiCountsSelf = self.overMenu or FFR_ModalOverlay.isGameGuiOpen()

    Logging.info(
        "FFR Modal Overlay: Land registration opened for farmland %d",
        tonumber(parcel.farmlandId) or 0
    )

    return true
end

--------------------------------------------------
-- Show Monthly Cost Summary
--------------------------------------------------

function FFR_ModalOverlay:showMonthly(
    data,
    callback,
    target
)
    if self.visible then
        self.pendingMonthly = {
            data = data,
            callback = callback,
            target = target
        }

        Logging.info(
            "FFR Modal Overlay: Monthly cost summary queued behind open window"
        )

        return true
    end

    if not self:ensureOverlay() then
        return false
    end

    self.mode = "MONTHLY"
    self.data = data
    self.callback = callback
    self.target = target
    self.visible = true
    self:captureInput()

    Logging.info(
        "FFR Modal Overlay: Monthly cost summary opened"
    )

    return true
end

--------------------------------------------------
-- Show Household Configuration
--------------------------------------------------

function FFR_ModalOverlay:showHousehold(manager, callback, target)
    if self.visible then return false end
    if not self:ensureOverlay() then return false end
    self.mode = "HOUSEHOLD"
    self.data = manager
    self.callback = callback
    self.target = target
    self.householdSelectedIndex = 1
    self.visible = true
    self:captureInput()
    Logging.info("FFR Modal Overlay: Household configuration opened")
    return true
end

--------------------------------------------------
-- Close Modal
--------------------------------------------------

function FFR_ModalOverlay:close()
    self.visible = false
    self.overMenu = false
    self.mode = nil
    self.data = nil
    self.callback = nil
    self.target = nil

    self:releaseInput()

    if self.pendingMonthly ~= nil then
        local pending = self.pendingMonthly

        self.pendingMonthly = nil

        self:showMonthly(
            pending.data,
            pending.callback,
            pending.target
        )
    end
end

--------------------------------------------------
-- Land Selection
--------------------------------------------------

function FFR_ModalOverlay:chooseLand(
    useCode,
    agriculturalPercent
)
    local callback = self.callback

    self:close()

    if callback ~= nil then
        callback(
            useCode,
            agriculturalPercent
        )
    end
end

--------------------------------------------------
-- Monthly Acknowledgement
--------------------------------------------------

function FFR_ModalOverlay:acknowledgeMonthly()
    local callback = self.callback
    local target = self.target

    self:close()

    if callback ~= nil then
        callback(target)
    end
end

--------------------------------------------------
-- Draw Rectangle
--------------------------------------------------

function FFR_ModalOverlay:rect(
    x,
    y,
    width,
    height,
    red,
    green,
    blue,
    alpha
)
    if self.whiteOverlay == nil then
        return
    end

    self.whiteOverlay:setPosition(
        x,
        y
    )

    self.whiteOverlay:setDimension(
        width,
        height
    )

    self.whiteOverlay:setColor(
        red,
        green,
        blue,
        alpha
    )

    self.whiteOverlay:render()
end

--------------------------------------------------
-- Draw Text
--------------------------------------------------

function FFR_ModalOverlay:text(
    x,
    y,
    size,
    value,
    red,
    green,
    blue,
    alignment,
    bold
)
    setTextColor(
        red or 1,
        green or 1,
        blue or 1,
        1
    )

    setTextBold(
        bold == true
    )

    if alignment == "right" then
        setTextAlignment(
            RenderText.ALIGN_RIGHT
        )
    elseif alignment == "center" then
        setTextAlignment(
            RenderText.ALIGN_CENTER
        )
    else
        setTextAlignment(
            RenderText.ALIGN_LEFT
        )
    end

    renderText(
        x,
        y,
        size,
        tostring(value or "")
    )

    setTextBold(false)

    setTextAlignment(
        RenderText.ALIGN_LEFT
    )
end

--------------------------------------------------
-- Draw Selection Button
--------------------------------------------------

function FFR_ModalOverlay:button(
    x,
    y,
    width,
    height,
    number,
    title,
    subtitle,
    hovered
)
    local shade = hovered and 0.030 or 0

    self:rect(
        x,
        y,
        width,
        height,
        0.035 + shade,
        0.043 + shade * 1.4,
        0.039 + shade,
        1
    )

    self:rect(
        x,
        y,
        0.035,
        height,
        0.48,
        0.78,
        0.02,
        1
    )

    self:text(
        x + 0.0175,
        y + height * 0.43,
        0.018,
        tostring(number),
        0.02,
        0.03,
        0.02,
        "center",
        true
    )

    self:text(
        x + 0.052,
        y + height * 0.58,
        0.017,
        title,
        0.95,
        0.96,
        0.95,
        "left",
        true
    )

    self:text(
        x + 0.052,
        y + height * 0.25,
        0.0125,
        subtitle,
        0.70,
        0.73,
        0.71,
        "left",
        false
    )
end

--------------------------------------------------
-- Draw Land Titles Office
--------------------------------------------------

function FFR_ModalOverlay:drawLand()
    local parcel = self.data or {}
    local manager = self.target

    self:rect(
        0,
        0,
        1,
        1,
        0,
        0,
        0,
        0.78
    )

    self:rect(
        0.12,
        0.08,
        0.76,
        0.84,
        0.018,
        0.023,
        0.020,
        1
    )

    self:rect(
        0.12,
        0.84,
        0.76,
        0.08,
        0.028,
        0.034,
        0.031,
        1
    )

    self:rect(
        0.15,
        0.825,
        0.70,
        0.003,
        0.48,
        0.78,
        0.02,
        1
    )

    self:text(
        0.15,
        0.868,
        0.026,
        FFR_L10n.t(parcel.isChange and "ffr_modal_land_change_title" or "ffr_modal_land_title"),
        0.92,
        0.93,
        0.92,
        "left",
        true
    )

    self:text(
        0.85,
        0.870,
        0.020,
        FFR_L10n.upper(FFR_L10n.t("ffr_common_farmland", parcel.farmlandId or 0)),
        0.48,
        0.78,
        0.02,
        "right",
        true
    )

    self:text(
        0.15,
        0.785,
        0.017,
        parcel.isChange and FFR_L10n.t("ffr_modal_land_change_current", tostring(parcel.currentUse or ""))
            or FFR_L10n.t("ffr_modal_land_declare"),
        1,
        1,
        1,
        "left",
        true
    )

    self:text(
        0.15,
        0.755,
        0.0125,
        FFR_L10n.t("ffr_modal_land_effect"),
        0.72,
        0.75,
        0.72,
        "left",
        false
    )

    local bookValue = FFR_L10n.formatMoney(0)

    if manager ~= nil
        and manager.formatMoney ~= nil
    then
        bookValue = manager:formatMoney(
            parcel.bookValue
        )
    end

    self:text(
        0.85,
        0.785,
        0.014,
        bookValue,
        1,
        1,
        1,
        "right",
        true
    )

    self:text(
        0.85,
        0.755,
        0.0125,
        FFR_L10n.formatArea(
            parcel.areaInHa,
            2
        ),
        0.72,
        0.75,
        0.72,
        "right",
        false
    )

    -- More titles bought at the same time wait behind this one.
    local waiting = manager ~= nil and manager.queue ~= nil and #manager.queue or 0
    if waiting > 0 then
        self:text(
            0.85,
            0.848,
            0.012,
            waiting == 1 and FFR_L10n.t("ffr_modal_land_waiting_one")
                or FFR_L10n.t("ffr_modal_land_waiting_many", waiting),
            0.95,
            0.79,
            0.32,
            "right",
            true
        )
    end

    local hovered = self:getLandOptionAt(self.mouseX, self.mouseY)
    local B = FFR_ModalOverlay.LAND_BUTTON

    for i, option in ipairs(FFR_ModalOverlay.LAND_OPTIONS) do
        self:button(
            B[1],
            option[1],
            B[2],
            B[3],
            i,
            FFR_L10n.t("ffr_modal_land_use" .. i),
            FFR_L10n.t("ffr_modal_land_use" .. i .. "_desc"),
            i == hovered
        )
    end

    self:text(
        0.50,
        0.165,
        0.015,
        FFR_L10n.t("ffr_modal_land_hint"),
        0.48,
        0.78,
        0.02,
        "center",
        true
    )

    if parcel.isChange then
        local b = FFR_ModalOverlay.LAND_KEEP_BUTTON
        local C = FFR_ModalOverlay.COLORS
        local lit = self:isOnKeepButton(self.mouseX, self.mouseY)
        self:fill(b[1], b[2], b[3], b[4], C.border)
        self:fill(b[1] + 0.001, b[2] + 0.002, b[3] - 0.002, b[4] - 0.004, lit and C.pill or C.card)
        self:say(b[1] + b[3] / 2, b[2] + 0.010, 0.014, FFR_L10n.t("ffr_modal_land_keep"), C.white, "center", true)
    end
end

-- The five declarations: button y, use code, agricultural percent (keys 1-5).
FFR_ModalOverlay.LAND_OPTIONS = {
    {0.625, "AGRICULTURAL", 100},
    {0.525, "FARMSTEAD", 0},
    {0.425, "COMBINED", 75},
    {0.325, "COMBINED", 50},
    {0.225, "ACCESS", 0}
}

-- Option buttons: x, width, height (also the mouse hit area).
FFR_ModalOverlay.LAND_BUTTON = {0.15, 0.70, 0.075}

-- Clicks this soon after the window appears belong to whatever was clicked before.
FFR_ModalOverlay.LAND_CLICK_GUARD_MS = 400

function FFR_ModalOverlay:getLandOptionAt(x, y)
    if x == nil or y == nil then return nil end
    local B = FFR_ModalOverlay.LAND_BUTTON
    if x < B[1] or x > B[1] + B[2] then return nil end
    for i, option in ipairs(FFR_ModalOverlay.LAND_OPTIONS) do
        if y >= option[1] and y <= option[1] + B[3] then return i end
    end
    return nil
end

function FFR_ModalOverlay:chooseLandOption(index)
    local option = FFR_ModalOverlay.LAND_OPTIONS[index]
    if option ~= nil then self:chooseLand(option[2], option[3]) end
end

-- KEEP CURRENT TITLE (change window only): x, y, width, height.
FFR_ModalOverlay.LAND_KEEP_BUTTON = {0.39, 0.100, 0.22, 0.032}

function FFR_ModalOverlay:isOnKeepButton(x, y)
    local b = FFR_ModalOverlay.LAND_KEEP_BUTTON
    local parcel = self.data or {}
    return parcel.isChange == true and x ~= nil and y ~= nil
        and x >= b[1] and x <= b[1] + b[3] and y >= b[2] and y <= b[2] + b[4]
end

function FFR_ModalOverlay:keepLand()
    local manager = self.target
    self:close()
    if manager ~= nil and manager.cancelChange ~= nil then manager:cancelChange() end
end

-- True while an FS25 screen or dialog (pause menu, shop, message) is open.
function FFR_ModalOverlay.isGameGuiOpen()
    if g_gui == nil then return false end
    if g_gui.getIsGuiVisible ~= nil then
        local ok, visible = pcall(g_gui.getIsGuiVisible, g_gui)
        if ok then return visible == true end
    end
    return g_gui.currentGui ~= nil
end

-- A land title waits (not drawn, no input) while a game menu is on top of it,
-- so clicks meant for the menu never pick a title; it stays open until chosen.
function FFR_ModalOverlay:isSuspended()
    return self.visible and self.mode == "LAND" and not self.guiCountsSelf and FFR_ModalOverlay.isGameGuiOpen()
end

--------------------------------------------------
-- Format Monthly Money
--------------------------------------------------

function FFR_ModalOverlay:money(value)
    local data = self.data or {}

    if data.formatMoney ~= nil then
        return data.formatMoney(value)
    end

    return FFR_L10n.formatMoney(value)
end

--------------------------------------------------
-- Draw Monthly Cost Row
--------------------------------------------------

function FFR_ModalOverlay:costRow(
    x,
    y,
    label,
    value
)
    self:text(
        x,
        y,
        0.014,
        label,
        0.88,
        0.90,
        0.88,
        "left",
        false
    )

    self:text(
        x + 0.27,
        y,
        0.014,
        self:money(value),
        1,
        1,
        1,
        "right",
        true
    )
end

--------------------------------------------------
-- Draw Monthly Cost Summary
--------------------------------------------------

function FFR_ModalOverlay:drawMonthly()
    local data = self.data or {}
    local costs = data.costs or {}
    local C = FFR_ModalOverlay.COLORS

    -- Dim the game, then the window frame (dashboard surface with a card border).
    self:rect(0, 0, 1, 1, 0, 0, 0, 0.72)
    self:fill(0.198, 0.118, 0.604, 0.764, C.border)
    self:fill(0.200, 0.120, 0.600, 0.760, C.surface)

    -- Header band: title, the month the bills are for, and a lime rule.
    self:fill(0.200, 0.800, 0.600, 0.080, C.header)
    self:fill(0.200, 0.800, 0.600, 0.003, C.lime)
    self:say(0.220, 0.846, 0.026, FFR_L10n.t("ffr_modal_month_title"), C.heading, "left", true)
    self:say(0.220, 0.818, 0.013, FFR_L10n.t("ffr_modal_month_desc"), C.white, "left", false)
    self:say(0.780, 0.842, 0.018, FFR_L10n.upper(self:getClosedMonthText(data)), C.gold, "right", true)

    -- Last month at a glance (from the Farm Status statement).
    local tiles = {
        {FFR_L10n.t("ffr_modal_month_revenue"), data.revenue, C.green},
        {FFR_L10n.t("ffr_modal_month_operating"), data.operating, C.white},
        {FFR_L10n.t("ffr_modal_month_net"), data.net, (tonumber(data.net) or 0) >= 0 and C.green or C.red}
    }
    for i, tile in ipairs(tiles) do
        local x = 0.220 + (i - 1) * 0.1885
        self:card(x, 0.705, 0.183, 0.075)
        self:say(x + 0.012, 0.753, 0.012, tile[1], C.grey, "left", true)
        self:say(x + 0.012, 0.717, 0.022, tile[2] ~= nil and self:money(tile[2]) or "-", tile[3], "left", true)
    end

    -- Bills: household and farm overhead side by side.
    local L = FFR_L10n.t
    self:costCard(0.220, L("ffr_modal_month_household"), costs.household, {
        {L("ffr_house_housing"), costs.mortgage}, {L("ffr_house_utilities"), costs.utilities}, {L("ffr_house_food"), costs.food},
        {L("ffr_house_vehicles"), costs.personalVehicle}, {L("ffr_house_health"), costs.health}, {L("ffr_house_recreation"), costs.recreation},
        {L("ffr_house_sports"), costs.sports}, {L("ffr_house_tuition"), costs.tuition}
    })
    local overhead = (tonumber(data.monthlyTotal) or 0) - (tonumber(costs.household) or 0)
    self:costCard(0.504, L("ffr_modal_month_overhead"), overhead, {
        {L("ffr_modal_month_insurance"), costs.insurance}, {L("ffr_modal_month_interest"), costs.interest}, {L("ffr_modal_month_principal"), costs.landPayment},
        {L("ffr_modal_month_equipment"), costs.equipmentPayment}, {L("ffr_modal_month_leases"), costs.lease},
        {L("ffr_modal_month_rent"), costs.rent},
        {L("ffr_modal_month_maintenance"), costs.maintenance}, {L("ffr_modal_month_tax"), costs.tax}
    })

    -- Totals.
    self:card(0.220, 0.215, 0.560, 0.100)
    self:say(0.235, 0.282, 0.016, L("ffr_modal_month_total"), C.white, "left", true)
    self:say(0.765, 0.279, 0.022, self:money(data.monthlyTotal), C.gold, "right", true)
    if (tonumber(data.annualTax) or 0) > 0 then
        self:say(0.235, 0.254, 0.013, L("ffr_modal_month_annual_tax"), C.grey, "left", false)
        self:say(0.765, 0.254, 0.014, self:money(data.annualTax), C.gold, "right", true)
    end
    local cash = tonumber(data.cashAfter) or 0
    self:say(0.235, 0.227, 0.016, L("ffr_modal_month_cash"), C.white, "left", true)
    self:say(0.765, 0.225, 0.022, self:money(cash), cash >= 0 and C.green or C.red, "right", true)

    -- The bank's insolvency message, as a red alert bar.
    if data.bankNotice ~= nil and data.bankNotice ~= "" then
        self:fill(0.220, 0.168, 0.560, 0.034, C.dangerBorder)
        self:fill(0.2215, 0.1695, 0.557, 0.031, C.dangerFill)
        self:say(0.500, 0.178, 0.014, data.bankNotice, C.red, "center", true)
    end

    -- Footer: key hint on the left, primary button on the right.
    self:fill(0.200, 0.120, 0.600, 0.040, C.footer)
    self:fill(0.220, 0.128, 0.050, 0.024, C.pill)
    self:say(0.245, 0.134, 0.012, L("ffr_modal_key_enter"), C.lime, "center", true)
    self:say(0.278, 0.134, 0.012, L("ffr_modal_continue"), C.white, "left", false)
    local b = FFR_ModalOverlay.MONTHLY_BUTTON
    self:fill(b[1], b[2], b[3], b[4], C.lime)
    self:say(b[1] + b[3] / 2, b[2] + 0.008, 0.015, L("ffr_modal_continue"), C.dark, "center", true)
end

--------------------------------------------------
-- Monthly window helpers (dashboard styling)
--------------------------------------------------

-- The dashboard's colours (FFR_DashboardFrame.FILLS and the layout script).
FFR_ModalOverlay.COLORS = {
    surface = {0.020, 0.024, 0.022, 0.97},
    header = {0.024, 0.029, 0.026, 1},
    border = {0.17, 0.20, 0.18, 1},
    card = {0.038, 0.044, 0.041, 1},
    divider = {0.20, 0.23, 0.21, 1},
    footer = {0.012, 0.015, 0.013, 1},
    pill = {0.090, 0.120, 0.075, 1},
    dangerBorder = {0.62, 0.16, 0.12, 1},
    dangerFill = {0.16, 0.045, 0.035, 1},
    lime = {0.54, 0.86, 0.18, 1},
    heading = {0.62, 0.92, 0.45, 1},
    gold = {0.95, 0.79, 0.32, 1},
    white = {0.92, 0.93, 0.92, 1},
    grey = {0.62, 0.66, 0.64, 1},
    green = {0.40, 0.95, 0.52, 1},
    red = {0.95, 0.36, 0.30, 1},
    dark = {0.02, 0.03, 0.02, 1}
}

-- CONTINUE button: x, y, width, height (also the mouse hit area).
FFR_ModalOverlay.MONTHLY_BUTTON = {0.640, 0.126, 0.140, 0.028}


function FFR_ModalOverlay:fill(x, y, width, height, color)
    self:rect(x, y, width, height, color[1], color[2], color[3], color[4] or 1)
end

function FFR_ModalOverlay:say(x, y, size, value, color, alignment, bold)
    self:text(x, y, size, value, color[1], color[2], color[3], alignment, bold)
end

-- Bordered card, as on the dashboard.
function FFR_ModalOverlay:card(x, y, width, height)
    self:fill(x, y, width, height, FFR_ModalOverlay.COLORS.border)
    self:fill(x + 0.0012, y + 0.002, width - 0.0024, height - 0.004, FFR_ModalOverlay.COLORS.card)
end

-- The bills are charged on day 1 for the month that just ended.
function FFR_ModalOverlay:getClosedMonthText(data)
    local period, year = tonumber(data.period), tonumber(data.year)
    if period == nil or year == nil then return "" end
    period = period - 1
    if period < 1 then period, year = 12, year - 1 end
    return FFR_L10n.date(period, year)
end

-- A card of cost lines with a subtotal at the bottom.
function FFR_ModalOverlay:costCard(x, title, subtotal, lines)
    local C = FFR_ModalOverlay.COLORS
    local width = 0.276
    self:card(x, 0.330, width, 0.360)
    self:say(x + 0.015, 0.657, 0.016, title, C.heading, "left", true)
    local y = 0.615
    for _, line in ipairs(lines) do
        local value = tonumber(line[2]) or 0
        self:say(x + 0.015, y, 0.014, line[1], C.white, "left", false)
        self:say(x + width - 0.015, y, 0.014, self:money(value), value > 0 and C.white or C.grey, "right", value > 0)
        -- 8 household lines must fit above the divider at 0.392.
        y = y - 0.030
    end
    self:fill(x + 0.015, 0.392, width - 0.030, 0.0015, C.divider)
    self:say(x + 0.015, 0.352, 0.014, FFR_L10n.t("ffr_modal_subtotal"), C.gold, "left", true)
    self:say(x + width - 0.015, 0.350, 0.018, self:money(subtotal), C.gold, "right", true)
end

--------------------------------------------------
-- Draw Household Configuration
--------------------------------------------------

function FFR_ModalOverlay:drawHousehold()
    local h = self.data
    if h == nil then return end
    self:rect(0,0,1,1,0,0,0,0.78)
    self:rect(0.13,0.08,0.74,0.84,0.018,0.023,0.020,1)
    self:rect(0.13,0.84,0.74,0.08,0.028,0.034,0.031,1)
    self:rect(0.16,0.825,0.68,0.003,0.48,0.78,0.02,1)
    local L = FFR_L10n.t
    self:text(0.16,0.868,0.026,L("ffr_modal_house_title"),0.92,0.93,0.92,"left",true)
    self:text(0.84,0.870,0.018,L("ffr_modal_house_per_month", self:money(h.totalMonthlyCost)),0.48,0.78,0.02,"right",true)
    self:text(0.16,0.785,0.017,L("ffr_modal_house_profile"),0.48,0.78,0.02,"left",true)
    self:text(0.54,0.785,0.017,L("ffr_modal_house_budget"),0.48,0.78,0.02,"left",true)
    local settings={
        {L("ffr_house_adults"),h.adults},{L("ffr_house_children"),h.children},{L("ffr_house_students"),h.universityStudents},
        {L("ffr_house_vehicles"),h.personalVehicles},{L("ffr_house_housing_level"),FFR_FamilyManager.getLevelName(h.housingLevel)},
        {L("ffr_house_activities"),FFR_FamilyManager.getLevelName(h.activityLevel)}
    }
    local values={
        {L("ffr_house_housing"),h.mortgageCost},{L("ffr_house_utilities"),h.utilityCost},{L("ffr_house_food"),h.foodCost},{L("ffr_house_vehicles"),h.vehicleCost},
        {L("ffr_house_health"),h.healthCost},{L("ffr_house_recreation"),h.recreationCost},{L("ffr_house_sports"),h.sportsCost},{L("ffr_house_tuition"),h.tuitionCost}
    }
    for i,row in ipairs(settings) do
        local y=0.730-(i-1)*0.075
        if i==self.householdSelectedIndex then self:rect(0.155,y-0.014,0.335,0.052,0.10,0.15,0.11,1) end
        self:text(0.17,y,0.015,row[1],0.88,0.90,0.88,"left",i==self.householdSelectedIndex)
        self:text(0.475,y,0.016,tostring(row[2]),1,1,1,"right",true)
    end
    for i,row in ipairs(values) do
        local y=0.730-(i-1)*0.053
        self:text(0.54,y,0.014,row[1],0.82,0.84,0.82,"left",false)
        self:text(0.83,y,0.014,self:money(row[2]),1,1,1,"right",true)
    end
    self:rect(0.54,0.282,0.29,0.002,0.48,0.78,0.02,1)
    self:text(0.54,0.245,0.017,L("ffr_modal_house_total"),1,1,1,"left",true)
    self:text(0.83,0.245,0.019,self:money(h.totalMonthlyCost),0.48,0.78,0.02,"right",true)
    self:text(0.16,0.205,0.014,L("ffr_modal_house_last_event"),0.70,0.73,0.71,"left",true)
    self:text(0.16,0.172,0.014,FFR_FamilyManager.getEventName(h.lastEvent),1,1,1,"left",false)
    self:text(0.49,0.172,0.014,self:money(h.lastEventCost),1,1,1,"right",true)
    self:text(0.16,0.120,0.013,L("ffr_modal_house_hint"),0.48,0.78,0.02,"left",true)
end

--------------------------------------------------
-- Draw
--------------------------------------------------

function FFR_ModalOverlay:draw()
    if not self.visible then
        return
    end

    if not self:ensureOverlay() then
        return
    end

    if self:isSuspended() then
        return
    end

    -- Over the pause menu the FFR page draws this window (drawOverMenu), above the menu.
    if self.overMenu and FFR_ModalOverlay.isGameGuiOpen() then
        return
    end

    if self.mode == "LAND" then
        self:drawLand()
    elseif self.mode == "MONTHLY" then
        self:drawMonthly()
    elseif self.mode == "HOUSEHOLD" then
        self:drawHousehold()
    end
end

-- Called from FFR_DashboardFrame:draw after the page, so the window is on top.
function FFR_ModalOverlay:drawOverMenu()
    if not self.visible or not self.overMenu or self.mode ~= "LAND" then return end
    if not self:ensureOverlay() then return end
    self:drawLand()
end

-- The FFR page passes input on to this window, and the mod listener may get the
-- same event: handle each one once.
function FFR_ModalOverlay:isRepeatInput(...)
    local parts = {tostring(g_time or 0)}
    for i = 1, select("#", ...) do parts[#parts + 1] = tostring(select(i, ...)) end
    local signature = table.concat(parts, "|")
    if signature == self.lastInput then return true end
    self.lastInput = signature
    return false
end

--------------------------------------------------
-- Keyboard Input
--------------------------------------------------

function FFR_ModalOverlay:keyEvent(
    unicode,
    sym,
    modifier,
    isDown
)
    if not self.visible
        or not isDown
        or Input == nil
        or self:isSuspended()
        or self:isRepeatInput("key", sym, isDown)
    then
        return
    end

    if self.mode == "LAND" then
        if (self.data or {}).isChange and Input.KEY_backspace ~= nil and sym == Input.KEY_backspace then
            self:keepLand()
            return
        end
        local keys = {Input.KEY_1, Input.KEY_2, Input.KEY_3, Input.KEY_4, Input.KEY_5}
        for i, key in ipairs(keys) do
            if sym == key then
                self:chooseLandOption(i)
                break
            end
        end

        return
    end

    if self.mode == "HOUSEHOLD" then
        local h = self.data
        if h == nil then return end
        if sym == Input.KEY_up then self.householdSelectedIndex = math.max(1, self.householdSelectedIndex - 1)
        elseif sym == Input.KEY_down then self.householdSelectedIndex = math.min(6, self.householdSelectedIndex + 1)
        elseif sym == Input.KEY_left or sym == Input.KEY_right then
            local names={"ADULTS","CHILDREN","STUDENTS","VEHICLES","HOUSING","ACTIVITIES"}
            h:changeSetting(names[self.householdSelectedIndex], sym == Input.KEY_right and 1 or -1)
        elseif sym == Input.KEY_r then h:resetDefault()
        elseif sym == Input.KEY_return or (Input.KEY_enter ~= nil and sym == Input.KEY_enter) then
            h:markDirty()
            local callback,target=self.callback,self.target
            self:close()
            if callback ~= nil then callback(target) end
        end
        return
    end

    if self.mode == "MONTHLY" then
        local enterPressed =
            sym == Input.KEY_return

        if Input.KEY_enter ~= nil then
            enterPressed =
                enterPressed
                or sym == Input.KEY_enter
        end

        enterPressed =
            enterPressed
            or sym == Input.KEY_space

        if enterPressed then
            self:acknowledgeMonthly()
        end
    end
end

--------------------------------------------------
-- Mouse Input
--------------------------------------------------

function FFR_ModalOverlay:mouseEvent(
    x,
    y,
    isDown,
    isUp,
    button
)
    self.mouseX, self.mouseY = x, y

    if not self.visible
        or self:isSuspended()
        or self:isRepeatInput("mouse", x, y, isDown, isUp, button)
    then
        return
    end

    if self.mode == "LAND" then
        -- Press and release must both land on the same option, after the
        -- click guard, so a click left over from buying the land is ignored.
        local left = Input == nil or Input.MOUSE_BUTTON_LEFT == nil or button == Input.MOUSE_BUTTON_LEFT
        local ready = (g_time or 0) - (self.openedAt or 0) >= FFR_ModalOverlay.LAND_CLICK_GUARD_MS
        local function hit(px, py)
            if self:isOnKeepButton(px, py) then return "KEEP" end
            return self:getLandOptionAt(px, py)
        end
        if isDown and left then
            self.pressedOption = ready and hit(x, y) or nil
        elseif isUp and left then
            local option = hit(x, y)
            local pressed = self.pressedOption
            self.pressedOption = nil
            if option ~= nil and option == pressed then
                if option == "KEEP" then self:keepLand() else self:chooseLandOption(option) end
            end
        end

        return
    end

    if not isUp then
        return
    end

    local b = FFR_ModalOverlay.MONTHLY_BUTTON

    if self.mode == "MONTHLY"
        and x >= b[1]
        and x <= b[1] + b[3]
        and y >= b[2]
        and y <= b[2] + b[4]
    then
        self:acknowledgeMonthly()
    end
end

--------------------------------------------------
-- Listener Lifecycle
--------------------------------------------------

function FFR_ModalOverlay:update(
    dt
)
    -- Back from a menu that covered a land title: show the cursor again and
    -- re-arm the click guard.
    local suspended = self:isSuspended()
    if self.wasSuspended and not suspended and self.visible then
        self.openedAt = g_time or 0
        self.pressedOption = nil
        if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
            g_inputBinding:setShowMouseCursor(true, true)
        end
    end
    self.wasSuspended = suspended
    -- A change window opened over the menu: if the menu closes first, take the
    -- game's input so the window can still be answered.
    if self.visible and self.overMenu and not self.ownsMenuContext and not FFR_ModalOverlay.isGameGuiOpen() then
        self:captureInput()
    end
end

function FFR_ModalOverlay:loadMap(
    mapName
)
    self.visible = false
    self.mode = nil
    self.data = nil
    self.callback = nil
    self.target = nil
    self.ownsMenuContext = false
    self.pendingMonthly = nil
end

function FFR_ModalOverlay:deleteMap()
    self.pendingMonthly = nil
    self:releaseInput()

    if self.whiteOverlay ~= nil then
        if self.whiteOverlay.delete ~= nil then
            self.whiteOverlay:delete()
        elseif self.whiteOverlay.overlayId ~= nil
            and self.whiteOverlay.overlayId ~= 0
        then
            delete(
                self.whiteOverlay.overlayId
            )
        end

        self.whiteOverlay = nil
    end

    self.visible = false
    self.mode = nil
    self.data = nil
    self.callback = nil
    self.target = nil
end

--------------------------------------------------
-- Install
--------------------------------------------------

g_FFRModalOverlay =
    FFR_ModalOverlay:new()

addModEventListener(
    g_FFRModalOverlay
)

Logging.info(
    "FFR Modal Overlay: Standard FS25 overlay system installed"
)
