FFR_MonthlyFinancialProcessor = {}
local FFR_MOD_DIR = g_currentModDirectory

--------------------------------------------------
-- Monthly financial processing
--
-- Once per game month (day 1, 10:00) the server
-- charges every farm its own overhead from its own
-- financial profile (g_FFR:getFarmState), settles
-- forward contracts, and at a year change charges
-- annual taxes and closes each farm's books.
--------------------------------------------------

function FFR_MonthlyFinancialProcessor:new()
    local self = {}
    setmetatable(self, {__index = FFR_MonthlyFinancialProcessor})
    self.updateTimer = 0
    self.updateInterval = 1000
    self.initialized = false
    self.lastPeriod = 0
    self.lastYear = 0
    self.processedSerial = nil
    self.pendingSerial = nil
    self.pendingPeriod = 0
    self.pendingYear = 0
    self.pendingPreviousYear = 0
    self.targetHour = 10
    self.monthsProcessed = 0
    self.totalExpensesProcessed = 0
    return self
end

function FFR_MonthlyFinancialProcessor:getCalendar()
    if g_currentMission == nil or g_currentMission.environment == nil then return nil, nil end
    local e = g_currentMission.environment
    local period = tonumber(e.currentPeriod)
    local year = tonumber(e.currentYear)
    if period == nil or period < 1 or period > 12 or year == nil or year < 1 then return nil, nil end
    return period, year
end

function FFR_MonthlyFinancialProcessor:getDayAndTime()
    if g_currentMission == nil or g_currentMission.environment == nil then return nil, nil, nil end
    local e = g_currentMission.environment
    local day = tonumber(e.currentDayInPeriod or e.currentDay or 1) or 1
    local hour = tonumber(e.currentHour)
    local minute = tonumber(e.currentMinute)
    if hour == nil and e.dayTime ~= nil then
        local totalMinutes = math.floor((tonumber(e.dayTime) or 0) / 60000)
        hour = math.floor(totalMinutes / 60) % 24
        minute = totalMinutes % 60
    end
    return day, hour or 0, minute or 0
end

function FFR_MonthlyFinancialProcessor:formatMoney(value)
    return FFR_L10n.formatMoney(value)
end

-- statement: {revenue, operating, net} of the month that just ended (optional).
function FFR_MonthlyFinancialProcessor:showCostSummary(period, year, costs, monthlyTotal, annualTax, cashAfter, bankNotice, statement)
    if g_FFRModalOverlay == nil then
        Logging.error("FFR Monthly Processing: Modal overlay unavailable")
        return false
    end
    statement = statement or {}
    return g_FFRModalOverlay:showMonthly({
        period = period, year = year, costs = costs, monthlyTotal = monthlyTotal,
        annualTax = annualTax, cashAfter = cashAfter, bankNotice = bankNotice,
        revenue = statement.revenue, operating = statement.operating, net = statement.net,
        formatMoney = function(value) return self:formatMoney(value) end
    }, function() Logging.info("FFR Monthly Processing: Cost summary acknowledged") end, self)
end

-- The local player's farm (the default farm on a dedicated server).
function FFR_MonthlyFinancialProcessor:getFarmId()
    if g_FFR == nil then return nil end
    if g_FFR.getLocalFarmId ~= nil then return g_FFR:getLocalFarmId() end
    if g_FFR.gameIntegrationManager == nil then return nil end
    return g_FFR.gameIntegrationManager:getActiveFarmId()
end

function FFR_MonthlyFinancialProcessor:getFarm(farmIdOverride)
    if g_farmManager == nil then return nil end
    local id = farmIdOverride or self:getFarmId()
    return id ~= nil and g_farmManager:getFarmById(id) or nil
end

-- Kept for the dashboard: farm profiles now hold every manager, so this only
-- confirms the local farm's profile exists.
function FFR_MonthlyFinancialProcessor:ensureManagers()
    if g_FFR == nil then return false end
    if g_FFR.updateLocalFarm ~= nil then g_FFR:updateLocalFarm() end
    return g_FFR.financialManager ~= nil and g_FFR.creditManager ~= nil
end

function FFR_MonthlyFinancialProcessor:getExpenseBreakdown(state)
    local f = state.financialManager
    local family = state.familyManager
    local interest = state.bankingManager:calculateMonthlyInterest(f, state.creditManager) or 0
    state.insuranceManager:updatePremiums(f)
    local insurance = (tonumber(state.insuranceManager.totalPremium) or 0) / 12
    -- Crop insurance: insured crops planted since the last bill (per planted acre).
    local cropBills = FFR_CropInsuranceManager ~= nil and FFR_CropInsuranceManager.getUnbilled(state) or {}
    for _, bill in ipairs(cropBills) do insurance = insurance + bill.premium end
    family:updateMonthlyCost()
    local household = tonumber(family.totalMonthlyCost) or 0
    return {
        interest = math.max(0, interest), insurance = math.max(0, insurance), household = math.max(0, household),
        cropBills = cropBills,
        mortgage = math.max(0, tonumber(family.mortgageCost) or 0),
        utilities = math.max(0, tonumber(family.utilityCost) or 0),
        food = math.max(0, tonumber(family.foodCost) or 0),
        personalVehicle = math.max(0, tonumber(family.vehicleCost) or 0),
        health = math.max(0, tonumber(family.healthCost) or 0),
        recreation = math.max(0, tonumber(family.recreationCost) or 0),
        sports = math.max(0, tonumber(family.sportsCost) or 0),
        tuition = math.max(0, tonumber(family.tuitionCost) or 0),
        -- FS25's building upkeep, held back daily by FFR_BuildingSyncManager.
        maintenance = math.max(0, tonumber(state.propertyMaintenanceDue) or 0),
        -- Never charge more principal than is still owed.
        landPayment = math.max(0, math.min(tonumber(f.monthlyLandPayment) or 0, tonumber(f.landDebt) or 0)),
        equipmentPayment = math.max(0, tonumber(f.monthlyEquipmentPayment) or 0),
        lease = math.max(0, tonumber(f.monthlyLeaseCost) or 0),
        -- Cash rent for rented-in land (FFR_LandRentManager), fixed per contract.
        rent = FFR_LandRentManager ~= nil and math.max(0, FFR_LandRentManager.getMonthlyRentDue(state)) or 0,
        tax = math.max(0, tonumber(f.monthlyTaxCost) or 0)
    }
end

-- Copies the farm's real balance into its financial profile.
function FFR_MonthlyFinancialProcessor:refreshCash(farmId)
    if g_FFR == nil or g_FFR.getFarmState == nil then return end
    local state = g_FFR:getFarmState(farmId)
    local farm = self:getFarm(farmId)
    if state == nil or farm == nil then return end
    local f = state.financialManager
    if farm.getBalance ~= nil then
        f.cashOnHand = tonumber(farm:getBalance()) or f.cashOnHand
    elseif farm.money ~= nil then
        f.cashOnHand = tonumber(farm.money) or f.cashOnHand
    end
end

-- Changes a farm's real money (server only). Without a farm id, the local farm.
function FFR_MonthlyFinancialProcessor:applyFarmBalance(amount, moneyTypeOverride, farmIdOverride)
    if g_currentMission ~= nil and g_currentMission.getIsServer ~= nil and not g_currentMission:getIsServer() then
        Logging.warning("FFR Monthly Processing: Farm balance can only change on the server")
        return false
    end
    local farmId = farmIdOverride or self:getFarmId()
    -- addMoney updates the finance statistics page and the HUD money change;
    -- Farm:changeBalance alone does neither. Keep it as a fallback only.
    if farmId ~= nil and g_currentMission ~= nil and g_currentMission.addMoney ~= nil then
        local moneyType = moneyTypeOverride or (MoneyType ~= nil and MoneyType.OTHER or nil)
        if FFR_RevenueTracker ~= nil then FFR_RevenueTracker.isApplyingFFRCharge = true end
        local ok, err = pcall(g_currentMission.addMoney, g_currentMission, amount, farmId, moneyType, true, true)
        if FFR_RevenueTracker ~= nil then FFR_RevenueTracker.isApplyingFFRCharge = false end
        if ok then
            self:refreshCash(farmId)
            return true
        end
        Logging.warning("FFR Monthly Processing: addMoney failed (%s); trying Farm:changeBalance", tostring(err))
    end
    local farm = self:getFarm(farmId)
    if farm == nil or farm.changeBalance == nil then
        Logging.error("FFR Monthly Processing: Farm balance API unavailable")
        return false
    end
    farm:changeBalance(amount, moneyTypeOverride or (MoneyType ~= nil and MoneyType.OTHER or nil))
    self:refreshCash(farmId)
    return true
end

function FFR_MonthlyFinancialProcessor:processAnnualTaxes(state, completedYear)
    local t, f = state.taxManager, state.financialManager
    f:updateAnnualProfit()
    t:updateAnnualTax(f, math.max(0, tonumber(f.annualProfit) or 0))
    local amount = math.max(0, tonumber(t.totalTaxesDue) or 0)
    if amount > 0 and self:applyFarmBalance(-amount, nil, state.farmId) then
        t.totalTaxesPaid = (tonumber(t.totalTaxesPaid) or 0) + amount
        t.totalTaxesDue = 0
        f.annualExpenses = (tonumber(f.annualExpenses) or 0) + amount
        f:updateAnnualProfit()
        Logging.info("FFR Annual Taxes: Farm %d, year %d charged $%d", state.farmId, completedYear, math.floor(amount))
        return amount
    end
    return 0
end

-- Statements kept per farm for the Farm Status page.
FFR_MonthlyFinancialProcessor.MAX_STATEMENTS = 24
FFR_MonthlyFinancialProcessor.MAX_YEARS = 20

-- Closes the statement for the month that just ended (the bills for it are
-- charged on day 1 of the next month). Revenue and operating costs come from
-- the money tracker; FFR costs are this month's overhead without loan principal.
function FFR_MonthlyFinancialProcessor:recordStatement(state, period, year, summary)
    local p, y = period - 1, year
    if p < 1 then p, y = 12, year - 1 end
    local f, c = state.financialManager, summary.costs or {}
    local principal = (tonumber(c.landPayment) or 0) + (tonumber(c.equipmentPayment) or 0)
    local overhead = math.max(0, (tonumber(summary.total) or 0) - principal)
    local revenue = tonumber(f.lastMonthRevenue) or 0
    local expenses = tonumber(f.lastMonthExpenses) or 0
    local tax = tonumber(summary.annualTax) or 0
    -- Whole dollars keep the save file and the multiplayer snapshot small.
    local function whole(v) return math.floor((tonumber(v) or 0) + 0.5) end
    table.insert(state.statements, {
        period = p, year = y, revenue = whole(revenue), expenses = whole(expenses), overhead = whole(overhead),
        principal = whole(principal), tax = whole(tax), net = whole(revenue - expenses - overhead - tax),
        cash = whole(f.cashOnHand), netWorth = whole(f.netWorth),
        debt = whole(f.totalDebt), stage = tonumber(state.creditManager.insolvencyStage) or 0
    })
    while #state.statements > FFR_MonthlyFinancialProcessor.MAX_STATEMENTS do
        table.remove(state.statements, 1)
    end
end

-- The month just closed, for the month-end window's top row.
function FFR_MonthlyFinancialProcessor:getStatementSummary(state)
    local record = state ~= nil and state.statements ~= nil and state.statements[#state.statements] or nil
    if record == nil then return nil end
    return {revenue = record.revenue, operating = record.expenses, net = record.net}
end

-- FFR overhead lines summed over the year (expense breakdown keys).
FFR_MonthlyFinancialProcessor.YEAR_COST_LINES = {"household", "interest", "insurance", "maintenance", "lease", "rent", "tax"}

-- Year-end balance report (one log line per farm): where the year's money came
-- from and went, the margin, and per-acre result, for balancing the difficulty
-- presets (BALANCE_PLAN.md). Read only; changes nothing.
function FFR_MonthlyFinancialProcessor:logYearBalance(state, completedYear, annualTax)
    local f, y = state.financialManager, state.yearCosts or {}
    local function n(v) return tonumber(v) or 0 end
    local overhead = 0
    for _, key in ipairs(FFR_MonthlyFinancialProcessor.YEAR_COST_LINES) do overhead = overhead + n(y[key]) end
    local revenue, expenses, profit = n(f.annualRevenue), n(f.annualExpenses), n(f.annualProfit)
    local other = expenses - overhead - n(annualTax)
    local arableHa = 0
    if g_FFRLandRegistryManager ~= nil then
        for _, row in ipairs(g_FFRLandRegistryManager:getTitles(state.farmId)) do
            if n(row.arableHa) > 0 then arableHa = arableHa + n(row.arableHa) end
        end
    end
    local acres = arableHa * FFR_L10n.ACRES_PER_HA
    local info = g_currentMission ~= nil and g_currentMission.missionInfo or nil
    Logging.info("FFR Year Balance: farm %d, year %d | revenue $%d | game & other costs $%d | FFR overhead $%d"
        .. " (household %d, interest %d, insurance %d, maintenance %d, leases %d, land rent %d, tax provision %d) | annual taxes $%d | net $%d"
        .. " | margin %s | %d arable ac, net $%d/ac | %d day(s)/month, economy %s, FFR %s",
        state.farmId, completedYear, math.floor(revenue), math.floor(other), math.floor(overhead),
        math.floor(n(y.household)), math.floor(n(y.interest)), math.floor(n(y.insurance)), math.floor(n(y.maintenance)),
        math.floor(n(y.lease)), math.floor(n(y.rent)), math.floor(n(y.tax)), math.floor(n(annualTax)), math.floor(profit),
        revenue > 0 and string.format("%.1f %%", profit / revenue * 100) or "-",
        math.floor(acres + 0.5), acres > 0 and math.floor(profit / acres) or 0,
        FFR_HerdRiskManager ~= nil and FFR_HerdRiskManager.getDaysPerMonth() or 0,
        tostring(info ~= nil and (info.economicDifficulty or info.economyDifficulty) or "?"),
        FFR_Settings ~= nil and tostring(FFR_Settings.difficulty) or "?")
end

-- Close a farm's books for a finished year: keep a history entry, credit a
-- profitable year, then start the new year's revenue and expense totals at zero.
function FFR_MonthlyFinancialProcessor:closeYear(state, completedYear, annualTax)
    local f = state.financialManager
    f:update()
    pcall(self.logYearBalance, self, state, completedYear, annualTax)
    state.yearCosts = {}
    local profit = tonumber(f.annualProfit) or 0
    table.insert(state.years, {
        year = completedYear, revenue = tonumber(f.annualRevenue) or 0,
        expenses = tonumber(f.annualExpenses) or 0, taxes = tonumber(annualTax) or 0,
        profit = profit, netWorth = tonumber(f.netWorth) or 0, debt = tonumber(f.totalDebt) or 0
    })
    while #state.years > FFR_MonthlyFinancialProcessor.MAX_YEARS do
        table.remove(state.years, 1)
    end
    local y = state.yearManager
    table.insert(y.yearlyProfit, profit)
    table.insert(y.yearlyNetWorth, tonumber(f.netWorth) or 0)
    table.insert(y.yearlyRevenue, tonumber(f.annualRevenue) or 0)
    table.insert(y.yearlyExpenses, tonumber(f.annualExpenses) or 0)
    y.totalYearsCompleted = (tonumber(y.totalYearsCompleted) or 0) + 1
    y.currentYear = completedYear + 1
    if profit > 0 then state.creditManager:addSuccessfulYear() end
    Logging.info("FFR Year %d closed for farm %d: revenue $%d, expenses $%d, profit $%d",
        completedYear, state.farmId, math.floor(tonumber(f.annualRevenue) or 0),
        math.floor(tonumber(f.annualExpenses) or 0), math.floor(profit))
    f:resetAnnualTracking()
end

-- Charges one farm for the month. Returns the overhead total and annual tax.
function FFR_MonthlyFinancialProcessor:processFarmMonth(state, period, year, completedYear)
    local f = state.financialManager
    self:refreshCash(state.farmId)
    local c = self:getExpenseBreakdown(state)
    local total = c.interest + c.insurance + c.household + c.landPayment + c.equipmentPayment + c.lease + c.rent + c.tax + c.maintenance
    local annualTax = 0
    -- The year rolled over since the last processed month: tax and close the finished year.
    if completedYear > 0 and year > completedYear then
        annualTax = self:processAnnualTaxes(state, completedYear)
        self:closeYear(state, completedYear, annualTax)
    end
    if total > 0 and not self:applyFarmBalance(-total, nil, state.farmId) then return nil end
    if FFR_CropInsuranceManager ~= nil and #c.cropBills > 0 then FFR_CropInsuranceManager.markBilled(state, c.cropBills) end
    state.propertyMaintenanceDue = math.max(0, (tonumber(state.propertyMaintenanceDue) or 0) - c.maintenance)
    -- This year's FFR overhead by line, for the year-end balance report (closeYear).
    state.yearCosts = state.yearCosts or {}
    for _, key in ipairs(FFR_MonthlyFinancialProcessor.YEAR_COST_LINES) do
        state.yearCosts[key] = (tonumber(state.yearCosts[key]) or 0) + (tonumber(c[key]) or 0)
    end
    -- Expansion-loan principal paid this month comes off the balance.
    if c.landPayment > 0 then
        f.landDebt = math.max(0, (tonumber(f.landDebt) or 0) - c.landPayment)
        if f.landDebt < 0.01 then
            f.landDebt, f.monthlyLandPayment = 0, 0
            Logging.info("FFR Expansion Loan: Farm %d paid off", state.farmId)
        end
    end
    -- Finance principal comes off each machine's balance; lease months are counted
    -- and leases past their decision month go back (FFR_EquipmentFinanceManager).
    if FFR_EquipmentFinanceManager ~= nil then
        FFR_EquipmentFinanceManager.applyMonthlyPayments(state)
    end
    -- Rent months counted, landlords paid, finished rentals handed back.
    if FFR_LandRentManager ~= nil then
        c.rentIncome = FFR_LandRentManager.applyMonthly(state)
    end
    -- A debt or lease payment that leaves the farm overdrawn counts as late.
    if (c.interest + c.landPayment + c.equipmentPayment + c.lease + c.rent) > 0 and (tonumber(f.cashOnHand) or 0) < 0 then
        state.creditManager:addLatePayment()
        Logging.warning("FFR Credit: Farm %d loan payment left it overdrawn; late payment recorded", state.farmId)
    end
    f.monthlyInterestCost = c.interest
    f.monthlyInsuranceCost = c.insurance
    f.monthlyHouseholdCost = c.household
    f.totalMonthlyObligations = total
    -- Loan principal repays debt; only the rest is an operating expense.
    f.annualExpenses = (tonumber(f.annualExpenses) or 0) + total - c.landPayment - c.equipmentPayment
    f:updateAnnualProfit()
    state.bankingManager.totalInterestPaid = (tonumber(state.bankingManager.totalInterestPaid) or 0) + c.interest
    state.insuranceManager.totalPremiumsPaid = (tonumber(state.insuranceManager.totalPremiumsPaid) or 0) + c.insurance
    state.familyManager.totalFamilyExpenses = (tonumber(state.familyManager.totalFamilyExpenses) or 0) + c.household
    f:update()
    -- Keep last month's figures for the dashboard, then start the new month at zero.
    f.lastMonthRevenue = tonumber(f.monthlyRevenue) or 0
    f.lastMonthExpenses = tonumber(f.monthlyExpenses) or 0
    f:resetMonthlyTracking()
    state.lastMonthlyTotal = total
    state.lastBreakdown = c
    Logging.info("FFR Monthly Processing: Farm %d charged $%d (household $%d, insurance $%d, interest $%d, principal $%d); annual tax $%d; cash $%d",
        state.farmId, math.floor(total), math.floor(c.household), math.floor(c.insurance), math.floor(c.interest),
        math.floor(c.landPayment + c.equipmentPayment), math.floor(annualTax), math.floor(tonumber(f.cashOnHand) or 0))
    return total, annualTax, c
end

function FFR_MonthlyFinancialProcessor:processMonth(period, year, previousYear)
    if g_FFR == nil or g_FFR.getFarmStates == nil then return false end
    -- Only the server charges money; clients receive the results (stage 3).
    if g_currentMission ~= nil and g_currentMission.getIsServer ~= nil and not g_currentMission:getIsServer() then return false end
    local serial = year * 12 + period
    if self.processedSerial == serial then return false end
    local completedYear = tonumber(previousYear) or 0
    local localFarmId = g_FFR.localFarmId
    local localSummary = nil
    -- Land prices move once a month, before rent and values are worked out.
    if FFR_LandMarketManager ~= nil then
        local ok, err = pcall(FFR_LandMarketManager.processMonth, serial)
        if not ok then Logging.warning("FFR Land Market: monthly move failed (%s)", tostring(err)) end
    end
    local summaries = {}
    local monthTotal = 0

    for _, state in ipairs(g_FFR:getFarmStates()) do
        local total, annualTax, costs = self:processFarmMonth(state, period, year, completedYear)
        if total ~= nil then
            monthTotal = monthTotal + total + (annualTax or 0)
            local summary = {state = state, total = total, annualTax = annualTax, costs = costs, cash = state.financialManager.cashOnHand}
            if state.farmId == localFarmId then
                localSummary = summary
            else
                summaries[state.farmId] = summary
            end
        end
    end

    -- Forward contracts whose deadline month has ended default now (the contract
    -- manager charges each farm's buyout and books it as that farm's expense).
    if g_FFR.contractManager ~= nil then
        local buyouts = g_FFR.contractManager:settleDue(period, year)
        if buyouts > 0 then
            Logging.info("FFR Monthly Processing: Contract default buyouts $%d", math.floor(buyouts))
        end
    end

    -- The bank checks every farm that ended the month overdrawn (insolvency
    -- ladder: warning, credit freeze, loans called, forced sale).
    if FFR_InsolvencyManager ~= nil then
        local function check(summary)
            local ok, notice = pcall(FFR_InsolvencyManager.processFarm, summary.state)
            if not ok then
                Logging.warning("FFR Insolvency: Check failed for farm %d (%s)", summary.state.farmId, tostring(notice))
                return
            end
            summary.bankNotice = notice
            summary.cash = summary.state.financialManager.cashOnHand
        end
        if localSummary ~= nil then check(localSummary) end
        for _, summary in pairs(summaries) do check(summary) end
    end

    -- Credit last, so contract defaults and late payments count this month; old
    -- marks age out and clean months clear them (FFR_CreditManager:processMonth).
    for _, state in ipairs(g_FFR:getFarmStates()) do
        state.financialManager:update()
        state.creditManager:processMonth(serial, state.financialManager.cashOnHand)
        state.creditManager:update(state.financialManager)
    end

    -- Close each charged farm's statement for the month that just ended.
    if localSummary ~= nil then self:recordStatement(localSummary.state, period, year, localSummary) end
    for _, summary in pairs(summaries) do self:recordStatement(summary.state, period, year, summary) end

    self.processedSerial = serial
    self.monthsProcessed = self.monthsProcessed + 1
    self.totalExpensesProcessed = self.totalExpensesProcessed + monthTotal

    -- The host sees its own farm's window here; every other farm's players get
    -- the same window through a MONTHLY notice.
    local isClient = g_currentMission == nil or g_currentMission.getIsClient == nil or g_currentMission:getIsClient()
    if localSummary ~= nil and isClient then
        self:showCostSummary(period, year, localSummary.costs, localSummary.total, localSummary.annualTax, localSummary.cash,
            localSummary.bankNotice, self:getStatementSummary(localSummary.state))
    end
    if FFR_Network ~= nil then
        for farmId, summary in pairs(summaries) do
            FFR_Network.sendNotice("MONTHLY", farmId, {
                period = period, year = year, costs = summary.costs, total = summary.total,
                annualTax = summary.annualTax, cash = summary.cash, bankNotice = summary.bankNotice,
                statement = self:getStatementSummary(summary.state)
            })
        end
        FFR_Network.markDirty()
    end
    if g_FFR.saveManager ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
    return true
end

-- Last monthly FFR charge for a farm (default: the local farm), for the dashboard.
function FFR_MonthlyFinancialProcessor:getLastMonthlyTotal(farmId)
    if g_FFR == nil or g_FFR.getFarmState == nil then return 0 end
    local state = g_FFR:getFarmState(farmId or self:getFarmId())
    return state ~= nil and (tonumber(state.lastMonthlyTotal) or 0) or 0
end

function FFR_MonthlyFinancialProcessor:queueMonth(period, year, previousYear)
    self.pendingSerial, self.pendingPeriod, self.pendingYear = year * 12 + period, period, year
    self.pendingPreviousYear = previousYear
    Logging.info("FFR Monthly Processing: Period %d year %d queued for day 1 at 10:00", period, year)
end

function FFR_MonthlyFinancialProcessor:update(dt)
    -- Bills are charged on the server; clients get a MONTHLY notice.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer < self.updateInterval then return end
    self.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    local period, year = self:getCalendar()
    if period == nil then return end
    local day, hour = self:getDayAndTime()
    local serial = year * 12 + period
    if not self.initialized then
        self.initialized = true
        local saved = g_FFR.saveManager ~= nil and g_FFR.saveManager.loadedMonthlyState or nil
        local savedSerial = saved ~= nil and tonumber(saved.processedSerial) or 0
        self.lastPeriod, self.lastYear = period, year
        if savedSerial > 0 and savedSerial < serial then
            -- Saved after the month changed but before it was charged: charge it now
            -- instead of letting a save/reload skip the bill.
            self.processedSerial = savedSerial
            self:queueMonth(period, year, tonumber(saved.lastYear) or year)
            Logging.info("FFR Monthly Processing: Unprocessed period %d year %d restored from save", period, year)
        else
            self.processedSerial = serial
            Logging.info("FFR Monthly Processing: Baseline set to period %d year %d; no charge applied", period, year)
        end
        return
    end
    if self.processedSerial ~= nil and serial < self.processedSerial then
        -- The calendar went backwards (a map's new-game start script or a time mod):
        -- no month has ended, so take the new date as the baseline instead of billing it.
        self.processedSerial, self.pendingSerial = serial, nil
        self.lastPeriod, self.lastYear = period, year
        Logging.info("FFR Monthly Processing: Calendar moved back to period %d year %d; baseline reset, no charge applied", period, year)
        return
    end
    if period ~= self.lastPeriod or year ~= self.lastYear then
        -- Capture the old year before overwriting it; the annual tax check needs it.
        self:queueMonth(period, year, self.lastYear)
        self.lastPeriod, self.lastYear = period, year
    end
    if self.pendingSerial ~= nil and self.processedSerial ~= self.pendingSerial then
        if day == 1 and hour >= self.targetHour then
            self:processMonth(self.pendingPeriod, self.pendingYear, self.pendingPreviousYear)
            self.pendingSerial = nil
        elseif day > 1 then
            Logging.warning("FFR Monthly Processing: 10:00 window was skipped; processing overdue month now")
            self:processMonth(self.pendingPeriod, self.pendingYear, self.pendingPreviousYear)
            self.pendingSerial = nil
        end
    end
end

function FFR_MonthlyFinancialProcessor:loadMap(mapName)
    self.updateTimer = 0
    self.initialized = false
    self.pendingSerial = nil
    self.processedSerial = nil
end
function FFR_MonthlyFinancialProcessor:deleteMap() self.initialized = false end
function FFR_MonthlyFinancialProcessor:draw() end
function FFR_MonthlyFinancialProcessor:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_MonthlyFinancialProcessor:keyEvent(unicode, sym, modifier, isDown) end

g_FFRMonthlyFinancialProcessor = FFR_MonthlyFinancialProcessor:new()
addModEventListener(g_FFRMonthlyFinancialProcessor)
Logging.info("FFR Monthly Financial Processor: Listener installed")
