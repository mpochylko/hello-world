FFR_Network = {}

--------------------------------------------------
-- Multiplayer networking
--
-- The server owns all FFR state. Three events:
--
-- * FFRSyncEvent    server -> clients: a snapshot of
--   markets, supplier deals, news, the contract book
--   and every farm's profile. Sent to a joining
--   player, whenever state changes, and every
--   BROADCAST_INTERVAL for cash and asset movement.
-- * FFRRequestEvent client -> server: a farm action
--   (loans, household, contracts, land use). The
--   server checks the player manages that farm,
--   runs it and replies with a RESULT notice.
-- * FFRNoticeEvent  server -> clients: request
--   results, monthly cost summaries and land-title
--   prompts. Clients act only on notices for their
--   own farm.
--
-- Singleplayer and the host run actions directly
-- through the same dispatcher, without events.
--------------------------------------------------

FFR_Network.BROADCAST_INTERVAL = 10000
FFR_Network.MIN_SEND_INTERVAL = 1000

FFR_Network.dirty = false
FFR_Network.broadcastTimer = 0
FFR_Network.sinceLastSend = 0
FFR_Network.nextRequestId = 1
FFR_Network.pendingCallbacks = {}

--------------------------------------------------
-- Roles
--------------------------------------------------

function FFR_Network.isServer()

    if g_currentMission == nil
        or g_currentMission.getIsServer == nil
    then

        return true

    end

    return g_currentMission:getIsServer() == true

end

function FFR_Network.isMultiplayer()

    if g_currentMission == nil then
        return false
    end

    local info = g_currentMission.missionDynamicInfo

    return info ~= nil and info.isMultiplayer == true

end

-- True when this machine is a client of someone else's server.
function FFR_Network.isClientOnly()

    return not FFR_Network.isServer()

end

--------------------------------------------------
-- Serializer
--
-- Turns plain data tables (numbers, strings,
-- booleans, nested tables) into one string for a
-- network stream, and back. Strings are length-
-- prefixed, so no escaping is needed. Functions and
-- other values are skipped.
--------------------------------------------------

function FFR_Network.encodeValue(value, out)

    local kind = type(value)

    if kind == "number" then

        -- 14 significant digits: exact for money and prices, and keeps
        -- rounded values short (1157.81, not 1157.8099999999999).
        table.insert(out, "n" .. string.format("%.14g", value) .. ";")

    elseif kind == "string" then

        table.insert(out, "s" .. tostring(string.len(value)) .. ":" .. value)

    elseif kind == "boolean" then

        table.insert(out, value and "T" or "F")

    elseif kind == "table" then

        table.insert(out, "{")

        for key, item in pairs(value) do

            local keyKind = type(key)
            local itemKind = type(item)

            if (keyKind == "string" or keyKind == "number")
                and (itemKind == "number" or itemKind == "string" or itemKind == "boolean" or itemKind == "table")
            then

                FFR_Network.encodeValue(key, out)
                FFR_Network.encodeValue(item, out)

            end

        end

        table.insert(out, "}")

    else

        table.insert(out, "F")

    end

end

function FFR_Network.encode(value)

    local out = {}

    FFR_Network.encodeValue(value, out)

    return table.concat(out)

end

-- Returns value, next position. Errors on malformed input (callers pcall).
function FFR_Network.decodeValue(text, pos)

    local tag = string.sub(text, pos, pos)

    if tag == "n" then

        local stop = string.find(text, ";", pos, true)

        return tonumber(string.sub(text, pos + 1, stop - 1)), stop + 1

    elseif tag == "s" then

        local colon = string.find(text, ":", pos, true)

        local length = tonumber(string.sub(text, pos + 1, colon - 1))

        return string.sub(text, colon + 1, colon + length), colon + length + 1

    elseif tag == "T" then

        return true, pos + 1

    elseif tag == "F" then

        return false, pos + 1

    elseif tag == "{" then

        local result = {}

        pos = pos + 1

        while string.sub(text, pos, pos) ~= "}" do

            local key, item

            key, pos = FFR_Network.decodeValue(text, pos)
            item, pos = FFR_Network.decodeValue(text, pos)

            if key ~= nil then
                result[key] = item
            end

        end

        return result, pos + 1

    end

    error("FFR_Network: bad data at " .. tostring(pos))

end

function FFR_Network.decode(text)

    if text == nil or text == "" then
        return nil
    end

    local ok, value = pcall(FFR_Network.decodeValue, text, 1)

    if not ok then

        Logging.warning("FFR Network: Could not read data (%s)", tostring(value))

        return nil

    end

    return value

end

-- Copies number, string and boolean fields between plain objects.
function FFR_Network.copyScalars(source, target)

    if type(source) ~= "table" or type(target) ~= "table" then
        return target
    end

    for key, value in pairs(source) do

        local kind = type(value)

        if type(key) == "string"
            and (kind == "number" or kind == "string" or kind == "boolean")
        then

            target[key] = value

        end

    end

    return target

end

--------------------------------------------------
-- Snapshot (server)
--------------------------------------------------

function FFR_Network.buildFarmSnapshot(state)

    local am = state.assetManager

    local collateral = 0

    if state.bankingManager.getLandCollateral ~= nil then
        collateral = state.bankingManager:getLandCollateral()
    end

    local function count(collection)
        local n = 0
        for _ in pairs(collection or {}) do n = n + 1 end
        return n
    end

    return {
        farmId = state.farmId,
        financial = FFR_Network.copyScalars(state.financialManager, {}),
        credit = FFR_Network.copyScalars(state.creditManager, {}),
        banking = FFR_Network.copyScalars(state.bankingManager, {}),
        insurance = FFR_Network.copyScalars(state.insuranceManager, {}),
        tax = FFR_Network.copyScalars(state.taxManager, {}),
        year = FFR_Network.copyScalars(state.yearManager, {}),
        family = FFR_Network.copyScalars(state.familyManager, {}),
        lastMonthlyTotal = tonumber(state.lastMonthlyTotal) or 0,
        statements = state.statements,
        years = state.years,
        titles = g_FFRLandRegistryManager ~= nil and g_FFRLandRegistryManager:getTitles(state.farmId) or nil,
        storedCrops = g_FFR.advisorManager ~= nil and g_FFR.advisorManager:getStoredCrops(state) or nil,
        cropPolicies = state.cropPolicies,
        cropClaims = state.cropClaims,
        cropDamageRows = FFR_CropDamageManager ~= nil and FFR_CropDamageManager.getFarmRows(state.farmId) or nil,
        herdPolicy = state.herdPolicy,
        herdClaims = state.herdClaims,
        herdEvents = state.herdEvents,
        herdRows = FFR_HerdRiskManager ~= nil and FFR_HerdRiskManager.getBarnRows(state.farmId) or nil,
        equipmentLoans = state.equipmentLoans,
        landRentals = state.landRentals,
        creditMarks = state.creditManager.marks,
        assets = {
            landCount = count(am.landAssets),
            landValue = tonumber(am.totalLandValue) or 0,
            equipmentCount = count(am.equipmentAssets),
            equipmentValue = tonumber(am.totalEquipmentValue) or 0,
            buildingCount = count(am.buildingAssets),
            buildingValue = tonumber(am.totalBuildingValue) or 0,
            inventoryCount = count(am.inventoryAssets),
            inventoryValue = tonumber(am.totalInventoryValue) or 0,
            landCollateral = collateral
        }
    }

end

-- includeHistory: add the closed price-history months (on join, and when they change).
function FFR_Network.buildSnapshot(includeHistory)

    if g_FFR == nil or not g_FFR.isInitialized then
        return nil
    end

    local snapshot = {
        version = 1,
        farms = {},
        contracts = {},
        news = {}
    }

    if FFR_Settings ~= nil then
        snapshot.settings = FFR_Settings.getSnapshot()
    end

    if includeHistory and g_FFRPriceHistory ~= nil then
        snapshot.priceHistory = g_FFRPriceHistory:getSnapshot()
    end

    if FFR_InputClassifier ~= nil then
        snapshot.inputClasses = FFR_InputClassifier.getSnapshot()
    end

    if g_FFR.marketEngine ~= nil then

        snapshot.market = {
            categoryModifiers = g_FFR.marketEngine.categoryModifiers,
            activeEvent = g_FFR.marketEngine.activeEvent
        }

    end

    if g_FFR.inputMarket ~= nil then

        snapshot.input = {
            inputs = g_FFR.inputMarket.inputs,
            activeEvent = g_FFR.inputMarket.activeEvent
        }

    end

    if g_FFR.newsSystem ~= nil then
        snapshot.news = g_FFR.newsSystem.newsItems or {}
    end

    -- Land prices and the land auction (shared by every farm).
    if FFR_LandMarketManager ~= nil then
        snapshot.landMarket = FFR_LandMarketManager.getSnapshot()
    end

    if FFR_LandAuctionManager ~= nil then
        snapshot.landAuction = FFR_LandAuctionManager.getSnapshot()
    end

    if g_FFR.contractManager ~= nil then

        local cm = g_FFR.contractManager

        for index, contract in ipairs(cm.contracts) do
            snapshot.contracts[index] = FFR_Network.copyScalars(contract, {})
            -- Delivery calls are a list, not a scalar.
            snapshot.contracts[index].calls = contract.calls
        end

        snapshot.contractBlocks = cm.blockedUntil

        snapshot.contractHistory = cm.history

    end

    for index, state in ipairs(g_FFR:getFarmStates()) do
        snapshot.farms[index] = FFR_Network.buildFarmSnapshot(state)
    end

    return snapshot

end

--------------------------------------------------
-- Snapshot (client)
--------------------------------------------------

function FFR_Network.applyFarmSnapshot(data)

    local state = g_FFR:getFarmState(data.farmId)

    if state == nil then
        return
    end

    FFR_Network.copyScalars(data.financial, state.financialManager)
    FFR_Network.copyScalars(data.credit, state.creditManager)
    FFR_Network.copyScalars(data.banking, state.bankingManager)
    FFR_Network.copyScalars(data.insurance, state.insuranceManager)
    FFR_Network.copyScalars(data.tax, state.taxManager)
    FFR_Network.copyScalars(data.year, state.yearManager)
    FFR_Network.copyScalars(data.family, state.familyManager)

    -- copyScalars may have overwritten the farm ids with the server's; same values.
    state.financialManager.farmId = state.farmId
    state.bankingManager.farmId = state.farmId

    state.lastMonthlyTotal = tonumber(data.lastMonthlyTotal) or 0

    -- Decoded lists keep their 1..n number keys, so ipairs works on them.
    if type(data.statements) == "table" then state.statements = data.statements end
    if type(data.years) == "table" then state.years = data.years end
    if type(data.titles) == "table" then state.landTitles = data.titles end
    if type(data.storedCrops) == "table" then state.storedCrops = data.storedCrops end
    state.cropPolicies = type(data.cropPolicies) == "table" and data.cropPolicies or {}
    if type(data.cropClaims) == "table" then state.cropClaims = data.cropClaims end
    if type(data.cropDamageRows) == "table" then state.cropDamageRows = data.cropDamageRows end
    state.herdPolicy = type(data.herdPolicy) == "table" and data.herdPolicy or nil
    if type(data.herdClaims) == "table" then state.herdClaims = data.herdClaims end
    if type(data.herdEvents) == "table" then state.herdEvents = data.herdEvents end
    if type(data.herdRows) == "table" then state.herdRows = data.herdRows end
    if type(data.equipmentLoans) == "table" then state.equipmentLoans = data.equipmentLoans end
    state.landRentals = type(data.landRentals) == "table" and data.landRentals or {}
    if type(data.creditMarks) == "table" then state.creditManager.marks = data.creditMarks end

    -- Assets are valued on the server; the client only shows the totals.
    local am = state.assetManager
    local assets = data.assets or {}

    am.isRemote = true
    am.remote = assets
    am.totalLandValue = tonumber(assets.landValue) or 0
    am.totalEquipmentValue = tonumber(assets.equipmentValue) or 0
    am.totalBuildingValue = tonumber(assets.buildingValue) or 0
    am.totalInventoryValue = tonumber(assets.inventoryValue) or 0
    am.totalAssetValue = am.totalLandValue + am.totalEquipmentValue + am.totalBuildingValue + am.totalInventoryValue

    am:updateFinancialManager(state.financialManager)

    state.financialManager:update()

end

function FFR_Network.applySnapshot(snapshot)

    if g_FFR == nil
        or not g_FFR.isInitialized
        or type(snapshot) ~= "table"
    then

        return

    end

    -- Difficulty first: the market range and households depend on it.
    if FFR_Settings ~= nil then
        FFR_Settings.applySnapshot(snapshot.settings)
    end

    if g_FFRPriceHistory ~= nil and snapshot.priceHistory ~= nil then
        g_FFRPriceHistory:applySnapshot(snapshot.priceHistory)
    end

    if FFR_InputClassifier ~= nil then
        FFR_InputClassifier.applySnapshot(snapshot.inputClasses)
    end

    if snapshot.market ~= nil and g_FFR.marketEngine ~= nil then

        local engine = g_FFR.marketEngine

        if type(snapshot.market.categoryModifiers) == "table" then
            engine.categoryModifiers = snapshot.market.categoryModifiers
        end

        engine.activeEvent = snapshot.market.activeEvent

        -- The client's sell-price hook uses these, so FS25's price pages match the server.
        engine:applyToCommodityManager(g_FFR.commodityManager)

    end

    if snapshot.input ~= nil and g_FFR.inputMarket ~= nil then

        if type(snapshot.input.inputs) == "table" then
            g_FFR.inputMarket.inputs = snapshot.input.inputs
        end

        g_FFR.inputMarket.activeEvent = snapshot.input.activeEvent

    end

    if FFR_LandMarketManager ~= nil then
        FFR_LandMarketManager.applySnapshot(snapshot.landMarket)
    end

    if FFR_LandAuctionManager ~= nil then
        FFR_LandAuctionManager.applySnapshot(snapshot.landAuction)
    end

    if g_FFR.newsSystem ~= nil and type(snapshot.news) == "table" then

        local items = {}

        for index = 1, #snapshot.news do
            items[index] = snapshot.news[index]
        end

        g_FFR.newsSystem.newsItems = items

    end

    if g_FFR.contractManager ~= nil and type(snapshot.contracts) == "table" then

        local cm = g_FFR.contractManager

        local contracts = {}

        for index = 1, #snapshot.contracts do

            local contract = snapshot.contracts[index]
            local commodity = cm:getCommodity(contract.commodity)

            contract.fillTypeIndex = commodity ~= nil and commodity.index or contract.fillTypeIndex

            table.insert(contracts, contract)

        end

        cm.contracts = contracts

        if type(snapshot.contractBlocks) == "table" then
            cm.blockedUntil = snapshot.contractBlocks
        end

        if type(snapshot.contractHistory) == "table" then
            cm.history = snapshot.contractHistory
        end

    end

    for index = 1, #(snapshot.farms or {}) do
        FFR_Network.applyFarmSnapshot(snapshot.farms[index])
    end

    if not g_FFR.hasReceivedSync then

        g_FFR.hasReceivedSync = true

        Logging.info("FFR Network: First state received from the server")

    end

end

--------------------------------------------------
-- Sending (server)
--------------------------------------------------

-- Something changed; send a snapshot soon (at most once per MIN_SEND_INTERVAL).
function FFR_Network.markDirty()

    FFR_Network.dirty = true

end

function FFR_Network.broadcastSnapshot()

    if g_server == nil or not FFR_Network.isMultiplayer() then
        return
    end

    -- Price history is large and changes once a month: only sent when it changed.
    local historyVersion = g_FFRPriceHistory ~= nil and g_FFRPriceHistory.version or 0

    local snapshot = FFR_Network.buildSnapshot(historyVersion ~= FFR_Network.sentHistoryVersion)

    if snapshot == nil then
        return
    end

    FFR_Network.sentHistoryVersion = historyVersion

    g_server:broadcastEvent(FFRSyncEvent.new(FFR_Network.encode(snapshot)))

    FFR_Network.dirty = false
    FFR_Network.broadcastTimer = 0
    FFR_Network.sinceLastSend = 0

end

function FFR_Network.sendSnapshotTo(connection)

    local snapshot = FFR_Network.buildSnapshot(true)

    if snapshot ~= nil and connection ~= nil then
        connection:sendEvent(FFRSyncEvent.new(FFR_Network.encode(snapshot)))
    end

end

-- Sends a notice to every client; each client keeps only its own farm's.
-- On the host the local farm's notice is handled right here.
function FFR_Network.sendNotice(kind, farmId, payload)

    if FFR_Network.isServer()
        and g_FFR ~= nil
        and farmId == g_FFR.localFarmId
        and (g_currentMission == nil or g_currentMission.getIsClient == nil or g_currentMission:getIsClient())
    then

        FFR_Network.handleNotice(kind, farmId, payload)

    end

    if g_server ~= nil and FFR_Network.isMultiplayer() then
        g_server:broadcastEvent(FFRNoticeEvent.new(kind, farmId, FFR_Network.encode(payload or {})))
    end

end

--------------------------------------------------
-- Permissions (server)
--------------------------------------------------

-- Requests from the host itself (no connection) are always allowed.
function FFR_Network.canManage(connection, farmId)

    if connection == nil
        or (connection.getIsServer ~= nil and connection:getIsServer())
    then

        return true

    end

    local userId = nil
    local userManager = g_currentMission ~= nil and g_currentMission.userManager or nil

    if userManager ~= nil and userManager.getUserIdByConnection ~= nil then

        local ok, id = pcall(userManager.getUserIdByConnection, userManager, connection)

        userId = ok and id or nil

    end

    local farm = g_farmManager ~= nil and g_farmManager:getFarmById(farmId) or nil

    if userId ~= nil and farm ~= nil and farm.isUserFarmManager ~= nil then

        local ok, isManager = pcall(farm.isUserFarmManager, farm, userId)

        if ok then
            return isManager == true
        end

    end

    Logging.warning("FFR Network: Could not check farm-manager rights for farm %s; request refused", tostring(farmId))

    return false

end

-- Whether the local player manages their farm (for the dashboard buttons).
-- If it cannot be checked, the server still enforces it.
function FFR_Network.canManageLocalFarm()

    if not FFR_Network.isMultiplayer() then
        return true
    end

    local farmId = g_FFR ~= nil and g_FFR.localFarmId or nil
    local farm = (farmId ~= nil and g_farmManager ~= nil) and g_farmManager:getFarmById(farmId) or nil
    local userId = g_currentMission ~= nil and g_currentMission.playerUserId or nil

    if farm ~= nil and userId ~= nil and farm.isUserFarmManager ~= nil then

        local ok, isManager = pcall(farm.isUserFarmManager, farm, userId)

        if ok then
            return isManager == true
        end

    end

    return true

end

-- Server-wide settings (difficulty) are for the server admin only.
-- Requests from the host itself (no connection) are always allowed.
function FFR_Network.canAdminister(connection)

    if connection == nil
        or (connection.getIsServer ~= nil and connection:getIsServer())
    then

        return true

    end

    local userManager = g_currentMission ~= nil and g_currentMission.userManager or nil

    if userManager ~= nil and userManager.getUserByConnection ~= nil then

        local ok, user = pcall(userManager.getUserByConnection, userManager, connection)

        if ok and user ~= nil and user.getIsMasterUser ~= nil then

            local checked, isAdmin = pcall(user.getIsMasterUser, user)

            if checked then
                return isAdmin == true
            end

        end

    end

    Logging.warning("FFR Network: Could not check admin rights; settings change refused")

    return false

end

-- Whether the local player may change server-wide settings (Options page).
function FFR_Network.isLocalAdmin()

    if FFR_Network.isServer() then
        return true
    end

    return g_currentMission ~= nil and g_currentMission.isMasterUser == true

end

FFR_Network.ADMIN_ACTIONS = {
    SET_DIFFICULTY = true,
    SET_INPUT_CLASS = true,
    RESET_INPUT_CLASS = true
}

--------------------------------------------------
-- Actions (server)
--
-- Every farm action runs here, for local and
-- remote players alike. Returns ok, message.
--------------------------------------------------

FFR_Network.LOAN_ACTIONS = {
    BORROW_OPERATING = {"requestOperatingLoan", "OPERATING_STEP"},
    REPAY_OPERATING = {"repayOperatingLoan", "OPERATING_STEP"},
    PAYOFF_OPERATING = {"payOffOperatingLoan", nil},
    BORROW_LAND = {"requestLandLoan", "LAND_STEP"},
    REPAY_LAND = {"repayLandLoan", "LAND_STEP"},
    PAYOFF_LAND = {"payOffLandLoan", nil}
}

FFR_Network.MAX_LOAN_AMOUNT = 500000

function FFR_Network.findContract(farmId, contractId)

    local cm = g_FFR.contractManager

    for _, contract in ipairs(cm ~= nil and cm.contracts or {}) do

        if contract.id == contractId and contract.farmId == farmId then
            return contract
        end

    end

    return nil

end

function FFR_Network.executeAction(action, farmId, args)

    args = args or {}

    if action == "SET_DIFFICULTY" and FFR_Settings ~= nil then
        return FFR_Settings.step(tonumber(args.direction) or 0)
    elseif action == "SET_INPUT_CLASS" and FFR_InputClassifier ~= nil then
        return FFR_InputClassifier.step(args.key, tonumber(args.direction) or 0)
    elseif action == "RESET_INPUT_CLASS" and FFR_InputClassifier ~= nil then
        return FFR_InputClassifier.reset(args.key)
    end

    local state = g_FFR ~= nil and g_FFR:getFarmState(farmId) or nil

    if state == nil then
        return false, FFR_L10n.t("ffr_msg_unknown_farm")
    end

    local loan = FFR_Network.LOAN_ACTIONS[action]

    if loan ~= nil then

        -- Borrow / repay use the amount from the Bank page's bar ($10K steps, max
        -- $500K); without one, the loan's standard step. Pay off ignores it.
        local amount = loan[2] ~= nil and FFR_BankingManager[loan[2]] or 0

        if loan[2] ~= nil and tonumber(args.amount) ~= nil then
            amount = math.floor(math.max(0, math.min(FFR_Network.MAX_LOAN_AMOUNT, tonumber(args.amount))) / 10000 + 0.5) * 10000
        end

        return state.bankingManager[loan[1]](state.bankingManager, amount, state.financialManager, state.creditManager)

    end

    if action == "HOUSEHOLD_CHANGE" then

        state.familyManager:changeSetting(args.setting, tonumber(args.direction) or 0)

        state.financialManager:update()

        return true, ""

    elseif action == "HOUSEHOLD_RESET" then

        state.familyManager:resetDefault()

        state.financialManager:update()

        return true, ""

    end

    local cm = g_FFR.contractManager

    if action == "CONTRACT_SIGN" and cm ~= nil then

        -- Priced again on the server; the client's quote is never trusted.
        local commodity = cm:getCommodity(args.commodity)
        local buyerIndex = 1

        for index, buyer in ipairs(cm:getBuyers(commodity)) do
            if buyer.key == args.buyerKey then buyerIndex = index end
        end

        local quote = cm:getQuote(args.commodity, buyerIndex, args.volume, args.monthsAhead)

        if quote ~= nil and quote.buyerKey ~= args.buyerKey then
            return false, FFR_L10n.t("ffr_contract_buyer_gone")
        end

        return cm:createContract(farmId, quote)

    elseif action == "CONTRACT_ROLL" and cm ~= nil then

        return cm:rollContract(FFR_Network.findContract(farmId, tonumber(args.contractId)))

    elseif action == "CONTRACT_BUYOUT" and cm ~= nil then

        return cm:buyOut(FFR_Network.findContract(farmId, tonumber(args.contractId)), false)

    elseif action == "INSURE_CROP" and FFR_CropInsuranceManager ~= nil then

        return FFR_CropInsuranceManager.insureCrop(state, tostring(args.fruitName or ""), tonumber(args.coverage))

    elseif action == "UNINSURE_CROP" and FFR_CropInsuranceManager ~= nil then

        return FFR_CropInsuranceManager.removeCrop(state, tostring(args.fruitName or ""))

    elseif action == "FILE_CROP_CLAIM" and FFR_CropInsuranceManager ~= nil then

        return FFR_CropInsuranceManager.fileClaim(state, tonumber(args.farmlandId))

    elseif action == "BUY_HERD_POLICY" and FFR_LivestockInsuranceManager ~= nil then

        return FFR_LivestockInsuranceManager.buyPolicy(state)

    elseif action == "EQUIP_FINANCE_PREPARE" and FFR_EquipmentFinanceManager ~= nil then

        -- Approved here, on the server; the shop purchase follows (FFR_ShopFinance).
        return FFR_EquipmentFinanceManager.prepare(state, args)

    elseif action == "EQUIP_PAYOFF" and FFR_EquipmentFinanceManager ~= nil then

        -- Pays off a finance loan, or buys out a lease.
        return FFR_EquipmentFinanceManager.payOff(state, tonumber(args.loanId))

    elseif action == "EQUIP_RETURN" and FFR_EquipmentFinanceManager ~= nil then

        return FFR_EquipmentFinanceManager.returnLease(state, tonumber(args.loanId), false)

    elseif action == "LAND_DECLARE" and g_FFRLandRegistryManager ~= nil then

        return g_FFRLandRegistryManager:declareUse(farmId, tonumber(args.farmlandId), args.use, tonumber(args.agriculturalPercent))

    elseif action == "LAND_RENT_IN" and FFR_LandRentManager ~= nil then

        return FFR_LandRentManager.rentIn(state, tonumber(args.farmlandId), tonumber(args.term))

    elseif action == "LAND_RENT_OUT" and FFR_LandRentManager ~= nil then

        return FFR_LandRentManager.rentOut(state, tonumber(args.farmlandId), tonumber(args.term))

    elseif action == "LAND_RENT_RENEW" and FFR_LandRentManager ~= nil then

        return FFR_LandRentManager.renew(state, tonumber(args.rentalId), tonumber(args.term))

    elseif action == "LAND_RENT_END" and FFR_LandRentManager ~= nil then

        return FFR_LandRentManager.endNow(state, tonumber(args.rentalId))

    elseif action == "LAND_BID" and FFR_LandAuctionManager ~= nil then

        return FFR_LandAuctionManager.bid(state, tonumber(args.farmlandId))

    end

    return false, FFR_L10n.t("ffr_msg_unknown_request")

end

-- Server side of a request: permission check, run, save, sync.
function FFR_Network.handleRequest(action, farmId, args, connection)

    if FFR_Network.ADMIN_ACTIONS[action] then

        if not FFR_Network.canAdminister(connection) then
            return false, FFR_L10n.t("ffr_msg_admin_only")
        end

    elseif not FFR_Network.canManage(connection, farmId) then
        return false, FFR_L10n.t("ffr_msg_manager_only")
    end

    local ok, success, message = pcall(FFR_Network.executeAction, action, farmId, args)

    if not ok then

        Logging.warning("FFR Network: Request %s failed (%s)", tostring(action), tostring(success))

        return false, FFR_L10n.t("ffr_msg_server_failed")

    end

    if g_FFR.saveManager ~= nil then
        g_FFR.saveManager:requestSave(g_FFR)
    end

    FFR_Network.markDirty()

    return success, message

end

--------------------------------------------------
-- Actions (any machine)
--
-- The dashboard calls this. onResult(ok, message)
-- runs right away on the server/host, or when the
-- server's answer arrives on a client.
--------------------------------------------------

function FFR_Network.perform(action, args, onResult)

    local farmId = g_FFR ~= nil and g_FFR.localFarmId or nil

    if FFR_Network.isServer() then

        local ok, message = FFR_Network.handleRequest(action, farmId, args, nil)

        if onResult ~= nil then
            onResult(ok, message)
        end

        return

    end

    if FFR_Network.ADMIN_ACTIONS[action] then

        if not FFR_Network.isLocalAdmin() then

            if onResult ~= nil then
                onResult(false, FFR_L10n.t("ffr_msg_admin_only"))
            end

            return

        end

    elseif not FFR_Network.canManageLocalFarm() then

        if onResult ~= nil then
            onResult(false, FFR_L10n.t("ffr_msg_manager_only"))
        end

        return

    end

    local requestId = FFR_Network.nextRequestId

    FFR_Network.nextRequestId = requestId + 1

    FFR_Network.pendingCallbacks[requestId] = onResult

    g_client:getServerConnection():sendEvent(
        FFRRequestEvent.new(requestId, action, farmId, FFR_Network.encode(args or {}))
    )

    if onResult ~= nil then
        onResult(nil, FFR_L10n.t("ffr_msg_request_sent"))
    end

end

--------------------------------------------------
-- Notices (client and host)
--------------------------------------------------

function FFR_Network.handleNotice(kind, farmId, payload)

    if g_FFR == nil or farmId ~= g_FFR.localFarmId then
        return
    end

    payload = payload or {}

    if kind == "RESULT" then

        local callback = FFR_Network.pendingCallbacks[payload.requestId]

        FFR_Network.pendingCallbacks[payload.requestId] = nil

        if callback ~= nil then
            callback(payload.ok == true, payload.message or "")
        end

    elseif kind == "MONTHLY" then

        if g_FFRMonthlyFinancialProcessor ~= nil then

            g_FFRMonthlyFinancialProcessor:showCostSummary(
                payload.period, payload.year, payload.costs or {},
                payload.total, payload.annualTax, payload.cash, payload.bankNotice, payload.statement
            )

        end

    elseif kind == "CROP_DAMAGE" then

        -- Hail and rain damage, and adjuster results (FFR_CropDamageManager).
        if FFR_CropDamageManager ~= nil then
            FFR_CropDamageManager.showNotice(payload.text)
        end

    elseif kind == "LAND_PROMPT" then

        -- Only the farm's managers declare land use.
        if g_FFRLandRegistryManager ~= nil and FFR_Network.canManageLocalFarm() then
            g_FFRLandRegistryManager:queueRemoteParcel(payload)
        end

    end

end

--------------------------------------------------
-- Listener: periodic broadcast and join sync
--------------------------------------------------

function FFR_Network:update(dt)

    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then
        return
    end

    if not FFR_Network.isServer() then

        -- Keep the local farm's cash current between snapshots.
        local state = g_FFR:getFarmState(g_FFR.localFarmId)
        local farm = (state ~= nil and g_farmManager ~= nil) and g_farmManager:getFarmById(state.farmId) or nil

        if farm ~= nil and farm.money ~= nil then
            state.financialManager.cashOnHand = tonumber(farm.money) or state.financialManager.cashOnHand
        end

        return

    end

    if not FFR_Network.isMultiplayer() then
        return
    end

    FFR_Network.broadcastTimer = FFR_Network.broadcastTimer + dt
    FFR_Network.sinceLastSend = FFR_Network.sinceLastSend + dt

    if (FFR_Network.dirty and FFR_Network.sinceLastSend >= FFR_Network.MIN_SEND_INTERVAL)
        or FFR_Network.broadcastTimer >= FFR_Network.BROADCAST_INTERVAL
    then

        FFR_Network.broadcastSnapshot()

    end

end

function FFR_Network:loadMap(mapName)

    FFR_Network.dirty = false
    FFR_Network.broadcastTimer = 0
    FFR_Network.sinceLastSend = 0
    FFR_Network.pendingCallbacks = {}

end

function FFR_Network:deleteMap()

    FFR_Network.pendingCallbacks = {}

end

function FFR_Network:draw() end
function FFR_Network:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_Network:keyEvent(unicode, sym, modifier, isDown) end

-- A joining player gets the full state straight away.
function FFR_Network.onSendInitialClientState(mission, connection, ...)

    local ok, err = pcall(FFR_Network.sendSnapshotTo, connection)

    if not ok then
        Logging.warning("FFR Network: Could not send state to joining player (%s)", tostring(err))
    end

end

--------------------------------------------------
-- Events
--------------------------------------------------

FFRSyncEvent = {}
local FFRSyncEvent_mt = Class(FFRSyncEvent, Event)
InitEventClass(FFRSyncEvent, "FFRSyncEvent")

function FFRSyncEvent.emptyNew()
    return Event.new(FFRSyncEvent_mt)
end

function FFRSyncEvent.new(data)
    local self = FFRSyncEvent.emptyNew()
    self.data = data
    return self
end

function FFRSyncEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.data or "")
end

function FFRSyncEvent:readStream(streamId, connection)
    self.data = streamReadString(streamId)
    self:run(connection)
end

function FFRSyncEvent:run(connection)
    if connection ~= nil and connection.getIsServer ~= nil and connection:getIsServer() then
        FFR_Network.applySnapshot(FFR_Network.decode(self.data))
    end
end

FFRRequestEvent = {}
local FFRRequestEvent_mt = Class(FFRRequestEvent, Event)
InitEventClass(FFRRequestEvent, "FFRRequestEvent")

function FFRRequestEvent.emptyNew()
    return Event.new(FFRRequestEvent_mt)
end

function FFRRequestEvent.new(requestId, action, farmId, args)
    local self = FFRRequestEvent.emptyNew()
    self.requestId = requestId
    self.action = action
    self.farmId = farmId
    self.args = args
    return self
end

function FFRRequestEvent:writeStream(streamId, connection)
    streamWriteInt32(streamId, self.requestId or 0)
    streamWriteString(streamId, self.action or "")
    streamWriteInt32(streamId, self.farmId or 0)
    streamWriteString(streamId, self.args or "")
end

function FFRRequestEvent:readStream(streamId, connection)
    self.requestId = streamReadInt32(streamId)
    self.action = streamReadString(streamId)
    self.farmId = streamReadInt32(streamId)
    self.args = streamReadString(streamId)
    self:run(connection)
end

-- Runs on the server for a client's request; answers that client only.
function FFRRequestEvent:run(connection)
    if connection == nil or (connection.getIsServer ~= nil and connection:getIsServer()) then
        return
    end
    local ok, message = FFR_Network.handleRequest(self.action, self.farmId, FFR_Network.decode(self.args), connection)
    connection:sendEvent(FFRNoticeEvent.new("RESULT", self.farmId,
        FFR_Network.encode({requestId = self.requestId, ok = ok == true, message = message or ""})))
end

FFRNoticeEvent = {}
local FFRNoticeEvent_mt = Class(FFRNoticeEvent, Event)
InitEventClass(FFRNoticeEvent, "FFRNoticeEvent")

function FFRNoticeEvent.emptyNew()
    return Event.new(FFRNoticeEvent_mt)
end

function FFRNoticeEvent.new(kind, farmId, payload)
    local self = FFRNoticeEvent.emptyNew()
    self.kind = kind
    self.farmId = farmId
    self.payload = payload
    return self
end

function FFRNoticeEvent:writeStream(streamId, connection)
    streamWriteString(streamId, self.kind or "")
    streamWriteInt32(streamId, self.farmId or 0)
    streamWriteString(streamId, self.payload or "")
end

function FFRNoticeEvent:readStream(streamId, connection)
    self.kind = streamReadString(streamId)
    self.farmId = streamReadInt32(streamId)
    self.payload = streamReadString(streamId)
    self:run(connection)
end

function FFRNoticeEvent:run(connection)
    if connection ~= nil and connection.getIsServer ~= nil and connection:getIsServer() then
        FFR_Network.handleNotice(self.kind, self.farmId, FFR_Network.decode(self.payload))
    end
end

--------------------------------------------------
-- Install
--------------------------------------------------

addModEventListener(FFR_Network)

if FSBaseMission ~= nil and FSBaseMission.sendInitialClientState ~= nil then

    FSBaseMission.sendInitialClientState =
        Utils.appendedFunction(
            FSBaseMission.sendInitialClientState,
            FFR_Network.onSendInitialClientState
        )

else

    Logging.warning("FFR Network: sendInitialClientState unavailable; joining players wait for the next broadcast")

end

Logging.info("FFR Network: Multiplayer sync installed")
