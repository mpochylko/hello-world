FFR_NewsSystem = {}

-- Oldest headlines are dropped past this count.
FFR_NewsSystem.MAX_ITEMS = 20

function FFR_NewsSystem:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_NewsSystem}
    )

    self.newsItems = {}

    return self

end

--------------------------------------------------
-- Add News Item
--------------------------------------------------

function FFR_NewsSystem:addNewsItem(headline)

    if headline == nil
        or headline == ""
    then

        return

    end

    table.insert(
        self.newsItems,
        headline
    )

    while #self.newsItems > FFR_NewsSystem.MAX_ITEMS do

        table.remove(
            self.newsItems,
            1
        )

    end

    Logging.info(
        "FFR NEWS: %s",
        headline
    )

end

--------------------------------------------------
-- Latest Headlines (newest first)
--------------------------------------------------

function FFR_NewsSystem:getLatest(count)

    local result = {}

    local limit =
        tonumber(count) or #self.newsItems

    for index = #self.newsItems, 1, -1 do

        if #result >= limit then
            break
        end

        table.insert(
            result,
            self.newsItems[index]
        )

    end

    return result

end

--------------------------------------------------
-- Generate News From Input Event
--------------------------------------------------

function FFR_NewsSystem:createInputMarketStory(event)

    if event == nil then
        return
    end

    -- Headlines are stored as text, in the language of the machine that runs the
    -- markets: ffr_news_story_<event name>, or the general supply headline.
    local key = "ffr_news_story_" .. FFR_L10n.slug(event.name)

    local story = FFR_L10n.hasText(key) and FFR_L10n.t(key) or FFR_L10n.t("ffr_news_story_general")

    self:addNewsItem(
        story
    )

end

--------------------------------------------------
-- Generate News From Commodity Market Event
--------------------------------------------------

function FFR_NewsSystem:createMarketStory(event)

    if event == nil
        or event.name == nil
    then

        return

    end

    local severity =
        tostring(event.severity or "")

    local prefix =
        FFR_L10n.eventName(event.name)

    if severity ~= ""
        and severity ~= "NEUTRAL"
        and severity ~= "LEGACY"
    then

        prefix = FFR_L10n.t("ffr_news_with_severity", prefix, FFR_L10n.named("ffr_event_severity_", severity))

    end

    local description =
        FFR_L10n.eventDescription(event.name, event.description)

    if description == "" then

        self:addNewsItem(
            prefix
        )

        return

    end

    self:addNewsItem(FFR_L10n.t("ffr_news_headline", prefix, description))

end

--------------------------------------------------
-- Print News Feed
--------------------------------------------------

function FFR_NewsSystem:printNews()

    Logging.info(
        "========== FFR NEWS =========="
    )

    for _, item in pairs(
        self.newsItems
    ) do

        Logging.info(
            "%s",
            tostring(item)
        )

    end

end
