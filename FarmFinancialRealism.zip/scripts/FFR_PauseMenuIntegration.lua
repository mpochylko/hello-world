FFR_PauseMenuIntegration = FFR_PauseMenuIntegration or {}
local MOD_DIR = g_currentModDirectory
local PAGE_NAME = "pageFFRDashboard"
local GUI_NAME = "FFRDashboardFrame"

function FFR_PauseMenuIntegration:new()
    local self = {}
    setmetatable(self, { __index = FFR_PauseMenuIntegration })
    self.frame = nil
    self.isRegistered = false
    self.retryTimer = 0
    self.retryInterval = 500
    self.retryCount = 0
    self.maxRetries = 60
    return self
end

function FFR_PauseMenuIntegration:getIsPageEnabled()
    return function()
        return g_currentMission ~= nil and g_FFR ~= nil and g_FFR.isInitialized == true
    end
end

function FFR_PauseMenuIntegration:getMenu()
    if g_gui == nil or g_gui.screenControllers == nil then
        return nil
    end
    return g_gui.screenControllers[InGameMenu] or g_inGameMenu
end

function FFR_PauseMenuIntegration:findTargetPosition(menu)
    local target = 1
    local afterPage = menu.pageMapOverview
    if afterPage ~= nil and menu.pagingElement ~= nil and menu.pagingElement.elements ~= nil then
        for i, element in ipairs(menu.pagingElement.elements) do
            if element == afterPage then
                target = i + 1
                break
            end
        end
    end
    return target
end

function FFR_PauseMenuIntegration:moveEntry(list, matcher, targetPosition)
    if type(list) ~= "table" then
        return
    end
    for i = #list, 1, -1 do
        if matcher(list[i]) then
            local entry = table.remove(list, i)
            local target = math.max(1, math.min(targetPosition, #list + 1))
            table.insert(list, target, entry)
            return
        end
    end
end

function FFR_PauseMenuIntegration:registerPage()
    if self.isRegistered then
        return true
    end

    local menu = self:getMenu()
    if g_client == nil or g_gui == nil or menu == nil or menu.pagingElement == nil
            or menu.pagingElement.elements == nil or menu.pagingElement.pages == nil
            or menu.pageFrames == nil or menu.controlIDs == nil then
        return false
    end

    if menu[PAGE_NAME] ~= nil then
        self.frame = menu[PAGE_NAME]
        self.isRegistered = true
        return true
    end

    local xmlFilename = Utils.getFilename("gui/FFRDashboardFrame.xml", MOD_DIR)
    if fileExists ~= nil and not fileExists(xmlFilename) then
        Logging.error("FFR Pause Menu: Dashboard XML not found at %s", tostring(xmlFilename))
        return false
    end

    local frame = FFR_DashboardFrame.new()
    g_gui:loadGui(xmlFilename, GUI_NAME, frame, true)
    if frame == nil or frame.elements == nil or #frame.elements == 0 then
        Logging.error("FFR Pause Menu: Dashboard frame failed to load from %s", tostring(xmlFilename))
        return false
    end

    local targetPosition = self:findTargetPosition(menu)
    menu.controlIDs[PAGE_NAME] = nil
    menu[PAGE_NAME] = frame
    menu.pagingElement:addElement(frame)
    menu:exposeControlsAsFields(PAGE_NAME)

    self:moveEntry(menu.pagingElement.elements, function(entry) return entry == frame end, targetPosition)
    self:moveEntry(menu.pagingElement.pages, function(entry) return entry ~= nil and entry.element == frame end, targetPosition)

    menu.pagingElement:updateAbsolutePosition()
    menu.pagingElement:updatePageMapping()
    menu:registerPage(frame, nil, self:getIsPageEnabled())

    local iconFilename = Utils.getFilename("icon.dds", MOD_DIR)
    menu:addPageTab(frame, iconFilename, GuiUtils.getUVs({ 0, 0, 1024, 1024 }))
    self:moveEntry(menu.pageFrames, function(entry) return entry == frame end, targetPosition)
    menu:rebuildTabList()

    if type(frame.initialize) == "function" then
        frame:initialize()
    end
    if type(frame.setVisible) == "function" then
        frame:setVisible(false)
    end

    self.frame = frame
    self.isRegistered = true
    Logging.info("FFR Pause Menu: Native dashboard page registered safely")
    return true
end

function FFR_PauseMenuIntegration:loadMap(mapName)
    self.frame = nil
    self.isRegistered = false
    self.retryTimer = 0
    self.retryCount = 0
end

function FFR_PauseMenuIntegration:update(dt)
    if self.isRegistered or self.retryCount >= self.maxRetries then
        return
    end
    self.retryTimer = self.retryTimer + dt
    if self.retryTimer < self.retryInterval then
        return
    end
    self.retryTimer = 0
    self.retryCount = self.retryCount + 1
    self:registerPage()
end

function FFR_PauseMenuIntegration:deleteMap()
    -- The InGameMenu owns the injected frame after addElement/registerPage.
    -- Do not delete or detach it here. Engine shutdown will dispose it once.
    self.frame = nil
    self.isRegistered = false
    self.retryTimer = 0
    self.retryCount = 0
end

function FFR_PauseMenuIntegration:draw() end
function FFR_PauseMenuIntegration:keyEvent(unicode, sym, modifier, isDown) end
function FFR_PauseMenuIntegration:mouseEvent(posX, posY, isDown, isUp, button) end

g_FFRPauseMenuIntegration = FFR_PauseMenuIntegration:new()
addModEventListener(g_FFRPauseMenuIntegration)
Logging.info("FFR Pause Menu: Safe integration listener installed")
