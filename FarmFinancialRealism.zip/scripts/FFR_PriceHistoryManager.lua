FFR_PriceHistoryManager = {}

--------------------------------------------------
-- Monthly price history per commodity
--
-- Every in-game hour the server samples each
-- commodity's best live station price (FFR-adjusted,
-- what the player would be paid). When the month
-- changes, the samples close into one record:
-- average, low and high. The Markets page charts
-- the last CHART_MONTHS months plus the month so far;
-- the average, trend and the Advisor's SELL / HOLD use
-- the last MONTHS_SHOWN (12) of them.
--
-- Saved in FFR_economy.xml. Clients get the closed
-- months in the snapshot when they change (version).
--------------------------------------------------

FFR_PriceHistoryManager.MAX_MONTHS = 24
FFR_PriceHistoryManager.MONTHS_SHOWN = 12
FFR_PriceHistoryManager.CHART_MONTHS = 24

function FFR_PriceHistoryManager:new()
    local self = {}
    setmetatable(self, {__index = FFR_PriceHistoryManager})
    -- name -> {months = {{period, year, avg, low, high}, ...}, current = {sum, count, low, high}}
    self.history = {}
    self.period = nil
    self.year = nil
    self.lastHour = nil
    self.updateTimer = 0
    -- Bumped when closed months change, so the server knows to resend them.
    self.version = 0
    return self
end

function FFR_PriceHistoryManager:getEntry(name)
    local entry = self.history[name]
    if entry == nil then
        entry = {months = {}, current = {sum = 0, count = 0, low = 0, high = 0}}
        self.history[name] = entry
    end
    entry.months = entry.months or {}
    entry.current = entry.current or {sum = 0, count = 0, low = 0, high = 0}
    return entry
end

function FFR_PriceHistoryManager:getLivePrice(commodity)
    -- Animals: best price per head (FFR_AnimalPriceManager).
    if commodity ~= nil and commodity.isAnimal and FFR_AnimalPriceManager ~= nil then
        local price = FFR_AnimalPriceManager.getHeadPrice(commodity.subTypeIndex)
        return price > 0 and price or nil
    end
    if g_FFRStationPriceManager == nil or commodity == nil then return nil end
    local ok, best = pcall(g_FFRStationPriceManager.getBestPrice, g_FFRStationPriceManager, commodity.index)
    if ok and best ~= nil then return tonumber(best.ffrPrice) end
    return nil
end

function FFR_PriceHistoryManager:sample()
    if g_FFR == nil or g_FFR.commodityManager == nil then return end
    local all = {}
    for _, commodity in pairs(g_FFR.commodityManager.commodities or {}) do table.insert(all, commodity) end
    if FFR_AnimalPriceManager ~= nil then
        local ok, animals = pcall(FFR_AnimalPriceManager.getMarketEntries)
        for _, animal in ipairs(ok and animals or {}) do table.insert(all, animal) end
    end
    for _, commodity in ipairs(all) do
        local price = self:getLivePrice(commodity)
        if price ~= nil and price > 0 then
            local c = self:getEntry(commodity.name).current
            c.sum, c.count = c.sum + price, c.count + 1
            c.low = c.count == 1 and price or math.min(c.low, price)
            c.high = c.count == 1 and price or math.max(c.high, price)
        end
    end
end

-- Closes the month being sampled into one record per commodity.
function FFR_PriceHistoryManager:closeMonth()
    if self.period == nil then return end
    for _, entry in pairs(self.history) do
        local c = entry.current
        if c ~= nil and c.count > 0 then
            table.insert(entry.months, {
                period = self.period, year = self.year,
                avg = math.floor(c.sum / c.count * 100 + 0.5) / 100,
                low = math.floor(c.low * 100 + 0.5) / 100,
                high = math.floor(c.high * 100 + 0.5) / 100
            })
            while #entry.months > FFR_PriceHistoryManager.MAX_MONTHS do table.remove(entry.months, 1) end
        end
        entry.current = {sum = 0, count = 0, low = 0, high = 0}
    end
    self.version = self.version + 1
    if FFR_Network ~= nil then FFR_Network.markDirty() end
end

-- Chart points, oldest first: the last closed months (default MONTHS_SHOWN) plus
-- the month so far (marked partial; its average uses this machine's live price on a client).
function FFR_PriceHistoryManager:getSeries(commodity, monthCount)
    local points = {}
    if commodity == nil then return points end
    local entry = self.history[commodity.name]
    local months = entry ~= nil and entry.months or {}
    local first = math.max(1, #months - (monthCount or FFR_PriceHistoryManager.MONTHS_SHOWN) + 1)
    for i = first, #months do
        local m = months[i]
        table.insert(points, {period = m.period, year = m.year, avg = m.avg, low = m.low, high = m.high})
    end
    local c = entry ~= nil and entry.current or nil
    local live = self:getLivePrice(commodity)
    if c ~= nil and c.count > 0 then
        table.insert(points, {period = self.period, year = self.year, avg = c.sum / c.count,
            low = c.low, high = c.high, partial = true})
    elseif live ~= nil and live > 0 then
        local period, year = self:getCalendar()
        table.insert(points, {period = period, year = year, avg = live, low = live, high = live, partial = true})
    end
    return points
end

-- Least-squares line through the averages of the last lastCount points (all when
-- nil): slope per month, the line's ends and firstIndex, the point it starts at.
function FFR_PriceHistoryManager:getTrend(points, lastCount)
    local firstIndex = math.max(1, #points - (lastCount or #points) + 1)
    local n = #points - firstIndex + 1
    if n < 2 then return nil end
    local sx, sy, sxx, sxy = 0, 0, 0, 0
    for i = 1, n do
        local p = points[firstIndex + i - 1]
        sx, sy = sx + i, sy + p.avg
        sxx, sxy = sxx + i * i, sxy + i * p.avg
    end
    local d = n * sxx - sx * sx
    if d == 0 then return nil end
    local slope = (n * sxy - sx * sy) / d
    local intercept = (sy - slope * sx) / n
    local mean = sy / n
    return {
        slope = slope, startValue = intercept + slope, endValue = intercept + slope * n, firstIndex = firstIndex,
        percentPerMonth = mean > 0 and slope / mean or 0
    }
end

function FFR_PriceHistoryManager:getCalendar()
    if g_currentMission == nil or g_currentMission.environment == nil then return nil, nil end
    local e = g_currentMission.environment
    return tonumber(e.currentPeriod), tonumber(e.currentYear)
end

--------------------------------------------------
-- Save / load (server) and snapshot (clients)
--------------------------------------------------

function FFR_PriceHistoryManager:saveToXML(xmlFile, key)
    if self.period ~= nil then
        setXMLInt(xmlFile, key .. "#period", self.period)
        setXMLInt(xmlFile, key .. "#year", self.year or 0)
    end
    local i = 0
    for name, entry in pairs(self.history) do
        local base = string.format("%s.commodity(%d)", key, i)
        local c = entry.current or {}
        setXMLString(xmlFile, base .. "#name", tostring(name))
        setXMLFloat(xmlFile, base .. "#sum", tonumber(c.sum) or 0)
        setXMLInt(xmlFile, base .. "#count", tonumber(c.count) or 0)
        setXMLFloat(xmlFile, base .. "#low", tonumber(c.low) or 0)
        setXMLFloat(xmlFile, base .. "#high", tonumber(c.high) or 0)
        for j, m in ipairs(entry.months or {}) do
            local mk = string.format("%s.month(%d)", base, j - 1)
            setXMLInt(xmlFile, mk .. "#period", tonumber(m.period) or 0)
            setXMLInt(xmlFile, mk .. "#year", tonumber(m.year) or 0)
            setXMLFloat(xmlFile, mk .. "#avg", tonumber(m.avg) or 0)
            setXMLFloat(xmlFile, mk .. "#low", tonumber(m.low) or 0)
            setXMLFloat(xmlFile, mk .. "#high", tonumber(m.high) or 0)
        end
        i = i + 1
    end
end

function FFR_PriceHistoryManager:loadFromXML(xmlFile, key)
    self.history = {}
    self.period = getXMLInt(xmlFile, key .. "#period")
    self.year = getXMLInt(xmlFile, key .. "#year")
    local i = 0
    while true do
        local base = string.format("%s.commodity(%d)", key, i)
        if not hasXMLProperty(xmlFile, base) then break end
        local name = getXMLString(xmlFile, base .. "#name")
        if name ~= nil then
            local entry = self:getEntry(name)
            entry.current = {
                sum = getXMLFloat(xmlFile, base .. "#sum") or 0,
                count = getXMLInt(xmlFile, base .. "#count") or 0,
                low = getXMLFloat(xmlFile, base .. "#low") or 0,
                high = getXMLFloat(xmlFile, base .. "#high") or 0
            }
            local j = 0
            while true do
                local mk = string.format("%s.month(%d)", base, j)
                if not hasXMLProperty(xmlFile, mk) then break end
                table.insert(entry.months, {
                    period = getXMLInt(xmlFile, mk .. "#period") or 0,
                    year = getXMLInt(xmlFile, mk .. "#year") or 0,
                    avg = getXMLFloat(xmlFile, mk .. "#avg") or 0,
                    low = getXMLFloat(xmlFile, mk .. "#low") or 0,
                    high = getXMLFloat(xmlFile, mk .. "#high") or 0
                })
                j = j + 1
            end
        end
        i = i + 1
    end
    self.version = self.version + 1
    Logging.info("FFR Price History: %d commodities restored", i)
end

-- Closed months only, as many as the chart shows (keeps the snapshot small).
function FFR_PriceHistoryManager:getSnapshot()
    local data = {}
    for name, entry in pairs(self.history) do
        local months = entry.months or {}
        local recent = {}
        for i = math.max(1, #months - FFR_PriceHistoryManager.CHART_MONTHS + 1), #months do
            table.insert(recent, months[i])
        end
        data[name] = recent
    end
    return {period = self.period or 0, year = self.year or 0, months = data}
end

function FFR_PriceHistoryManager:applySnapshot(data)
    if type(data) ~= "table" or type(data.months) ~= "table" then return end
    for name, months in pairs(data.months) do
        if type(months) == "table" then self:getEntry(name).months = months end
    end
    if tonumber(data.period) ~= nil and tonumber(data.period) > 0 then
        self.period, self.year = tonumber(data.period), tonumber(data.year)
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

function FFR_PriceHistoryManager:update(dt)
    self.updateTimer = self.updateTimer + dt
    if self.updateTimer < 1000 then return end
    self.updateTimer = 0
    if g_FFR == nil or not g_FFR.isInitialized or g_FFR.isDeleted then return end
    -- Samples are taken on the server only; clients get the closed months.
    if FFR_Network ~= nil and FFR_Network.isClientOnly() then return end
    local period, year = self:getCalendar()
    if period == nil or year == nil or period < 1 then return end
    local hour = tonumber(g_currentMission.environment.currentHour)
    if self.period == nil then
        self.period, self.year = period, year
    elseif self.period ~= period or self.year ~= year then
        self:closeMonth()
        self.period, self.year = period, year
        self.lastHour = nil
    end
    if hour ~= nil and hour ~= self.lastHour then
        self.lastHour = hour
        self:sample()
    end
end

function FFR_PriceHistoryManager:loadMap(mapName)
    self.history = {}
    self.period, self.year, self.lastHour = nil, nil, nil
    self.updateTimer = 0
end

function FFR_PriceHistoryManager:deleteMap() self.history = {} end
function FFR_PriceHistoryManager:draw() end
function FFR_PriceHistoryManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_PriceHistoryManager:keyEvent(unicode, sym, modifier, isDown) end

g_FFRPriceHistory = FFR_PriceHistoryManager:new()
addModEventListener(g_FFRPriceHistory)
Logging.info("FFR Price History: Monthly recorder installed")
