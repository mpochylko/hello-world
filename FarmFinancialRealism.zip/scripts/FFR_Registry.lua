FFR_Registry = {}

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_Registry:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_Registry}
    )

    self.crops = {}
    self.farmland = {}
    self.vehicles = {}

    return self

end

--------------------------------------------------
-- FillType Scanner
--------------------------------------------------

function FFR_Registry:scanFillTypes()

    Logging.info("FFR: Scanning FillTypes")

    if g_fillTypeManager == nil then

        Logging.warning(
            "FFR: FillType Manager is not available"
        )

        return

    end

    local fillTypes =
        g_fillTypeManager:getFillTypes()

    if fillTypes == nil then

        Logging.warning(
            "FFR: FillType table is not available"
        )

        return

    end

    self.crops = {}

    local count = 0

    for _, fillType in pairs(fillTypes) do

        if fillType ~= nil
            and fillType.name ~= nil
        then

            local name =
                tostring(fillType.name)

            self.crops[name] = {

                name = name,

                index =
                    fillType.index or 0

            }

            count = count + 1

        end

    end

    Logging.info(
        "FFR FillType Scan Complete: "
        .. tostring(count)
    )

end

--------------------------------------------------
-- Farmland Scanner
--------------------------------------------------

function FFR_Registry:scanFarmland()

    Logging.info("FFR: Scanning Farmland")

    self.farmland = {}

    if g_farmlandManager == nil then

        Logging.info(
            "FFR: Farmland Manager is not ready"
        )

        return

    end

    local farmlands =
        g_farmlandManager.farmlands

    if farmlands == nil then

        Logging.info(
            "FFR: Farmland table is not ready"
        )

        return

    end

    local count = 0

    for id, farmland in pairs(farmlands) do

        if farmland ~= nil then

            local price =
                farmland.price or 0

            self.farmland[id] = {

                id = id,

                price = price,

                isOwned = false

            }

            count = count + 1

        end

    end

    Logging.info(
        "FFR Farmland Scan Complete: "
        .. tostring(count)
    )

end

--------------------------------------------------
-- Vehicle Scanner
--------------------------------------------------

function FFR_Registry:scanVehicles()

    Logging.info("FFR: Scanning Vehicles")

    self.vehicles = {}

    if g_currentMission == nil then

        Logging.info(
            "FFR: Current Mission is not ready"
        )

        return

    end

    --------------------------------------------------
    -- FS25 keeps vehicles in the vehicle system.
    --------------------------------------------------

    local vehicles =
        g_currentMission.vehicles

    if vehicles == nil
        and g_currentMission.vehicleSystem ~= nil
    then

        vehicles =
            g_currentMission.vehicleSystem.vehicles

    end

    if vehicles == nil then

        Logging.info(
            "FFR: Vehicle table is not ready"
        )

        return

    end

    local count = 0

    for _, vehicle in pairs(vehicles) do

        if vehicle ~= nil then

            local name =
                "UNKNOWN"

            if vehicle.getName ~= nil then

                local vehicleName =
                    vehicle:getName()

                if vehicleName ~= nil then
                    name = tostring(vehicleName)
                end

            end

            table.insert(
                self.vehicles,
                {
                    name = name,
                    vehicle = vehicle
                }
            )

            count = count + 1

        end

    end

    Logging.info(
        "FFR Vehicle Scan Complete: "
        .. tostring(count)
    )

end

--------------------------------------------------
-- Count Helper
--------------------------------------------------

function FFR_Registry:getTableCount(data)

    if data == nil then
        return 0
    end

    local count = 0

    for _ in pairs(data) do
        count = count + 1
    end

    return count

end

--------------------------------------------------
-- Summary
--------------------------------------------------

function FFR_Registry:printSummary()

    local cropCount =
        self:getTableCount(
            self.crops
        )

    local farmlandCount =
        self:getTableCount(
            self.farmland
        )

    local vehicleCount =
        #self.vehicles

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR REGISTRY SUMMARY"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Detected FillTypes: "
        .. tostring(cropCount)
    )

    Logging.info(
        "Detected Farmland: "
        .. tostring(farmlandCount)
    )

    Logging.info(
        "Detected Vehicles: "
        .. tostring(vehicleCount)
    )

    Logging.info(
        "========================================"
    )

end