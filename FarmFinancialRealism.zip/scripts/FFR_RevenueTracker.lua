FFR_RevenueTracker = {}

--------------------------------------------------
-- Runtime State
--------------------------------------------------

FFR_RevenueTracker.isInstalled = false

-- Set while FFR itself charges the farm so its own
-- overhead is not counted twice as a native expense.
FFR_RevenueTracker.isApplyingFFRCharge = false

FFR_RevenueTracker.trackedCount = 0

--------------------------------------------------
-- Capital Money Types
--
-- Buying or selling land, vehicles and buildings
-- moves value between cash and assets. It is not
-- operating income or expense, so it stays out of
-- annual profit (and income tax). Names are looked
-- up defensively; a type the game does not define
-- is simply skipped.
--------------------------------------------------

FFR_RevenueTracker.CAPITAL_MONEY_TYPES = {
    "SHOP_VEHICLE_BUY",
    "SHOP_VEHICLE_SELL",
    "SHOP_PROPERTY_BUY",
    "SHOP_PROPERTY_SELL",
    "FIELD_BUY",
    "FIELD_SELL",
    "LOAN",
    "TRANSFER"
}

function FFR_RevenueTracker:isCapitalMoneyType(
    moneyType
)

    if moneyType == nil
        or MoneyType == nil
    then

        return false

    end

    for _, typeName in ipairs(
        self.CAPITAL_MONEY_TYPES
    ) do

        local capitalType =
            MoneyType[typeName]

        if capitalType ~= nil
            and moneyType == capitalType
        then

            return true

        end

    end

    return false

end

--------------------------------------------------
-- Money Hook
--------------------------------------------------

function FFR_RevenueTracker.onAddMoney(
    mission,
    amount,
    farmId,
    moneyType,
    ...
)

    if FFR_RevenueTracker.isApplyingFFRCharge then
        return
    end

    if g_FFR == nil
        or not g_FFR.isInitialized
        or g_FFR.isDeleted
        or g_FFR.getFarmState == nil
    then

        return

    end

    --------------------------------------------------
    -- Booked to whichever farm the money belongs to
    -- (the spectator farm and invalid ids give nil).
    --------------------------------------------------

    local state =
        g_FFR:getFarmState(farmId)

    if state == nil then
        return
    end

    local safeAmount =
        tonumber(amount)

    if safeAmount == nil
        or safeAmount == 0
    then

        return

    end

    if FFR_RevenueTracker:isCapitalMoneyType(
        moneyType
    ) then

        return

    end

    local financial =
        state.financialManager

    if safeAmount > 0 then

        financial.monthlyRevenue =
            (tonumber(financial.monthlyRevenue) or 0)
            + safeAmount

        financial.annualRevenue =
            (tonumber(financial.annualRevenue) or 0)
            + safeAmount

    else

        financial.monthlyExpenses =
            (tonumber(financial.monthlyExpenses) or 0)
            - safeAmount

        financial.annualExpenses =
            (tonumber(financial.annualExpenses) or 0)
            - safeAmount

    end

    financial:updateAnnualProfit()

    FFR_RevenueTracker.trackedCount =
        FFR_RevenueTracker.trackedCount + 1

end

--------------------------------------------------
-- Install Hook
--------------------------------------------------

function FFR_RevenueTracker:install()

    if self.isInstalled then
        return true
    end

    if FSBaseMission == nil
        or FSBaseMission.addMoney == nil
    then

        Logging.warning(
            "FFR Revenue Tracker: FSBaseMission.addMoney unavailable; annual profit will not include game income"
        )

        return false

    end

    FSBaseMission.addMoney =

        Utils.appendedFunction(
            FSBaseMission.addMoney,
            FFR_RevenueTracker.onAddMoney
        )

    self.isInstalled = true

    Logging.info(
        "FFR Revenue Tracker: Money hook installed"
    )

    return true

end

FFR_RevenueTracker:install()
