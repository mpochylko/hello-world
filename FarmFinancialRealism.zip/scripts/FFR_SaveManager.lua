FFR_SaveManager = {}

--------------------------------------------------
-- FFR save file
--
-- Everything FFR keeps is in one file next to the
-- savegame, FFR_economy.xml, written only together
-- with the native save:
--
-- * general#formatVersion says how the file is laid
--   out (FORMAT_VERSION); older files are migrated
--   on load (single-farm saves, separate land-title
--   and household files);
-- * general#complete is written last, so a file cut
--   off half-way (crash, full disk) is recognised;
-- * before each save the last good file is kept as
--   FFR_economy.backup.xml, and a damaged or
--   incomplete main file is replaced by it on load;
-- * after each save and load a one-line report
--   counts what was written / restored per system,
--   so log.txt shows at a glance that nothing is lost.
--------------------------------------------------

-- 3: one file for everything (land titles inside, completion marker, backup).
-- 4: equipment loans per farm (farm.equipmentFinance); older files have none.
-- 5: crop policy lists insured crops and billed parcels (policy.crop / policy.billed,
--    policy#allCrops); an older policy has none and covers every crop.
-- 6: land market index, land auctions and per-farm land rentals (farm.landRent);
--    older files have none (index 100 %, no rentals, first auction scheduled fresh).
FFR_SaveManager.FORMAT_VERSION = 6

FFR_SaveManager.MOD_NAME = g_currentModName

--------------------------------------------------
-- Constructor
--------------------------------------------------

function FFR_SaveManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_SaveManager}
    )

    self.fileName =
        "FFR_economy.xml"

    self.rootKey =
        "ffrEconomy"

    self.backupFileName =
        "FFR_economy.backup.xml"

    -- The mod version that wrote the file (modDesc), for the log.
    self.version =
        FFR_SaveManager.getModVersion()

    self.savegameDirectory = nil

    self.filePath = nil

    self.hasLoaded = false

    self.hasSaveFile = false

    self.lastSaveSuccessful = false

    self.isDirty = false

    return self

end

function FFR_SaveManager.getModVersion()

    if g_modManager ~= nil
        and g_modManager.getModByName ~= nil
        and FFR_SaveManager.MOD_NAME ~= nil
    then

        local ok, mod = pcall(g_modManager.getModByName, g_modManager, FFR_SaveManager.MOD_NAME)

        if ok and mod ~= nil and mod.version ~= nil then
            return tostring(mod.version)
        end

    end

    return "unknown"

end

--------------------------------------------------
-- Request Save
--
-- Mid-game changes only mark the state dirty. The
-- file is written by the native savegame hook, so a
-- player who quits without saving gets FFR state that
-- still matches their savegame.
--------------------------------------------------

function FFR_SaveManager:requestSave(
    ffr
)

    self.isDirty = true

    --------------------------------------------------
    -- Anything worth saving is worth showing to the
    -- other players: send a sync soon.
    --------------------------------------------------

    if FFR_Network ~= nil then
        FFR_Network.markDirty()
    end

    return true

end

--------------------------------------------------
-- Savegame Directory
--------------------------------------------------

function FFR_SaveManager:getSavegameDirectory()

    if self.savegameDirectory ~= nil then
        return self.savegameDirectory
    end

    if g_currentMission == nil then
        return nil
    end

    local missionInfo =
        g_currentMission.missionInfo

    if missionInfo == nil then
        return nil
    end

    local directory =
        missionInfo.savegameDirectory

    if directory == nil
        or directory == ""
    then

        return nil
    end

    self.savegameDirectory =
        directory

    return directory

end

--------------------------------------------------
-- Build File Path
--------------------------------------------------

function FFR_SaveManager:getFilePath()

    local directory =
        self:getSavegameDirectory()

    if directory == nil then
        return nil
    end

    self.filePath =

        directory

        .. "/"

        .. self.fileName

    return self.filePath

end

--------------------------------------------------
-- Safe Number
--------------------------------------------------

function FFR_SaveManager:getNumber(
    value,
    defaultValue
)

    local result =
        tonumber(value)

    if result == nil then

        return defaultValue or 0

    end

    return result

end

--------------------------------------------------
-- Safe String
--------------------------------------------------

function FFR_SaveManager:getString(
    value,
    defaultValue
)

    if value == nil then

        return defaultValue or ""

    end

    return tostring(value)

end

--------------------------------------------------
-- File Presence
--------------------------------------------------

function FFR_SaveManager:fileExists()

    local filePath =
        self:getFilePath()

    if filePath == nil then
        return false
    end

    if _G.fileExists == nil then
        return false
    end

    return _G.fileExists(
        filePath
    )

end

--------------------------------------------------
-- Write General Information
--------------------------------------------------

function FFR_SaveManager:writeGeneral(
    xmlFile,
    ffr
)

    local key =
        self.rootKey
        .. ".general"

    setXMLString(
        xmlFile,
        key .. "#version",
        self.version
    )

    setXMLBool(
        xmlFile,
        key .. "#initialized",
        true
    )

    setXMLInt(xmlFile, key .. "#formatVersion", FFR_SaveManager.FORMAT_VERSION)

    if ffr ~= nil and ffr.getGameCalendar ~= nil then

        local period, year = ffr:getGameCalendar()

        setXMLInt(xmlFile, key .. "#calendarPeriod", tonumber(period) or 0)
        setXMLInt(xmlFile, key .. "#calendarYear", tonumber(year) or 0)

    end

    if ffr ~= nil
        and ffr.gameIntegrationManager ~= nil
    then

        local farmId =

            ffr.gameIntegrationManager.activeFarmId

            or 0

        setXMLInt(
            xmlFile,
            key .. "#farmId",
            farmId
        )

    end

end

--------------------------------------------------
-- Write Commodity Market
--------------------------------------------------

function FFR_SaveManager:writeCommodityMarket(
    xmlFile,
    ffr
)

    if ffr == nil
        or ffr.commodityManager == nil
    then

        return

    end

    local commodityManager =
        ffr.commodityManager

    local marketEngine =
        ffr.marketEngine

    local marketKey =
        self.rootKey
        .. ".commodityMarket"

    if marketEngine ~= nil
        and marketEngine.activeEvent ~= nil
    then

        setXMLString(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#name",
            self:getString(
                marketEngine.activeEvent.name,
                ""
            )
        )

    end

    if marketEngine ~= nil
        and marketEngine.categoryModifiers ~= nil
    then

        local modifierIndex = 0

        for category, modifier in pairs(
            marketEngine.categoryModifiers
        ) do

            local key =

                string.format(
                    "%s.categoryModifiers.modifier(%d)",
                    marketKey,
                    modifierIndex
                )

            setXMLString(
                xmlFile,
                key .. "#category",
                tostring(category)
            )

            setXMLFloat(
                xmlFile,
                key .. "#value",
                self:getNumber(
                    modifier,
                    1.00
                )
            )

            modifierIndex =
                modifierIndex + 1

        end

    end

    local commodityIndex = 0

    for commodityName, commodity in pairs(
        commodityManager.commodities
    ) do

        local key =

            string.format(
                "%s.commodities.commodity(%d)",
                marketKey,
                commodityIndex
            )

        setXMLString(
            xmlFile,
            key .. "#name",
            tostring(commodityName)
        )

        setXMLString(
            xmlFile,
            key .. "#category",
            self:getString(
                commodity.category,
                "unknown"
            )
        )

        setXMLFloat(
            xmlFile,
            key .. "#basePrice",
            self:getNumber(
                commodity.basePrice,
                0
            )
        )

        setXMLFloat(
            xmlFile,
            key .. "#currentPrice",
            self:getNumber(
                commodity.currentPrice,
                0
            )
        )

        setXMLFloat(
            xmlFile,
            key .. "#priceModifier",
            self:getNumber(
                commodity.priceModifier,
                1.00
            )
        )

        setXMLFloat(
            xmlFile,
            key .. "#volatility",
            self:getNumber(
                commodity.volatility,
                1.00
            )
        )

        commodityIndex =
            commodityIndex + 1

    end

end

--------------------------------------------------
-- Write Input Market
--------------------------------------------------

function FFR_SaveManager:writeInputMarket(
    xmlFile,
    ffr
)

    if ffr == nil
        or ffr.inputMarket == nil
    then

        return

    end

    local inputMarket =
        ffr.inputMarket

    local marketKey =
        self.rootKey
        .. ".inputMarket"

    if inputMarket.activeEvent ~= nil then

        setXMLString(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#name",
            self:getString(
                inputMarket.activeEvent.name,
                ""
            )
        )

        setXMLInt(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#durationDays",
            math.floor(
                self:getNumber(
                    inputMarket.activeEvent.durationDays,
                    0
                )
            )
        )

        setXMLInt(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#expiryMonth",
            math.floor(
                self:getNumber(
                    inputMarket.activeEvent.expiryMonth,
                    0
                )
            )
        )

        setXMLInt(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#expiryYear",
            math.floor(
                self:getNumber(
                    inputMarket.activeEvent.expiryYear,
                    0
                )
            )
        )

        -- Brand programs are built at runtime, so their terms are saved in full.
        local event = inputMarket.activeEvent

        if event.brand ~= nil then

            local key = marketKey .. ".activeEvent"

            setXMLString(xmlFile, key .. "#brand", tostring(event.brand))
            setXMLString(xmlFile, key .. "#brandTitle", tostring(event.brandTitle or event.brand))
            setXMLString(xmlFile, key .. "#brandCategory", tostring(event.brandCategory or ""))
            setXMLInt(xmlFile, key .. "#brandDiscount", math.floor(self:getNumber(event.brandDiscount, 0)))

        end

    end

    local inputIndex = 0

    for inputName, inputData in pairs(
        inputMarket.inputs
    ) do

        local key =

            string.format(
                "%s.inputs.input(%d)",
                marketKey,
                inputIndex
            )

        setXMLString(
            xmlFile,
            key .. "#name",
            tostring(inputName)
        )

        setXMLFloat(
            xmlFile,
            key .. "#modifier",
            self:getNumber(
                inputData.modifier,
                1.00
            )
        )

        inputIndex =
            inputIndex + 1

    end

end

--------------------------------------------------
-- Write Financial State
--------------------------------------------------

-- keyOverride / managerOverride: one farm's section and object (per-farm save).
-- Without them: the top-level single-farm section of saves before v0.9.9.
function FFR_SaveManager:writeFinancialState(
    xmlFile,
    ffr,
    keyOverride,
    managerOverride
)

    if ffr == nil
        or ffr.financialManager == nil
    then

        return

    end

    local financial =
        managerOverride or ffr.financialManager

    local key =
        keyOverride or (self.rootKey .. ".financial")

    --------------------------------------------------
    -- Native FS25 already saves farm cash.
    -- FFR must not duplicate the cash balance.
    --------------------------------------------------

    setXMLFloat(
        xmlFile,
        key .. "#operatingLoan",
        self:getNumber(
            financial.operatingLoan,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#equipmentDebt",
        self:getNumber(
            financial.equipmentDebt,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#landDebt",
        self:getNumber(
            financial.landDebt,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#availableCredit",
        self:getNumber(
            financial.availableCredit,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyLandPayment",
        self:getNumber(
            financial.monthlyLandPayment,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyEquipmentPayment",
        self:getNumber(
            financial.monthlyEquipmentPayment,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyHouseholdCost",
        self:getNumber(
            financial.monthlyHouseholdCost,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyInsuranceCost",
        self:getNumber(
            financial.monthlyInsuranceCost,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyLeaseCost",
        self:getNumber(
            financial.monthlyLeaseCost,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#monthlyTaxCost",
        self:getNumber(
            financial.monthlyTaxCost,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#annualRevenue",
        self:getNumber(
            financial.annualRevenue,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#annualExpenses",
        self:getNumber(
            financial.annualExpenses,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#annualProfit",
        self:getNumber(
            financial.annualProfit,
            0
        )
    )

end

--------------------------------------------------
-- Write Credit State
--------------------------------------------------

-- keyOverride / managerOverride: one farm's section and object (per-farm save).
-- Without them: the top-level single-farm section of saves before v0.9.9.
function FFR_SaveManager:writeCreditState(
    xmlFile,
    ffr,
    keyOverride,
    managerOverride
)

    if ffr == nil
        or ffr.creditManager == nil
    then

        return

    end

    local credit =
        managerOverride or ffr.creditManager

    local key =
        keyOverride or (self.rootKey .. ".credit")

    setXMLInt(
        xmlFile,
        key .. "#creditScore",
        math.floor(
            self:getNumber(
                credit.creditScore,
                700
            )
        )
    )

    setXMLString(
        xmlFile,
        key .. "#creditRating",
        self:getString(
            credit.creditRating,
            "GOOD"
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#interestRateModifier",
        self:getNumber(
            credit.interestRateModifier,
            1.00
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#maxOperatingLoan",
        self:getNumber(
            credit.maxOperatingLoan,
            0
        )
    )

    setXMLFloat(
        xmlFile,
        key .. "#maxExpansionLoan",
        self:getNumber(
            credit.maxExpansionLoan,
            0
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#missedPayments",
        math.floor(
            self:getNumber(
                credit.missedPayments,
                0
            )
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#latePayments",
        math.floor(
            self:getNumber(
                credit.latePayments,
                0
            )
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#successfulYears",
        math.floor(
            self:getNumber(
                credit.successfulYears,
                0
            )
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#contractDefaults",
        math.floor(
            self:getNumber(
                credit.contractDefaults,
                0
            )
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#taxPenalties",
        math.floor(
            self:getNumber(
                credit.taxPenalties,
                0
            )
        )
    )

    setXMLInt(xmlFile, key .. ".insolvency#stage", math.floor(self:getNumber(credit.insolvencyStage, 0)))
    setXMLInt(xmlFile, key .. ".insolvency#monthsOverdrawn", math.floor(self:getNumber(credit.monthsOverdrawn, 0)))
    setXMLString(xmlFile, key .. ".insolvency#notice", self:getString(credit.insolvencyNotice, ""))
    setXMLFloat(xmlFile, key .. ".insolvency#forcedSaleTotal", self:getNumber(credit.forcedSaleTotal, 0))

    -- When each mark was recorded, so it can age out (FFR_CreditManager).
    if credit.saveMarks ~= nil then
        credit:saveMarks(xmlFile, key .. ".marks")
    end

end

--------------------------------------------------
-- Write Monthly Processing State
--
-- The calendar position is shared by all farms.
-- Per-farm totals are written in writeFarms.
--------------------------------------------------

function FFR_SaveManager:writeMonthlyState(
    xmlFile,
    ffr
)

    local processor =
        g_FFRMonthlyFinancialProcessor

    if processor == nil then
        return
    end

    local key =
        self.rootKey
        .. ".monthly"

    setXMLInt(
        xmlFile,
        key .. "#processedSerial",
        math.floor(
            self:getNumber(
                processor.processedSerial,
                0
            )
        )
    )

    setXMLInt(
        xmlFile,
        key .. "#lastYear",
        math.floor(
            self:getNumber(
                processor.lastYear,
                0
            )
        )
    )

end

--------------------------------------------------
-- Per-Farm Profiles
--
-- ffrEconomy.farms.farm(n)#farmId with each farm's
-- financial, credit, totals and household.
--------------------------------------------------

function FFR_SaveManager:writeFarms(
    xmlFile,
    ffr
)

    if ffr == nil
        or ffr.getFarmStates == nil
    then

        return

    end

    for index, state in ipairs(ffr:getFarmStates()) do

        local key =
            string.format("%s.farms.farm(%d)", self.rootKey, index - 1)

        setXMLInt(xmlFile, key .. "#farmId", state.farmId)

        self:writeFinancialState(xmlFile, ffr, key .. ".financial", state.financialManager)

        self:writeCreditState(xmlFile, ffr, key .. ".credit", state.creditManager)

        setXMLFloat(xmlFile, key .. ".totals#interestPaid", self:getNumber(state.bankingManager.totalInterestPaid, 0))
        setXMLFloat(xmlFile, key .. ".totals#premiumsPaid", self:getNumber(state.insuranceManager.totalPremiumsPaid, 0))
        setXMLFloat(xmlFile, key .. ".totals#taxesPaid", self:getNumber(state.taxManager.totalTaxesPaid, 0))
        setXMLFloat(xmlFile, key .. ".totals#lastMonthlyTotal", self:getNumber(state.lastMonthlyTotal, 0))
        setXMLFloat(xmlFile, key .. ".totals#maintenanceDue", self:getNumber(state.propertyMaintenanceDue, 0))
        for _, line in ipairs(FFR_MonthlyFinancialProcessor.YEAR_COST_LINES) do
            setXMLFloat(xmlFile, key .. ".yearCosts#" .. line, self:getNumber((state.yearCosts or {})[line], 0))
        end
        setXMLInt(xmlFile, key .. ".totals#yearsCompleted", math.floor(self:getNumber(state.yearManager.totalYearsCompleted, 0)))

        state.familyManager:saveToXML(xmlFile, key .. ".household")

        self:writeRecords(xmlFile, key .. ".statements.month", state.statements, FFR_SaveManager.STATEMENT_FIELDS)

        self:writeRecords(xmlFile, key .. ".years.year", state.years, FFR_SaveManager.YEAR_FIELDS)

        if FFR_CropInsuranceManager ~= nil then
            FFR_CropInsuranceManager.saveFarm(xmlFile, key .. ".cropInsurance", state)
        end

        if FFR_LivestockInsuranceManager ~= nil then
            FFR_LivestockInsuranceManager.saveFarm(xmlFile, key .. ".livestockInsurance", state)
        end

        if FFR_LandRentManager ~= nil then
            FFR_LandRentManager.saveFarm(xmlFile, key .. ".landRent", state)
        end

        if FFR_EquipmentFinanceManager ~= nil then
            FFR_EquipmentFinanceManager.saveFarm(xmlFile, key .. ".equipmentFinance", state)
        end

    end

end

--------------------------------------------------
-- Farm Status statements (lists of flat number
-- records, see FFR_MonthlyFinancialProcessor)
--------------------------------------------------

FFR_SaveManager.STATEMENT_FIELDS = {
    "period", "year", "revenue", "expenses", "overhead", "principal",
    "tax", "net", "cash", "netWorth", "debt", "stage"
}

FFR_SaveManager.YEAR_FIELDS = {
    "year", "revenue", "expenses", "taxes", "profit", "netWorth", "debt"
}

function FFR_SaveManager:writeRecords(
    xmlFile,
    baseKey,
    records,
    fields
)

    for index, record in ipairs(records or {}) do

        local key = string.format("%s(%d)", baseKey, index - 1)

        for _, field in ipairs(fields) do
            setXMLFloat(xmlFile, key .. "#" .. field, self:getNumber(record[field], 0))
        end

    end

end

function FFR_SaveManager:readRecords(
    xmlFile,
    baseKey,
    fields
)

    local records = {}

    local index = 0

    while true do

        local key = string.format("%s(%d)", baseKey, index)

        if not hasXMLProperty(xmlFile, key) then
            break
        end

        local record = {}

        for _, field in ipairs(fields) do
            record[field] = getXMLFloat(xmlFile, key .. "#" .. field) or 0
        end

        table.insert(records, record)

        index = index + 1

    end

    return records

end

-- Returns true if the file has per-farm sections (v0.9.9 and later).
function FFR_SaveManager:readFarms(
    xmlFile,
    ffr
)

    local index = 0

    local found = false

    while true do

        local key =
            string.format("%s.farms.farm(%d)", self.rootKey, index)

        if not hasXMLProperty(xmlFile, key) then
            break
        end

        local state =
            ffr:getFarmState(getXMLInt(xmlFile, key .. "#farmId"))

        if state ~= nil then

            self:readFinancialState(xmlFile, ffr, key .. ".financial", state.financialManager)

            self:readCreditState(xmlFile, ffr, key .. ".credit", state.creditManager)

            state.bankingManager.totalInterestPaid = getXMLFloat(xmlFile, key .. ".totals#interestPaid") or 0
            state.insuranceManager.totalPremiumsPaid = getXMLFloat(xmlFile, key .. ".totals#premiumsPaid") or 0
            state.taxManager.totalTaxesPaid = getXMLFloat(xmlFile, key .. ".totals#taxesPaid") or 0
            state.lastMonthlyTotal = getXMLFloat(xmlFile, key .. ".totals#lastMonthlyTotal") or 0
            state.propertyMaintenanceDue = getXMLFloat(xmlFile, key .. ".totals#maintenanceDue") or 0
            state.yearCosts = {}
            for _, line in ipairs(FFR_MonthlyFinancialProcessor.YEAR_COST_LINES) do
                state.yearCosts[line] = getXMLFloat(xmlFile, key .. ".yearCosts#" .. line) or 0
            end
            state.yearManager.totalYearsCompleted = getXMLInt(xmlFile, key .. ".totals#yearsCompleted") or 0

            state.householdLoaded =
                state.familyManager:loadFromXML(xmlFile, key .. ".household")

            state.statements = self:readRecords(xmlFile, key .. ".statements.month", FFR_SaveManager.STATEMENT_FIELDS)

            state.years = self:readRecords(xmlFile, key .. ".years.year", FFR_SaveManager.YEAR_FIELDS)

            if FFR_CropInsuranceManager ~= nil then
                FFR_CropInsuranceManager.loadFarm(xmlFile, key .. ".cropInsurance", state)
            end

            if FFR_LivestockInsuranceManager ~= nil then
                FFR_LivestockInsuranceManager.loadFarm(xmlFile, key .. ".livestockInsurance", state)
            end

            -- After the financial state: the loans set the equipment totals.
            if FFR_LandRentManager ~= nil then
                FFR_LandRentManager.loadFarm(xmlFile, key .. ".landRent", state)
            end

            if FFR_EquipmentFinanceManager ~= nil then
                FFR_EquipmentFinanceManager.loadFarm(xmlFile, key .. ".equipmentFinance", state)
            end

            found = true

        end

        index = index + 1

    end

    return found

end

-- Saves before v0.9.9 held one farm at the top level; it becomes the default farm.
function FFR_SaveManager:migrateSingleFarm(
    xmlFile,
    ffr
)

    local state =
        ffr:getFarmState(FFR_FarmState.getDefaultFarmId())

    if state == nil then
        return
    end

    if hasXMLProperty(xmlFile, self.rootKey .. ".financial") then
        self:readFinancialState(xmlFile, ffr, nil, state.financialManager)
    end

    if hasXMLProperty(xmlFile, self.rootKey .. ".credit") then
        self:readCreditState(xmlFile, ffr, nil, state.creditManager)
    end

    local monthly = self.loadedMonthlyState

    if monthly ~= nil then

        state.bankingManager.totalInterestPaid = tonumber(monthly.totalInterestPaid) or 0
        state.insuranceManager.totalPremiumsPaid = tonumber(monthly.totalPremiumsPaid) or 0
        state.taxManager.totalTaxesPaid = tonumber(monthly.totalTaxesPaid) or 0
        state.lastMonthlyTotal = tonumber(monthly.lastMonthlyTotal) or 0

    end

    -- The household lived in its own file before v0.9.9.
    state.householdLoaded = state.familyManager:load()

    Logging.info(
        "FFR Load: Single-farm save migrated to farm %d",
        state.farmId
    )

end

function FFR_SaveManager:readMonthlyState(
    xmlFile,
    ffr
)

    local key =
        self.rootKey
        .. ".monthly"

    if not hasXMLProperty(
        xmlFile,
        key
    ) then

        return

    end

    self.loadedMonthlyState = {

        processedSerial =
            getXMLInt(
                xmlFile,
                key .. "#processedSerial"
            ),

        lastYear =
            getXMLInt(
                xmlFile,
                key .. "#lastYear"
            ),

        lastMonthlyTotal =
            getXMLFloat(
                xmlFile,
                key .. "#lastMonthlyTotal"
            ),

        totalInterestPaid =
            getXMLFloat(
                xmlFile,
                key .. "#totalInterestPaid"
            ),

        totalPremiumsPaid =
            getXMLFloat(
                xmlFile,
                key .. "#totalPremiumsPaid"
            ),

        totalTaxesPaid =
            getXMLFloat(
                xmlFile,
                key .. "#totalTaxesPaid"
            )

    }

end

--------------------------------------------------
-- Save All FFR State
--------------------------------------------------

function FFR_SaveManager:save(
    ffr
)

    local filePath =
        self:getFilePath()

    if filePath == nil then

        Logging.warning(
            "FFR Save: Savegame directory is unavailable"
        )

        self.lastSaveSuccessful = false

        return false

    end

    -- Keep the last good file before overwriting it.
    self:backupCurrentFile()

    local xmlFile =

        createXMLFile(
            "FFREconomy",
            filePath,
            self.rootKey
        )

    if xmlFile == nil
        or xmlFile == 0
    then

        Logging.error(
            "FFR Save: Could not create FFR_economy.xml"
        )

        self.lastSaveSuccessful = false

        return false

    end

    self:writeGeneral(
        xmlFile,
        ffr
    )

    self:writeCommodityMarket(
        xmlFile,
        ffr
    )

    self:writeInputMarket(
        xmlFile,
        ffr
    )

    self:writeFarms(
        xmlFile,
        ffr
    )

    self:writeMonthlyState(
        xmlFile,
        ffr
    )

    if FFR_Settings ~= nil then
        FFR_Settings.saveToXML(xmlFile, self.rootKey .. ".settings")
    end

    if g_FFRPriceHistory ~= nil then
        g_FFRPriceHistory:saveToXML(xmlFile, self.rootKey .. ".priceHistory")
    end

    if FFR_InputClassifier ~= nil then
        FFR_InputClassifier.saveToXML(xmlFile, self.rootKey .. ".inputClasses")
    end

    if FFR_UnitManager ~= nil then
        FFR_UnitManager.saveToXML(xmlFile, self.rootKey .. ".units")
    end

    if FFR_LandMarketManager ~= nil then
        FFR_LandMarketManager.saveToXML(xmlFile, self.rootKey .. ".landMarket")
    end

    if FFR_LandAuctionManager ~= nil then
        FFR_LandAuctionManager.saveToXML(xmlFile, self.rootKey .. ".landAuctions")
    end

    if FFR_CropDamageManager ~= nil then
        FFR_CropDamageManager.saveToXML(xmlFile, self.rootKey .. ".cropDamage")
    end

    if ffr ~= nil
        and ffr.contractManager ~= nil
    then

        ffr.contractManager:saveToXML(
            xmlFile,
            self.rootKey .. ".contracts"
        )

    end

    self:writeDynamicEvent(xmlFile, ffr)

    -- Land titles live in this file since format 3 (was FFR_landRegistry.xml).
    if g_FFRLandRegistryManager ~= nil then
        g_FFRLandRegistryManager:saveToXML(xmlFile, self.rootKey .. ".landRegistry")
    end

    -- Written last: a file without it was cut off and is not trusted on load.
    setXMLBool(xmlFile, self.rootKey .. ".general#complete", true)

    local success =
        saveXMLFile(
            xmlFile
        )

    delete(
        xmlFile
    )

    self.lastSaveSuccessful =
        success == true

    self.hasSaveFile =
        self.lastSaveSuccessful

    -- Reopen what was written: it must parse and carry the completion marker.
    if self.lastSaveSuccessful and not self:isValidFile(filePath) then
        self.lastSaveSuccessful = false
    end

    self.hasSaveFile = self.lastSaveSuccessful

    if self.lastSaveSuccessful then

        self.isDirty = false

        Logging.info(
            "FFR Save: Saved (format %d, mod %s) - %s",
            FFR_SaveManager.FORMAT_VERSION,
            tostring(self.version),
            self:getReport(ffr)
        )

    else

        Logging.error(
            "FFR Save: Failed to save economy state; the backup from the previous save is kept"
        )

    end

    return self.lastSaveSuccessful

end

--------------------------------------------------
-- Integrity and backup
--------------------------------------------------

function FFR_SaveManager:getBackupPath()

    local directory = self:getSavegameDirectory()

    if directory == nil then
        return nil
    end

    return directory .. "/" .. self.backupFileName

end

-- A file FFR can trust: it parses, has the root, and was finished. Files from
-- before format 3 have no completion marker; their "initialized" flag counts.
function FFR_SaveManager:isValidFile(path)

    if path == nil or _G.fileExists == nil or not _G.fileExists(path) then
        return false
    end

    local xmlFile = loadXMLFile("FFREconomyCheck", path)

    if xmlFile == nil or xmlFile == 0 then
        return false
    end

    local key = self.rootKey .. ".general"
    local format = getXMLInt(xmlFile, key .. "#formatVersion")
    local valid

    if format ~= nil and format >= 3 then
        valid = getXMLBool(xmlFile, key .. "#complete") == true
    else
        valid = getXMLBool(xmlFile, key .. "#initialized") == true
    end

    delete(xmlFile)

    return valid

end

-- Copies the current file to the backup, only if it is a good one.
function FFR_SaveManager:backupCurrentFile()

    local path = self:getFilePath()
    local backup = self:getBackupPath()

    if backup == nil or not self:isValidFile(path) then
        return false
    end

    local ok = false

    if copyFile ~= nil then
        ok = pcall(copyFile, path, backup, true)
    end

    if not ok and saveXMLFileTo ~= nil then

        local xmlFile = loadXMLFile("FFREconomyBackup", path)

        if xmlFile ~= nil and xmlFile ~= 0 then
            ok = pcall(saveXMLFileTo, xmlFile, backup)
            delete(xmlFile)
        end

    end

    if not ok then
        Logging.warning("FFR Save: Could not keep a backup of the previous save")
    end

    return ok

end

--------------------------------------------------
-- Market event state (folded in from the old
-- FFR_MarketEventPersistence patch file)
--------------------------------------------------

function FFR_SaveManager:writeDynamicEvent(xmlFile, ffr)

    if ffr == nil or ffr.marketEngine == nil or ffr.marketEngine.activeEvent == nil then
        return
    end

    local engine = ffr.marketEngine
    local event = engine.activeEvent
    local key = self.rootKey .. ".commodityMarket.dynamicEvent"

    setXMLString(xmlFile, key .. "#id", tostring(event.id or event.name or ""))
    setXMLString(xmlFile, key .. "#name", tostring(event.name or ""))
    setXMLString(xmlFile, key .. "#description", tostring(event.description or ""))
    setXMLString(xmlFile, key .. "#severity", tostring(event.severity or "LEGACY"))
    setXMLString(xmlFile, key .. "#phase", tostring(event.phase or "ACTIVE"))

    for _, field in ipairs({"startPeriod", "startYear", "expiryPeriod", "expiryYear", "durationMonths", "elapsedMonths"}) do
        setXMLInt(xmlFile, key .. "#" .. field, tonumber(event[field]) or 0)
    end

    setXMLInt(xmlFile, key .. "#lastProcessedPeriod", tonumber(engine.lastProcessedPeriod) or 0)
    setXMLInt(xmlFile, key .. "#lastProcessedYear", tonumber(engine.lastProcessedYear) or 0)

    local lists = {
        {"peakAdjustment", event.peakAdjustments, "value", setXMLFloat},
        {"cooldown", engine.cooldowns, "untilSerial", setXMLInt},
        {"recovery", engine.recoveryProtection, "untilSerial", setXMLInt}
    }

    for _, list in ipairs(lists) do

        local index = 0

        for category, value in pairs(list[2] or {}) do

            local itemKey = string.format("%s.%s(%d)", key, list[1], index)

            setXMLString(xmlFile, itemKey .. "#category", tostring(category))
            list[4](xmlFile, itemKey .. "#" .. list[3], tonumber(value) or 0)

            index = index + 1

        end

    end

end

function FFR_SaveManager:readDynamicEvent(xmlFile, ffr)

    if ffr == nil or ffr.marketEngine == nil then
        return
    end

    local engine = ffr.marketEngine
    local key = self.rootKey .. ".commodityMarket.dynamicEvent"

    if not hasXMLProperty(xmlFile, key) then
        return
    end

    local event = {
        id = getXMLString(xmlFile, key .. "#id"),
        name = getXMLString(xmlFile, key .. "#name"),
        description = getXMLString(xmlFile, key .. "#description"),
        severity = getXMLString(xmlFile, key .. "#severity"),
        phase = getXMLString(xmlFile, key .. "#phase"),
        peakAdjustments = {},
        currentAdjustments = {}
    }

    for _, field in ipairs({"startPeriod", "startYear", "expiryPeriod", "expiryYear", "durationMonths", "elapsedMonths"}) do
        event[field] = getXMLInt(xmlFile, key .. "#" .. field) or 0
    end

    event.durationMonths = math.max(1, event.durationMonths)

    local function readList(name, field, getter)

        local result = {}
        local index = 0

        while true do

            local itemKey = string.format("%s.%s(%d)", key, name, index)

            if not hasXMLProperty(xmlFile, itemKey) then
                break
            end

            local category = getXMLString(xmlFile, itemKey .. "#category")
            local value = getter(xmlFile, itemKey .. "#" .. field)

            if category ~= nil and value ~= nil then
                result[category] = value
            end

            index = index + 1

        end

        return result

    end

    event.peakAdjustments = readList("peakAdjustment", "value", getXMLFloat)
    engine.cooldowns = readList("cooldown", "untilSerial", getXMLInt)
    engine.recoveryProtection = readList("recovery", "untilSerial", getXMLInt)
    engine.lastProcessedPeriod = getXMLInt(xmlFile, key .. "#lastProcessedPeriod") or 0
    engine.lastProcessedYear = getXMLInt(xmlFile, key .. "#lastProcessedYear") or 0
    engine.activeEvent = event
    engine:recalculateCurrentAdjustments()

end

--------------------------------------------------
-- Report: what was saved / restored, one line
--------------------------------------------------

function FFR_SaveManager:getReport(ffr)

    if ffr == nil or ffr.getFarmStates == nil then
        return "no data"
    end

    local farms, statements, cropPolicies, herdPolicies, claims, equipmentLoans, rentals = 0, 0, 0, 0, 0, 0, 0

    for _, state in ipairs(ffr:getFarmStates()) do

        farms = farms + 1
        statements = statements + #(state.statements or {})

        for _, loan in ipairs(state.equipmentLoans or {}) do
            if loan.status == "ACTIVE" then equipmentLoans = equipmentLoans + 1 end
        end

        cropPolicies = cropPolicies + #(state.cropPolicies or {})
        if FFR_LandRentManager ~= nil then rentals = rentals + FFR_LandRentManager.countOpen(state) end
        if state.herdPolicy ~= nil then herdPolicies = herdPolicies + 1 end

        claims = claims + #(state.cropClaims or {}) + #(state.herdClaims or {})

    end

    local function count(t)
        local n = 0
        for _ in pairs(t or {}) do n = n + 1 end
        return n
    end

    local history = g_FFRPriceHistory ~= nil and count(g_FFRPriceHistory.history) or 0
    local titles = g_FFRLandRegistryManager ~= nil and count(g_FFRLandRegistryManager.registrations) or 0
    local damage = FFR_CropDamageManager ~= nil and count(FFR_CropDamageManager.records) or 0
    local classes = FFR_InputClassifier ~= nil and count(FFR_InputClassifier.overrides) or 0
    local contracts = ffr.contractManager ~= nil and #(ffr.contractManager.contracts or {}) or 0

    return string.format(
        "%d farm(s), %d contract(s), %d land title(s), %d statement(s), %d crop / %d herd polic(ies), %d claim(s), %d equipment loan(s), %d damaged field(s), %d price histor(ies), %d input class override(s), %d land rental(s), land index %d %%, difficulty %s, units %s",
        farms, contracts, titles, statements, cropPolicies, herdPolicies, claims, equipmentLoans, damage, history, classes,
        rentals, FFR_LandMarketManager ~= nil and math.floor(FFR_LandMarketManager.index * 100 + 0.5) or 100,
        FFR_Settings ~= nil and tostring(FFR_Settings.difficulty) or "-",
        FFR_UnitManager ~= nil and FFR_UnitManager.getReport() or "-"
    )

end

--------------------------------------------------
-- Restore Commodity Event
--------------------------------------------------

function FFR_SaveManager:restoreMarketEvent(
    marketEngine,
    eventName
)

    if marketEngine == nil
        or eventName == nil
        or eventName == ""
    then

        return false

    end

    local events =
        marketEngine:getEvents()

    if events == nil then
        return false
    end

    for _, event in pairs(events) do

        if event.name == eventName then

            marketEngine.activeEvent =
                event

            return true

        end

    end

    --------------------------------------------------
    -- Normal for generated events (e.g. Stable
    -- Markets); the full event is restored from the
    -- dynamicEvent block right after this.
    --------------------------------------------------

    Logging.info(
        "FFR Load: Market event is not a fixed template; restoring from saved event data"
    )

    return false

end

--------------------------------------------------
-- Restore Input Event
--------------------------------------------------

function FFR_SaveManager:restoreInputEvent(
    inputMarket,
    eventName
)

    if inputMarket == nil
        or eventName == nil
        or eventName == ""
    then

        return false

    end

    local events =
        inputMarket:getEvents()

    if events == nil then
        return false
    end

    for _, event in pairs(events) do

        if event.name == eventName then

            inputMarket.activeEvent =
                event

            return true

        end

    end

    Logging.warning(
        "FFR Load: Saved input event was not found"
    )

    return false

end

--------------------------------------------------
-- Read Commodity Market
--------------------------------------------------

function FFR_SaveManager:readCommodityMarket(
    xmlFile,
    ffr
)

    if ffr == nil
        or ffr.commodityManager == nil
    then

        return

    end

    local marketKey =
        self.rootKey
        .. ".commodityMarket"

    local eventName =

        getXMLString(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#name"
        )

    if ffr.marketEngine ~= nil then

        self:restoreMarketEvent(
            ffr.marketEngine,
            eventName
        )

        local modifierIndex = 0

        while true do

            local key =

                string.format(
                    "%s.categoryModifiers.modifier(%d)",
                    marketKey,
                    modifierIndex
                )

            if not hasXMLProperty(
                xmlFile,
                key
            ) then

                break

            end

            local category =

                getXMLString(
                    xmlFile,
                    key .. "#category"
                )

            local modifier =

                getXMLFloat(
                    xmlFile,
                    key .. "#value"
                )

            if category ~= nil
                and modifier ~= nil
            then

                ffr.marketEngine
                    .categoryModifiers[
                        category
                    ] = modifier

            end

            modifierIndex =
                modifierIndex + 1

        end

    end

    local commodityIndex = 0

    while true do

        local key =

            string.format(
                "%s.commodities.commodity(%d)",
                marketKey,
                commodityIndex
            )

        if not hasXMLProperty(
            xmlFile,
            key
        ) then

            break

        end

        local commodityName =

            getXMLString(
                xmlFile,
                key .. "#name"
            )

        if commodityName ~= nil then

            local commodity =

                ffr.commodityManager
                    .commodities[
                        commodityName
                    ]

            if commodity ~= nil then

                commodity.basePrice =

                    getXMLFloat(
                        xmlFile,
                        key .. "#basePrice"
                    )

                    or commodity.basePrice

                commodity.currentPrice =

                    getXMLFloat(
                        xmlFile,
                        key .. "#currentPrice"
                    )

                    or commodity.currentPrice

                commodity.priceModifier =

                    getXMLFloat(
                        xmlFile,
                        key .. "#priceModifier"
                    )

                    or commodity.priceModifier

                commodity.volatility =

                    getXMLFloat(
                        xmlFile,
                        key .. "#volatility"
                    )

                    or commodity.volatility

            end

        end

        commodityIndex =
            commodityIndex + 1

    end

end

--------------------------------------------------
-- Read Input Market
--------------------------------------------------

function FFR_SaveManager:readInputMarket(
    xmlFile,
    ffr
)

    if ffr == nil
        or ffr.inputMarket == nil
    then

        return

    end

    local inputMarket =
        ffr.inputMarket

    local marketKey =
        self.rootKey
        .. ".inputMarket"

    local eventName =

        getXMLString(
            xmlFile,
            marketKey
                .. ".activeEvent"
                .. "#name"
        )

    local brand =
        getXMLString(xmlFile, marketKey .. ".activeEvent#brand")

    if brand ~= nil and inputMarket.createBrandEvent ~= nil then

        local event = inputMarket:createBrandEvent({
            brand = brand,
            title = getXMLString(xmlFile, marketKey .. ".activeEvent#brandTitle") or brand,
            category = getXMLString(xmlFile, marketKey .. ".activeEvent#brandCategory")
        })

        event.name = eventName or event.name
        event.brandDiscount = getXMLInt(xmlFile, marketKey .. ".activeEvent#brandDiscount") or event.brandDiscount
        event.brandModifier = 1 - event.brandDiscount / 100

        inputMarket.activeEvent = event

    else

        self:restoreInputEvent(
            inputMarket,
            eventName
        )

    end

    if inputMarket.activeEvent ~= nil then

        inputMarket.activeEvent.durationDays =

            getXMLInt(
                xmlFile,
                marketKey
                    .. ".activeEvent"
                    .. "#durationDays"
            )

            or inputMarket.activeEvent.durationDays

        inputMarket.activeEvent.expiryMonth =

            getXMLInt(
                xmlFile,
                marketKey
                    .. ".activeEvent"
                    .. "#expiryMonth"
            )

            or 0

        inputMarket.activeEvent.expiryYear =

            getXMLInt(
                xmlFile,
                marketKey
                    .. ".activeEvent"
                    .. "#expiryYear"
            )

            or 0

    end

    local inputIndex = 0

    while true do

        local key =

            string.format(
                "%s.inputs.input(%d)",
                marketKey,
                inputIndex
            )

        if not hasXMLProperty(
            xmlFile,
            key
        ) then

            break

        end

        local inputName =

            getXMLString(
                xmlFile,
                key .. "#name"
            )

        local modifier =

            getXMLFloat(
                xmlFile,
                key .. "#modifier"
            )

        if inputName ~= nil
            and modifier ~= nil
            and inputMarket.inputs[
                inputName
            ] ~= nil
        then

            inputMarket.inputs[
                inputName
            ].modifier =
                modifier

        end

        inputIndex =
            inputIndex + 1

    end

end

--------------------------------------------------
-- Read Financial State
--------------------------------------------------

-- keyOverride / managerOverride: one farm's section and object (per-farm save).
-- Without them: the top-level single-farm section of saves before v0.9.9.
function FFR_SaveManager:readFinancialState(
    xmlFile,
    ffr,
    keyOverride,
    managerOverride
)

    if ffr == nil
        or ffr.financialManager == nil
    then

        return

    end

    local financial =
        managerOverride or ffr.financialManager

    local key =
        keyOverride or (self.rootKey .. ".financial")

    financial.operatingLoan =

        getXMLFloat(
            xmlFile,
            key .. "#operatingLoan"
        )

        or 0

    financial.equipmentDebt =

        getXMLFloat(
            xmlFile,
            key .. "#equipmentDebt"
        )

        or 0

    financial.landDebt =

        getXMLFloat(
            xmlFile,
            key .. "#landDebt"
        )

        or 0

    financial.availableCredit =

        getXMLFloat(
            xmlFile,
            key .. "#availableCredit"
        )

        or 0

    financial.monthlyLandPayment =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyLandPayment"
        )

        or 0

    financial.monthlyEquipmentPayment =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyEquipmentPayment"
        )

        or 0

    financial.monthlyHouseholdCost =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyHouseholdCost"
        )

        or 0

    financial.monthlyInsuranceCost =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyInsuranceCost"
        )

        or 0

    financial.monthlyLeaseCost =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyLeaseCost"
        )

        or 0

    financial.monthlyTaxCost =

        getXMLFloat(
            xmlFile,
            key .. "#monthlyTaxCost"
        )

        or 0

    financial.annualRevenue =

        getXMLFloat(
            xmlFile,
            key .. "#annualRevenue"
        )

        or 0

    financial.annualExpenses =

        getXMLFloat(
            xmlFile,
            key .. "#annualExpenses"
        )

        or 0

    financial.annualProfit =

        getXMLFloat(
            xmlFile,
            key .. "#annualProfit"
        )

        or 0

end

--------------------------------------------------
-- Read Credit State
--------------------------------------------------

-- keyOverride / managerOverride: one farm's section and object (per-farm save).
-- Without them: the top-level single-farm section of saves before v0.9.9.
function FFR_SaveManager:readCreditState(
    xmlFile,
    ffr,
    keyOverride,
    managerOverride
)

    if ffr == nil
        or ffr.creditManager == nil
    then

        return

    end

    local credit =
        managerOverride or ffr.creditManager

    local key =
        keyOverride or (self.rootKey .. ".credit")

    credit.creditScore =

        getXMLInt(
            xmlFile,
            key .. "#creditScore"
        )

        or credit.creditScore

    credit.creditRating =

        getXMLString(
            xmlFile,
            key .. "#creditRating"
        )

        or credit.creditRating

    credit.interestRateModifier =

        getXMLFloat(
            xmlFile,
            key .. "#interestRateModifier"
        )

        or credit.interestRateModifier

    credit.maxOperatingLoan =

        getXMLFloat(
            xmlFile,
            key .. "#maxOperatingLoan"
        )

        or credit.maxOperatingLoan

    credit.maxExpansionLoan =

        getXMLFloat(
            xmlFile,
            key .. "#maxExpansionLoan"
        )

        or credit.maxExpansionLoan

    credit.missedPayments =

        getXMLInt(
            xmlFile,
            key .. "#missedPayments"
        )

        or 0

    credit.latePayments =

        getXMLInt(
            xmlFile,
            key .. "#latePayments"
        )

        or 0

    credit.successfulYears =

        getXMLInt(
            xmlFile,
            key .. "#successfulYears"
        )

        or 0

    credit.contractDefaults =

        getXMLInt(
            xmlFile,
            key .. "#contractDefaults"
        )

        or 0

    credit.taxPenalties =

        getXMLInt(
            xmlFile,
            key .. "#taxPenalties"
        )

        or 0

    credit.insolvencyStage = getXMLInt(xmlFile, key .. ".insolvency#stage") or 0
    credit.monthsOverdrawn = getXMLInt(xmlFile, key .. ".insolvency#monthsOverdrawn") or 0
    credit.insolvencyNotice = getXMLString(xmlFile, key .. ".insolvency#notice") or ""
    credit.forcedSaleTotal = getXMLFloat(xmlFile, key .. ".insolvency#forcedSaleTotal") or 0

    if credit.loadMarks ~= nil then
        credit:loadMarks(xmlFile, key .. ".marks")
    end

end

--------------------------------------------------
-- Load All FFR State
--------------------------------------------------

function FFR_SaveManager:load(
    ffr
)

    local filePath =
        self:getFilePath()

    if filePath == nil then

        Logging.info(
            "FFR Load: Savegame directory is not ready"
        )

        return false

    end

    if not self:fileExists() and not self:isValidFile(self:getBackupPath()) then

        Logging.info(
            "FFR Load: No existing economy file found"
        )

        self.hasLoaded = true

        self.hasSaveFile = false

        return false

    end

    --------------------------------------------------
    -- A damaged or half-written file is replaced by
    -- the backup kept at the previous save.
    --------------------------------------------------

    if not self:isValidFile(filePath) then

        local backup = self:getBackupPath()

        if self:isValidFile(backup) then

            Logging.warning(
                "FFR Load: FFR_economy.xml is damaged or incomplete; restoring from %s",
                self.backupFileName
            )

            filePath = backup

        else

            Logging.error(
                "FFR Load: FFR_economy.xml is damaged and there is no usable backup; starting a new FFR economy"
            )

            self.hasLoaded = true

            self.hasSaveFile = false

            return false

        end

    end

    local xmlFile =

        loadXMLFile(
            "FFREconomy",
            filePath
        )

    if xmlFile == nil
        or xmlFile == 0
    then

        Logging.error(
            "FFR Load: Could not open FFR_economy.xml"
        )

        return false

    end

    local generalKey = self.rootKey .. ".general"

    self.loadedFormat = getXMLInt(xmlFile, generalKey .. "#formatVersion") or 1

    self.loadedVersion = getXMLString(xmlFile, generalKey .. "#version") or "legacy"

    if ffr ~= nil then

        local period = getXMLInt(xmlFile, generalKey .. "#calendarPeriod") or 0
        local year = getXMLInt(xmlFile, generalKey .. "#calendarYear") or 0

        if period > 0 then ffr.currentCalendarPeriod = period end
        if year > 0 then ffr.currentCalendarYear = year end

    end

    -- Difficulty first: the market and households below are scaled by it.
    if FFR_Settings ~= nil then
        FFR_Settings.loadFromXML(xmlFile, self.rootKey .. ".settings")
    end

    if g_FFRPriceHistory ~= nil and hasXMLProperty(xmlFile, self.rootKey .. ".priceHistory") then
        g_FFRPriceHistory:loadFromXML(xmlFile, self.rootKey .. ".priceHistory")
    end

    if FFR_InputClassifier ~= nil then
        FFR_InputClassifier.loadFromXML(xmlFile, self.rootKey .. ".inputClasses")
    end

    if FFR_UnitManager ~= nil then
        FFR_UnitManager.loadFromXML(xmlFile, self.rootKey .. ".units")
    end

    if FFR_LandMarketManager ~= nil and hasXMLProperty(xmlFile, self.rootKey .. ".landMarket") then
        FFR_LandMarketManager.loadFromXML(xmlFile, self.rootKey .. ".landMarket")
    end

    if FFR_LandAuctionManager ~= nil then
        FFR_LandAuctionManager.loadFromXML(xmlFile, self.rootKey .. ".landAuctions")
    end

    if FFR_CropDamageManager ~= nil then
        FFR_CropDamageManager.loadFromXML(xmlFile, self.rootKey .. ".cropDamage")
    end

    self:readCommodityMarket(
        xmlFile,
        ffr
    )

    self:readDynamicEvent(
        xmlFile,
        ffr
    )

    self:readInputMarket(
        xmlFile,
        ffr
    )

    -- Land titles: in this file from format 3; older saves keep the titles the
    -- registry read from FFR_landRegistry.xml when the map loaded.
    if g_FFRLandRegistryManager ~= nil and hasXMLProperty(xmlFile, self.rootKey .. ".landRegistry") then
        g_FFRLandRegistryManager:loadFromXML(xmlFile, self.rootKey .. ".landRegistry")
    end

    self:readMonthlyState(
        xmlFile,
        ffr
    )

    --------------------------------------------------
    -- Per-farm profiles; older single-farm saves go
    -- to the default farm (farm 1 in singleplayer).
    --------------------------------------------------

    if ffr ~= nil
        and ffr.getFarmState ~= nil
        and not self:readFarms(xmlFile, ffr)
    then

        self:migrateSingleFarm(
            xmlFile,
            ffr
        )

    end

    if ffr ~= nil
        and ffr.contractManager ~= nil
    then

        ffr.contractManager:loadFromXML(
            xmlFile,
            self.rootKey .. ".contracts"
        )

    end

    delete(
        xmlFile
    )

    if FFR_Settings ~= nil then
        FFR_Settings.applyToGame()
    end

    self.hasLoaded = true

    self.hasSaveFile = true

    if self.loadedFormat < FFR_SaveManager.FORMAT_VERSION then
        Logging.info(
            "FFR Load: Save from format %d (mod %s) migrated; it is written as format %d at the next save",
            self.loadedFormat, tostring(self.loadedVersion), FFR_SaveManager.FORMAT_VERSION
        )
    end

    Logging.info(
        "FFR Load: Restored (format %d) - %s",
        self.loadedFormat,
        self:getReport(ffr)
    )

    return true

end

--------------------------------------------------
-- Save Manager Report
--------------------------------------------------

function FFR_SaveManager:printReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR SAVE MANAGER REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "File: %s",
        self:getString(
            self:getFilePath(),
            "Unavailable"
        )
    )

    Logging.info(
        "Existing Save File: %s",
        tostring(
            self.hasSaveFile
        )
    )

    Logging.info(
        "State Loaded: %s",
        tostring(
            self.hasLoaded
        )
    )

    Logging.info(
        "Last Save Successful: %s",
        tostring(
            self.lastSaveSuccessful
        )
    )

    Logging.info(
        "========================================"
    )

end
