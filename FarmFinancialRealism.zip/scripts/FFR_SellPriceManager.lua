FFR_SellPriceManager = {}

--------------------------------------------------
-- Runtime State
--------------------------------------------------

FFR_SellPriceManager.isInstalled = false

FFR_SellPriceManager.priceCallCount = 0

FFR_SellPriceManager.adjustedCallCount = 0

FFR_SellPriceManager.lastFillTypeName = nil

FFR_SellPriceManager.lastNativePrice = 0

FFR_SellPriceManager.lastAdjustedPrice = 0

FFR_SellPriceManager.lastModifier = 1.00

--------------------------------------------------
-- Get Active Commodity Manager
--------------------------------------------------

function FFR_SellPriceManager:getCommodityManager()

    if g_FFR == nil then
        return nil
    end

    return g_FFR.commodityManager

end

--------------------------------------------------
-- Get Active Market Engine
--------------------------------------------------

function FFR_SellPriceManager:getMarketEngine()

    if g_FFR == nil then
        return nil
    end

    return g_FFR.marketEngine

end

--------------------------------------------------
-- Resolve Fill Type Description
--------------------------------------------------

function FFR_SellPriceManager:getFillTypeDescription(
    fillTypeIndex
)

    if fillTypeIndex == nil then
        return nil
    end

    if g_fillTypeManager == nil then
        return nil
    end

    if g_fillTypeManager.getFillTypeByIndex == nil then
        return nil
    end

    return

        g_fillTypeManager:getFillTypeByIndex(
            fillTypeIndex
        )

end

--------------------------------------------------
-- Resolve Fill Type Name
--------------------------------------------------

function FFR_SellPriceManager:getFillTypeName(
    fillTypeIndex
)

    local fillTypeDescription =

        self:getFillTypeDescription(
            fillTypeIndex
        )

    if fillTypeDescription == nil then
        return nil
    end

    local name =
        fillTypeDescription.name

    if name == nil then
        return nil
    end

    return

        string.upper(
            tostring(name)
        )

end

--------------------------------------------------
-- Get Registered FFR Commodity
--------------------------------------------------

function FFR_SellPriceManager:getCommodity(
    fillTypeIndex
)

    local commodityManager =
        self:getCommodityManager()

    if commodityManager == nil then
        return nil
    end

    if commodityManager.commodities == nil then
        return nil
    end

    local fillTypeName =

        self:getFillTypeName(
            fillTypeIndex
        )

    if fillTypeName == nil then
        return nil
    end

    return

        commodityManager.commodities[
            fillTypeName
        ]

end

--------------------------------------------------
-- Get Active Commodity Modifier
--------------------------------------------------

function FFR_SellPriceManager:getModifier(
    fillTypeIndex
)

    local commodity =

        self:getCommodity(
            fillTypeIndex
        )

    if commodity == nil then
        return 1.00
    end

    local modifier =

        tonumber(
            commodity.priceModifier
        )

    if modifier == nil then
        return 1.00
    end

    if modifier <= 0 then
        return 1.00
    end

    return modifier

end

--------------------------------------------------
-- Adjust Effective Selling Price
--------------------------------------------------

function FFR_SellPriceManager:adjustPrice(
    nativePrice,
    fillTypeIndex
)

    local safeNativePrice =
        tonumber(nativePrice)

    if safeNativePrice == nil then
        return nativePrice
    end

    if safeNativePrice <= 0 then
        return nativePrice
    end

    local commodity =

        self:getCommodity(
            fillTypeIndex
        )

    --------------------------------------------------
    -- Unsupported fill types remain unchanged.
    --------------------------------------------------

    if commodity == nil then
        return nativePrice
    end

    local modifier =

        self:getModifier(
            fillTypeIndex
        )

    local adjustedPrice =

        safeNativePrice
        * modifier

    self.adjustedCallCount =
        self.adjustedCallCount + 1

    self.lastFillTypeName =
        commodity.name

    self.lastNativePrice =
        safeNativePrice

    self.lastAdjustedPrice =
        adjustedPrice

    self.lastModifier =
        modifier

    return adjustedPrice

end

--------------------------------------------------
-- Selling Station Price Hook
--------------------------------------------------

--------------------------------------------------
-- One-sale price override
--
-- Set by the contract manager around a single sale
-- so the station pays the contract rate on the
-- contracted litres: {station, fillTypeIndex,
-- pricePerLiter, used}. Cleared right after.
--------------------------------------------------

FFR_SellPriceManager.saleOverride = nil

function FFR_SellPriceManager.getEffectiveFillTypePrice(
    sellingStation,
    superFunc,
    fillTypeIndex,
    ...
)

    local override = FFR_SellPriceManager.saleOverride

    if override ~= nil
        and override.station == sellingStation
        and override.fillTypeIndex == fillTypeIndex
    then

        override.used = true

        return override.pricePerLiter

    end

    --------------------------------------------------
    -- Always obtain the native effective station price
    -- first. This preserves:
    --
    -- * station priceScale
    -- * economic difficulty
    -- * seasonal price behavior
    -- * great demand
    -- * price-drop systems
    -- * compatible earlier hooks
    --------------------------------------------------

    local nativePrice =

        superFunc(
            sellingStation,
            fillTypeIndex,
            ...
        )

    FFR_SellPriceManager.priceCallCount =

        FFR_SellPriceManager.priceCallCount
        + 1

    if g_FFR == nil then
        return nativePrice
    end

    if not g_FFR.isInitialized then
        return nativePrice
    end

    if g_FFR.commodityManager == nil then
        return nativePrice
    end

    return

        FFR_SellPriceManager:adjustPrice(
            nativePrice,
            fillTypeIndex
        )

end

--------------------------------------------------
-- Install Selling Price Hook
--------------------------------------------------

function FFR_SellPriceManager:install()

    if self.isInstalled then

        Logging.info(
            "FFR Sell Prices: Hook already installed"
        )

        return true

    end

    if SellingStation == nil then

        Logging.error(
            "FFR Sell Prices: SellingStation class is unavailable"
        )

        return false

    end

    if SellingStation.getEffectiveFillTypePrice == nil then

        Logging.error(
            "FFR Sell Prices: Effective price method is unavailable"
        )

        return false

    end

    SellingStation.getEffectiveFillTypePrice =

        Utils.overwrittenFunction(

            SellingStation.getEffectiveFillTypePrice,

            FFR_SellPriceManager
                .getEffectiveFillTypePrice

        )

    self.isInstalled = true

    Logging.info(
        "FFR Sell Prices: Effective selling-price hook installed"
    )

    return true

end

--------------------------------------------------
-- Report
--------------------------------------------------

function FFR_SellPriceManager:printReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR SELL PRICE REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Hook Installed: %s",
        tostring(
            self.isInstalled
        )
    )

    Logging.info(
        "Total Price Calls: %d",
        tonumber(
            self.priceCallCount
        )
        or 0
    )

    Logging.info(
        "Adjusted Price Calls: %d",
        tonumber(
            self.adjustedCallCount
        )
        or 0
    )

    if self.lastFillTypeName ~= nil then

        Logging.info(
            "Last Commodity: %s",
            tostring(
                self.lastFillTypeName
            )
        )

        Logging.info(
            "Last Native Price Per Liter: %.6f",
            tonumber(
                self.lastNativePrice
            )
            or 0
        )

        Logging.info(
            "Last FFR Modifier: %.3f",
            tonumber(
                self.lastModifier
            )
            or 1.00
        )

        Logging.info(
            "Last Adjusted Price Per Liter: %.6f",
            tonumber(
                self.lastAdjustedPrice
            )
            or 0
        )

    else

        Logging.info(
            "No supported commodity price has been requested yet"
        )

    end

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Install Immediately
--------------------------------------------------

FFR_SellPriceManager:install()