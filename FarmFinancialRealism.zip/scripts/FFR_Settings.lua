FFR_Settings = {}

--------------------------------------------------
-- Difficulty presets
--
-- One server-wide preset (Easy / Normal / Hard),
-- chosen by the server admin on the dashboard's
-- Options page (the player in singleplayer). A new
-- choice is stored as pending and takes effect at
-- the next month change, for every farm at once.
--
-- The server saves it in FFR_economy.xml and sends
-- it to clients in the snapshot, so sell prices and
-- contract quotes match on every machine.
--------------------------------------------------

FFR_Settings.ORDER = {"EASY", "NORMAL", "HARD"}

-- Insolvency ladder: months overdrawn in a row before each stage.
-- A missing stage is never reached (Easy stops at credit freeze).
FFR_Settings.PRESETS = {
    EASY = {
        name = "Easy",
        household = 0.50,
        eventStrength = 0.75,
        calmChance = 0.50,
        drasticWeight = 0,
        minModifier = 0.75,
        maxModifier = 1.30,
        interest = 0.80,
        taxes = 0.75,
        insurance = 0.80,
        insolvency = {warning = 1, freeze = 3}
    },
    NORMAL = {
        name = "Normal",
        household = 1.00,
        eventStrength = 1.00,
        calmChance = 0.30,
        drasticWeight = 5,
        minModifier = 0.65,
        maxModifier = 1.40,
        interest = 1.00,
        taxes = 1.00,
        insurance = 1.00,
        insolvency = {warning = 1, freeze = 3, called = 5, forcedSale = 6}
    },
    HARD = {
        name = "Hard",
        household = 1.50,
        eventStrength = 1.50,
        calmChance = 0.15,
        drasticWeight = 10,
        minModifier = 0.50,
        maxModifier = 1.60,
        interest = 1.25,
        taxes = 1.25,
        insurance = 1.25,
        insolvency = {warning = 1, freeze = 2, called = 3, forcedSale = 3}
    }
}

FFR_Settings.DEFAULT = "NORMAL"

FFR_Settings.difficulty = FFR_Settings.DEFAULT
FFR_Settings.pendingDifficulty = nil

function FFR_Settings.isValid(name)
    return name ~= nil and FFR_Settings.PRESETS[name] ~= nil
end

function FFR_Settings.get()
    return FFR_Settings.PRESETS[FFR_Settings.difficulty] or FFR_Settings.PRESETS[FFR_Settings.DEFAULT]
end

function FFR_Settings.getValue(key)
    return FFR_Settings.get()[key]
end

function FFR_Settings.getName(name)
    local key = name or FFR_Settings.difficulty
    if FFR_Settings.PRESETS[key] == nil then key = FFR_Settings.DEFAULT end
    return FFR_L10n.t("ffr_difficulty_" .. string.lower(key))
end

-- The preset after the next month change (the current one if nothing is pending).
function FFR_Settings.getNextDifficulty()
    return FFR_Settings.pendingDifficulty or FFR_Settings.difficulty
end

-- Steps the next-month choice through Easy / Normal / Hard (server side).
function FFR_Settings.step(direction)
    local current = FFR_Settings.getNextDifficulty()
    local index = 2
    for i, name in ipairs(FFR_Settings.ORDER) do
        if name == current then index = i end
    end
    index = math.max(1, math.min(#FFR_Settings.ORDER, index + (tonumber(direction) or 0)))
    return FFR_Settings.setPending(FFR_Settings.ORDER[index])
end

function FFR_Settings.setPending(name)
    if not FFR_Settings.isValid(name) then
        return false, FFR_L10n.t("ffr_options_unknown")
    end
    if name == FFR_Settings.difficulty then
        FFR_Settings.pendingDifficulty = nil
        return true, FFR_L10n.t("ffr_options_stays", FFR_Settings.getName(name))
    end
    FFR_Settings.pendingDifficulty = name
    Logging.info("FFR Settings: Difficulty %s chosen; applies at the next month change", name)
    return true, FFR_L10n.t("ffr_options_applies", FFR_Settings.getName(name))
end

-- Called at each month change on the server. Returns true if the preset changed.
function FFR_Settings.applyPending()
    local pending = FFR_Settings.pendingDifficulty
    FFR_Settings.pendingDifficulty = nil
    if pending == nil or pending == FFR_Settings.difficulty then
        return false
    end
    FFR_Settings.difficulty = pending
    FFR_Settings.applyToGame()
    Logging.info("FFR Settings: Difficulty is now %s", pending)
    if FFR_Network ~= nil then FFR_Network.markDirty() end
    return true
end

-- Pushes the active preset into the systems that cache its values.
function FFR_Settings.applyToGame()
    if g_FFR == nil then return end
    local preset = FFR_Settings.get()
    if g_FFR.marketEngine ~= nil and g_FFR.marketEngine.applyPreset ~= nil then
        g_FFR.marketEngine:applyPreset(preset)
        g_FFR.marketEngine:applyToCommodityManager(g_FFR.commodityManager)
    end
    if g_FFR.getFarmStates ~= nil and g_FFR.farms ~= nil then
        for _, state in pairs(g_FFR.farms) do
            state.familyManager:recalculate()
            state.financialManager:update()
        end
    end
end

--------------------------------------------------
-- Save / load (FFR_economy.xml) and network sync
--------------------------------------------------

function FFR_Settings.saveToXML(xmlFile, key)
    setXMLString(xmlFile, key .. "#difficulty", FFR_Settings.difficulty)
    if FFR_Settings.pendingDifficulty ~= nil then
        setXMLString(xmlFile, key .. "#pendingDifficulty", FFR_Settings.pendingDifficulty)
    end
end

function FFR_Settings.loadFromXML(xmlFile, key)
    local difficulty = getXMLString(xmlFile, key .. "#difficulty")
    local pending = getXMLString(xmlFile, key .. "#pendingDifficulty")
    FFR_Settings.difficulty = FFR_Settings.isValid(difficulty) and difficulty or FFR_Settings.DEFAULT
    FFR_Settings.pendingDifficulty = FFR_Settings.isValid(pending) and pending or nil
    Logging.info("FFR Settings: Difficulty %s loaded", FFR_Settings.difficulty)
end

function FFR_Settings.getSnapshot()
    return {difficulty = FFR_Settings.difficulty, pendingDifficulty = FFR_Settings.pendingDifficulty or ""}
end

function FFR_Settings.applySnapshot(data)
    if type(data) ~= "table" then return end
    local changed = data.difficulty ~= FFR_Settings.difficulty
    if FFR_Settings.isValid(data.difficulty) then FFR_Settings.difficulty = data.difficulty end
    FFR_Settings.pendingDifficulty = FFR_Settings.isValid(data.pendingDifficulty) and data.pendingDifficulty or nil
    if changed then FFR_Settings.applyToGame() end
end

--------------------------------------------------
-- Listener: each savegame starts on Normal until
-- its FFR_economy.xml (or the server) says otherwise.
--------------------------------------------------

function FFR_Settings:loadMap(mapName)
    FFR_Settings.difficulty = FFR_Settings.DEFAULT
    FFR_Settings.pendingDifficulty = nil
end

function FFR_Settings:deleteMap() end
function FFR_Settings:update(dt) end
function FFR_Settings:draw() end
function FFR_Settings:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_Settings:keyEvent(unicode, sym, modifier, isDown) end

addModEventListener(FFR_Settings)
Logging.info("FFR Settings: Difficulty presets installed")
