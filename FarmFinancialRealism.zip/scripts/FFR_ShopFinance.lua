FFR_ShopFinance = {}

--------------------------------------------------
-- FINANCE and LEASE in the FS25 shop
--
-- On the shop's configuration screen, for new
-- machines only (not used offers, owned machines,
-- placeables or hand tools):
--
-- * a FINANCE button is added next to BUY;
-- * LEASE opens FFR's lease instead of FS25's
--   pay-per-hour lease (FS25's own LEASE keeps working
--   for anything FFR does not lease).
--
-- Both open FFR's terms window, drawn by the shop
-- screen itself so it sits on top of it. ACCEPT asks
-- the server to approve the deal, then buys the
-- machine through FS25's own BuyVehicleEvent priced
-- at what is due today; FFR_EquipmentFinanceManager
-- opens the contract when the machine arrives.
--
-- The window uses FFR_ModalOverlay's drawing helpers
-- and colours (the month-end window's look).
--------------------------------------------------

-- Window position (screen fractions, bottom-left origin).
FFR_ShopFinance.X, FFR_ShopFinance.Y, FFR_ShopFinance.W, FFR_ShopFinance.H = 0.320, 0.200, 0.360, 0.600

FFR_ShopFinance.window = nil
FFR_ShopFinance.hits = {}

--------------------------------------------------
-- Buttons
--------------------------------------------------

function FFR_ShopFinance.isEligible(storeItem, vehicle, saleItem)
    if storeItem == nil or vehicle ~= nil or saleItem ~= nil then return false end
    if not FFR_EquipmentFinanceManager.installed then return false end
    if StoreSpecies ~= nil and StoreSpecies.VEHICLE ~= nil and storeItem.species ~= nil and storeItem.species ~= StoreSpecies.VEHICLE then
        return false
    end
    return (tonumber(storeItem.price) or 0) > 0
end

function FFR_ShopFinance.ensureButton(screen)
    if screen.ffrFinanceButton ~= nil then return screen.ffrFinanceButton end
    local buy = screen.buyButton
    if buy == nil or buy.clone == nil or buy.parent == nil then return nil end
    local parent = buy.parent
    local button = buy:clone(parent)
    if button == nil then return nil end
    button:setText(FFR_L10n.t("ffr_finance_button"))
    -- Its own key, so ENTER still means BUY.
    if button.setInputAction ~= nil then
        pcall(button.setInputAction, button, "MENU_EXTRA_2")
    else
        button.inputActionName = "MENU_EXTRA_2"
    end
    button.onClickCallback = function() FFR_ShopFinance.open(screen, "FINANCE") end
    -- Right after BUY in the button row.
    local elements = parent.elements or {}
    local buyIndex, ownIndex = nil, nil
    for i, element in ipairs(elements) do
        if element == buy then buyIndex = i end
        if element == button then ownIndex = i end
    end
    if buyIndex ~= nil and ownIndex ~= nil and ownIndex ~= buyIndex + 1 then
        table.remove(elements, ownIndex)
        table.insert(elements, buyIndex + 1, button)
    end
    screen.ffrFinanceButton = button
    return button
end

-- LEASE: FFR's lease for machines FFR handles, FS25's own for the rest.
function FFR_ShopFinance.routeLeaseButton(screen, eligible)
    local lease = screen.leaseButton
    if lease == nil then return end
    if screen.ffrLeaseOriginal == nil then
        screen.ffrLeaseOriginal = lease.onClickCallback or false
        screen.ffrLeaseCallback = function() FFR_ShopFinance.open(screen, "LEASE") end
    end
    if eligible then
        lease.onClickCallback = screen.ffrLeaseCallback
    elseif screen.ffrLeaseOriginal ~= false then
        lease.onClickCallback = screen.ffrLeaseOriginal
    end
end

function FFR_ShopFinance.onUpdateButtons(screen, storeItem, vehicle, saleItem)
    local ok, err = pcall(function()
        local eligible = FFR_ShopFinance.isEligible(storeItem, vehicle, saleItem)
        screen.ffrStoreItem = storeItem
        FFR_ShopFinance.routeLeaseButton(screen, eligible)
        local button = FFR_ShopFinance.ensureButton(screen)
        if button == nil then return end
        button:setVisible(eligible and (screen.buyButton.getIsVisible == nil or screen.buyButton:getIsVisible()))
        if button.parent ~= nil and button.parent.invalidateLayout ~= nil then button.parent:invalidateLayout() end
    end)
    if not ok then Logging.warning("FFR Shop Finance: Could not update the shop buttons (%s)", tostring(err)) end
end

--------------------------------------------------
-- Window
--------------------------------------------------

function FFR_ShopFinance.getState()
    return g_FFR ~= nil and g_FFR.isInitialized and g_FFR:getFarmState(g_FFR.localFarmId) or nil
end

function FFR_ShopFinance.getPrice(screen, storeItem)
    local price = tonumber(screen.totalPrice)
    if price == nil and g_currentMission ~= nil and g_currentMission.economyManager ~= nil then
        local ok, result = pcall(g_currentMission.economyManager.getBuyPrice, g_currentMission.economyManager, storeItem, screen.configurations)
        price = ok and tonumber(result) or nil
    end
    return price or tonumber(storeItem.price) or 0
end

-- kind: FINANCE or LEASE.
function FFR_ShopFinance.open(screen, kind)
    local storeItem = screen.ffrStoreItem
    local state = FFR_ShopFinance.getState()
    if storeItem == nil or state == nil then return end
    local m = FFR_EquipmentFinanceManager
    -- Finance starts at the least down payment the farm's credit allows, five
    -- years; a lease at three years.
    local downIndex = 1
    for i, down in ipairs(m.DOWN_PAYMENTS) do
        if down < m.getMinDown(state.creditManager) - 0.0001 then downIndex = i + 1 end
    end
    FFR_ShopFinance.window = {
        screen = screen, storeItem = storeItem, kind = kind, price = FFR_ShopFinance.getPrice(screen, storeItem),
        name = m.getItemName(storeItem), downIndex = math.min(downIndex, #m.DOWN_PAYMENTS),
        termIndex = kind == "LEASE" and 2 or 5, message = nil, busy = false
    }
end

function FFR_ShopFinance.close()
    FFR_ShopFinance.window = nil
    FFR_ShopFinance.hits = {}
end

function FFR_ShopFinance.isOpenFor(screen)
    return FFR_ShopFinance.window ~= nil and FFR_ShopFinance.window.screen == screen
end

function FFR_ShopFinance.getTermList(w)
    local m = FFR_EquipmentFinanceManager
    return w.kind == "LEASE" and m.LEASE_TERMS or m.TERMS
end

function FFR_ShopFinance.getTerms(w)
    return FFR_EquipmentFinanceManager.DOWN_PAYMENTS[w.downIndex], FFR_ShopFinance.getTermList(w)[w.termIndex]
end

function FFR_ShopFinance.step(field, direction)
    local w = FFR_ShopFinance.window
    if w == nil or w.busy then return end
    local list = field == "down" and FFR_EquipmentFinanceManager.DOWN_PAYMENTS or FFR_ShopFinance.getTermList(w)
    local key = field == "down" and "downIndex" or "termIndex"
    w[key] = math.max(1, math.min(#list, w[key] + direction))
    w.message = nil
end

-- What is charged in the shop today.
function FFR_ShopFinance.getDueToday(state, w)
    local m = FFR_EquipmentFinanceManager
    local down, term = FFR_ShopFinance.getTerms(w)
    if w.kind == "LEASE" then return m.getLeaseQuote(state, w.price, term).dueToday end
    return m.getQuote(state, w.price, down, term).downPayment
end

-- ACCEPT: the server approves the deal first; only then is the machine bought.
function FFR_ShopFinance.accept()
    local w = FFR_ShopFinance.window
    local state = FFR_ShopFinance.getState()
    if w == nil or w.busy or state == nil then return end
    local down, term = FFR_ShopFinance.getTerms(w)
    local ok, message = FFR_EquipmentFinanceManager.check(state, w.kind, w.price, down, term)
    if not ok then
        w.message, w.messageOk = message, false
        return
    end
    local screen = w.screen
    local purchase = {
        storeItem = w.storeItem, farmId = g_FFR.localFarmId, price = FFR_ShopFinance.getDueToday(state, w),
        configurations = screen.configurations, configurationData = screen.configurationData,
        licensePlateData = screen.licensePlateData
    }
    w.busy, w.message, w.messageOk = true, FFR_L10n.t("ffr_finance_waiting"), true
    FFR_Network.perform("EQUIP_FINANCE_PREPARE", {kind = w.kind, xml = w.storeItem.xmlFilename, price = w.price, down = down, term = term},
        function(approved, text)
            if approved == nil then return end
            local open = FFR_ShopFinance.window
            if not approved then
                if open ~= nil then open.busy, open.message, open.messageOk = false, text, false end
                return
            end
            FFR_ShopFinance.sendPurchase(purchase)
            FFR_ShopFinance.close()
        end)
end

function FFR_ShopFinance.sendPurchase(p)
    local ok, err = pcall(function()
        local data = BuyVehicleData.new()
        data:setOwnerFarmId(p.farmId)
        data:setPrice(p.price)
        data:setStoreItem(p.storeItem)
        data:setConfigurations(p.configurations or {})
        if data.setConfigurationData ~= nil and p.configurationData ~= nil then data:setConfigurationData(p.configurationData) end
        if data.setLicensePlateData ~= nil and p.licensePlateData ~= nil then data:setLicensePlateData(p.licensePlateData) end
        g_client:getServerConnection():sendEvent(BuyVehicleEvent.new(data))
    end)
    if not ok then
        Logging.warning("FFR Shop Finance: Purchase could not be sent (%s)", tostring(err))
        if FFR_CropDamageManager ~= nil then FFR_CropDamageManager.showNotice(FFR_L10n.t("ffr_finance_send_failed")) end
    end
end

--------------------------------------------------
-- Drawing (from the shop screen's draw)
--------------------------------------------------

function FFR_ShopFinance.addHit(x, y, w, h, action)
    table.insert(FFR_ShopFinance.hits, {x = x, y = y, w = w, h = h, action = action})
end

function FFR_ShopFinance.drawStepper(o, C, x, y, value, field)
    o:fill(x, y, 0.024, 0.028, C.pill)
    o:say(x + 0.012, y + 0.007, 0.014, "<", C.lime, "center", true)
    o:fill(x + 0.028, y, 0.104, 0.028, C.border)
    o:fill(x + 0.029, y + 0.002, 0.102, 0.024, C.card)
    o:say(x + 0.080, y + 0.007, 0.013, value, C.white, "center", true)
    o:fill(x + 0.136, y, 0.024, 0.028, C.pill)
    o:say(x + 0.148, y + 0.007, 0.014, ">", C.lime, "center", true)
    FFR_ShopFinance.addHit(x, y, 0.024, 0.028, function() FFR_ShopFinance.step(field, -1) end)
    FFR_ShopFinance.addHit(x + 0.136, y, 0.024, 0.028, function() FFR_ShopFinance.step(field, 1) end)
end

-- The rows below the steppers: label, value, and what is due today.
function FFR_ShopFinance.getRows(state, w)
    local m, L, money = FFR_EquipmentFinanceManager, FFR_L10n.t, FFR_L10n.formatMoney
    local down, term = FFR_ShopFinance.getTerms(w)
    local rating = state.creditManager.creditRating ~= nil and FFR_CreditManager.getRatingName(state.creditManager.creditRating) or "-"
    if w.kind == "LEASE" then
        local q = m.getLeaseQuote(state, w.price, term)
        return {
            {L("ffr_lease_residual", math.floor((m.RESIDUALS[term] or 0) * 100 + 0.5)), money(q.residual)},
            {L("ffr_finance_rate", rating), string.format("%.2f %%", q.rate * 100)},
            {L("ffr_lease_payment"), money(q.payment)},
            {L("ffr_lease_total"), money(q.totalPayments)},
            {L("ffr_lease_hours"), L("ffr_lease_hours_value", math.floor(q.hours + 0.5))},
            {L("ffr_lease_overage"), money(q.overageFee)}
        }, q.dueToday, {"ffr_lease_note_1", "ffr_lease_note_2"}
    end
    local q = m.getQuote(state, w.price, down, term)
    return {
        {L("ffr_finance_financed"), money(q.financed)},
        {L("ffr_finance_rate", rating), string.format("%.2f %%", q.rate * 100)},
        {L("ffr_finance_principal"), money(q.principal)},
        {L("ffr_finance_first_interest"), money(q.firstInterest)},
        {L("ffr_finance_first_payment"), money(q.firstPayment)},
        {L("ffr_finance_total_interest"), money(q.totalInterest)}
    }, q.downPayment, {"ffr_finance_note_1", "ffr_finance_note_2"}
end

function FFR_ShopFinance.draw()
    local w = FFR_ShopFinance.window
    local o = g_FFRModalOverlay
    local state = FFR_ShopFinance.getState()
    if w == nil or o == nil or state == nil or not o:ensureOverlay() then return end
    local C, L, money = FFR_ModalOverlay.COLORS, FFR_L10n.t, FFR_L10n.formatMoney
    local X, Y, W, H = FFR_ShopFinance.X, FFR_ShopFinance.Y, FFR_ShopFinance.W, FFR_ShopFinance.H
    local left, right = X + 0.020, X + W - 0.020
    local lease = w.kind == "LEASE"
    FFR_ShopFinance.hits = {}

    o:rect(0, 0, 1, 1, 0, 0, 0, 0.55)
    o:fill(X - 0.002, Y - 0.002, W + 0.004, H + 0.004, C.border)
    o:fill(X, Y, W, H, C.surface)
    o:fill(X, Y + H - 0.075, W, 0.075, C.header)
    o:fill(X, Y + H - 0.075, W, 0.003, C.lime)
    o:say(left, Y + H - 0.038, 0.022, L(lease and "ffr_lease_title" or "ffr_finance_title"), C.heading, "left", true)
    o:say(left, Y + H - 0.062, 0.014, w.name, C.white, "left", false)

    local down, term = FFR_ShopFinance.getTerms(w)
    local rows, dueToday, notes = FFR_ShopFinance.getRows(state, w)
    local y = Y + H - 0.110
    o:say(left, y, 0.015, L("ffr_finance_price"), C.white, "left", false)
    o:say(right, y, 0.016, money(w.price), C.white, "right", true)
    if not lease then
        y = y - 0.044
        o:say(left, y + 0.007, 0.015, L("ffr_finance_down"), C.white, "left", false)
        FFR_ShopFinance.drawStepper(o, C, right - 0.160, y,
            L("ffr_finance_down_value", math.floor(down * 100 + 0.5), money(math.floor(w.price * down + 0.5))), "down")
        y = y - 0.040
    else
        y = y - 0.044
    end
    o:say(left, y + 0.007, 0.015, L("ffr_finance_term"), C.white, "left", false)
    FFR_ShopFinance.drawStepper(o, C, right - 0.160, y, FFR_L10n.months(term), "term")
    y = y - 0.018
    o:fill(left, y, W - 0.040, 0.0015, C.divider)

    y = y - 0.034
    for _, row in ipairs(rows) do
        o:say(left, y, 0.014, row[1], C.white, "left", false)
        o:say(right, y, 0.014, row[2], C.white, "right", true)
        y = y - 0.028
    end
    o:say(left, y, 0.016, L("ffr_finance_due_today"), C.gold, "left", true)
    o:say(right, y, 0.018, money(dueToday), C.gold, "right", true)

    y = y - 0.034
    o:say(left, y, 0.011, L(notes[1]), C.grey, "left", false)
    o:say(left, y - 0.017, 0.011, L(notes[2]), C.grey, "left", false)

    if w.message ~= nil and w.message ~= "" then
        o:say(X + W / 2, Y + 0.062, 0.013, w.message, w.messageOk and C.lime or C.red, "center", true)
    end

    -- CANCEL and ACCEPT.
    local by, bw, bh = Y + 0.016, 0.150, 0.032
    o:fill(left, by, bw, bh, C.pill)
    o:say(left + bw / 2, by + 0.009, 0.014, L("ffr_finance_cancel"), C.white, "center", true)
    FFR_ShopFinance.addHit(left, by, bw, bh, FFR_ShopFinance.close)
    o:fill(right - bw, by, bw, bh, w.busy and C.border or C.lime)
    o:say(right - bw / 2, by + 0.009, 0.014, L("ffr_finance_accept"), C.dark, "center", true)
    FFR_ShopFinance.addHit(right - bw, by, bw, bh, FFR_ShopFinance.accept)
end

--------------------------------------------------
-- Shop screen hooks
--------------------------------------------------

function FFR_ShopFinance.onDraw(screen)
    if not FFR_ShopFinance.isOpenFor(screen) then return end
    local ok, err = pcall(FFR_ShopFinance.draw)
    if not ok then
        Logging.warning("FFR Shop Finance: Window could not be drawn (%s)", tostring(err))
        FFR_ShopFinance.close()
    end
end

-- While the window is open it takes every click.
function FFR_ShopFinance.onMouseEvent(screen, superFunc, posX, posY, isDown, isUp, button, eventUsed)
    if not FFR_ShopFinance.isOpenFor(screen) then
        return superFunc(screen, posX, posY, isDown, isUp, button, eventUsed)
    end
    if isUp then
        for _, hit in ipairs(FFR_ShopFinance.hits) do
            if posX >= hit.x and posX <= hit.x + hit.w and posY >= hit.y and posY <= hit.y + hit.h then
                hit.action()
                break
            end
        end
    end
    return true
end

-- BACK closes the window, ACCEPT accepts; nothing reaches the shop behind it.
function FFR_ShopFinance.onInputEvent(screen, superFunc, action, value, eventUsed)
    if not FFR_ShopFinance.isOpenFor(screen) then
        return superFunc(screen, action, value, eventUsed)
    end
    if InputAction ~= nil then
        if action == InputAction.MENU_BACK then
            FFR_ShopFinance.close()
        elseif action == InputAction.MENU_ACCEPT then
            FFR_ShopFinance.accept()
        end
    end
    return true
end

function FFR_ShopFinance.onClose(screen)
    if FFR_ShopFinance.isOpenFor(screen) then FFR_ShopFinance.close() end
end

function FFR_ShopFinance.install()
    if ShopConfigScreen == nil or ShopConfigScreen.updateButtons == nil then
        Logging.warning("FFR Shop Finance: ShopConfigScreen not found; no FINANCE button")
        return
    end
    ShopConfigScreen.updateButtons = Utils.appendedFunction(ShopConfigScreen.updateButtons, FFR_ShopFinance.onUpdateButtons)
    ShopConfigScreen.draw = Utils.appendedFunction(ShopConfigScreen.draw, FFR_ShopFinance.onDraw)
    ShopConfigScreen.mouseEvent = Utils.overwrittenFunction(ShopConfigScreen.mouseEvent, FFR_ShopFinance.onMouseEvent)
    ShopConfigScreen.inputEvent = Utils.overwrittenFunction(ShopConfigScreen.inputEvent, FFR_ShopFinance.onInputEvent)
    if ShopConfigScreen.onClose ~= nil then
        ShopConfigScreen.onClose = Utils.appendedFunction(ShopConfigScreen.onClose, FFR_ShopFinance.onClose)
    end
    Logging.info("FFR Shop Finance: FINANCE and LEASE buttons installed")
end

FFR_ShopFinance.install()
