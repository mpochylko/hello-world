FFR_StationPriceManager = {}

function FFR_StationPriceManager:getModifier(fillTypeIndex)
    if FFR_SellPriceManager ~= nil and FFR_SellPriceManager.getModifier ~= nil then
        return tonumber(FFR_SellPriceManager:getModifier(fillTypeIndex)) or 1.00
    end
    return 1.00
end

-- Text keys from station tables (e.g. sellingStationById), kept as a last-resort name.
FFR_StationPriceManager.nameHints = {}

-- Per-source counts from the last scan, for the one-time diagnostic log.
FFR_StationPriceManager.sourceCounts = {}

function FFR_StationPriceManager:countSource(key)
    self.sourceCounts[key] = (self.sourceCounts[key] or 0) + 1
end

-- Forget the cached list (e.g. when a new mission loads).
function FFR_StationPriceManager:clearCache()
    self.cachedStations = nil
    self.cachedAt = nil
    self.nameHints = {}
end

function FFR_StationPriceManager:addStation(output, seen, station, nameHint, source)
    if type(station) ~= "table" or seen[station] then return end
    if station.getEffectiveFillTypePrice == nil then self:countSource("skipped: no price function"); return end
    if station.isSellingPoint == false then self:countSource("skipped: not a selling point"); return end
    seen[station] = true
    if type(nameHint) == "string" and nameHint ~= "" then self.nameHints[station] = nameHint end
    table.insert(output, station)
    self:countSource(source or "other")
end

-- Collects selling stations from every place FS25 may keep them, once each:
-- economy manager lists, storage-system unloading stations, and selling-station placeables.
-- The scan walks every placeable and unloading station on the map, and the
-- dashboard asks for prices many times a second, so the list is reused briefly.
FFR_StationPriceManager.CACHE_MS = 2000

function FFR_StationPriceManager:getStations()
    local now = tonumber(g_time) or 0
    if self.cachedStations ~= nil and now >= (self.cachedAt or 0)
        and now - (self.cachedAt or 0) < FFR_StationPriceManager.CACHE_MS then
        return self.cachedStations
    end
    local stations, seen = {}, {}
    self.sourceCounts = {}
    if g_currentMission == nil then return stations end

    local economy = g_currentMission.economyManager
    if economy ~= nil then
        for _, container in ipairs({economy.sellingStations, economy.sellingStationList, economy.sellingStationById}) do
            if type(container) == "table" then
                for key, value in pairs(container) do
                    local station = type(key) == "table" and key or value
                    self:addStation(stations, seen, station, key, "economy manager")
                end
            end
        end
    end

    local storageSystem = g_currentMission.storageSystem
    if storageSystem ~= nil then
        local containers = {storageSystem.unloadingStations, storageSystem.sellingStations}
        if storageSystem.getUnloadingStations ~= nil then
            local ok, result = pcall(storageSystem.getUnloadingStations, storageSystem)
            if ok then table.insert(containers, result) end
        end
        for _, container in ipairs(containers) do
            if type(container) == "table" then
                for key, value in pairs(container) do
                    local station = type(key) == "table" and key or value
                    if type(station) == "table" then
                        self:addStation(stations, seen, station, key, "storage system")
                        self:addStation(stations, seen, station.sellingStation, key, "storage system")
                    end
                end
            end
        end
    end

    local placeableSystem = g_currentMission.placeableSystem
    if placeableSystem ~= nil and type(placeableSystem.placeables) == "table" then
        for _, placeable in pairs(placeableSystem.placeables) do
            local spec = placeable.spec_sellingStation or placeable.spec_sellingStationPlaceable
            if spec ~= nil then
                self:countSource("selling-station placeables seen")
                self:addStation(stations, seen, spec.sellingStation, nil, "placeables")
                if type(spec.sellingStations) == "table" then
                    for key, station in pairs(spec.sellingStations) do self:addStation(stations, seen, station, key, "placeables") end
                end
            end
        end
    end

    self.cachedStations = stations
    self.cachedAt = now
    return stations
end

-- Accept only real text: resolves $l10n_ keys, drops tables, blanks and line breaks.
function FFR_StationPriceManager:cleanName(value)
    if type(value) ~= "string" then return nil end
    local text = value
    if string.sub(text, 1, 6) == "$l10n_" and g_i18n ~= nil and g_i18n.convertText ~= nil then
        local ok, converted = pcall(g_i18n.convertText, g_i18n, text)
        if ok and type(converted) == "string" then text = converted end
    end
    text = string.gsub(text, "[\r\n\t]+", " ")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    if text == "" or string.sub(text, 1, 6) == "$l10n_" then return nil end
    return text
end

function FFR_StationPriceManager:callName(object)
    if object == nil or object.getName == nil then return nil end
    local ok, value = pcall(object.getName, object)
    if ok then return self:cleanName(value) end
    return nil
end

function FFR_StationPriceManager:storeItemName(object)
    if object == nil or object.configFileName == nil or g_storeManager == nil
        or g_storeManager.getItemByXMLFilename == nil then return nil end
    local ok, item = pcall(g_storeManager.getItemByXMLFilename, g_storeManager, object.configFileName)
    if ok and item ~= nil then return self:cleanName(item.name) end
    return nil
end

-- Returns the name and which field it came from (for the one-time diagnostic).
-- Checked one by one: the old version put possibly-nil fields in a list and
-- walked it with ipairs, which stops at the first nil and skipped real names.
function FFR_StationPriceManager:resolvePlaceableName(placeable, label)
    if placeable == nil then return nil end
    local name = self:callName(placeable)
    if name ~= nil then return name, label .. ":getName" end
    name = self:cleanName(placeable.name)
    if name ~= nil then return name, label .. ".name" end
    name = self:storeItemName(placeable)
    if name ~= nil then return name, label .. " store item" end
    return nil
end

function FFR_StationPriceManager:resolveStationName(station)
    if station == nil then return nil, "none" end
    -- The building the station belongs to has the name players see on the map.
    local placeables = {
        {station.owningPlaceable, "owningPlaceable"},
        {station.unloadingStation ~= nil and station.unloadingStation.owningPlaceable or nil, "unloadingStation.owningPlaceable"},
        {station.unloadTrigger ~= nil and station.unloadTrigger.owningPlaceable or nil, "unloadTrigger.owningPlaceable"}
    }
    for _, entry in ipairs(placeables) do
        local name, source = self:resolvePlaceableName(entry[1], entry[2])
        if name ~= nil then return name, source end
    end
    local name = self:callName(station)
    if name ~= nil then return name, "station:getName" end
    for _, field in ipairs({"stationName", "name", "title"}) do
        name = self:cleanName(station[field])
        if name ~= nil then return name, "station." .. field end
    end
    name = self:cleanName(self.nameHints[station])
    if name ~= nil then return name, "station table key" end
    return nil, "none"
end

-- Stable id for a selling station across save/load, used to tie a forward
-- contract to its buyer. Prefers the owning building's unique id, then its name.
function FFR_StationPriceManager:getStationKey(station)
    if station == nil then return nil end
    local placeable = station.owningPlaceable
    if placeable ~= nil then
        if placeable.getUniqueId ~= nil then
            local ok, id = pcall(placeable.getUniqueId, placeable)
            if ok and id ~= nil and tostring(id) ~= "" then return "uid:" .. tostring(id) end
        end
        if placeable.uniqueId ~= nil and tostring(placeable.uniqueId) ~= "" then
            return "uid:" .. tostring(placeable.uniqueId)
        end
    end
    local name = self:resolveStationName(station)
    if name ~= nil then return "name:" .. name end
    return nil
end

-- Finds a live station by key; nil if it no longer exists (e.g. the building was sold).
function FFR_StationPriceManager:findStationByKey(key)
    if key == nil then return nil end
    for _, station in pairs(self:getStations()) do
        if self:getStationKey(station) == key then return station end
    end
    return nil
end

function FFR_StationPriceManager:getStationName(station, fallbackIndex)
    local name = self:resolveStationName(station)
    if name == nil then
        local number = tonumber(fallbackIndex)
        name = number ~= nil and FFR_L10n.t("ffr_market_station_n", number) or FFR_L10n.t("ffr_market_station")
    end
    -- Full name: FS25 shortens text that does not fit its box, and contracts
    -- store this name, so it must not be cut here.
    return name
end

-- Logs once per session where station names come from, so a log.txt shows
-- what FS25 actually exposes if names still look wrong.
function FFR_StationPriceManager:logDiagnostics(stations)
    if self.hasLoggedDiagnostics then return end
    self.hasLoggedDiagnostics = true
    local count = 0
    for _ in pairs(stations) do count = count + 1 end
    Logging.info("FFR Station Prices: %d selling stations found", count)
    for source, n in pairs(self.sourceCounts) do
        Logging.info("FFR Station Prices:   %s: %d", tostring(source), n)
    end
    local shown = 0
    for _, station in pairs(stations) do
        if shown >= 5 then break end
        local name, source = self:resolveStationName(station)
        Logging.info("FFR Station Prices:   '%s' from %s (owningPlaceable=%s)",
            tostring(name or "?"), source, tostring(station.owningPlaceable ~= nil))
        shown = shown + 1
    end
end

function FFR_StationPriceManager:containsFillType(container, fillTypeIndex)
    if type(container) ~= "table" then return false end
    if container[fillTypeIndex] ~= nil then
        local value = container[fillTypeIndex]
        return value ~= false and value ~= 0
    end
    for key, value in pairs(container) do
        if tonumber(key) == fillTypeIndex then return value ~= false and value ~= 0 end
        if tonumber(value) == fillTypeIndex then return true end
        if type(value) == "table" then
            local nested = value.fillTypeIndex or value.fillType or value.index
            if tonumber(nested) == fillTypeIndex then return true end
        end
    end
    return false
end

function FFR_StationPriceManager:stationAcceptsFillType(station, fillTypeIndex)
    if station == nil then return false end

    -- Ask the station itself first when it can answer.
    for _, methodName in ipairs({"getIsFillTypeSupported", "getIsFillTypeAllowed", "acceptsFillType"}) do
        local method = station[methodName]
        if method ~= nil then
            local ok, accepted = pcall(method, station, fillTypeIndex)
            if ok then return accepted == true end
        end
    end

    -- Native station price tables are authoritative when present.
    local priceTables = {
        station.fillTypePrices,
        station.prices,
        station.priceMultipliers,
        station.acceptedFillTypes,
        station.supportedFillTypes
    }
    local foundStructuredData = false
    for _, container in ipairs(priceTables) do
        if type(container) == "table" then
            foundStructuredData = true
            if self:containsFillType(container, fillTypeIndex) then return true end
        end
    end

    -- Some stations expose acceptance through unloading stations or triggers.
    local relatedObjects = {
        station.unloadingStation,
        station.unloadTrigger,
        station.sellingStation
    }
    for _, object in ipairs(relatedObjects) do
        if object ~= nil then
            local methods = {"getIsFillTypeSupported", "getIsFillTypeAllowed", "acceptsFillType"}
            for _, methodName in ipairs(methods) do
                local method = object[methodName]
                if method ~= nil then
                    local ok, accepted = pcall(method, object, fillTypeIndex)
                    if ok then return accepted == true end
                end
            end
            local containers = {object.acceptedFillTypes, object.supportedFillTypes, object.fillTypes}
            for _, container in ipairs(containers) do
                if type(container) == "table" then
                    foundStructuredData = true
                    if self:containsFillType(container, fillTypeIndex) then return true end
                end
            end
        end
    end

    -- If a station exposes structured acceptance or price data and the fill type
    -- was absent, it is not accepted. This prevents the base game missing-filltype call stack.
    return not foundStructuredData
end

function FFR_StationPriceManager:getPriceRows(fillTypeIndex)
    local rows = {}
    fillTypeIndex = tonumber(fillTypeIndex)
    if fillTypeIndex == nil then return rows end

    local modifier = self:getModifier(fillTypeIndex)
    local stations = self:getStations()
    self:logDiagnostics(stations)
    for index, station in pairs(stations) do
        if station ~= nil
            and station.getEffectiveFillTypePrice ~= nil
            and self:stationAcceptsFillType(station, fillTypeIndex)
        then
            local ok, finalPrice = pcall(station.getEffectiveFillTypePrice, station, fillTypeIndex)
            finalPrice = tonumber(finalPrice)
            if ok and finalPrice ~= nil and finalPrice > 0 then
                table.insert(rows, {
                    station = station,
                    name = self:getStationName(station, index),
                    key = self:getStationKey(station),
                    nativePrice = (finalPrice / math.max(modifier, 0.0001)) * 1000,
                    ffrPrice = finalPrice * 1000,
                    modifier = modifier
                })
            end
        end
    end

    table.sort(rows, function(a, b)
        if math.abs(a.ffrPrice - b.ffrPrice) > 0.001 then return a.ffrPrice > b.ffrPrice end
        return tostring(a.name) < tostring(b.name)
    end)
    return rows
end

function FFR_StationPriceManager:getBestPrice(fillTypeIndex)
    return self:getPriceRows(fillTypeIndex)[1]
end

g_FFRStationPriceManager = FFR_StationPriceManager
Logging.info("FFR Station Prices: Acceptance-aware live reader installed")
