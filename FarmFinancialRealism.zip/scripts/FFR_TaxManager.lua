FFR_TaxManager = {}

function FFR_TaxManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_TaxManager}
    )

    --------------------------------------------------
    -- Tax Rates
    --------------------------------------------------

    self.propertyTaxRate = 0.010

    --------------------------------------------------
    -- Annual Values
    --------------------------------------------------

    self.assessedPropertyValue = 0

    self.propertyTaxDue = 0

    self.incomeTaxDue = 0

    self.totalTaxesDue = 0

    --------------------------------------------------
    -- History
    --------------------------------------------------

    self.totalTaxesPaid = 0

    self.taxPenalties = 0

    self.unpaidTaxes = 0

    return self

end

-- Difficulty preset multiplier for every tax (FFR_Settings).
function FFR_TaxManager:getRateScale()

    if FFR_Settings == nil then
        return 1
    end

    return tonumber(FFR_Settings.getValue("taxes")) or 1

end

--------------------------------------------------
-- Property Assessment
--------------------------------------------------

function FFR_TaxManager:updatePropertyTax(
    financialManager
)

    if financialManager == nil then
        return
    end

    self.assessedPropertyValue =

        financialManager.landValue
        +
        financialManager.buildingValue

    self.propertyTaxDue =

        self.assessedPropertyValue
        *
        self.propertyTaxRate
        *
        self:getRateScale()

end

--------------------------------------------------
-- Income Tax
--------------------------------------------------

function FFR_TaxManager:calculateIncomeTax(
    annualProfit
)

    local tax = 0

    if annualProfit <= 100000 then

        tax = annualProfit * 0.10

    elseif annualProfit <= 500000 then

        tax =
            (100000 * 0.10)
            +
            ((annualProfit - 100000)
            * 0.20)

    else

        tax =
            (100000 * 0.10)
            +
            (400000 * 0.20)
            +
            ((annualProfit - 500000)
            * 0.30)

    end

    self.incomeTaxDue = tax * self:getRateScale()

end

--------------------------------------------------
-- Annual Tax Update
--------------------------------------------------

function FFR_TaxManager:updateAnnualTax(
    financialManager,
    annualProfit
)

    self:updatePropertyTax(
        financialManager
    )

    self:calculateIncomeTax(
        annualProfit
    )

    self.totalTaxesDue =

        self.propertyTaxDue
        +
        self.incomeTaxDue

end

--------------------------------------------------
-- Pay Taxes
--------------------------------------------------

function FFR_TaxManager:payTaxes(
    financialManager
)

    if financialManager == nil then
        return false
    end

    if financialManager.cashOnHand
        < self.totalTaxesDue
    then

        return false

    end

    financialManager:removeCash(
        self.totalTaxesDue
    )

    self.totalTaxesPaid =
        self.totalTaxesPaid
        + self.totalTaxesDue

    self.totalTaxesDue = 0

    return true

end

--------------------------------------------------
-- Apply Penalty
--------------------------------------------------

function FFR_TaxManager:applyPenalty()

    local penalty =

        self.totalTaxesDue
        * 0.05

    self.taxPenalties =
        self.taxPenalties + penalty

    self.unpaidTaxes =
        self.unpaidTaxes
        + self.totalTaxesDue
        + penalty

end

--------------------------------------------------
-- Report
--------------------------------------------------

function FFR_TaxManager:printTaxReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR TAX REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Property Tax Due: $"
        .. math.floor(
            self.propertyTaxDue
        )
    )

    Logging.info(
        "Income Tax Due: $"
        .. math.floor(
            self.incomeTaxDue
        )
    )

    Logging.info(
        "Total Taxes Due: $"
        .. math.floor(
            self.totalTaxesDue
        )
    )

    Logging.info(
        "Tax Penalties: $"
        .. math.floor(
            self.taxPenalties
        )
    )

    Logging.info(
        "========================================"
    )

end