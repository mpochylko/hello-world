FFR_UnitManager = {}

--------------------------------------------------
-- Units of measure (v0.9.50)
--
-- Display only: FS25 keeps every amount in liters
-- and every price per 1,000 L; FFR shows them in the
-- player's chosen units on its own pages and in the
-- FS25 HUD (vehicle fill bars, the vehicle info box,
-- silo and barn food panels).
--
-- Three settings (Options > UNITS):
--   crop   grain, oilseeds, pulses: L / BU / T / TN
--   solid  everything else solid:   L / T / TN / LB
--   liquid                          L / GAL
--
-- A bushel is weight-based, as in the grain trade:
-- the crop's standard test weight (BUSHEL_LB) and the
-- map's own weight per liter (fillType.massPerLiter).
-- A product without a bushel standard uses the solid
-- setting even when "crop" is set to bushels.
--
-- Saved with the native save (FFR_economy.xml,
-- units). On a multiplayer client the choice lasts
-- for the session.
--------------------------------------------------

FFR_UnitManager.CROP_UNITS = {"L", "BU", "T", "TN"}
FFR_UnitManager.SOLID_UNITS = {"L", "T", "TN", "LB"}
FFR_UnitManager.LIQUID_UNITS = {"L", "GAL"}

FFR_UnitManager.settings = {crop = "L", solid = "L", liquid = "L"}

-- Standard bushel weights (lb), USDA / Canadian Grain Commission.
FFR_UnitManager.BUSHEL_LB = {
    WHEAT = 60, SOYBEAN = 60, MAIZE = 56, CORN = 56, SORGHUM = 56, RYE = 56,
    BARLEY = 48, TRITICALE = 48, BUCKWHEAT = 48, OAT = 32, SPELT = 40,
    CANOLA = 50, MUSTARD = 50, MILLET = 50, FLAX = 56, LINSEED = 56, SUNFLOWER = 25,
    RICE = 45, RICELONGGRAIN = 45, PEA = 60, PEAS = 60, LENTILS = 60, CHICKPEAS = 60,
    PINTOBEAN = 60, DRYBEAN = 60, FABABEAN = 60, CAMELINA = 50
}

-- FFR commodity categories that trade in bushels when a crop is not in the table.
FFR_UnitManager.BUSHEL_DEFAULT = {grain = 56, oilseed = 50, pulse = 60}

-- Liquids: exact names, then name parts.
FFR_UnitManager.LIQUIDS = {
    DIESEL = true, DEF = true, WATER = true, MILK = true, GOATMILK = true, BUFFALOMILK = true,
    LIQUIDMANURE = true, DIGESTATE = true, LIQUIDFERTILIZER = true, HERBICIDE = true,
    WINE = true, BEER = true, GRAPEJUICE = true, SUNFLOWER_OIL = true, CANOLA_OIL = true,
    OLIVE_OIL = true, NH3 = true, ANHYDROUS = true, SLURRY = true
}
FFR_UnitManager.LIQUID_PARTS = {"MILK", "_OIL", "JUICE", "LIQUID", "WATER", "SYRUP"}

-- Never converted: energy, gases, pieces.
FFR_UnitManager.SKIP = {ELECTRICCHARGE = true, METHANE = true, UNKNOWN = true}

FFR_UnitManager.LB_KG = 0.45359237
FFR_UnitManager.SHORT_TON_KG = 907.18474
FFR_UnitManager.GALLON_L = 3.785411784

--------------------------------------------------
-- Product facts
--------------------------------------------------

function FFR_UnitManager.getFillType(name)
    if g_fillTypeManager == nil or name == nil then return nil end
    local ok, fillType = pcall(g_fillTypeManager.getFillTypeByName, g_fillTypeManager, string.upper(tostring(name)))
    return ok and fillType or nil
end

-- kg per liter from the map's fill type (FS25 keeps t / L), else 0.75.
function FFR_UnitManager.getKgPerLiter(name)
    local fillType = FFR_UnitManager.getFillType(name)
    local mass = fillType ~= nil and tonumber(fillType.massPerLiter) or nil
    if mass == nil or mass <= 0 then return 0.75 end
    if mass < 0.05 then return mass * 1000 end
    return mass
end

function FFR_UnitManager.isLiquid(name)
    local upper = string.upper(tostring(name or ""))
    if FFR_UnitManager.LIQUIDS[upper] then return true end
    for _, part in ipairs(FFR_UnitManager.LIQUID_PARTS) do
        if string.find(upper, part, 1, true) then return true end
    end
    return false
end

-- Pounds per bushel, or nil when the product does not trade in bushels.
function FFR_UnitManager.getBushelLb(name)
    local upper = string.upper(tostring(name or ""))
    if FFR_UnitManager.BUSHEL_LB[upper] ~= nil then return FFR_UnitManager.BUSHEL_LB[upper] end
    local cm = g_FFR ~= nil and g_FFR.commodityManager or nil
    local commodity = cm ~= nil and cm.commodities ~= nil and cm.commodities[upper] or nil
    local category = commodity ~= nil and commodity.category or nil
    return category ~= nil and FFR_UnitManager.BUSHEL_DEFAULT[category] or nil
end

-- The unit code a product is shown in right now.
function FFR_UnitManager.getUnit(name)
    local upper = string.upper(tostring(name or ""))
    local s = FFR_UnitManager.settings
    if upper == "" or FFR_UnitManager.SKIP[upper] then return "L" end
    if FFR_UnitManager.isLiquid(upper) then return s.liquid end
    if FFR_UnitManager.getBushelLb(upper) ~= nil and s.crop ~= "L" then return s.crop end
    if FFR_UnitManager.getBushelLb(upper) ~= nil and s.crop == "L" then return "L" end
    return s.solid
end

-- Liters in one display unit of a product.
function FFR_UnitManager.getLitersPerUnit(name, unit)
    unit = unit or FFR_UnitManager.getUnit(name)
    if unit == "GAL" then return FFR_UnitManager.GALLON_L end
    local kg = FFR_UnitManager.getKgPerLiter(name)
    if unit == "BU" then return (FFR_UnitManager.getBushelLb(name) or 56) * FFR_UnitManager.LB_KG / kg end
    if unit == "T" then return 1000 / kg end
    if unit == "TN" then return FFR_UnitManager.SHORT_TON_KG / kg end
    if unit == "LB" then return FFR_UnitManager.LB_KG / kg end
    return 1
end

--------------------------------------------------
-- Formatting
--------------------------------------------------

function FFR_UnitManager.formatValue(value, decimals)
    local d = decimals or 0
    local scale = 10 ^ d
    local rounded = math.floor(math.abs(tonumber(value) or 0) * scale + 0.5) / scale
    local whole = math.floor(rounded)
    local s = FFR_L10n.formatNumber(whole)
    if d > 0 then s = s .. "." .. string.format("%0" .. d .. "d", math.floor((rounded - whole) * scale + 0.5)) end
    return ((tonumber(value) or 0) < 0 and "-" or "") .. s
end

-- Decimals by size, so small loads stay readable.
function FFR_UnitManager.getDecimals(unit, value)
    local v = math.abs(tonumber(value) or 0)
    if unit == "T" or unit == "TN" then return v < 100 and 2 or (v < 10000 and 1 or 0) end
    if unit == "BU" or unit == "GAL" then return v < 100 and 1 or 0 end
    return 0
end

-- Liters of a product as text in the chosen unit: "1,250 bu", "12.4 t", "8,000 L".
function FFR_UnitManager.formatAmount(liters, name)
    local unit = FFR_UnitManager.getUnit(name)
    local value = (tonumber(liters) or 0) / FFR_UnitManager.getLitersPerUnit(name, unit)
    return FFR_L10n.t("ffr_unit_amount_" .. string.lower(unit), FFR_UnitManager.formatValue(value, FFR_UnitManager.getDecimals(unit, value)))
end

-- A price per 1,000 L as a price per display unit (number).
function FFR_UnitManager.convertPrice(pricePer1000, name)
    local unit = FFR_UnitManager.getUnit(name)
    if unit == "L" then return tonumber(pricePer1000) or 0 end
    return (tonumber(pricePer1000) or 0) / 1000 * FFR_UnitManager.getLitersPerUnit(name, unit)
end

-- Money with cents for small unit prices ($5.12 / bu), whole dollars otherwise.
function FFR_UnitManager.formatUnitMoney(value)
    local number = tonumber(value) or 0
    if math.abs(number) >= 100 then return FFR_L10n.formatMoney(number) end
    if g_i18n ~= nil and g_i18n.formatMoney ~= nil then
        local ok, text = pcall(g_i18n.formatMoney, g_i18n, math.abs(number), 2, true, true)
        if ok and type(text) == "string" and text ~= "" then return (number < 0 and "-" or "") .. text end
    end
    return string.format("%s$%.2f", number < 0 and "-" or "", math.abs(number))
end

-- "$5.12 / bu", "$241 / t" or "$1,234 / 1,000 L".
function FFR_UnitManager.formatPrice(pricePer1000, name)
    local unit = FFR_UnitManager.getUnit(name)
    if unit == "L" then return FFR_L10n.t("ffr_unit_per_1000l", FFR_L10n.formatMoney(pricePer1000)) end
    return FFR_L10n.t("ffr_unit_per_" .. string.lower(unit), FFR_UnitManager.formatUnitMoney(FFR_UnitManager.convertPrice(pricePer1000, name)))
end

-- Chart axis labels: the converted number with money formatting, no unit.
function FFR_UnitManager.formatPriceValue(pricePer1000, name)
    local unit = FFR_UnitManager.getUnit(name)
    if unit == "L" then return FFR_L10n.formatMoney(pricePer1000) end
    return FFR_UnitManager.formatUnitMoney(FFR_UnitManager.convertPrice(pricePer1000, name))
end

function FFR_UnitManager.getUnitName(unit)
    return FFR_L10n.t("ffr_unit_name_" .. string.lower(tostring(unit or "L")))
end

--------------------------------------------------
-- Settings (Options > UNITS)
--------------------------------------------------

function FFR_UnitManager.getChoices(kind)
    if kind == "crop" then return FFR_UnitManager.CROP_UNITS end
    if kind == "solid" then return FFR_UnitManager.SOLID_UNITS end
    return FFR_UnitManager.LIQUID_UNITS
end

function FFR_UnitManager.step(kind, direction)
    local choices = FFR_UnitManager.getChoices(kind)
    local index = 1
    for i, code in ipairs(choices) do if code == FFR_UnitManager.settings[kind] then index = i end end
    index = index + (tonumber(direction) or 0)
    if index < 1 then index = #choices elseif index > #choices then index = 1 end
    FFR_UnitManager.settings[kind] = choices[index]
    Logging.info("FFR Units: %s shown in %s", kind, choices[index])
    if g_FFR ~= nil and g_FFR.saveManager ~= nil and g_FFR.saveManager.requestSave ~= nil then g_FFR.saveManager:requestSave(g_FFR) end
end

function FFR_UnitManager.isConverting()
    local s = FFR_UnitManager.settings
    return s.crop ~= "L" or s.solid ~= "L" or s.liquid ~= "L"
end

function FFR_UnitManager.isValid(kind, code)
    for _, c in ipairs(FFR_UnitManager.getChoices(kind)) do if c == code then return true end end
    return false
end

function FFR_UnitManager.saveToXML(xmlFile, key)
    for _, kind in ipairs({"crop", "solid", "liquid"}) do
        setXMLString(xmlFile, key .. "#" .. kind, FFR_UnitManager.settings[kind])
    end
end

function FFR_UnitManager.loadFromXML(xmlFile, key)
    for _, kind in ipairs({"crop", "solid", "liquid"}) do
        local code = getXMLString(xmlFile, key .. "#" .. kind)
        FFR_UnitManager.settings[kind] = FFR_UnitManager.isValid(kind, code) and code or "L"
    end
end

function FFR_UnitManager.getReport()
    local s = FFR_UnitManager.settings
    return string.format("%s / %s / %s", s.crop, s.solid, s.liquid)
end

--------------------------------------------------
-- FS25 HUD: rewrite the liter figure in texts the
-- game already built (layout and bars untouched).
-- Skipped while the Unit Converter mod is active,
-- so amounts are never converted twice.
--------------------------------------------------

function FFR_UnitManager.isOtherConverterLoaded()
    if g_modIsLoaded == nil then return false end
    for _, name in ipairs({"FS25_UnitConverter", "FS25_ImperialSystemConversionSettings", "FS25_LitersToTonnes"}) do
        if g_modIsLoaded[name] then return true end
    end
    return false
end

function FFR_UnitManager.isHudActive()
    return FFR_UnitManager.isConverting() and not FFR_UnitManager.isOtherConverterLoaded()
end

-- Fill type name from a translated title ("Wheat" -> WHEAT), built once per map.
function FFR_UnitManager.getNameByTitle(title)
    if type(title) ~= "string" then return nil end
    if FFR_UnitManager.titles == nil then
        FFR_UnitManager.titles = {}
        if g_fillTypeManager ~= nil then
            for _, fillType in pairs(g_fillTypeManager.fillTypes or {}) do
                if type(fillType.title) == "string" and fillType.name ~= nil then
                    FFR_UnitManager.titles[string.lower(fillType.title)] = fillType.name
                end
            end
        end
    end
    return FFR_UnitManager.titles[string.lower((title:gsub("%s*:%s*$", "")))]
end

function FFR_UnitManager.getNameByIndex(index)
    if g_fillTypeManager == nil or index == nil then return nil end
    local ok, fillType = pcall(g_fillTypeManager.getFillTypeByIndex, g_fillTypeManager, index)
    return ok and fillType ~= nil and fillType.name or nil
end

-- Replaces the first "<number> l" in a text with the product's chosen unit.
-- liters: the exact amount when the caller knows it (else the number in the text).
function FFR_UnitManager.swapLiters(text, name, liters)
    if type(text) ~= "string" or name == nil or FFR_UnitManager.getUnit(name) == "L" then return text end
    local swapped = string.gsub(text, "(%d[%d%.,' \194\160]*)%s*[lL]%f[%A]", function(number)
        local amount = tonumber(liters) or tonumber((string.gsub(number, "[^%d]", "")))
        if amount == nil then return nil end
        return FFR_UnitManager.formatAmount(amount, name)
    end, 1)
    return swapped
end

function FFR_UnitManager.installHudHooks()
    if FFR_UnitManager.hudInstalled then return end
    FFR_UnitManager.hudInstalled = true

    -- Vehicle fill bars (bottom right).
    if FillLevelsDisplay ~= nil and FillLevelsDisplay.updateFillLevelData ~= nil then
        FillLevelsDisplay.updateFillLevelData = Utils.appendedFunction(FillLevelsDisplay.updateFillLevelData, function(display)
            if not FFR_UnitManager.isHudActive() or type(display.fillLevelData) ~= "table" then return end
            for _, data in ipairs(display.fillLevelData) do
                if type(data) == "table" and type(data.fillLevelText) == "string" then
                    local ok, text = pcall(FFR_UnitManager.swapLiters, data.fillLevelText,
                        FFR_UnitManager.getNameByIndex(data.fillType), data.fillLevel)
                    if ok and text ~= nil then data.fillLevelText = text end
                end
            end
        end)
    end

    -- Vehicle info box: FillUnit.showInfo adds one line per fill unit (title, amount).
    -- The box is found among the arguments by its addLine method, whatever their order.
    if FillUnit ~= nil and FillUnit.showInfo ~= nil then
        FillUnit.showInfo = Utils.overwrittenFunction(FillUnit.showInfo, function(vehicle, superFunc, ...)
            local box = nil
            if FFR_UnitManager.isHudActive() then
                for i = 1, select("#", ...) do
                    local arg = select(i, ...)
                    if type(arg) == "table" and type(arg.addLine) == "function" then box = arg break end
                end
            end
            if box == nil then return superFunc(vehicle, ...) end
            local addLine = box.addLine
            box.addLine = function(b, keyText, valueText, ...)
                if type(valueText) == "string" then
                    local ok, text = pcall(FFR_UnitManager.swapLiters, valueText, FFR_UnitManager.getNameByTitle(keyText))
                    if ok and text ~= nil then valueText = text end
                end
                return addLine(b, keyText, valueText, ...)
            end
            local ok, result = pcall(superFunc, vehicle, ...)
            box.addLine = addLine
            if not ok then Logging.warning("FFR Units: vehicle info failed (%s)", tostring(result)) end
            return result
        end)
    end

    -- Silos and barn food: placeable info panels (title = product, text = amount).
    -- The info table is the first table argument.
    for _, className in ipairs({"PlaceableSilo", "PlaceableHusbandryFood"}) do
        local class = rawget(_G, className)
        if class ~= nil and class.updateInfo ~= nil then
            class.updateInfo = Utils.overwrittenFunction(class.updateInfo, function(placeable, superFunc, ...)
                local result = superFunc(placeable, ...)
                if FFR_UnitManager.isHudActive() then
                    for i = 1, select("#", ...) do
                        local infoTable = select(i, ...)
                        if type(infoTable) == "table" then
                            for _, entry in ipairs(infoTable) do
                                if type(entry) == "table" and type(entry.text) == "string" then
                                    local ok, text = pcall(FFR_UnitManager.swapLiters, entry.text, FFR_UnitManager.getNameByTitle(entry.title))
                                    if ok and text ~= nil then entry.text = text end
                                end
                            end
                            break
                        end
                    end
                end
                return result
            end)
        end
    end
end

--------------------------------------------------
-- Listener
--------------------------------------------------

-- Settings come from the save (FFR_SaveManager); a new game starts in liters.
function FFR_UnitManager:loadMap(mapName)
    FFR_UnitManager.titles = nil
    if FFR_UnitManager.isOtherConverterLoaded() then
        Logging.info("FFR Units: another unit converter mod is active; FFR converts only its own pages")
    end
end
function FFR_UnitManager:deleteMap()
    FFR_UnitManager.titles = nil
    FFR_UnitManager.settings = {crop = "L", solid = "L", liquid = "L"}
end
function FFR_UnitManager:update(dt) end
function FFR_UnitManager:draw() end
function FFR_UnitManager:mouseEvent(posX, posY, isDown, isUp, button) end
function FFR_UnitManager:keyEvent(unicode, sym, modifier, isDown) end

FFR_UnitManager.installHudHooks()
addModEventListener(FFR_UnitManager)
Logging.info("FFR Units: Units of measure installed (FFR pages and FS25 fill displays)")
