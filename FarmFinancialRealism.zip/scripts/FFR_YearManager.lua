FFR_YearManager = {}

function FFR_YearManager:new()

    local self = {}

    setmetatable(
        self,
        {__index = FFR_YearManager}
    )

    --------------------------------------------------
    -- Calendar
    --------------------------------------------------

    self.currentYear = 1

    self.currentMonth = 1

    self.currentQuarter = 1

    --------------------------------------------------
    -- Statistics
    --------------------------------------------------

    self.totalYearsCompleted = 0

    self.totalMonthsProcessed = 0

    --------------------------------------------------
    -- Farm History
    --------------------------------------------------

    self.yearlyProfit = {}

    self.yearlyNetWorth = {}

    self.yearlyRevenue = {}

    self.yearlyExpenses = {}

    --------------------------------------------------
    -- Market Cycle
    --------------------------------------------------

    self.marketCycle = "NORMAL"

    return self

end

--------------------------------------------------
-- Quarter Calculation
--------------------------------------------------

function FFR_YearManager:updateQuarter()

    self.currentQuarter =

        math.ceil(
            self.currentMonth / 3
        )

end

--------------------------------------------------
-- Monthly Processing
--------------------------------------------------

function FFR_YearManager:processMonth(

    financialManager,
    bankingManager,
    creditManager,
    insuranceManager,
    familyManager

)

    --------------------------------------------------
    -- Banking
    --------------------------------------------------

    if bankingManager ~= nil then

        bankingManager:processMonth(

            financialManager,
            creditManager

        )

    end

    --------------------------------------------------
    -- Insurance
    --------------------------------------------------

    if insuranceManager ~= nil then

        insuranceManager:processMonth(
            financialManager
        )

    end

    --------------------------------------------------
    -- Family
    --------------------------------------------------

    if familyManager ~= nil then

        familyManager:processMonth(
            financialManager
        )

    end

    --------------------------------------------------

    self.currentMonth =
        self.currentMonth + 1

    self.totalMonthsProcessed =
        self.totalMonthsProcessed + 1

    self:updateQuarter()

    Logging.info(

        "FFR Month Complete: "

        .. tostring(
            self.currentMonth - 1
        )

    )

    --------------------------------------------------
    -- Quarter End
    --------------------------------------------------

    if self.currentMonth > 12 then

        self:endYear(
            financialManager,
            creditManager
        )

    end

end

--------------------------------------------------
-- Annual Market Conditions
--------------------------------------------------

function FFR_YearManager:generateMarketCycle()

    local roll =

        math.random(
            1,
            100
        )

    if roll <= 15 then

        self.marketCycle =
            "BOOM"

    elseif roll <= 35 then

        self.marketCycle =
            "BULL"

    elseif roll <= 65 then

        self.marketCycle =
            "NORMAL"

    elseif roll <= 85 then

        self.marketCycle =
            "BEAR"

    else

        self.marketCycle =
            "RECESSION"

    end

    Logging.info(

        "FFR Economic Cycle: "

        .. self.marketCycle

    )

end

--------------------------------------------------
-- Year End
--------------------------------------------------

function FFR_YearManager:endYear(

    financialManager,
    creditManager

)

    financialManager:update()

    local yearProfit =

        financialManager.cashOnHand

    table.insert(
        self.yearlyProfit,
        yearProfit
    )

    table.insert(
        self.yearlyNetWorth,
        financialManager.netWorth
    )

    --------------------------------------------------
    -- Credit Improvement
    --------------------------------------------------

    if yearProfit > 0 then

        if creditManager ~= nil then

            creditManager:addSuccessfulYear()

        end

    end

    --------------------------------------------------

    self.totalYearsCompleted =

        self.totalYearsCompleted + 1

    Logging.info(

        "FFR Year Complete: "

        .. tostring(
            self.currentYear
        )

    )

    Logging.info(

        "Year End Net Worth: $"

        .. tostring(
            math.floor(
                financialManager.netWorth
            )
        )

    )

    --------------------------------------------------
    -- Advance Year
    --------------------------------------------------

    self.currentYear =
        self.currentYear + 1

    self.currentMonth = 1

    self.currentQuarter = 1

    self:generateMarketCycle()

end

--------------------------------------------------
-- Farm Age
--------------------------------------------------

function FFR_YearManager:getFarmAge()

    return self.currentYear

end

--------------------------------------------------
-- History Access
--------------------------------------------------

function FFR_YearManager:getLastNetWorth()

    local count =
        #self.yearlyNetWorth

    if count <= 0 then
        return 0
    end

    return self.yearlyNetWorth[count]

end

--------------------------------------------------
-- Annual Report
--------------------------------------------------

function FFR_YearManager:printAnnualReport()

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR YEAR REPORT"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Current Year: "
        .. tostring(
            self.currentYear
        )
    )

    Logging.info(
        "Current Month: "
        .. tostring(
            self.currentMonth
        )
    )

    Logging.info(
        "Economic Cycle: "
        .. self.marketCycle
    )

    Logging.info(
        "Years Completed: "
        .. tostring(
            self.totalYearsCompleted
        )
    )

    Logging.info(
        "Months Processed: "
        .. tostring(
            self.totalMonthsProcessed
        )
    )

    Logging.info(
        "========================================"
    )

end

--------------------------------------------------
-- Executive Review
--------------------------------------------------

function FFR_YearManager:printExecutiveSummary(

    financialManager,
    creditManager

)

    Logging.info(
        "========================================"
    )

    Logging.info(
        "FFR EXECUTIVE SUMMARY"
    )

    Logging.info(
        "========================================"
    )

    Logging.info(
        "Farm Age: "
        .. tostring(
            self.currentYear
        )
        .. " Years"
    )

    Logging.info(
        "Economic Cycle: "
        .. self.marketCycle
    )

    Logging.info(
        "Credit Rating: "
        .. creditManager.creditRating
    )

    Logging.info(
        "Net Worth: $"
        .. tostring(
            math.floor(
                financialManager.netWorth
            )
        )
    )

    Logging.info(
        "Cash On Hand: $"
        .. tostring(
            math.floor(
                financialManager.cashOnHand
            )
        )
    )

    Logging.info(
        "========================================"
    )

end